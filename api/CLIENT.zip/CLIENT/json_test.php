<?php

function addSubscriber($email, $apiKey) {
    $url = 'https://api.madmimi.com/audience_members';
    $data = array('email' => $email);

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_USERPWD, "api:$apiKey");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the request
    $response = curl_exec($ch);
    
    // Check for cURL errors
    if(curl_errno($ch)) {
        $error = curl_error($ch);
        echo "cURL Error: $error\n";
    } else {
        // Get HTTP response code
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        // Close cURL session
        curl_close($ch);

        // Check response status
        if ($httpCode == 200) {
            echo "Subscriber added successfully\n";
        } else {
            echo "Error: HTTP response code $httpCode\n";
            echo "Response: $response\n";
        }
    }
}

$apiKey = '94fe5291617cfa8237e51030c0655a9c';
$email = 'crm@deboxglobal.com';

addSubscriber($email, $apiKey);

?>
