<?php
include "inc.php";  
if($_REQUEST['add']=='yes'){
	
	$quotationId= $_REQUEST['quotationId']; 
	$rs1=GetPageRecord(' * ',_QUOTATION_MASTER_,'id="'.$quotationId.'"'); 
	$quotationData = mysqli_fetch_array($rs1); 
	$queryId = $quotationData['queryId'];
	$calculationType = $quotationData['calculationType'];

	// Service added in this day
	$dayIdQuery='';
	$dayIdQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'" ');  
	$dayIdData=mysqli_fetch_array($dayIdQuery);

	$dayId = $dayIdData['id'];
	$srdate = $dayIdData['srdate'];
	
	$totalDays = $_REQUEST['totalDays'];
	$destinationId = $_REQUEST['destinationId'];
	$slabId = $_REQUEST['slabId'];
	$dmcId = $_REQUEST['dmcId'];
	$tableN = $_REQUEST['tableN'];
	$serviceId = $_REQUEST['serviceId'];
	$noOfVehicles = $_REQUEST['noOfVehicles'];
	
	if($calculationType!=3){
		if($dmcId!='' && $tableN==2){
			$select1 = '*';  
			$where1= 'id="'.$dmcId.'"'; 
			$rs1 = GetPageRecord($select1,'quotationActivityRateMaster',$where1); 
			$dmcRateD = mysqli_fetch_array($rs1); 
		}else{
			$select1 = '*';  
			$where1= 'id="'.$dmcId.'"'; 
			$rs1 = GetPageRecord($select1,'dmcotherActivityRate',$where1); 
			$dmcRateD = mysqli_fetch_array($rs1); 
		}

		$dmcId = $dmcRateD['id'];
		$currencyId = $dmcRateD['currencyId'];
		$currencyValue = ($dmcRateD['currencyValue']>0)?$dmcRateD['currencyValue']:getCurrencyVal($currencyId);
		// $currencyValue = $dmcRateD['currencyValue'];

		$gstValue=getGstValueById($dmcRateD['gstTax']); 
			$transferType=addslashes($dmcRateD['transferType']);
			$ticketAdultCostMC =  getMarkupCost($dmcRateD['ticketAdultCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);
			$ticketchildCostMC =  getMarkupCost($dmcRateD['ticketchildCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);
			$ticketinfantCostMC =  getMarkupCost($dmcRateD['ticketinfantCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);

			$ticketAdultCost = getCostWithGST(($dmcRateD['ticketAdultCost']+$ticketAdultCostMC),getGstValueById($dmcRateD['gstTax']),0);
			$ticketchildCost = getCostWithGST(($dmcRateD['ticketchildCost']+$ticketchildCostMC),getGstValueById($dmcRateD['gstTax']),0);
			$ticketinfantCost = getCostWithGST(($dmcRateD['ticketinfantCost']+$ticketinfantCostMC),getGstValueById($dmcRateD['gstTax']),0);
			

			$adultCost=$childCost=$infantCost=$vehicleId=$vehicleCost=0;
			if($transferType==1){
				$adultCostMC =  getMarkupCost($dmcRateD['adultCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);
				$childCostMC =  getMarkupCost($dmcRateD['childCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);
				$infantCostMC =  getMarkupCost($dmcRateD['infantCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);

				$adultCost = getCostWithGST(($dmcRateD['adultCost']+$adultCostMC),getGstValueById($dmcRateD['gstTax']),0);
				$childCost = getCostWithGST(($dmcRateD['childCost']+$childCostMC),getGstValueById($dmcRateD['gstTax']),0);
				$infantCost = getCostWithGST(($dmcRateD['infantCost']+$infantCostMC),getGstValueById($dmcRateD['gstTax']),0);
			}elseif($transferType==2 || $transferType==3){
				$vehicleCostMC =  getMarkupCost($dmcRateD['vehicleCost'],$dmcRateD['markupCost'],$dmcRateD['markupType']);
				$vehicleId=addslashes($dmcRateD['vehicleId']);   
				$vehicleCost = getCostWithGST(($dmcRateD['vehicleCost']+$vehicleCostMC),getGstValueById($dmcRateD['gstTax']),0);
			}
			if($transferType!=4){
			$repCost = getCostWithGST($dmcRateD['repCost'],getGstValueById($dmcRateD['gstTax']),0);
			}
		$supplierId = $dmcRateD['supplierId'];

	}else{
		// complete package costing
		$checkPackageRateQuery="";
		$checkPackageRateQuery=GetPageRecord('*','packageWiseRateMaster',' quotationId="'.$quotationId.'"');
		if(mysqli_num_rows($checkPackageRateQuery) > 0){
 			$getPackageRateData=mysqli_fetch_array($checkPackageRateQuery);	

		    $currencyId = $getPackageRateData['currencyId'];
		    // $currencyValue = getCurrencyVal($currencyId);
		    $currencyValue = $getPackageRateData['currencyValue'];
		    $supplierId = $getPackageRateData['supplierId'];
		}

		$dmcId  = 0;
		$price  = 0;
		$paxRange  = 0;
	}
	
	 $namevalue ='fromDate="'.$srdate.'",toDate="'.$srdate.'",slabId="'.$slabId.'",transferType="'.$transferType.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",infantCost="'.$infantCost.'",vehicleId="'.$vehicleId.'",vehicleCost="'.$vehicleCost.'",repCost="'.$repCost.'",ticketAdultCost="'.$ticketAdultCost.'",ticketchildCost="'.$ticketchildCost.'",ticketinfantCost="'.$ticketinfantCost.'",currencyId="'.$currencyId.'",currencyValue="'.$currencyValue.'",otherActivityName="'.$serviceId.'",otherActivityCity="'.$destinationId.'",dateotherActivity="'.$srdate.'",supplierId="'.$supplierId.'",tariffId="'.$dmcId.'",queryId="'.$queryId.'",quotationId="'.$quotationId.'",dayId="'.$dayId.'",remark="'.$remarks.'",noOfVehicles="'.$noOfVehicles.'"';
	$lastid = addlistinggetlastid(_QUOTATION_OTHER_ACTIVITY_MASTER_,$namevalue); 

	$namevalue1 ='serviceId="'.$lastid.'",serviceType="activity",dayId="'.$dayId.'",startDate="'.$srdate.'",endDate="'.$srdate.'",queryId="'.$queryId.'",quotationId="'.$quotationId.'",startTime="'.date('Y-m-d H:i:s').'",endTime="'.date('Y-m-d H:i:s').'",srn="'.$dayId.'"'; 
	addlisting('quotationItinerary',$namevalue1); 
	?> 
	<script type="text/javascript"> 
	closeinbound();
	selectthisE(<?php echo $dmcId; ?>,<?php echo $tableN; ?>)
	loadquotationmainfile(); 
	</script>
	
<?php 
} 
?>