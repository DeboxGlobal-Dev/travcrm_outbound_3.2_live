<?php
include "inc.php";    

if($_REQUEST['action']=='addeditactivityprice' && $_REQUEST['rateid']!=''){

	$dayQuery=GetPageRecord('*','newQuotationDays','id ="'.$_REQUEST['dayId'].'"'); 
	$newQuotationData=mysqli_fetch_array($dayQuery); 
	$quotationId = $newQuotationData['quotationId'];

	if($_REQUEST['rateid'] > 0 && $_REQUEST['tableN'] == 2){
		$rsat=GetPageRecord('*','quotationActivityRateMaster','id="'.$_REQUEST['rateid'].'"'); 
		$dmcActivityData=mysqli_fetch_array($rsat);
		$serviceId = $dmcActivityData['serviceId'];
		$activitySupplierId = $dmcActivityData['supplierId'];
		$transferType = $dmcActivityData['transferType'];

	}elseif($_REQUEST['rateid'] > 0 && $_REQUEST['tableN'] == 1){
		$rsat=GetPageRecord('*','dmcotherActivityRate','id="'.$_REQUEST['rateid'].'"'); 
		$dmcActivityData=mysqli_fetch_array($rsat);
		$serviceId = $dmcActivityData['serviceid'];
		$activitySupplierId = $dmcActivityData['supplierId'];
		$transferType = $dmcActivityData['transferType'];
	}elseif($_REQUEST['rateid'] > 0 && $_REQUEST['tableN'] == 3){ 
		$serviceId = $_REQUEST['rateid']; 
		$transferType = $_REQUEST['transferType'];
	}

	$rsq=GetPageRecord('*','queryMaster','id="'.$newQuotationData['queryId'].'"'); 
	$resquery=mysqli_fetch_array($rsq);

	$rs2=GetPageRecord('otherActivityName,id',_PACKAGE_BUILDER_OTHER_ACTIVITY_MASTER_,'id="'.$serviceId.'"'); 
	$activityData=mysqli_fetch_array($rs2); 
	?>  
	<style>
		.topaboxouter{margin: 30px;
		    margin-top: 160px;}
		.topabox{
		    margin-bottom: 20px;
		    padding-bottom: 10px;
		    border-bottom: 0px #e8e8e8 solid;
		    font-size: 18px;}
			
		.topaboxlist {
		    border: 1px #e8e8e8 solid;
		    padding: 10px;
		    margin-bottom: 30px;
		    box-sizing: border-box;
		    background: #fbfbfb;
		}

		.gridtable td { 
		    border-bottom: #f1f1f1 0px solid !important;     padding-bottom: 10px !important;
		}
		.labletext {
		    font-size: 11px;
		    color: #909090;
		    margin-bottom: 5px;
		    text-transform: uppercase;
		}
		.addeditpagebox .griddiv .gridlable {
		    color: #8a8a8a;
		    width: 100%;
		    display: inline-block;
		    padding-bottom: 0px;
		    font-size: 11px;text-transform: uppercase;
		}
	    .addeditpagebox .griddiv{
	        margin-bottom: 0px !important;
	    }

		.addTriffRoom .addeditpagebox .griddiv { 
		    border-bottom: 0px #eee solid !important;
		    overflow: hidden !important;
		    position: relative !important; 
		}

		.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
	    width: 100% !important;
	}

		.addtopaboxlist {
		        border: 2px rgba(186, 228, 193, 0.75) solid;
		    padding: 10px;
		    margin-bottom: 30px;
		    box-sizing: border-box;
		    background: #f2fff7;
		}

		.addGreenHeader{    background: rgba(186, 228, 193, 0.75);
		    padding: 10px;
		    font-size: 15px;
		    font-weight: bold;
		    padding-left: 23px;}
			
		.addtopaboxlist .gridtable td {
		    padding: 12px 4px;
		    border-bottom: #f1f1f1 0px solid !important;
		    position: relative;
		}
		.roompricelistmain {
		    padding: 0px;
		    border: 1px #eeeeee solid;
		    background-color: #fff;
		    margin-top: 20px;
		}
		.roompricelistmain .headermainprice {
		    padding: 10px;
		    border-bottom: solid 1px #CCCCCC;
		    font-size: 13px;
		    font-weight: bold;
		}
		input[name='addnewuserbtn']{
			display:none;
		}

	</style>
	<div class="topaboxlist"  style="background-color: #ffffff; border-radius: 3px; padding: 3px; box-shadow: 0px 10px 35px;"> 
	<table width="100%" border="0" cellspacing="0" cellpadding="8">
	  <tr>

	    <td width="100%" align="left"><strong style="font-size: 18px;"><?php echo clean($activityData['otherActivityName']); ?> </strong></td>
	    <td width="12%" align="right" valign="top"><i class="fa fa-times" style="cursor:pointer; font-size: 20px; color: #c51d1d;" onclick="parent.$('#loadprice').hide();"></i></td>
	  </tr> 
	</table>

	<div class="addeditpagebox addtopaboxlist">	
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addrate" target="actoinfrm"  id="addrate"> 
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" > 
	  		<tbody> 
		  	<tr >
					<td width="15%"  align="left">
						<div class="griddiv"><label>
							<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
							<select id="activitySupplierId" name="activitySupplierId" class="gridfield validate" displayname="Suppliers" autocomplete="off"  >  
								<?php 
								$where='status = 1 and deletestatus=0 and name!="" and  ( activityType=3 or activityType=1 ) order by name asc';  
								$rs=GetPageRecord('id,name',_SUPPLIERS_MASTER_,$where);   
								while($editSupplierData=mysqli_fetch_array($rs)){   ?> 
									<option value="<?php echo strip($editSupplierData['id']); ?>"  <?php if($editSupplierData['id']==$activitySupplierId){ ?>selected="selected"<?php } ?>><?php echo strip($editSupplierData['name']); ?></option> 
								<?php  } ?>
							</select>

							</label>
						</div>
					</td>    
				<td width="10%" align="left"><div class="griddiv">
					<label>
					<div class="gridlable">Tarif Type<span class="redmind"></span></div>
					<select id="tarifType2" name="tarifType2" class="gridfield" displayname="Tarif Type" autocomplete="off">
						<option value="1">Normal</option>
						<option value="2">Weekend</option>
					</select>
					</label>
					</div>
				</td>

			<td width="10%">
			<div class="griddiv"><label>

			<div class="gridlable">Transfer&nbsp;Type</div>

			<select id="ActransferType3" name="ActransferType3" class="gridfield " autocomplete="off" onchange="selectQuotActTPType();">
				
				<option value="1" <?php if ($transferType == '1') { ?> selected="selected" <?php } ?>>SIC</option>
				
				<option value="2" <?php if ($transferType == '2') { ?> selected="selected" <?php } ?>>PVT</option>
				
				<option value="3" <?php if ($transferType == '3') { ?> selected="selected" <?php } ?>>VIP</option>
				<option value="4" <?php if ($transferType == '4') { ?> selected="selected" <?php } ?>>Ticket Only</option>
				
			</select>

			</label>

		</div>
	</td>
				<td width="10%" align="left">
					<div class="griddiv">
						<label>  
						<div class="gridlable">Currency<span class="redmind"></span></div>
						<select id="currencyId" name="currencyId" class="gridfield validate" displayname="Currency" autocomplete="off"  onchange="getROE(this.value,'currencyVal125');"    >
						 <option value="">Select</option>
							<?php 
							$currencyId = ($dmcActivityData['currencyId']>0)?$dmcActivityData['currencyId']:$baseCurrencyId;
							$currencyValue = ($dmcActivityData['currencyValue']>0)?$dmcActivityData['currencyValue']:getCurrencyVal($currencyId);
							$select=''; 
							$where=''; 
							$rs='';  
							$select='*';    
							$where=' deletestatus=0 and status=1 order by name asc';  
							$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where); 
							while($resListing=mysqli_fetch_array($rs)){   
							?>
							<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$currencyId){ ?>selected="selected"<?php } ?> ><?php echo strip($resListing['name']); ?></option>
							<?php } ?>
							</select>
						</label>
					</div>			
				</td> 
				<td width="10%"  align="left"><div class="griddiv" >
				<label> 
				<div class="gridlable">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
				<input class="gridfield validate" name="currencyValue"  displayname="ROE Value" id="currencyVal125" value="<?php echo trim($currencyValue); ?>" style="display:inline-block;" >
				</label>
				</div>
				</td>

				<td width="10%" align="left"><div class="griddiv"><label>
					<div class="gridlable">Adult Ticket</div>
					<input name="ActticketAdultCost2" type="text" class="gridfield"  id="ActticketAdultCost2" value="<?php echo $dmcActivityData['ticketAdultCost'] ?>" maxlength="6" onkeyup="numericFilter(this);" />
					</label>
					</div>
				</td>

				<td width="10%" align="left"><div class="griddiv"><label>
					<div class="gridlable">Child Ticket</div>
					<input name="ActticketchildCost2" type="text" class="gridfield"  id="ActticketchildCost2" value="<?php echo $dmcActivityData['ticketchildCost'] ?>" maxlength="6" onkeyup="numericFilter(this);" />
					</label>
					</div>
				</td>

				<td width="10%" align="left"><div class="griddiv"><label>
					<div class="gridlable">Infant Ticket</div>
					<input name="ActticketinfantCost2" type="text" class="gridfield"  id="ActticketinfantCost2" value="<?php echo $dmcActivityData['ticketinfantCost'] ?>" maxlength="6" onkeyup="numericFilter(this);" />
					</label>
					</div>
				</td>
			</tr> 
			<tr>

			<td width="10%" class="SIC" style="display:table-cell;" align="left"><div class="griddiv"><label>
					<div class="gridlable">Adult Transfer</div>
					<input name="ActadultCost2" type="text" class="gridfield"  id="ActadultCost2" value="<?php echo $dmcActivityData['adultCost'] ?>" maxlength="6" onkeyup="numericFilter(this);" />
					</label>
					</div>
				</td>

				<td width="10%" class="SIC" style="display:table-cell;" align="left"><div class="griddiv"><label>
					<div class="gridlable">Child Transfer</div>
					<input name="ActchildCost2" type="text" class="gridfield"  id="ActchildCost2" value="<?php echo $dmcActivityData['childCost'] ?>" maxlength="6" onkeyup="numericFilter(this);" />
					</label>
					</div>
				</td>

				<td width="10%" class="SIC" style="display:table-cell;" align="left"><div class="griddiv"><label>
					<div class="gridlable">Infant Transfer</div>
					<input name="ActinfantCost2" type="text" class="gridfield"  id="ActinfantCost2" value="<?php echo $dmcActivityData['infantCost'] ?>" maxlength="6" onkeyup="numericFilter(this);" />
					</label>
					</div>
				</td>

				<td width="10%" class="PVT" style="display:none;">
					<div class="griddiv">
						<label>
						<div class="gridlable">Vehicle&nbsp;Type</div>
						<select id="ActvehicleId2" name="ActvehicleId2" class="gridfield" displayname="Vehicle Name" autocomplete="off">
							<?php 
							$rs2="";
							$rs2=GetPageRecord('*','vehicleTypeMaster',' 1 and deletestatus=0 and status=1 order by name asc '); 
							while($vehicleData=mysqli_fetch_array($rs2)){ ?>
								<option value="<?php echo $vehicleData['id']; ?>" <?php if($vehicleData['id']==$dmcActivityData['vehicleId']){ echo "selected"; } ?> ><?php echo ucfirst($vehicleData['name']); ?></option>
							<?php } ?>
						</select>
						</label>
					</div>
				</td>

				<td width="10%" class="PVT" style="display:none;">
					<div class="griddiv">
						<label>
							<div class="gridlable">Vehicle Cost</div>
							<input name="ActvehicleCost2" type="text" class="gridfield" id="ActvehicleCost2" value="<?php echo $dmcActivityData['vehicleCost'] ?>" style="width: 99%;">
						</label>
					</div>
				</td>
				<td width="10%" class="ticketOnly" >
					<div class="griddiv">
						<label>
							<div class="gridlable">REP. COST</div>
							<input name="ActrepCost2" type="text" class="gridfield" id="ActrepCost2" value="<?php echo $dmcActivityData['repCost'] ?>" style="width: 99%;">
						</label>
					</div>
				</td>

				<td width="10%" class="ticketOnlyshow111" >
					<div class="griddiv">
						<label>
							<div class="gridlable">Markup&nbsp;Type</div>
							
							<select name="markupType2" type="text" class="gridfield" id="markupType2" style="width: 99%;">
								<option value="1">%</option>
								<option value="2">Flat</option>
							</select>
						</label>
					</div>
				</td>
				<td width="10%" class="ticketOnlyshow111" >
					<div class="griddiv">
						<label>
							<div class="gridlable">Markup&nbsp;Cost</div>
							<input name="markupCost2" type="text" class="gridfield" id="markupCost2" value="<?php echo $dmcActivityData['markupCost'] ?>" style="width: 99%;">
						</label>
					</div>
				</td>

				<td width="100" align="left"><div class="griddiv"><label>
					<div class="gridlable">GST&nbsp;SLAB(%)</div>
					<select id="gstTax" name="gstTax" class="gridfield" displayname="Restaurant GST" autocomplete="off" style="width: 100%;">
		      <?php
		      $rs2 = "";
		       $rs2 = GetPageRecord('*', 'gstMaster', ' 1 and status=1 and serviceType="Activity"');
		      while ($gstSlabData = mysqli_fetch_array($rs2)) { ?>
		      <option value="<?php echo $gstSlabData['id']; ?>" <?php if($dmcActivityData['gstTax']==$gstSlabData['id']){ ?> selected="selected" <?php } ?> ><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
		       <?php
		      }
		       ?>
		      </select>
					</label>
					</div>
				</td> 
				<td width="100" align="left" valign="middle"  ><input type="button" name="Submit" value="   Save   " class="bluembutton"  onclick="formValidation('addrate','saveflight','0');"> 
				  <input name="action" type="hidden" id="action" value="addQuotationActivityPrice">
				  <input name="serviceId" type="hidden" id="serviceId" value="<?php echo $serviceId; ?>">
				  <input name="quotationId" type="hidden" id="quotationId" value="<?php echo $quotationId ; ?>">
				  <input name="dayId" type="hidden" id="dayId" value="<?php echo $_REQUEST['dayId'] ; ?>">
				  <input name="rateid" type="hidden" id="rateid" value="<?php echo $_REQUEST['rateid'] ; ?>">
				  <input name="tableN" type="hidden" id="tableN" value="<?php echo $_REQUEST['tableN'] ; ?>">
	       </td>
				</tr> 
			</tbody>
		</table>
	</form>
	</div>
	</div>

	<script type="text/javascript">
		function selectQuotActTPType(){
			var ActransferType = $("#ActransferType3").val();
			if(ActransferType == 1){
				$('.SIC').css('display','table-cell');
				$('.ticketOnly').css('display','table-cell');
				$('.PVT').css('display','none');
				$('.ticketOnlyshow').css('display','none');
			}else if(ActransferType == 2 || ActransferType == 3){
				$('.PVT').css('display','table-cell');
				$('.ticketOnly').css('display','table-cell');
				$('.SIC').css('display','none');
				$('.ticketOnlyshow').css('display','none');
			}else{
				$('.PVT').css('display','none');
				$('.ticketOnly').css('display','none');
				$('.SIC').css('display','none');
				$('.ticketOnlyshow').css('display','table-cell');
			}
		}

		selectQuotActTPType();
	</script>


	<?php 
} ?>