<?php
include "inc.php";
include "config/logincheck.php";
?>
<style>
	.saveeditor{
	cursor: pointer;padding:5px 10px;width:50px;margin-right: 10px;text-align: center;background: #233a49;color: white;border-radius: 21px;}
	.gridLan{ padding: 10px 20px;}
	.gridcheck{
	cursor: pointer;padding: 10px;background: #2c526b;margin: 10px;color: white;border-radius: 6px;}
	.closeeditor{
	cursor: pointer;width:60px;padding:5px 10px;background: white;text-align: center;color:black;border:1px solid black;border-radius: 21px;}
	#alertswhitebox h1{text-align: left;
	  background-color: #233a49;
	  color: #fff;
	  margin-bottom: 12px !important;
	  border-radius: 3px;
	  text-transform: uppercase;
	  font-weight: 600 !important;
	  text-shadow: 1px 1px 1px #000;
	  letter-spacing: 1px;    font-size: 13px !important;
	  font-weight: 500;
	  padding:8px 10px !important;
	}
 
	#alertswhitebox .bluembutton {     
		margin-left: 0px;
    background-color: #233a49 !important;border-radius:4px;
	}
	#alertswhitebox .whitembutton {
	    background-color: #cccccc5c !important;border-radius:4px;
	}
	#alertswhitebox textarea{-moz-box-shadow: inset 0 0 10px #000000;
	    -webkit-box-shadow: inset 0 0 10px #000000;
	    box-shadow: inset 0 0 5px #0000003d;
	    border: 1px solid #ccc; outline:0px;}
	#alertswhitebox input{-moz-box-shadow: inset 0 0 10px #000000;
	    -webkit-box-shadow: inset 0 0 10px #000000;
	    box-shadow: inset 0 0 5px #0000003d;
	    border: 1px solid #ccc; outline:0px;}
		#alertswhitebox select{-moz-box-shadow: inset 0 0 10px #000000;
	    -webkit-box-shadow: inset 0 0 10px #000000;
	    box-shadow: inset 0 0 5px #0000003d;
	    border: 1px solid #ccc; outline:0px;}
		#alertnotificationsmainbox .contentclass {
	    padding: 12px;
	    text-align: center;
	    border: 3px solid #d6d6d6d1;
	}
	#alertnotificationsmainbox  .select2-container .select2-search--inline {
	    width: 100% !important;
	}
	#alertnotificationsmainbox .select2-search__field {
	    width: 100% !important;    margin: 0px !important; padding: 4px !important;
	}
	#alertnotificationsmainbox  .select2-container--default .select2-selection--multiple .select2-selection__rendered {
	    box-sizing: border-box;
	    list-style: none;
	    margin: 0;
	    padding: 0 5px;
	    width: 100%;
	    margin: 0px !important;
	    padding: 0px;
	}
	#alertnotificationsmainbox input:not(.selectize-input input) {
	    -moz-box-shadow: inset 0 0 10px #ffffff3d !important;
	    -webkit-box-shadow: inset 0 0 10px #ffffff3d !important;
	    box-shadow: inset 0 0 5px #ffffff3d !important;
	    border: 1px solid #ccc !important;
	}
</style>
<?php 

if($_GET['action']=='userdeactivate'){ 
	
	?>
	<link href="css/main.css" rel="stylesheet" type="text/css" />
	<div class="delbg"><img src="images/user-remove-64.png" /></div>
	<div class="contentclass">
	<h1>User Deactivation</h1>
	<div id="contentbox">The user(s) you have selected will no longer be able to CRM. However, if you reactivate them at a later date, they will be able to view all of their existing data.</div>
	<div id="buttonsbox">
		<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Deactivate Now" onClick="$('#listform').attr('method','post');$('#listform').attr('target','actoinfrm');$('#listform').attr('action','frm_action.crm');submitfieldfrm('listform');"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
	</div>
</div>
<?php } ?>
	<?php if($_GET['action']=='useractivate'){ ?>
	<div class="addbg"><img src="images/activeusertopicon.png" /></div>
	<div class="contentclass">
<h1>User Activation</h1>
 <div id="contentbox">Are you sure you want to activate the user(s)?</div>
 <div id="buttonsbox">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="greenmbutton2" id="addnewuserbtn" value="Activate Now" onClick="$('#listform').attr('method','post');$('#listform').attr('target','actoinfrm');$('#listform').attr('action','frm_action.crm');submitfieldfrm('listform');"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
	</div>
	<?php } ?>
	<?php if($_GET['action']=='deleteprofile'){ ?>
	<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Are you sure you want to delete this profile?</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete" onClick="deleteprofile();"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<script>
	function deleteprofile(){
		var dltid=$('#dids').val();
		$('#actiondiv').load('frm_action.crm?action=deleteprofile&did='+dltid);
	}
	</script>
	<?php } ?>
		<?php if($_GET['action']=='deleteemailtemplate'){ ?>
		<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Are you sure you want to delete this email template?</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete" onClick="deleteemailtemplate();"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
	<script>
	function deleteemailtemplate(){
	var dltid=$('#dids').val();
	$('#actiondiv').load('frm_action.crm?action=deleteemailtemplate&did='+dltid);
	}
	</script>
	<?php } ?>
		<?php if($_GET['action']=='deletesmstemplate'){ ?>
		<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Are you sure you want to delete this sms template?</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete" onClick="deletesmstemplate();"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<script>
	function deletesmstemplate(){
	var dltid=$('#dids').val();
	$('#actiondiv').load('frm_action.crm?action=deletesmstemplate&did='+dltid);
	}
	</script>
	<?php } ?>
	<?php if($_GET['action']=='sendtestmail'){ ?><div class="contentclass">
<h1 style="text-align:center;">Send Test Mail</h1>
  <div style="text-align:center; margin-bottom:30px; margin-top:10px; display:none;" id="mailsending"><img src="images/emailsending.png" width="100" />
    <br />
    Mail Sending...</div>
	<div id="sendtestmailresult" style="text-align:center; margin-bottom:0px; margin-top:10px; display:none;">
	</div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="greenbuttonx2" id="addnewuserbtn" value="Send Now" onclick="sendtestmail();"  /></td>
        <td  ><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<script>
	function deleteprofile(){
	var dltid=$('#dids').val();
	$('#actiondiv').load('frm_action.crm?action=deleteprofile&did='+dltid);
	}
	</script>
	<?php } ?>
	<?php if($_GET['action']=='dltrole'){ ?>
	<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Are you sure you want to delete this role?</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete" onClick="startloading();deleterole();"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
	<script>
	function deleterole(){
	var dltid=$('#dids').val();
	$('#actiondiv').load('frm_action.crm?action=deleterole&did='+dltid);
	}
	</script>
	<?php } ?>
	<?php if($_GET['action']=='filemorethen20'){ ?>
	<div class="errors"><img src="images/errors.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Maximum upload file size limit 20MB</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding-right:20px;"><input type="button" class="whitembutton"   value="Ok" onclick="alertspopupopenClose();<?php if($_REQUEST['ac']=='timelinepost'){ ?>loadtimelinefunc();<?php } ?><?php if($_REQUEST['ac']=='timelinereply'){ ?>loadpostreply('<?php echo $_REQUEST['id']; ?>','<?php echo $_REQUEST['addedBy']; ?>');<?php } ?>" /></td>
      </tr>
   </table>
</div>
</div>
	<?php } ?>
	<?php if($_GET['action']=='filetypenot'){ ?>
	<div class="errors"><img src="images/errors.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Invalid file type</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding-right:20px;"><input type="button" class="whitembutton"   value="Ok" onclick="alertspopupopenClose();<?php if($_REQUEST['ac']=='timelinepost'){ ?>loadtimelinefunc();<?php } ?><?php if($_REQUEST['ac']=='timelinereply'){ ?>loadpostreply('<?php echo $_REQUEST['id']; ?>','<?php echo $_REQUEST['addedBy']; ?>');<?php } ?>" /></td>
      </tr>
   </table>
</div>
</div>
	<?php } ?>
	<?php if($_GET['action']=='selectrole'){
$select='company';
$where='id="'.$loginusersuperParentId.'"';
$rs=GetPageRecord($select,_USER_MASTER_,$where);
$companynamerole=mysqli_fetch_array($rs);
?>
<div class="contentclass">
<h1>Roles List</h1>
  <div id="contentbox" style="max-height:340px; overflow:auto;border: 2px #e6e6e6 solid;    border-radius: 5px;" >
  <div class="roletophr">
    <div class="namein"><table border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td><div class="hminus" id="tabdivc"  onclick="opencloserolltabs('c');"></div></td>
        <td class="nametd"><?php echo $companynamerole['company']; ?></td>
        <td>&nbsp;</td>
      </tr>
    </table></div>
	<div class="nameinin"  id="rdivc" >
	<div class="roletophr">
	<div class="namein"><table border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td><div class="hminus" id="tabdiv1"  onclick="opencloserolltabs('1');"></div></td>
        <td class="nametd"><a href="#" onclick="selectrollbox('1','CEO');">CEO</a></td>
        <td>&nbsp;</td>
      </tr>
    </table></div>
  </div>
  <div class="nameinin"  id="rdiv1">Loading...</div>
	</div>
  <script>
  loadroleinnerselect('1');
  </script>
  </div>
  </div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<script>
	function deleteprofile(){
	var dltid=$('#dids').val();
	$('#actiondiv').load('frm_action.crm?action=deleteprofile&did='+dltid);
	}
	</script>
	<?php } ?>
	<?php if($_GET['action']=='dlttimelinepost'){ ?>
	<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1 style="text-align:center;">Are you sure you want to delete this <?php if($_REQUEST['timelinecomment']==1){ echo 'comment'; } else { echo 'post'; } ?>?</h1>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete" onClick="dltposts('<?php echo $_GET['id']; ?>');alertspopupopenClose();"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
	<script>
	function deleterole(){
	var dltid=$('#dids').val();
	$('#actiondiv').load('frm_action.crm?action=deleterole&did='+dltid);
	}
	</script>
	<?php } ?>
	<?php 

if($_GET['action']=='selectParent'){ ?>
	<div class="contentclass">
		<h1 style="text-align:left;"><?php  if($_GET['c']=='1'){ echo 'Sales Person'; } else { echo 'Operation Person'; } ?></h1>
		<div class="topaboxlist">
			<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
				<thead>
					<tr>
						<th width="22%" valign="top" align="center">Name</th>
						<th width="22%" valign="top" align="center">Today&nbsp;Query</th>
						<th width="22%" valign="top" align="center">Total&nbsp;Open Query</th>
						<th width="22%" valign="top" align="center">Language&nbsp;known</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php
							if($_REQUEST['lang']!=''){
								$langIdQuery = "and FIND_IN_SET(".trim($_REQUEST['lang']).", languagelist)";
							}else{
								$langIdQuery ="";
							}
							if($loginuserprofileId==1){
								$wheresearchassign=' 1   ';
							} else {
								$wheresearchassign=' ( id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].') ) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].')))  or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].'))))  or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].'))))) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in  (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].')))))) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in  (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].'))))))) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in  (select id from roleMaster where parentId in ( select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].')))))))))  ';
							$wheresearchassign='( '.$wheresearchassign.' '.$langIdQuery.'  or id = '.$_SESSION['userid'].' or addedBy = '.$_SESSION['userid'].') ';
							}

							$wheresearchassign=' 1   ';
							$select='';
							$where='';
							$rs='';
							$select='profilePhoto,email,firstName,lastName,id,languagelist';
							if($_GET['c']==1){
									$where=' '.$wheresearchassign.' '.$langIdQuery.' and superParentId='.$loginusersuperParentId.' and status=1 and deletestatus=0 and ( userType=0 or userType=2 or userType=3 ) order by firstName asc';
							} else {
									$where=' '.$wheresearchassign.' '.$langIdQuery.' and superParentId='.$loginusersuperParentId.' and status=1 and deletestatus=0 and ( userType=1 or userType=2 ) order by id asc';
							}
							$rs=GetPageRecord($select,_USER_MASTER_,$where);
							while($userInfopost=mysqli_fetch_array($rs)){
							$nn=1;
						?></td>
					</tr>
				</tbody>
				<tr>
					<td><?php echo strip($userInfopost['firstName']); ?> <?php echo strip($userInfopost['lastName']); ?></td>
					<td >
						<?php
							$sql2='select id from queryMaster where assignTo="'.$userInfopost['id'].'" and DATE(queryDate)="'.date('Y-m-d').'"';
							$res12 = mysqli_query (db(),$sql2);
						echo mysqli_num_rows($res12); ?>
					</td>
					<td><?php
						$sql3='select id from queryMaster where assignTo="'.$userInfopost['id'].'" and queryStatus=10   and deletestatus=0';
						$res1 = mysqli_query (db(),$sql3);
						echo $tquery=mysqli_num_rows($res1); ?>  </td>
					<td>
						<?php
						//echo $_REQUEST['lang'];
						if($_REQUEST['lang']!=''){
							$rs22=GetPageRecord('*','tbl_languagemaster','id="'.trim($_REQUEST['lang']).'" and deletestatus=0 ');
							$Lnggdata=mysqli_fetch_array($rs22);
							echo $Lnggdata['name'];
						}else{
							//echo $userInfopost['pin'];
							$langarray = explode(',',rtrim($userInfopost['languagelist'],','));
							//print_r($langarray);
							foreach($langarray as $newArray){
								$langQuery = 'id="'.$newArray.'"';
								$rs22=GetPageRecord('*','tbl_languagemaster',$langQuery);
								$Lnggdata=mysqli_fetch_array($rs22);
								echo $Lnggdata['name'].',';
							}
						}
						?>
					</td>
					<td align="center"><div class="selectParentList2" onclick="selectOwner('<?php echo strip($userInfopost['firstName'].' '.$userInfopost['lastName']); ?>','<?php echo encode(strip($userInfopost['id'])); ?>');selectthis(this);"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div></td>
				</tr>
				<style>
				.selectParentList2{
				border: 1px solid;
				padding: 3px 15px;
				text-align: center;
				font-size: 13px;
				border-radius: 3px;
				background-color:#4caf50;
				cursor: pointer;
				color: #fff;
				}
				</style>
				<?php } ?>
			</table>
		</div>
		<div class="topaboxlist" style="background-color:#cbf4fe; "></div>
		<div id="contentbox" style="max-height:340px; overflow:auto; text-align:left; " >
		</div>
		<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
				<tr>
					<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
				</tr>
			</table>
		</div></div>
		<script>
		function selectOwner(name,id){
			$('#ownerName').val(name);
			$('#assignTo').val(id);
			alertspopupopenClose();
		}
		</script>
	<?php 
}

if($_GET['action']=='selectDocketParent'){ ?>
	<div class="contentclass">
		<h1 style="text-align:left;"><?php  if($_GET['c']=='1'){ echo 'Sales Person'; } else { echo 'Operation Person'; } ?></h1>
		<div class="topaboxlist">
			<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
				<thead>
					<tr>
						<th width="22%" align="center">Name </th>
						<th width="22%" align="left">Today Query</th>
						<th width="22%" align="center">Total Open Query&nbsp; </th>
						<th width="22%" align="left">Language known </th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php
							if($_REQUEST['lang']!=''){
								$langIdQuery = "and FIND_IN_SET(".trim($_REQUEST['lang']).", languagelist)";
							}else{
								$langIdQuery ="";
							}
							if($loginuserprofileId==1){
							$wheresearchassign=' 1   ';
							} else {
							$wheresearchassign=' ( id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].') ) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].')))  or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].'))))  or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].'))))) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in  (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].')))))) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in  (select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].'))))))) or id in (select id from '._USER_MASTER_.' where  roleId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in (select id from roleMaster where parentId in  (select id from roleMaster where parentId in ( select id from roleMaster where parentId in ( select id from roleMaster where parentId ='.$LoginUserDetails['roleId'].')))))))))  ';
							$wheresearchassign='( '.$wheresearchassign.' '.$langIdQuery.'  or id = '.$_SESSION['userid'].' or addedBy = '.$_SESSION['userid'].') ';
							}
							$select='';
							$where='';
							$rs='';
							$select='profilePhoto,email,firstName,lastName,id,languagelist';
							if($_GET['userType']==1){
								$where=' '.$wheresearchassign.' '.$langIdQuery.' and superParentId='.$loginusersuperParentId.' and status="1" and deletestatus=0 and  ( userType=1 or userType=2 ) order by firstName asc';
							} else {
								$where=' '.$wheresearchassign.'  '.$langIdQuery.'  and superParentId='.$loginusersuperParentId.' and status="1" and deletestatus=0 and ( userType=0 or userType=2 or userType=3 ) order by id asc';
							}
							$rs=GetPageRecord($select,_USER_MASTER_,$where);
							while($userInfopost=mysqli_fetch_array($rs)){
							$nn=1;
						?></td>
					</tr>
				</tbody>
				<tr>
					<td><?php echo strip($userInfopost['firstName']); ?> <?php echo strip($userInfopost['lastName']); ?></td>
					<td >
						<?php
							$sql2='select id from queryMaster where assignTo="'.$userInfopost['id'].'" and DATE(queryDate)="'.date('Y-m-d').'"';
							$res12 = mysqli_query (db(),$sql2);
						echo mysqli_num_rows($res12); ?>
					</td>
					<td><?php
						$sql3='select id from queryMaster where assignTo="'.$userInfopost['id'].'" and queryStatus=10   and deletestatus=0';
						$res1 = mysqli_query (db(),$sql3);
						echo $tquery=mysqli_num_rows($res1); ?>  </td>
					<td>
						<?php
						if($_REQUEST['lang']!=''){
							$rs22=GetPageRecord('*','tbl_languagemaster','id="'.trim($_REQUEST['lang']).'" and deletestatus=0 ');
							$Lnggdata=mysqli_fetch_array($rs22);
							echo $Lnggdata['name'];
						}else{
							$langarray = explode(',',rtrim($userInfopost['languagelist'],','));
							foreach($langarray as $newArray){
								$langQuery = 'id="'.$newArray.'"';
								$rs22=GetPageRecord('*','tbl_languagemaster',$langQuery);
								$Lnggdata=mysqli_fetch_array($rs22);
								echo $Lnggdata['name'].',';
							}
						}
						?>
					</td>
					<td align="center"><div class="selectParentList2" onclick="selectOwner('<?php echo strip($userInfopost['firstName'].' '.$userInfopost['lastName']); ?>','<?php echo encode(strip($userInfopost['id'])); ?>');"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div></td>
				</tr>
				<style>
				.selectParentList2{
				border: 1px solid;
				padding: 3px 15px;
				text-align: center;
				font-size: 13px;
				border-radius: 3px;
				background-color:#4caf50;
				cursor: pointer;
				color: #fff;
				}
				</style>
				<?php } ?>
			</table>
		</div>
		<div class="topaboxlist" style="background-color:#cbf4fe; "></div>
		<div id="contentbox" style="max-height:340px; overflow:auto; text-align:left; " >
		</div>
		<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
				<tr>
					<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
				</tr>
			</table>
		</div></div>
		<script>
		function selectOwner(name,id){
			$('#opsPersonName').val(name);
			$('#opsPersonId').val(id);
			alertspopupopenClose();
		}
		</script>
	<?php 
}
?>
<?php if($_GET['action']=='leadsdelete'){ ?>
<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1>Are you sure you want to delete selected <?php echo $_REQUEST['name']; ?>?</h1>
 <div id="buttonsbox">
 <table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete Now" onClick="$('#listform').attr('method','post');$('#listform').attr('target','actoinfrm');$('#listform').attr('action','frm_action.crm');submitfieldfrm('listform');"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
	</div>
	<?php } ?>
<?php if($_GET['action']=='corportatedelete'){ ?>
<div class="delbg"><img src="images/Remove-64.png" /></div>
	<div class="contentclass">
<h1 style="padding:18px;">Are you sure you want to delete selected <?php echo $_REQUEST['name']; ?>?</h1>
 <div id="buttonsbox">
 <table border="0" align="center" cellpadding="0" cellspacing="0" style="margin-bottom:30px;">
      <tr>
        <td><input name="addnewuserbtn" type="button" class="redmbutton2" id="addnewuserbtn" value="Delete Now" onClick="$('#listform').attr('method','post');$('#listform').attr('target','actoinfrm');$('#listform').attr('action','frm_action.crm');submitfieldfrm('listform');"  /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
	</div>
	<?php } ?>
	<?php if($_GET['action']=='addeditdocument'){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.' and sectionType="'.$_REQUEST['sectionType'].'"';
$rs1=GetPageRecord($select1,_DOCUMENT_DETAILS_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
$docType=clean($editresult['docType']);
$documentNo=clean($editresult['documentNo']);
$countryId=clean($editresult['countryId']);
$issueDate=clean($editresult['issueDate']);
$expiryDate=clean($editresult['expiryDate']);
}
?>
<div class="contentclass">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Document Detail </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmdocument" target="actoinfrm" id="addeditfrmdocument">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top"><div class="griddiv"><label>
	<div class="gridlable">Document Type<span class="redmind"></span></div>
	<select id="docType" name="docType" class="gridfield validate" displayname="Document Name" autocomplete="off"   >
	 <option value="">Select Document</option>
	<option value="1" <?php if($docType['docType']==1){ ?>selected="selected"<?php } ?>>AADHAAR</option>
	<option value="2" <?php if($docType['docType']==2){ ?>selected="selected"<?php } ?>>PASSPORT</option>
	<option value="3" <?php if($docType['docType']==3){ ?>selected="selected"<?php } ?>>VISA</option>
	<option value="5" <?php if($docType['docType']==5){ ?>selected="selected"<?php } ?>>COVID V. CERT.</option>
	<option value="6" <?php if($docType['docType']==6){ ?>selected="selected"<?php } ?>>OTHER</option>
</select>
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">Document No. <span class="redmind"></span></div>
	<input name="documentNo" type="text" class="gridfield validate" id="documentNo"  displayname="Document Number" value="<?php echo $documentNo; ?>" maxlength="100" />
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">
Issue Country <span class="redmind"></span></div>
	<select id="countryId" name="countryId" class="gridfield validate" displayname="Country Name" autocomplete="off"   >
	 <option value="">Select Country</option>
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' deletestatus=0 and status=1 order by name asc';
		$rs=GetPageRecord($select,_COUNTRY_MASTER_,$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$countryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
		<?php } ?>
		</select>
	</label>
	</div>
	</td>
    <td width="1%" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td width="49%" valign="top">
  <div class="griddiv">
  	<label>
  	<script>
  		function changedatefunction(){
  var fromDate = $('#fromDate').val().split("-").reverse().join("-");
  var toDate = $('#toDate').val().split("-").reverse().join("-");
  var fromDatestamp = toTimestamp(''+fromDate+'');
  var toDatestamp = toTimestamp(''+toDate+'');
 if(fromDate!= '' && fromDate!= '' && fromDatestamp>= toDatestamp)
    {
    alert("Please ensure that the To Travel Date is greater than From Travel Date.");
    $('#toDate').val('');
    }
  var totaldays = showDays(toDate,fromDate);
  if(totaldays!='' || totaldays!='0'){
  $('#night').val(totaldays);
  var date = new Date(fromDate);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() - 7);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = ('0'+dd).slice(-2) + '-' + ('0'+mm).slice(-2) + '-' + y;
  $('#closerDate').val(someFormattedDate);
  var night = totaldays;
if(night<6){
$('#queryPriority').val('3');
}
  }
}
 $(document).ready(function() {
$('#issueDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
	<div class="gridlable" >Issue Date </div>
	<input name="issueDate" type="text" id="issueDate" class="gridfield calfieldicon"  displayname="Issue Date"   autocomplete="off" value="<?php if(isset($issueDate)) {echo date('d-m-Y',strtotime($issueDate));}else{echo "01-01-2010";} ?>" style="width:100%;"/>
	</label>
	</div>
	<label>
  <div class="griddiv">
  	<script>
 $(document).ready(function() {
$('#expiryDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
	<div class="gridlable">
Expiry Date  </div>
	<input name="expiryDate" type="text" id="expiryDate" class="gridfield calfieldicon"  displayname="Expiry Date"   autocomplete="off" value="<?php if(isset($expiryDate)) {echo date('d-m-Y',strtotime($expiryDate));}else{echo "01-01-2010";} ?>" style="width:100%; display: inline-block; "/>
	</div>
	</label>
	 </td>
  </tr>
</table>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
 <input name="masterId" type="hidden" id="masterId" value="<?php echo $_REQUEST['masterId']; ?>" />
	  <input name="action" type="hidden" id="action" value="<?php if($_REQUEST['id']!=''){ echo 'editdocument'; } else { echo 'adddocument'; } ?>" />
	  <input name="sectionType" type="hidden" id="sectionType" value="<?php echo $_REQUEST['sectionType']; ?>" />
</form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmdocument','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='addeditbankinfo'){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.' and sectionType="'.$_REQUEST['sectionType'].'"';
$rs1=GetPageRecord($select1,_BANK_DETAILS_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
$bankName=clean($editresult['bankName']);
$beneficiary=clean($editresult['beneficiary']);
$branch=clean($editresult['branch']);
$accountNumber=clean($editresult['accountNumber']);
$IFSCCode=clean($editresult['IFSCCode']);
$address=clean($editresult['address']);
$phoneNumber=clean($editresult['phoneNumber']);
$email=clean($editresult['email']);
$swiftCode=clean($editresult['swiftCode']);
$primaryvalue=clean($editresult['primaryvalue']);
}
?>
<div class="contentclass">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Bank Detail </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
    <div class="griddiv">
    	<label>
	<div class="gridlable">Bank Name<span class="redmind"></span></div>
	<input name="bankName" type="text" class="gridfield validate" id="bankName" displayname="Bank Name" value="<?php echo $bankName; ?>" maxlength="100" />
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">Branch <span class="redmind"></span></div>
	<input name="branch" type="text" class="gridfield validate" id="branch"  displayname="Branch" value="<?php echo $branch; ?>" maxlength="100" />
	</label>
	</div>
	<div class="griddiv">
    	<label>
	<div class="gridlable">Beneficiary N<span class="redmind"></span></div>
	<input name="beneficiary" type="text" class="gridfield validate" id="beneficiary" displayname="Beneficiary Name" value="<?php echo $beneficiary; ?>" maxlength="100" />
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">
Account No. <span class="redmind"></span></div>
	<input name="accountNumber" type="text" class="gridfield validate" id="accountNumber" displayname="Account No." value="<?php echo $accountNumber; ?>" maxlength="100" />
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">IFSC Code <span class="redmind"></span></div>
	<input name="IFSCCode" type="text" class="gridfield validate" id="IFSCCode" displayname="IFSC Code" value="<?php echo $IFSCCode; ?>" maxlength="100" />
	</label>
	</div>
	</td>
    <td width="1%" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td width="49%" valign="top">
  <div class="griddiv"><label>
	<div class="gridlable">Phone No. </div>
	<input name="phoneNumber" type="text" class="gridfield" id="phoneNumber" value="<?php echo $phoneNumber; ?>" maxlength="100" />
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">
Email Id </div>
	<input name="email" type="text" class="gridfield" id="email" value="<?php echo $email; ?>" maxlength="100" />
	</label>
	</div>
  <div class="griddiv"><label>
	<div class="gridlable">
Swift Code  </div>
	<input name="swiftCode" type="text" class="gridfield" id="swiftCode" value="<?php echo $swiftCode; ?>" maxlength="100" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Address </div>
	<input name="address" type="text" class="gridfield" id="address" value="<?php echo $address; ?>" maxlength="100" />
	</label>
	</div>
	<div class="griddiv" style="border:0px;"><label>
	<div class="gridlable" style="border:0px; width:100%;">Mark as Default </div>
	<input name="primaryvalue" type="checkbox" id="primaryvalue" style="display:block;" value="1"  <?php if($primaryvalue==1){ ?>checked="checked"<?php } ?>/>
	</label>
	</div>
	 </td>
  </tr>
  <tr>
    <td colspan="3" valign="top"></td>
    </tr>
</table>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
 <input name="masterId" type="hidden" id="masterId" value="<?php echo $_REQUEST['masterId']; ?>" />
	  <input name="action" type="hidden" id="action" value="<?php if($_REQUEST['id']!=''){ echo 'editbankdetail'; } else { echo 'addbankdetail'; } ?>" />
	  <input name="sectionType" type="hidden" id="sectionType" value="<?php echo $_REQUEST['sectionType']; ?>" />
</form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } ?>

	<?php
 
if($_REQUEST['action']=='selectCorporate' && $_REQUEST['clientType']!=''){

?>  
<style>

	.gridtable td { 
	    border-bottom: #f1f1f1 0px solid !important; 
        padding-bottom: 10px !important;
	}
	.gridtable22 td{
			padding-right: 5px;
			padding-bottom: 12px;
	}
	.gridtable2222 td{
		padding-bottom: 12px;
	}
	.addeditpagebox .griddiv .gridlable {
	    color: #8a8a8a;
	    width: 100%;
	    display: inline-block;
	    padding-bottom: 0px;
	    font-size: 11px;text-transform: uppercase;
	}
    .addeditpagebox .griddiv{
        margin-bottom: 0px !important;
    }

	 .addtopaboxlist {
	    border: 2px rgba(186, 228, 193, 0.75) solid;
	    padding: 10px;
	    margin-bottom: 30px;
	    box-sizing: border-box;
	    background: #f2fff7;
	}

</style>
<div class="topaboxlist"  style="background-color: #ffffff; border-radius: 3px; padding: 3px; box-shadow: 0px 10px 35px;"> 
<table width="100%" border="0" cellspacing="0" cellpadding="8">
  <tr>

    <td width="100%" align="left"><strong style="font-size: 18px;"><?php if($_REQUEST['clientType']!=2){ echo "Add Agent "; }else{ echo "Add B2C"; } ?> </strong></td>
    <td width="12%" align="right" valign="top"><i class="fa fa-times" style="cursor:pointer; font-size: 20px; color: #c51d1d;" onclick="alertspopupopenClose();"></i></td>
  </tr> 
</table>

<div class="addeditpagebox addtopaboxlist">
<?php if($_REQUEST['clientType']!=2){ ?> 	
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addagentqery" target="actoinfrm"  id="addagentqery"> 
<input type="hidden" name="addTo" id="addTo" value="<?php echo $_REQUEST['addTo'] ?>">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" > 
  		<tbody> 
	  	<tr >
			<td width="50%"  align="left" style="padding-right: 10px;">
			   	<div class="griddiv"><label>
					<div class="gridlable">Company&nbsp;Type<span class="redmind"></span></div>
					<select id="copmanyType" name="copmanyType" class="gridfield validate" displayname="Company Type" autocomplete="off"  > 
                    <option value="0">None</option>
                    <?php 
                    $select=''; 
                    $where=''; 
                    $rs='';  
                    $select='*';    
                    $where=' deletestatus=0 and status=1 order by id asc';  
                    $rs=GetPageRecord($select,_COMPANY_TYPE_MASTER_,$where); 
                    while($resListing=mysqli_fetch_array($rs)){  

                    ?>
                    <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcompanyTypeId){ ?> selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>
                    <?php } ?>
					</select>

					</label>
				</div>
			</td>    
		  	<td width="50%" align="left">
				<div class="griddiv"><label>
				<div class="gridlable">Company Name<span class="redmind"></span></div>
                    <input type="text" id="leadcompanyName" name="leadcompanyName" class="gridfield validate"  autocomplete="off" displayname="Company Name">
				</label>
				</div>
			</td>
            </tr>

           <tr>
			   <td width="100%" colspan="2">
			  
			<table border="0" cellpadding="0" cellspacing="0">
            
            <div class="gridlable">Contact Person<span class="redmind"></span></div>
			<tr>
				<td width="321" align="left" style="padding: 0px 3px 0px 0px;">
                <div class="griddiv"><label>
				<select id="division" name="division" class="gridfield validate" displayname="Division" autocomplete="off"  placeholder="Division" >
				<option value="">Select</option>
					 <?php  
					$selectd='*';    
					$whered=' deletestatus=0 and status=1 order by name asc';  
					$rsd=GetPageRecord($selectd,_DIVISION_MASTER_,$whered); 
					while($resListingd=mysqli_fetch_array($rsd)){  
					?>
					<option value="<?php echo strip($resListingd['id']); ?>" <?php if($resListingd['name'] == "Operations" || $resListingd['name'] == "Operation" ){ ?> selected <?php }; ?>><?php echo strip($resListingd['name']); ?></option>
					<?php } ?>
				</select>
                </label></div>
				</td>
		    <td width="321" align="left" style="padding: 0px 3px 0px 0px;"><div class="griddiv"><label><input name="contactPerson" type="text" class="gridfield validate" id="contactPerson" value="" displayname="Contact Person"  maxlength="100" placeholder="Contact Person" /></label></div></td> 
		    <td width="288" align="left" style="padding: 0px 3px 0px 0px;"><div class="griddiv"><label><input name="designation" type="text" class="gridfield" id="designation" value="" displayname="Designation" placeholder="Designation" /></label></div></td> 
		    <td width="100" align="center" style="padding: 0px 3px 0px 0px;width: 116px;
"><div class="griddiv"><label>
			<?php 
				$rsn="";
				$rs1cmp=GetPageRecord('*','companySettingsMaster','id=1');
				$cmpcountryData=mysqli_fetch_array($rs1cmp);
				$compcountryCode = $cmpcountryData['compcountryCode'];
			?>
			<input name="countryCode" type="text" class="gridfield validate" id="countryCode" value="<?php echo '+'. $compcountryCode; ?>" displayname="Country Code" placeholder="+91" />
		
			</label></div></td> 
		    <td width="270" align="center" style="padding: 0px 3px 0px 0px;"><div class="griddiv"><label><input name="phone" type="text" class="gridfield validate" id="phone" value="" displayname="Phone" maxlength="10"  placeholder="Phone" /></label></div></td> 
		    <td width="380" align="center" style="padding: 0px 3px 0px 0px;"><div class="griddiv"><label><input name="email" type="text" class="gridfield validate" id="email" value="" displayname="Email"  placeholder="Email" /></label></div></td> 

		  </tr>
            
         
		</table> 
		</td>
		   </tr>
            <tr >

			<td width="50%"  align="left" style="padding-right: 10px;">
			   	<div class="griddiv"><label>
					<div class="gridlable">Market&nbsp;Type</div>
					<select id="marketType" name="marketType" class="gridfield" displayname="Market Type" autocomplete="off"  >  
					 	<?php 
						
                        $rs=GetPageRecord('*','marketMaster',' deletestatus=0 and status=1 order by name asc');  
                        while($resListing=mysqli_fetch_array($rs)){   
                        ?> 
                        <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editmarketType){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option> 
                        <?php } ?>
					</select>

					</label>
				</div>
			</td>    
		  	<td width="50%" align="left">
				<div class="griddiv"><label>
				<div class="gridlable">Nationality<span class="redmind"></span></div>
                <select name="nationality" id="nationality" class="gridfield validate" displayname="Nationality">
                <option value=""> Select</option>
                <?php   
                $rs=GetPageRecord($select,'nationalityMaster',' deletestatus=0 order by name asc');  
                while($resListing=mysqli_fetch_array($rs)){   
                ?> 
                <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$nationality){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option> 
                <?php } ?>
                </select>
				</label>
				</div>
			</td>
            </tr>

            <tr >
			<td width="50%"  align="left" style="padding-right: 10px;">
			   	<div class="griddiv"><label>
					<div class="gridlable">Category
						<!-- <span class="redmind"></span>  -->
					</div>
					<select id="categoryid" name="categoryid" class="gridfield " displayname="Category" autocomplete="off"  >
                        <option value="">Select</option>  
                    <option value="1" >Big</option>
	                 <option value="2" >Medium</option>
	                <option value="3" >Small</option>
					</select>

					</label>
				</div>
			</td>    
		  	<td width="50%" align="left">
				<div class="griddiv"><label>
				<div class="gridlable">Tour Type
					<!-- <span class="redmind"></span> -->
				</div>
                <select name="tourType" id="tourType" class="gridfield " displayname="Tour Type">
                <option value=""> Select</option>
                <?php   
                $rs=GetPageRecord($select,'tourTypeMaster',' deletestatus=0 order by name asc');  
                while($resListing=mysqli_fetch_array($rs)){   
                ?> 
                <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$tourType){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option> 
                <?php } ?>
                </select>
				</label>
				</div>
			</td>
            </tr>
            <tr >
			<td width="50%"  align="left" style="padding-right: 10px;">
			   	<div class="griddiv"><label>
					<div class="gridlable">Sales&nbsp;Person</div>
					<select id="salesPerson" name="salesPerson" class="gridfield" displayname="Sales Person" autocomplete="off"  >  
                    <option value="">Select</option>
                    <?php   
                        $select='*';    
                        $where='status="1" and deletestatus=0 order by firstName asc'; 
                        $restypeSalesq=GetPageRecord($select,_USER_MASTER_,$where); 
                        while($restypeSales=mysqli_fetch_array($restypeSalesq)){  ?>
                    <option value="<?php echo $restypeSales['id']; ?>" <?php if($restypeSales['id']==$editassignTo){ ?>selected="selected"<?php } ?>><?php echo strip($restypeSales['firstName']).' '.strip($restypeSales['lastName']); ?></option>
                    <?php } ?>
                    </select>

					</label>
				</div>
			</td>    
		  	<td width="50%" align="left">
				<div class="griddiv"><label>
				<div class="gridlable">Operation Person</div>
                <select name="operationPerson" id="operationPerson" class="gridfield" displayname="Operation Person">
                    <option value=""> Select</option>
                    <?php  
                    $select='*';    
                    $where='status="1" and deletestatus=0 and ( userType=0 or userType=1 or userType=2 ) order by firstName asc'; 
                    $rs=GetPageRecord($select,_USER_MASTER_,$where); 
                    while($restype=mysqli_fetch_array($rs)){  
                    ?>
                <option value="<?php echo strip($restype['id']); ?>" <?php if($restype['id']==$editOpsAassignTo){ ?>selected="selected"<?php } ?>><?php echo strip($restype['firstName']).' '.strip($restype['lastName']); ?></option>
                <?php } ?>
                </select>
				</label>
				</div>
			</td>
            </tr>

		<tr>
			<td colspan="2" align="right" valign="middle">
                <input type="button" value="Close" name="Submit" class="greybutton" onclick="alertspopupopenClose();">
                <input type="button" name="Submit" value="Save" class="bluembutton bluembutton2"  onclick="formValidation('addagentqery','saveflight','0');"> 
			  <input name="action" type="hidden" id="action" value="saveLeadCorporate">
			  <input name="businessType" type="hidden" id="businessType" value="<?php echo $_REQUEST['clientType']; ?>">

            </td>
			</tr> 
		</tbody>
	</table>

</form>
<?php }elseif($_REQUEST['clientType']==2){ ?> 
	<!-- Add B2C -->

	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addclienttoquery" target="actoinfrm"  id="addclienttoquery"> 

	<h2 style="padding-bottom: 15px;">Personal Information</h2>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable22" > 
	  <tbody> 

	  <tr >	   
			<td width="20%" align="left">
				<div class="griddiv"><label>


				
			<?php
			$rs1cmp=GetPageRecord('*','companySettingsMaster','id=1');
			$editresultcmp=mysqli_fetch_array($rs1cmp);
			$nationalitycmp=clean($editresultcmp['id']);
			$nationalityId=clean($editresultcmp['nationality']);
			
			?>
				<div class="gridlable">Nationality<span class=""></span></div>
				<select name="nationality" id="nationality" class="gridfield" displayname="Nationality">
				<option value=""> Select</option>
				<?php   
				$rs=GetPageRecord('*','nationalityMaster',' deletestatus=0 order by name asc');  
				while($resListing=mysqli_fetch_array($rs)){   
				?> 
				<option value="<?php echo $resListing['id']; ?>" <?php if($resListing['id'] == $nationalityId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
				<?php } ?>
				</select>
				</label>
				</div>
			</td>

			<td width="20%">
		<div class="griddiv"><label>
				<div class="gridlable">Title&nbsp;<span class="redmind"></span></div>
				<select id="contacttitleId" name="contacttitleId" class="gridfield validate" displayname="Title" autocomplete="off" >
				<option value="">None</option>
				<?php 

				$select=''; 

				$where=''; 

				$rs='';  

				$select='*';    

				$where=' deletestatus=0 and status=1 order by id asc';  

				$rs=GetPageRecord($select,_NAME_TITLE_MASTER_,$where); 

				while($resListing=mysqli_fetch_array($rs)){  
				?>

				<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcontacttitleId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>

				<?php } ?>
				</select></label>

				</div></td>
				<td width="20%"><div class="griddiv"><label>

				<div class="gridlable">First Name<span class="redmind"></span>  </div>

				<input name="firstName" type="text" class="gridfield validate" id="firstName" value="<?php echo $editfirstName; ?>" displayname="First Name" maxlength="100" />

				</label>

				</div></td>

				<td width="20%"><div class="griddiv"><label>

				<div class="gridlable">Middle Name</div>

				<input name="middleName" type="text" class="gridfield" id="middleName" displayname="Middle Name" maxlength="100" />

				</label>

				</div>
				</td>

				<td width="20%"><div class="griddiv"><label>

				<div class="gridlable">Last Name<span class=""></span>   </div>

				<input name="lastName" type="text" class="gridfield " id="lastName" value="<?php echo $editlastName; ?>" displayname="Last Name" maxlength="100" />

				</label>

				</div>
				</td>

			<td width="25%"  align="left" style="padding-right: 5px;display: none;">
				<div class="griddiv"><label>
					<div class="gridlable">Market&nbsp;Type<span class="redmind"></span> </div>
					<select id="marketType" name="marketType" class="gridfield validate" displayname="Market Type" autocomplete="off"  >  
						<?php 
						
						$rs=GetPageRecord('*','marketMaster',' deletestatus=0 and status=1 order by name asc');  
						while($resListing=mysqli_fetch_array($rs)){   
						?> 
						<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editmarketType){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option> 
						<?php } ?>
					</select>

					</label>
				</div>
			</td> 

			  
	</tr>
	<tr>
		
		</tr>

		<tr>
		<td>
		<div class="griddiv">

			<label>

			<div class="gridlable">Gender<span class="redmind"></span></div>
			</label>
					<select name="gender" id="gender" class="gridfield validate"  autocomplete="off">
					<option value="">Select</option>
					<option value="Male">Male</option>
					<option value="Female">Female</option>
					<option value="Other">Other</option>
					</select>
			</div></td>
			<td>
		<div class="griddiv">

			<label>

			<div class="gridlable">Date of Birth</div>

			<input name="birthDate" type="text" id="birthDate" class="gridfield calfieldicon"  autocomplete="off" value="<?php echo date("d-m-Y", strtotime('now'));?>" /></label>

			</div></td>

			<td width="25%"  align="left" style="padding-right: 5px;">
			   <div class="griddiv"><label>
				<div class="gridlable">Sales&nbsp;Person</div>
				<select id="salesPerson" name="salesPerson" class="gridfield " displayname="Sales Person" autocomplete="off"  >  
				<option value="">Select</option>
				<?php   
					$select='*';    
					$where='status="1" and deletestatus=0 order by firstName asc'; 
					$restypeSalesq=GetPageRecord($select,_USER_MASTER_,$where); 
					while($restypeSales=mysqli_fetch_array($restypeSalesq)){  ?>
				<option value="<?php echo $restypeSales['id']; ?>" <?php if($restypeSales['id']==$editassignTo){ ?>selected="selected"<?php } ?>><?php echo strip($restypeSales['firstName']).' '.strip($restypeSales['lastName']); ?></option>
				<?php } ?>
				</select>

				</label>
			</div>
		</td>
		</tr>
		<table width="" border="0" cellpadding="0" cellspacing="0">
									<tr>
									<h2>Contact Information</h2>
									<!-- <div class="gridlable" style="width: 12% !important; display:inline-block;    padding: 4px 20px 4px 0px;">Contact No.<span class="redmind"></span></div> -->

									<!-- <label>
									<div class="gridlable" style="width: 38% !important; display:inline-block;    padding: 4px 0px 4px 0px;">Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Number<span class=""></span></div></label> -->

									<label>
									<!-- <div class="gridlable" style="width: 45% !important; display:inline-block;    padding: 4px 0px 4px 0px;">Email<span class=""></span></div></label> -->
								
										<td width="15%" align="left" >
										<div class="griddiv"><label>
										<div class="gridlable">Contact&nbsp;Type<span class="redmind"></span></div>
											<select id="PhoneTypeId" name="PhoneTypeId" class="gridfield " displayname="Mobile" autocomplete="off" style="padding: 9px; height: 37px;">

										<?php
										$select = '*';
										$where = ' status=1 order by id asc';
										$rs = GetPageRecord($select, _PHONE_TYPE_MASTER_, $where);
										while ($restype = mysqli_fetch_array($rs)) { ?>
										<option value="<?php echo strip($restype['id']); ?>" <?php if ($restype['id'] == $reslisting['phonetype']) { ?> selected="selected" <?php } ?> ><?php echo strip($restype['name']); ?></option>
												<?php } ?>
											</select>
										</label></div>
										</td>

												
										<td width="" align="left" style="padding-right: 0px;">
													<div class="griddiv "><label>
													<div class="gridlable">Code<span class="redmind"></span></div>
													
													<?php 
													$rsn="";
													$rs1cmp=GetPageRecord('*','companySettingsMaster','id=1');
													$cmpcountryData=mysqli_fetch_array($rs1cmp);
													$compcountryCode = $cmpcountryData['compcountryCode'];
													?>
													<input style="border-bottom: 2px solid red;width: 50px;" name="countryCode" type="text" class="gridfield validate" displayname="Country Code" id="countryCode" maxlength="5" value="<?php echo '+'. $compcountryCode; ?>" placeholder="+91"/>
													</label></div>
												</td>
													<td width="" align="left" style="padding-right: 10px;">
													<div class="griddiv "><label>
													<div class="gridlable">Number<span class="redmind"></span></div>
													<input style="width:140px;" name="PhoneNo" type="text" class="gridfield validate" displayname="Mobile" id="PhoneNo" maxlength="11" placeholder="Enter Mobile"/>
													</label></div>
												</td>
												
													<td width="15%" align="left" style=""><div class="griddiv"><label>
													<div class="gridlable">Email&nbsp;Type</div>
														<select id="EmailTypeId" name="EmailTypeId" class="gridfield " autocomplete="off" style="padding: 9px; height: 37px;">

															<?php
															$select = '*';
															$where = ' status=1 order by id asc';
															$rs = GetPageRecord($select, _EMAIL_TYPE_MASTER_, $where);
															while ($restype = mysqli_fetch_array($rs)) {
															?>
																<option value="<?php echo strip($restype['id']); ?>" <?php if ($restype['id'] == $reslisting['emailtype']) { ?>selected="selected" <?php } ?>><?php echo strip($restype['name']); ?></option>
															<?php } ?>
														</select>
													</label></div>
													<!-- <hr> -->
													</td>
														
													<td width="" align="left">
													<div class="griddiv"><label>
													<div class="gridlable">Email&nbsp;</div>
													<input name="Email" type="email" class="gridfield " displayname="Email" id="Email" style="width:190px;" maxlength="100" />
													</label></div>
												</td>
													
												</tr>
											</table>
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="gridtable2222">
							<tr>
								<h2 class="childinformation">Address Information</h2>
							</tr>
							<tr>
								<td width="20%" style="padding-right:10px;">
									<div class="griddiv" style="display:noned;"><label>
											<div class="gridlable">Country</div>
											<select id="countryIdB" name="country" class="gridfield " displayname="Country" autocomplete="off" onchange="getStateAllStates(this.value);">
												<option value="">Select</option>
												<?php
												$DefaultCountry = 'India';
												$select1 = '';
												$wherec = '';
												$rsc = '';
												$select1 = '*';
												$wherec = ' deletestatus=0 order by name asc';
												$rsc = GetPageRecord($select1, 'countryMaster', $wherec);
												while ($coresListing = mysqli_fetch_array($rsc)) {

													if ($coresListing['countryId'] != '') {
														$isDefaultCountry = $coresListing['id'] == $editresult['countryId'];
													} else {
														$isDefaultCountry = $coresListing['name'] === $DefaultCountry;
													}
												?>
													<option value="<?php echo strip($coresListing['id']); ?>" <?php if ($coresListing['id'] == $isDefaultCountry) { ?>selected="selected" <?php } ?>><?php echo strip($coresListing['name']); ?></option>
												<?php } ?>
											</select>
										</label>
									</div>
								</td>

								<td width="20%" style="padding-right:10px;">
									<div class="griddiv" style="display:noned;"><label>

											<div class="gridlable">State</div>
											<select id="loadstates" name="loadstates" class="gridfield " displayname="State" autocomplete="off" onchange="getStateAllCities();">
												<option value="">Select</option>
												<?php

												$rstate = "";

												$rstate = GetPageRecord('*', _STATE_MASTER_, ' id="' . $editstateId . '" order by name asc');

												while ($stateData = mysqli_fetch_array($rstate)) {

												?>
													<option value="<?php echo strip($stateData['id']); ?>" selected="selected"><?php echo strip($stateData['name']); ?></option>

												<?php } ?>
											</select>
										</label>
									</div>
								</td>

								<td width="20%" style="padding-right:10px;">
									<div class="griddiv" style="display:noned;"><label>
											<div class="gridlable">City</div>
											<select id="loadcities" name="loadcities" class="gridfield " displayname="City" autocomplete="off">
												<option value="">Select</option>
												<?php
												$rstatess = "";

												$rstatess = GetPageRecord('*', _STATE_MASTER_, ' id="' . $editcityId . '" order by name asc');

												while ($statesData = mysqli_fetch_array($rstatess)) {

												?>
													<option value="<?php echo strip($statesData['id']); ?>"><?php echo strip($statesData['name']); ?></option>

												<?php } ?>
											</select>
										</label>
									</div>
								</td>

								<td width="20%" style="padding-right:10px;">
									<div class="griddiv" style="display:noned;"><label>
											<div class="gridlable">Pin/Zip</div>
											<input type="number" name="pinzip" id="pinzip" class="gridfield" value="<?php echo $editresult['pinzip']; ?>">
										</label>
									</div>
								</td>

							</tr>
							<tr>
								<td colspan="4" style="padding-right:10px;">
									<div class="griddiv" style="display:noned;"><label>
											<div class="gridlable">Address</div>
											<textarea name="addressInfo" id="addressInfo" rows="" style="width:98%; padding:5px; margin-top:3px;"><?php echo $editresult['addressInfo']; ?></textarea>
										</label>
									</div>
								</td>
							</tr>
						</table>
						<script>
							function defaultsateload(){
								var countryId = $('#countryIdB').val();
								if(countryId!=''){
									$('#loadstates').load('loadstatcity.php?action=loadallstates&countryId=' + countryId + '&selectIdst=<?php echo $editstateId; ?>');
								}
							}

							defaultsateload();
							function defualtcities(){
								var stateId = $('#loadstates').val();
								if(stateId!=''){
									$('#loadcities').load('loadstatcity.php?action=loadallCities&stateId=' + stateId + '&selectIdct=<?php echo $editcityId; ?>');
								}
							}
							defualtcities();

							function getStateAllStates(countaryId) {
								var countryId = $('#countryIdB').val();

								$('#loadstates').load('loadstatcity.php?action=loadallstates&countryId=' + countryId + '&selectIdst=<?php echo $editstateId; ?>');
							}



							function getStateAllCities() {
								var stateId = $('#loadstates').val();
								$('#loadcities').load('loadstatcity.php?action=loadallCities&stateId='+stateId+'&selectIdct=<?php echo $editcityId; ?>');
							}

						
								getStateAllStates();
								getStateAllCities();
						
						</script>

								
		<table width="100%">
		<tr>
		<td width="100%" align="right" valign="middle">
			<input type="button" value="Close" name="Submit" class="greybutton" onclick="alertspopupopenClose();">
			<input type="button" name="Submit" value="Save" class="bluembutton bluembutton2"  onclick="formValidation('addclienttoquery','saveflight','0');"> 
		  <input name="action" type="hidden" id="action" value="saveLeadCorporate">
		  <input name="businessType" type="hidden" id="businessType" value="<?php echo $_REQUEST['clientType']; ?>">

		</td>
		</tr> 
		</table>
		</div>

	</tbody>
</table>

</form>

	
	
	<?php } ?>
</div>
</div>

<script>
    function closewindow(){
        $("#addAgentfromquery").hide();

    }
	$(function() {
	$("#birthDate").Zebra_DatePicker({
	format: 'd-m-Y', 
	});
	});
									

</script>


<?php } ?>

<style>
    
element.style {
}
.greybutton {
    background-color: #efefef;
    padding: 8px 26px !important;
    margin-left: 10px;
    margin-top:10px;
    outline: 0px;
    color: #000000!important;
    font-size: 14px;
    border: 1px #787877 solid;
    border-radius: 27px;
    cursor: pointer;
}
.bluembutton2{
    padding: 8px 26px !important;

}
</style>

<?php if($_GET['action']=='queryclose'){
if($_GET['queryId']!=''){
$id=($_GET['queryId']);
?>
<div class="contentclass">
<h1 style="text-align:left;">Change Query Status </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
<table border="0" cellpadding="2" cellspacing="0" style="margin-bottom:10px; margin-top:10px;">
  <tr>
    <td align="left"><label>
      <input name="changequerystatus" type="radio" value="3" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').hide();">
    </label></td>
    <td align="left">Query Confirmed</td>
    <td align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td align="left"><input name="changequerystatus" type="radio" value="4" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').hide();"></td>
    <td align="left">Query Lost</td>
    <td align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td align="left"><input name="changequerystatus" type="radio" value="5" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').show();"></td>
    <td align="left">Time Limit Booking </td>
  </tr>
  <tr>
    <td align="left"><label><input name="changequerystatus" type="radio" value="6" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').hide();$('#followquerydate').hide();"></label></td>
    <td align="left">Options Sent</td>
    <td align="left"></td>
    <td align="left"><label><input name="changequerystatus" type="radio" value="7"  onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').show();"></label></td>
    <td align="left">Follow-Up</td>
    <td align="left"></td>
    <td align="left"></td>
    <td align="left"></td>
    <td align="left"></td>
  </tr>
  <tr>
    <td align="left"></td>
    <td colspan="8" align="left"></td>
  </tr>
</table>
<div style="margin-bottom:10px; display:none;" id="textareiabox" class="shoqhidebuttonsquery">Remark:<textarea name="queryclosedetails" cols="" rows="" id="queryclosedetails" style="width:100%; height:60px; padding:10px; font-family:Arial, Helvetica, sans-serif; font-size:12px; border:1px #CCCCCC solid; box-sizing:border-box;" placeholder="Enter query related details"></textarea>
</div>
<div id="followquerydate" style="display:none;padding:0px !important;" >
<div class="griddiv"><label>
  <script>
 $(document).ready(function() {
$('#followupdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
	<div class="gridlable"  style="width:100%;">Follow-Up Date
	<input name="followupdate" type="text" id="followupdate" class="gridfield calfieldicon"  displayname="Date"   autocomplete="off" value="" style="width:100%;"/>
	</div>
	<div class="gridlable"  style="width:100%; margin-top:5px;">Follow-Up Time
	<select id="endtime" name="endtime" class="gridfield" autocomplete="off"   >
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
    <option value="<?php echo date('g:i A',$i); ?>" <?php if('11:00 AM'==date('g:i A',$i) && $_REQUEST['id']==''){  ?> selected="selected"<?php } ?> <?php if($editendtime==date('g:i A',$i)){ ?> selected="selected"<?php } ?>><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
</select>
	</div>
	<style>
	.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
	</label>
 </div>
</div>
<div style="overflow:hidden;">
  <input name="changestausidqueryid" type="hidden" id="changestausidqueryid" value="<?php echo $id; ?>">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; display:none;" class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Change Status    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
</form>
  </div>
</div>
<style>
input[type="radio"] {
    display: block;
}
</style>
	<?php } } ?>
<?php if($_GET['action']=='micequeryclose'){
if($_GET['queryId']!=''){
$id=($_GET['queryId']);
?>
<div class="contentclass">
<h1 style="text-align:left;">Change Query Status </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
<table border="0" cellpadding="2" cellspacing="0" style="margin-bottom:10px; margin-top:10px;">
  <tr>
    <td align="left"><label>
      <input name="changequerystatus" type="radio" value="3" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').hide();">
    </label></td>
    <td align="left">Query Confirmed</td>
    <td align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td align="left"><input name="changequerystatus" type="radio" value="4" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').hide();"></td>
    <td align="left">Query Lost</td>
    <td align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td align="left"><input name="changequerystatus" type="radio" value="5" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').show();"></td>
    <td align="left">Time Limit Booking </td>
  </tr>
  <tr>
    <td align="left"><label><input name="changequerystatus" type="radio" value="6" onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').hide();$('#followquerydate').hide();"></label></td>
    <td align="left">Options Sent</td>
    <td align="left"></td>
    <td align="left"><label><input name="changequerystatus" type="radio" value="7"  onClick="$('.shoqhidebuttonsquery').css('display','grid');$('#textareiabox').show();$('#followquerydate').show();"></label></td>
    <td align="left">Follow-Up</td>
    <td align="left"></td>
    <td align="left"></td>
    <td align="left"></td>
    <td align="left"></td>
  </tr>
  <tr>
    <td align="left"></td>
    <td colspan="8" align="left"></td>
  </tr>
</table>
<div style="margin-bottom:10px; display:none;" id="textareiabox" class="shoqhidebuttonsquery">Remark:<textarea name="queryclosedetails" cols="" rows="" id="queryclosedetails" style="width:100%; height:60px; padding:10px; font-family:Arial, Helvetica, sans-serif; font-size:12px; border:1px #CCCCCC solid; box-sizing:border-box;" placeholder="Enter query related details"></textarea>
</div>
<div id="followquerydate" style="display:none;padding:0px !important;" >
<div class="griddiv"><label>
  <script>
 $(document).ready(function() {
$('#followupdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
	<div class="gridlable"  style="width:100%;">Follow-Up Date
	<input name="followupdate" type="text" id="followupdate" class="gridfield calfieldicon"  displayname="Date"   autocomplete="off" value="" style="width:100%;"/>
	</div>
	<div class="gridlable"  style="width:100%; margin-top:5px;">Follow-Up Time
	<select id="endtime" name="endtime" class="gridfield" autocomplete="off"   >
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
    <option value="<?php echo date('g:i A',$i); ?>" <?php if('11:00 AM'==date('g:i A',$i) && $_REQUEST['id']==''){  ?> selected="selected"<?php } ?> <?php if($editendtime==date('g:i A',$i)){ ?> selected="selected"<?php } ?>><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
</select>
	</div>
	<style>
	.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
	</label>
 </div>
</div>
<div style="overflow:hidden;">
  <input name="micechangestausidqueryid" type="hidden" id="changestausidqueryid" value="<?php echo $id; ?>">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; display:none;" class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Change Status    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
</form>
  </div>
</div>
<style>
input[type="radio"] {
    display: block;
}
</style>
	<?php } } ?>
<!-- ------------------------------------------LOGIN USER DETAILS START------------------------------------------------ -->
	<?php if($_GET['action']=='viewlogin'){
 			 $userId=decode($_GET['userId']);
 			$fullname=($_GET['fullname']);
 			$datec=($_GET['dateCount']);
?>
<div class="contentclass">
<h1 style="text-align:left;">Login Date And Time Status&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $fullname; ?></strong></h1><hr>
<h1 style="text-align:left; margin-top: 8%;">&nbsp;&nbsp;&nbsp;&nbsp;Login Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login Time</h1>
  <div id="contentbox" style="max-height:340px; overflow:auto; text-align:left;  " >
  	<?php
			$selv ='SELECT * FROM userlogin WHERE userId="'.$userId.'" and dateCount="'.$datec.'" order by dateAdded desc ';
            $rslv = mysqli_query (db(),$selv) or die(mysqli_error(db()));
            $countv = mysqli_num_rows($rslv);
            if($countv > 0){
            	while ($row = mysqli_fetch_array($rslv)) {
            	?>
  <div class="selectParentList"><table width="100%" border="0" cellpadding="0" cellspacing="0">
            	<tr>
				    <td width="50%"><div class="name"><strong><?php echo $row['dateCount']; ?></strong></div>
			      </td>
				    <td width="50%"><div class="name"><strong><?php echo date('H:i:s',strtotime($row['dateAdded'])); ?></strong></div></td>
	    </tr>
</table></div>
            	<?php
            	}
            }
	 ?>
  </div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<script>
	function selectOwner(name,id){
	$('#ownerName').val(name);
	$('#assignTo').val(id);
	alertspopupopenClose();
	}
	</script>
	<?php } ?>
<!-- ------------------------------------------LOGIN USER DETAILS END--------------------------------------------------- -->
<?php if($_GET['action']=='paymentrequestqueryid'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Add Payment Request</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Enter Query ID <span class="redmind"></span></div>
	<input name="QueryId" type="text" class="gridfield validate" id="QueryId" onKeyUp="numericFilter(this);" value="" maxlength="6" displayname="Query ID" field_min_length="6"  />
	</label>
	<input name="addpaymentrequest" type="hidden" id="addpaymentrequest" value="1" />
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Continue    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='selectSupplier_paymentrequest'){
$paymentid=clean($_GET['paymentid']);
$night=clean($_GET['night']);
 $select2='supplierType';
$where2='id="'.$night.'"';
$rs2=GetPageRecord($select2,_QUERY_MASTER_,$where2);
$getdmc=mysqli_fetch_array($rs2);
?>
<div class="contentclass">
<h1 style="text-align:left;">Select Supplier </h1>
<div style="margin-bottom:5px;">
<div style="margin-bottom:20px;">
<select id="companyTypeId" name="companyTypeId" class="gridfield" displayname="Company Type" onchange="searchcompanynamefunc();" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
 <?php if($getdmc['supplierType']==2){ ?>
<!-- <option value="12">DMC</option>-->
 <?php }else{?>
 <?php  if($_REQUEST['suppliermainhotel']==1){ ?>
 <option value="1">Hotel</option>
 <?php  } else {
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_SUPPLIERS_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
 <?php  }
 } ?>
 <?php }?>
</select>
</div>
<input name="searchcompanyname" type="text" id="searchcompanyname" style="padding:10px; border:1px  #CCCCCC solid; width:100%; box-sizing:border-box;" placeholder="Enter Supplier Name,City, State" onkeyup="searchcompanynamefunc();" autocomplete="off" />
</div>
  <div   style="max-height:340px; overflow:auto; text-align:left;" id="loadcorporatecompany">
  <div style="text-align:center; color:#CCCCCC; padding:30px 0px;">Search Supplier Name</div>
  </div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td  >
		<?php if($_REQUEST['suppliermainhotel']!=1){ ?>
		<input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
		<?php } else { ?>
		<input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="$('#dmchotel<?php echo $_REQUEST['paymentid']; ?>').load('loaddmchotel.php?supsectionid=<?php echo $_REQUEST['paymentid']; ?>');" />
		<?php } ?>
		</td>
      </tr>
   </table>
</div></div>
	<script>
	function searchcompanynamefunc(){
	var searchcompanyname = encodeURIComponent($('#searchcompanyname').val());
	var companyTypeId = encodeURIComponent($('#companyTypeId').val());
	$('#loadcorporatecompany').load('loadsuppliercompany.php?searchcompanyname='+searchcompanyname+'&companyTypeId='+companyTypeId+'&paymentid=<?php echo $paymentid; ?>&night=<?php echo $night; ?>&suppliermainhotel=<?php echo $_REQUEST['suppliermainhotel']; ?>');
	}
	</script>
	<?php } ?>
<?php if($_GET['action']=='selectSupplier'){
$paymentid=clean($_GET['paymentid']);
$night=clean($_GET['night']);
$night=clean($_GET['userQueryId']);
$select2='supplierType,fromDate,toDate';
$where2='id="'.$night.'"';
$rs2=GetPageRecord($select2,_QUERY_MASTER_,$where2);
$getdmc=mysqli_fetch_array($rs2);
?>
<div class="contentclass">
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div style="margin-bottom:5px;">
	<div style="margin-bottom:20px;">
<table width="100%">
  <tr>
    <td width="50%" align="left"><select id="companyTypeId" name="companyTypeId" class="gridfield validate" displayname="Service" onchange="selcetservicefun();" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
 <option value="">Select Service</option>
 <?php //if($getdmc['supplierType']==2){ ?>
 <!--<option value="12">DMC</option>-->
 <?php //}else{?>
 <?php //if($_REQUEST['suppliermainhotel']==1){ ?>
<!-- <option value="1">Hotel</option>-->
 <?php //} else {
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_SUPPLIERS_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
 <?php }
// }
 // }?>
</select></td>
    <td width="50%" align="left" id="supplierIdtd" style="display:none;"><select id="supplierId" name="supplierId" class="gridfield" displayname="Service type"  autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
  <option value="">Select</option>
</select></td>
  </tr>
</table>
<table width="100%" id="hotelcolumns" style="display:none;">
  <tr>
    <td width="40%" align="left"><select id="roomType" name="roomType" class="gridfield"   autocomplete="off"  displayname="Room type"style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid;">
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 order by name asc';
$rs=GetPageRecord($select,_ROOM_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select></td>
 <td  align="left"><input name="supConfirmationNo" type="text" id="supConfirmationNo" class="textfieldsup"  value="" maxlength="200" placeholder="SUP Confirmation No."   style="padding:10px; border:1px  #CCCCCC solid;     width: 150px !important; box-sizing:border-box;"/></td>
    <td width="18%" align="left"><input name="fromDate" type="text" id="fromDate" placeholder="Check In"  style="padding:10px; border:1px  #CCCCCC solid;     width: 150px !important; box-sizing:border-box;"   class="textfieldsup calfieldicon"  displayname="Check In"   autocomplete="off" value="<?php echo date("d-m-Y",strtotime($getdmc['fromDate'])); ?>"/></td>
    <td width="18%" align="left"><input name="toDate" type="text" id="toDate" placeholder="Check Out" style="padding:10px; border:1px  #CCCCCC solid;  width: 150px !important;box-sizing:border-box;" class="textfieldsup calfieldicon" displayname="Check Out" autocomplete="off" value="<?php echo date("d-m-Y",strtotime($getdmc['toDate'])); ?>" /></td>
  </tr>
  <tr>
    <td colspan="4" align="left"><div style="margin-top:20px;"><h1 style="text-align:left;">Inclusion</h1>
   <div style="margin-bottom:20px; margin-bottom:0px;  padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
     <table border="0" cellpadding="4" cellspacing="0" id="allcheckbox<?php echo $listofsuppliers['id']; ?>" style="font-size:12px;">
      <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 order by name asc';
$rs=GetPageRecord($select,_AMENITIES_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
      <tr>
         <td align="left"><input type="checkbox" id="c<?php echo $resListing['id']; ?><?php echo $listofsuppliers['id']; ?>" name="check_listaminities<?php echo $listofsuppliers['id']; ?>[]" class="chk"  value="<?php echo ($resListing['id']); ?>" style="display:block;"/></td>
         <td align="left"><?php echo $resListing['name']; ?></td>
       </tr>
	   <?php } ?>
     </table>
	 <script>
   $('#checkallcheckbox<?php echo $listofsuppliers['id']; ?>').click(function(event) {
    if(this.checked) {
        // Iterate each checkbox
        $('#allcheckbox<?php echo $listofsuppliers['id']; ?> :checkbox').each(function() {
            this.checked = true;
        });
    }
});
   </script>
	 <div style="margin-top:10px; text-align:left; font-size:13px;">
	 Special Request
	 <input name="specialrequest<?php echo $listofsuppliers['id']; ?>"  class="gridfield" id="specialrequest<?php echo $listofsuppliers['id']; ?>" size="200" maxlength="180" style="width:100%; box-sizing:border-box; padding:6px; margin-top:5px;">
	 </div>
   </div></div></td>
    </tr>
</table>
<table width="100%" id="flightcolumns" style="display:none;">
  <tr>
    <td width="33%" align="left"><input name="flightName" type="text" id="flightName" class="textfieldsup"  value="" maxlength="200" placeholder="Flight Name" displayname="Flight Name"   style="padding:10px; border:1px  #CCCCCC solid;     box-sizing:border-box;"/></td>
	 <td  width="33%" align="left"><input name="flightNumber" type="text" id="flightNumber" class="textfieldsup"  value="" maxlength="200" placeholder="Flight No." displayname="Flight No."    style="padding:10px; border:1px  #CCCCCC solid;    box-sizing:border-box;"/></td>
    <td width="33%" align="left"><input name="flightDate" type="text" id="flightDate" placeholder="Flight Date" displayname="Flight Date"   style="padding:10px; border:1px  #CCCCCC solid;    box-sizing:border-box;"   class="textfieldsup calfieldicon"   autocomplete="off" value="<?php echo date("d-m-Y",strtotime($getdmc['fromDate'])); ?>"/></td>
  </tr>
</table>
<table width="100%" id="transfercolumns" style="display:none;">
  <tr>
    <td width="50%" align="left"><select id="transferId" name="transferId" class="gridfield"   autocomplete="off"  displayname="Transfer type"style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid;" >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' name!="" and deletestatus=0  order by name';
$rs=GetPageRecord($select,_TRANSFER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select></td>
    <td width="50%" align="left"><input name="transferDate" type="text" id="transferDate" placeholder="Transfer Date" displayname="Transfer Date"  style="padding:10px; border:1px  #CCCCCC solid;  box-sizing:border-box;"   class="textfieldsup calfieldicon"   autocomplete="off" value="<?php echo date("d-m-Y",strtotime($getdmc['fromDate'])); ?>"/></td>
  </tr>
</table>
<table width="100%" id="sightseeingcolumns" style="display:none;">
  <tr>
    <td width="33%" align="left"><select id="sightseeingId" name="sightseeingId" class="gridfield"   autocomplete="off"  displayname="Sightseeing type" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid;" >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' name!="" and deletestatus=0 order by name';
$rs=GetPageRecord($select,_SIGHTSEEING_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select></td>
    <td width="33%" align="left"><input name="sightseeingDate" type="text" id="sightseeingDate" placeholder="Sightseeing Date" displayname="Sightseeing Date"  style="padding:10px; border:1px  #CCCCCC solid;      box-sizing:border-box;"   class="textfieldsup calfieldicon"   autocomplete="off" value="<?php echo date("d-m-Y",strtotime($getdmc['fromDate'])); ?>"/></td>
		 <td width="33%" align="left"><select id="sightSeeingTime" name="sightSeeingTime" class="gridfield"   autocomplete="off"  displayname="Sightseeing time" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid;">
<option value="">Select time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    {
	 if($starttime==date('g:i A',$i)){ $strtTimeSelected='selected="selected"';}else{ $strtTimeSelected="";}
	?>
   <option value="<?php echo date('g:i A',$i); ?>" <?php echo $strtTimeSelected;?> ><?php echo date('g:i A',$i); ?></option>
    <?php  }  ?>
</select></td>
  </tr>
</table>
	</div>
<input type="hidden" name="paymentid" id="paymentid" value="<?php echo $paymentid; ?>" />
<input type="hidden" name="night" id="night" value="<?php echo $night; ?>" />
<input type="hidden" name="voucherid" id="voucherid" value="<?php echo $_REQUEST['voucherid']; ?>" />
<input type="hidden" name="userSupplierType" id="userSupplierType" value="<?php echo $getdmc['supplierType']; ?>" />
<input type="hidden" name="action" id="action" value="addvoucherdata" />
<input type="hidden" name="mainsupplierId" id="mainsupplierId" value="<?php echo $_REQUEST['mainsupplierId']; ?>" />
</div>
</form>
  <div  style="max-height:340px; overflow:auto; text-align:left;" id="loadcorporatecompany">
  <!--<div style="text-align:center; color:#CCCCCC; padding:30px 0px;">Search Supplier Name</div>-->
  </div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td  >
		<input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');">
		<?php if($_REQUEST['suppliermainhotel']!=1){ ?>
		<input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
		<?php } else { ?>
		<input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="$('#dmchotel<?php echo $_REQUEST['voucherid']; ?>').load('loaddmchotel.php?voucherid=<?php echo $_REQUEST['voucherid']; ?>');" />
		<?php } ?>
		</td>
      </tr>
   </table>
</div></div>
	<script>
	function selcetservicefun(){
	var searchcompanyname = encodeURIComponent($('#searchcompanyname').val());
	var companyTypeId = encodeURIComponent($('#companyTypeId').val());
	var userSupplierType = encodeURIComponent($('#userSupplierType').val());
		if(companyTypeId==1)
		{
			$('#hotelcolumns').show();
			$('#flightcolumns').hide();
			$('#transfercolumns').hide();
			$('#sightseeingcolumns').hide();
			$('#fromDate').addClass('validate');
			$('#toDate').addClass('validate');
			$('#flightName').removeClass('validate');
			$('#flightNumber').removeClass('validate');
			$('#flightDate').removeClass('validate');
			$('#transferDate').removeClass('validate');
			$('#sightseeingDate').removeClass('validate');
			$('#supplierId').attr('displayname','Hotel');
		}
		else if(companyTypeId==2)
		{
			$('#hotelcolumns').hide();
			$('#flightcolumns').show();
			$('#transfercolumns').hide();
			$('#sightseeingcolumns').hide();
			$('#fromDate').removeClass('validate');
			$('#toDate').removeClass('validate');
			$('#flightName').addClass('validate');
			$('#flightNumber').addClass('validate');
			$('#flightDate').addClass('validate');
			$('#transferDate').removeClass('validate');
			$('#sightseeingDate').removeClass('validate');
			$('#supplierId').attr('displayname','Airlines');
		}
		else if(companyTypeId==10)
		{
			$('#hotelcolumns').hide();
			$('#flightcolumns').hide();
			$('#transfercolumns').show();
			$('#sightseeingcolumns').hide();
			$('#fromDate').removeClass('validate');
			$('#toDate').removeClass('validate');
			$('#flightName').removeClass('validate');
			$('#flightNumber').removeClass('validate');
			$('#flightDate').removeClass('validate');
			$('#transferDate').addClass('validate');
			$('#sightseeingDate').removeClass('validate');
			$('#supplierId').attr('displayname','Transfer');
		}
		else if(companyTypeId==11)
		{
			$('#hotelcolumns').hide();
			$('#flightcolumns').hide();
			$('#transfercolumns').hide();
			$('#sightseeingcolumns').show();
			$('#fromDate').removeClass('validate');
			$('#toDate').removeClass('validate');
			$('#flightName').removeClass('validate');
			$('#flightNumber').removeClass('validate');
			$('#flightDate').removeClass('validate');
			$('#transferDate').removeClass('validate');
			$('#sightseeingDate').addClass('validate');
			$('#supplierId').attr('displayname','Sightseeing');
		}
		else if(companyTypeId=='')
		{
			$('#hotelcolumns').hide();
			$('#flightcolumns').hide();
			$('#transfercolumns').hide();
			$('#sightseeingcolumns').hide();
			$('#fromDate').removeClass('validate');
			$('#toDate').removeClass('validate');
			$('#flightName').removeClass('validate');
			$('#flightNumber').removeClass('validate');
			$('#flightDate').removeClass('validate');
			$('#transferDate').removeClass('validate');
			$('#sightseeingDate').removeClass('validate');
			$('#supplierId').attr('displayname','');
		}
		if((companyTypeId==1 && userSupplierType==2) || userSupplierType==1)
		{
			$('#supplierIdtd').show();
			$('#supplierId').addClass('validate');
		$('#supplierId').load('loadsuppliercompany_services.php?searchcompanyname='+searchcompanyname+'&companyTypeId='+companyTypeId+'&paymentid=<?php echo $paymentid; ?>&night=<?php echo $night; ?>&suppliermainhotel=<?php echo $_REQUEST['suppliermainhotel']; ?>&voucherid=<?php echo $_REQUEST['voucherid']; ?>&userSupplierType='+userSupplierType);
		}
		else
		{
			$('#supplierIdtd').hide();
			$('#supplierId').removeClass('validate');
		}
	}
	</script>
	<!--<script>
	function searchcompanynamefunc(){
	var searchcompanyname = encodeURIComponent($('#searchcompanyname').val());
	var companyTypeId = encodeURIComponent($('#companyTypeId').val());
	$('#loadcorporatecompany').load('loadsuppliercompany_voucher.php?searchcompanyname='+searchcompanyname+'&companyTypeId='+companyTypeId+'&paymentid=<?php echo $paymentid; ?>&night=<?php echo $night; ?>&suppliermainhotel=<?php echo $_REQUEST['suppliermainhotel']; ?>&voucherid=<?php echo $_REQUEST['voucherid']; ?>');
	}
	</script>-->
<script>
$(document).ready(function() {
$('#toDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#fromDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#flightDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#transferDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#sightseeingDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
});
//$('.Zebra_DatePicker_Icon_Wrapper').removeAttr('style','position: relative;float: none; top: auto; right: auto; bottom: auto; left: auto;');
</script>
<?php } ?>
<?php if($_GET['action']=='addsupplierinpaymentrequest' && $_GET['supplierid']!='' && $_GET['paymentid']!=''){
$paymentid=clean($_GET['paymentid']);
$companyTypeId=clean($_GET['companyTypeId']);
$select1='*';
$where1='id='.$_REQUEST['night'].'';
$rs1=GetPageRecord($select1,_QUERY_MASTER_,$where1);
$editqueryId=mysqli_fetch_array($rs1);
if($_GET['supplierid']!=''){
$id=$_GET['supplierid'];
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_SUPPLIERS_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
$editassignTo=clean($editresult['assignTo']);
$editname=clean($editresult['name']);
$editcontactPerson=clean($editresult['contactPerson']);
$editcompanyTypeId=clean($editresult['companyTypeId']);
$editcountryId=clean($editresult['countryId']);
$editstateId=clean($editresult['stateId']);
$editcityId=clean($editresult['cityId']);
$edittitle=clean($editresult['title']);
$addedBy=clean($editresult['addedBy']);
$dateAdded=clean($editresult['dateAdded']);
$modifyBy=clean($editresult['modifyBy']);
$modifyDate=clean($editresult['modifyDate']);
$editaddress1=clean($editresult['address1']);
$editaddress2=clean($editresult['address2']);
$editaddress3=clean($editresult['address3']);
$editpinCode=clean($editresult['pinCode']);
$editgstn=clean($editresult['gstn']);
$editagreement=clean($editresult['agreement']);
$editid=clean($editresult['id']);
$supplierMainType=clean($editresult['supplierMainType']);
}
?>
<script>
 $(document).ready(function() {
$('#paymentreminderdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#paymentdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<div class="contentclass">
<h1 style="text-align:left;">Supplier Information </h1>
<div style=" margin-bottom: 10px;  padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
<table border="0" cellpadding="5" cellspacing="0" style="font-size:13px;">
  <tr>
    <td align="left" valign="top" class="lightgraytextm">Supplier Type</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php //if($supplierMainType==1){ echo 'Individual'; } else { echo 'DMC'; } ?></td>
    <td align="left" valign="top">&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Contact Person </td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo $editcontactPerson; ?></td>
    <td align="left" valign="top">&nbsp;&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Located</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo getCityName($editcountryId); ?>, <?php echo getStateName($editstateId); ?>, <?php echo $editpinCode; ?> <?php echo getCountryName($editcountryId); ?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="lightgraytextm">Supplier&nbsp;Services </td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo getsuppliersTypeNameList($editid); ?></td>
    <td align="left" valign="top">&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Contact No.</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo getPrimaryPhone($editid,'suppliers'); ?></td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Address</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo $editaddress1; ?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="lightgraytextm"><span class="gridlable">Company</span></td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo $editname; ?></td>
    <td align="left" valign="top">&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Email Id</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo getPrimaryEmail($editid,'suppliers'); ?></td>
    <td align="left" valign="top">&nbsp;</td>
   <td align="left" valign="top" class="lightgraytextm"><span class="gridlable">GSTN</span></td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top"><?php echo $editgstn; ?></td>
  </tr>
</table>
</div>
 <?php
	  $nod=1;
$select='*';
$where='masterId='.$editid.' and sectionType="suppliers" and primaryvalue=1 order by id desc';
$rs=GetPageRecord($select,_BANK_DETAILS_MASTER_,$where);
while($usermasterdocument=mysqli_fetch_array($rs)){
?>
<h1 style="text-align:left;">Bank Details  </h1>
<div style="margin-bottom:10px;    padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
<table border="0" cellpadding="5" cellspacing="0" style="font-size:13px;">
  <tr>
    <td align="left" valign="top" class="lightgraytextm">Bank Name</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['bankName']); ?>  </td>
    <td align="left" valign="top">&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">IFSC Code</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top">
	 <?php echo strip($usermasterdocument['IFSCCode']); ?> </td>
    <td align="left" valign="top">&nbsp;&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Email Id</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['email']); ?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="lightgraytextm">Branch</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['branch']); ?></td>
    <td align="left" valign="top">&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Address</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['address']); ?></td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Swift Code</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['swiftCode']); ?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="lightgraytextm"><span class="gridlable">Account No.</span></td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['accountNumber']); ?></td>
    <td align="left" valign="top">&nbsp;&nbsp;</td>
    <td align="left" valign="top" class="lightgraytextm">Phone No.</td>
    <td align="left" valign="top" class="lightgraytextm">:</td>
    <td align="left" valign="top"><?php echo strip($usermasterdocument['phoneNumber']); ?></td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
</table>
</div>
<?php } ?>
<script>
 $(document).ready(function() {
$('#toDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#fromDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
<h1 style="text-align:left;">Payment Details</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
 <div style="margin-bottom:0px; margin-bottom:0px;  padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
 <?php
 if($editqueryId['clientType']==1){
$select1='stateId,name';
$where1='id='.$editqueryId['companyId'].'';
$rs1=GetPageRecord($select1,_CORPORATE_MASTER_,$where1);
$editqueryClient=mysqli_fetch_array($rs1);
 }
  if($editqueryId['clientType']==2){
$select1='stateId,firstName,lastName';
$where1='id='.$editqueryId['companyId'].'';
$rs1=GetPageRecord($select1,_CONTACT_MASTER_,$where1);
$editqueryClient=mysqli_fetch_array($rs1);
 }
if($_REQUEST['supplierstateId']=='' || $_REQUEST['supplierstateId']=='null'){
$select1='name';
$where1='id='.$editqueryClient['stateId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$editqueryClientState=mysqli_fetch_array($rs1);
} else {
$select1='name';
$where1='id='.$_REQUEST['supplierstateId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$editqueryClientState=mysqli_fetch_array($rs1);
}
$select1='name';
$where1='id='.$_REQUEST['selfId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$selfstate=mysqli_fetch_array($rs1);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3" valign="top"><table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:15px;">
      <tr>
        <td colspan="6">Invoice State: <strong><?php echo $editqueryClientState['name']; ?></strong></td>
        <td colspan="5"><strong>Tax Type </strong></td>
        </tr>
      <tr>
        <td colspan="11" style="padding-bottom:5px;"></td>
        </tr>
      <tr>
        <td><?php if($companyTypeId==1){ ?>Check In<?php } else { ?>
          Date
          <?php } ?>: </td>
        <td><input name="fromDate" type="text" id="fromDate"   class="textfieldsup calfieldicon validate"  displayname="Check In"   autocomplete="off" value="<?php echo date('d-m-Y',strtotime($editqueryId['fromDate'])); ?>" style="width:110px;"/></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
     <?php if($companyTypeId==1){ ?>   <td><?php if($companyTypeId==1){ ?>Check Out<?php } else { ?>
          Date
          <?php } ?>: </td>
        <td><input name="toDate" type="text" id="toDate" class="textfieldsup calfieldicon" displayname="Check Out" autocomplete="off" value="<?php echo date('d-m-Y',strtotime($editqueryId['toDate'])); ?>" style="width:110px;" /></td>
		<?php } ?>
		 <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 <td><input name="touropratorgst" type="radio" value="1"  style="display:block;" id="touropratorgst" onclick="changetouropratorgst();Suppliercalculatecost();" /></td>
		  <td>GST 5%</td>
		  <td>&nbsp;&nbsp;&nbsp;</td>
		  <td><input name="touropratorgst" type="radio" value="2"  style="display:block;" id="touropratorgst2"  onclick="changetouropratorgst();Suppliercalculatecost();"/></td>
		  <td>GST 18%</td>
      </tr>
    </table>
	<script>
	function changetouropratorgst(){
	var touropratorgst='';
	if($('#touropratorgst').is(':checked')) {
	 touropratorgst = $('#touropratorgst').val();
	}
	if($('#touropratorgst2').is(':checked')) {
	 touropratorgst = $('#touropratorgst2').val();
	}
	if('<?php echo $editqueryClientState['name']; ?>'=='<?php echo $selfstate['name']; ?>' && touropratorgst==1){
	$('#suppliercgst').val('0');
	$('#suppliersgst').val('0');
	$('#supplierigst').val('0');
	$('#suppliercgst').val('2.5');
	$('#suppliersgst').val('2.5');
	}
	if('<?php echo $editqueryClientState['name']; ?>'!='<?php echo $selfstate['name']; ?>' && touropratorgst==1){
	$('#suppliercgst').val('0');
	$('#suppliersgst').val('0');
	$('#supplierigst').val('5');
	}
	var suppliertotalcost = Number($('#supplierpernight').val());
 //$('#showalert').text(suppliertotalcost);
	if('<?php echo $editqueryClientState['name']; ?>'=='<?php echo $selfstate['name']; ?>' && touropratorgst==2 && suppliertotalcost!=''){
	$('#suppliercgst').val('0');
	$('#suppliersgst').val('0');
	$('#supplierigst').val('0');
	if(suppliertotalcost<1000){
	$('#suppliercgst').val('9');
	$('#suppliersgst').val('9');
	}
	if(suppliertotalcost>999 && suppliertotalcost<2500){
	$('#suppliercgst').val('9');
	$('#suppliersgst').val('9');
	}
	if(suppliertotalcost>2499 && suppliertotalcost<7500){
	$('#suppliercgst').val('9');
	$('#suppliersgst').val('9');
	}
	if(suppliertotalcost>7499){
	$('#suppliercgst').val('9');
	$('#suppliersgst').val('9');
	}
	}
	if('<?php echo $editqueryClientState['name']; ?>'!='<?php echo $selfstate['name']; ?>' && touropratorgst==2 && suppliertotalcost!=''){
	$('#suppliercgst').val('0');
	$('#suppliersgst').val('0');
	$('#supplierigst').val('0');
	if(suppliertotalcost<1000){
	$('#supplierigst').val('18');
	}
	if(suppliertotalcost>999 && suppliertotalcost<2500){
	$('#supplierigst').val('18');
	}
	if(suppliertotalcost>2499 && suppliertotalcost<7500){
	$('#supplierigst').val('18');
	}
	if(suppliertotalcost>7499){
	$('#supplierigst').val('18');
	}
	}
	}
	</script>	</td>
  </tr>
  <tr>
    <td colspan="3" valign="top" style=" border-top: 2px #ccc solid;">&nbsp;</td>
    </tr>
  <tr>
    <td valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="4"><strong>Cost to Client </strong></td>
    </tr>
  <tr>
    <td ><div class="textflablesup" <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?> ><?php if($editqueryId["supplierType"]==1){?><?php if($companyTypeId==1){ ?>Rooms<?php }  ?><?php if($companyTypeId==2){ ?>Name<?php }  ?><?php if($companyTypeId==10){ ?>Name<?php }  ?><?php if($companyTypeId==11){ ?>Name<?php }  }else{?>Package Name<?php }?>
	    <input name="suppliernorooms" type="text" class="textfieldsup <?php if($companyTypeId==1){?>validate<?php } ?>" <?php if($companyTypeId!=1){ ?>style="display:none;"<?php } ?> displayname="Rooms" id="suppliernorooms" onkeyup="Suppliercalculatecost();" onblur="Suppliercalculatecost();" value="<?php if($editqueryId["supplierType"]==2){ echo '1'; } else { ?><?php if($companyTypeId==1){ echo $editqueryId['rooms']; } else { echo '1';  } } ?>" />
		<input name="suppliername" type="text" class="textfieldsup"  displayname="Name" id="suppliername" onkeyup="Suppliercalculatecost();namecopytocompany();" onblur="Suppliercalculatecost();namecopytocompany();" value="" maxlength="200" style="    width: 130px; display:none; <?php if($companyTypeId!=1){ ?>display:block;<?php } ?>"/>
		<script>
		function namecopytocompany(){
		var suppliername2 = $('#suppliername').val();
		var compsuppliername2 = $('#compsuppliername').val('');
		$('#compsuppliername').val(suppliername2);
		}
		</script>
	</div></td>
    <td  <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?> ><div class="textflablesup"><?php if($companyTypeId==1){ ?>No. of Nights<?php } else { ?>No of Pax<?php } ?>
	<input name="suppliernonight" type="text"  class="textfieldsup validate"  displayname="No. of Nights" id="suppliernonight" onkeyup="numericFilter(this);Suppliercalculatecost();" onblur="Suppliercalculatecost();" value="<?php if($editqueryId["supplierType"]==2){ echo '1'; } else { ?><?php echo $editqueryId['night']; } ?>" maxlength="3" />
	</div></td>
    <td><div class="textflablesup"><?php if($editqueryId["supplierType"]==1){?><?php if($companyTypeId==1){ ?>Per Night Cost<?php } else { ?>Per Pax Cost <?php } ?>
	    <?php }else{?>Package Cost<?php }?><span id="showalert"></span><input name="supplierpernight"  displayname="Per Night Cost" type="text" class="textfieldsup validate" id="supplierpernight"  onkeyup="numericFilter(this);Suppliercalculatecost();" onblur="Suppliercalculatecost();"  maxlength="10"/>
	</div></td>
    <td><div class="textflablesup">Cost
        <input name="suppliertotalcost" type="text" class="textfieldsup validate"   displayname="Cost" id="suppliercost"   />
	</div></td>
  </tr>
  <tr>
    <td></td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">Tax CGST %</div> </td>
    <td><input name="suppliercgst" type="text" class="textfieldsup" id="suppliercgst"  onkeyup="numericFilter(this);Suppliercalculatecost();" onblur="Suppliercalculatecost();"  maxlength="3"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">SGST %</div></td>
    <td><input name="suppliersgst" type="text" class="textfieldsup" id="suppliersgst"  onkeyup="numericFilter(this);Suppliercalculatecost();"  onblur="Suppliercalculatecost();" maxlength="3"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">IGST %</div></td>
    <td><input name="supplierigst" type="text" class="textfieldsup" id="supplierigst" onkeyup="numericFilter(this);Suppliercalculatecost();" onblur="Suppliercalculatecost();"  maxlength="3" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">Total Cost</div></td>
    <td><input name="suppliertoalcost" type="text" class="textfieldsup validate" id="suppliertoalcost" readonly="readonly"  displayname="Total Cost" /></td>
  </tr>
</table></td>
    <td valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td><table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="4"><strong>Cost to Company </strong></td>
    </tr>
  <tr>
    <td><div class="textflablesup" <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?> ><?php if($editqueryId["supplierType"]==1){?><?php if($companyTypeId==1){ ?>Rooms<?php }  ?><?php if($companyTypeId==2){ ?>
      Name
       <?php }  ?><?php if($companyTypeId==10){ ?>
       Name
       <?php }  ?><?php if($companyTypeId==11){ ?>
        Name
        <?php }  ?>
	<?php }else{?>Package Name<?php }?>
	    <input name="companynorooms" type="text" class="textfieldsup <?php if($companyTypeId==1){?>validate<?php } ?>" id="companynorooms" onkeyup="Suppliercalculatecost();" onblur="Suppliercalculatecost();" value="<?php if($editqueryId["supplierType"]==2){ echo '1'; } else { ?><?php if($companyTypeId==1){ echo $editqueryId['rooms']; } else { echo '1'; } ?>" displayname="Company Rooms" <?php if($companyTypeId!=1){ ?>style="display:none;"<?php } } ?>/>
	<input name="compsuppliername" type="text" class="textfieldsup"  displayname="Name" id="compsuppliername"  value="" maxlength="200" style="    width: 130px; display:none; <?php if($companyTypeId!=1){ ?>display:block;<?php } ?>"/>
	</div></td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>><div class="textflablesup"><?php if($companyTypeId==1){ ?>No. of Nights<?php } else { ?>No of Pax<?php } ?>
	<input name="companynonight" type="text" displayname="Company  No. of Nights" class="textfieldsup validate" id="companynonight" onkeyup="numericFilter(this);Companycalculatecost();" onblur="Companycalculatecost();" value="<?php if($editqueryId["supplierType"]==2){ echo '1'; } else { ?><?php echo $editqueryId['night']; } ?>" maxlength="3"/>
	</div></td>
    <td><div class="textflablesup"><?php if($editqueryId["supplierType"]==1){?><?php if($companyTypeId==1){ ?>Per Night Cost<?php } else { ?>Per Pax Cost <?php } ?>
	    <?php }else{?>Package Cost<?php }?>
	    <input name="companypernight" type="text" class="textfieldsup validate"  displayname="Company Per Night Cost" id="companypernight" onkeyup="numericFilter(this);Companycalculatecost();"  onblur="Companycalculatecost();" maxlength="10" />
	</div></td>
    <td><div class="textflablesup">Cost
        <input name="companytotalcost" type="text" class="textfieldsup validate" id="companycost"  readonly="readonly"  displayname="Company Cost"/>
	</div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">Tax CGST %</div> </td>
    <td><input name="companycgst" type="text" class="textfieldsup" id="companycgst" onkeyup="numericFilter(this);Companycalculatecost();" maxlength="3"  onblur="Companycalculatecost();"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">SGST %</div></td>
    <td><input name="companysgst" type="text" class="textfieldsup" id="companysgst" onkeyup="numericFilter(this);Companycalculatecost();" maxlength="3"  onblur="Companycalculatecost();"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">IGST %</div></td>
    <td><input name="companyigst" type="text" class="textfieldsup" id="companyigst" onkeyup="numericFilter(this);Companycalculatecost();" maxlength="3"  onblur="Companycalculatecost();"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td <?php if($editqueryId["supplierType"]==2){?>style="display:none"<?php } ?>>&nbsp;</td>
    <td align="right"><div class="textflablesup">Total Cost</div></td>
    <td><input name="companytoalcost" type="text" class="textfieldsup validate" id="companytoalcost" readonly="readonly"   displayname="Company Total Cost"/></td>
  </tr>
</table></td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
    <td valign="top">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr id="grossprofitouterdiv" style="display:none;">
    <td colspan="3" valign="top" >
	<div  style="padding:10px;  border-top: 2px #ccc solid; border-bottom: 2px #ccc solid;"><table width="100%">
  <tr>
    <td><span style="float:left;">Gross Margin: <span id="grossprofitdiv" style="font-size:16px; font-weight:bold;"></span></span></td>
    <td><span style="float:right;">Total Profit: <span id="profit" style="font-size:16px; font-weight:bold;"></span></span>  </td>
  </tr>
</table>
</div>
	</td>
    </tr>
  <tr>
    <td valign="top">&nbsp;</td>
    <td valign="top">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
 </div>
  </div>
  <h1 style="text-align:left; padding-top:10px;">Supplier Invoice</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
  <div style="margin-bottom:0px; margin-bottom:0px;  padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
  <table border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>Upload Supplier Invoice:&nbsp; </td>
    <td><input name="supplierInvoice" type="file" id="supplierInvoice" class="textfieldsup"/></td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td>Supplier Invoice Amount:&nbsp;</td>
    <td><input name="supplierAmount" type="text" class="textfieldsup" id="supplierAmount" onkeyup="numericFilter(this);Suppliercalculatecost();" onblur="Suppliercalculatecost();"  maxlength="10" /></td>
  </tr>
</table>
  </div>
  </div>
  <h1 style="text-align:left; display:none;">Payment Mode</h1>
<div style="margin-bottom:0px;    padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td align="left" valign="top" style="display:none;"><table border="0" cellpadding="5" cellspacing="0" style="font-size:12px;">
      <tr>
        <td><input name="paymentmode" type="radio" value="1" style="display:block;" /></td>
        <td>Direct by guest&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td><input name="paymentmode" type="radio" value="2" style="display:block;" /></td>
        <td>Payment before Check In&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td><input name="paymentmode" type="radio" value="3" style="display:block;" /></td>
        <td>Payment after Check Out&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td><input name="paymentmode" type="radio" style="display:block;" value="4" checked="checked" /></td>
        <td>Billed to Company (Credit)</td>
      </tr>
      <tr>
        <td colspan="8"></td>
        </tr>
    </table>
      <div class="textflablesup"></div></td>
    </tr>
  <tr>
    <td align="left" valign="top"><table border="0" cellpadding="5" cellspacing="0" style="font-size:12px;">
        <tr>
          <td><div class="textflablesup">Payment Date </div></td>
          <td><span class="textflablesup">
            <input name="paymentdate" type="text" class="textfieldsup" id="paymentdate" value="<?php echo date('d-m-Y', strtotime('-1 day', strtotime($editqueryId['fromDate']))); ?>" />
          </span></td>
          <td><div class="textflablesup">Payment Reminder Date </div></td>
          <td><span class="textflablesup">
            <input name="paymentreminderdate" type="text" class="textfieldsup" id="paymentreminderdate" value="<?php echo date('d-m-Y', strtotime('-2 day', strtotime($editqueryId['fromDate']))); ?>" />
          </span></td>
          </tr>
        <tr style="display:none;">
          <td colspan="4"><input name="commissionable" type="radio" style="display:inline;" value="1" checked="checked" />
            Commissionable&nbsp;&nbsp;&nbsp;&nbsp;<input name="commissionable" type="radio" value="2" style="display:inline;" />
            Non Commissionable</td>
          </tr>
      </table>
      <input name="paymentId" type="hidden" id="paymentId" value="<?php echo $paymentid; ?>" /></td>
      <input name="supplierId" type="hidden" id="supplierId" value="<?php echo $editid; ?>" />
      <input name="selfId" type="hidden" id="supplierId" value="<?php echo $_REQUEST['selfId']; ?>" />

      <input name="supplierstateId" type="hidden" id="supplierstateId" value="<?php echo $_REQUEST['supplierstateId']; ?>" />
      <input name="companystateId" type="hidden" id="companystateId" value="<?php echo $_REQUEST['companystateId']; ?>" />
      <input name="companyTypeId" type="hidden" id="companyTypeId" value="<?php echo $_REQUEST['companyTypeId']; ?>" />
	  <input name="action" type="hidden" id="action" value="addspliertopaymentlist" />
	  </td>
  </tr>
</table>
  </div>
  </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div> </div>
<script>
function Suppliercalculatecost(){
var suppliernonight = $('#suppliernonight').val();
var supplierpernight = $('#supplierpernight').val();
var suppliercost = $('#suppliercost').val();
var companynorooms = $('#companynorooms').val();
var suppliertoalcost = $('#suppliertoalcost').val();
var companynonight = $('#companynonight').val();
var companypernight = $('#companypernight').val();
var companycost = $('#companycost').val();
var companycgst = $('#companycgst').val();
var companysgst = $('#companysgst').val();
var companyigst = $('#companyigst').val();
var companytoalcost = $('#companytoalcost').val();
var companynorooms = $('#companynorooms').val();
if(suppliernonight!='' &&  supplierpernight!=''){
var cost = Number(suppliernonight*supplierpernight*companynorooms);
var companycost = Number(companynonight*companypernight*companynorooms);
var grosscost = Number(cost-companycost);
$('#suppliercost').val(cost);
changetouropratorgst();
var suppliercgst = $('#suppliercgst').val();
var suppliersgst = $('#suppliersgst').val();
var supplierigst = $('#supplierigst').val();
var suppliercgst_cost=0;
var suppliersgst_cost=0;
var supplierigst_cost=0;
if(suppliercgst!=''){
suppliercgst_cost = Number(grosscost/100*suppliercgst);
}
if(suppliersgst!=''){
suppliersgst_cost = Number(grosscost/100*suppliersgst);
}
if(supplierigst!=''){
supplierigst_cost = Number(grosscost/100*supplierigst);
}
var sototalcost = Number(cost+suppliercgst_cost+suppliersgst_cost+supplierigst_cost);
$('#suppliertoalcost').val(sototalcost);
}
showgrossprofit();
profit();
}
function showgrossprofit(){
var companytotalcost = $('#companycost').val();
var suppliertotalcost = $('#suppliercost').val();
if(suppliertotalcost!=''){
$('#grossprofitouterdiv').show();
} else{
$('#grossprofitouterdiv').hide();
}
$('#grossprofitdiv').text(Number(suppliertotalcost-companytotalcost));
var grossprofitdiv = Number($('#grossprofitdiv').text());
if(grossprofitdiv>0){
$('#grossprofitdiv').css('color','#17940a');
} else {
$('#grossprofitdiv').css('color','#c70606');
}
}
function profit(){
var companytotalcost = $('#companycost').val();
var suppliertotalcost = $('#suppliercost').val();
if(suppliertotalcost!=''){
$('#profit').show();
} else{
$('#profit').hide();
}
$('#profit').text(Number(suppliertotalcost-companytotalcost));
var grossprofitdiv = Number($('#profit').text());
if(grossprofitdiv>0){
$('#profit').css('color','#17940a');
} else {
$('#profit').css('color','#c70606');
}
}
function Companycalculatecost(){
var companynonight = $('#companynonight').val();
var companypernight = $('#companypernight').val();
var companycost = $('#companycost').val();
var companycgst = $('#companycgst').val();
var companysgst = $('#companysgst').val();
var companyigst = $('#companyigst').val();
var companytoalcost = $('#companytoalcost').val();
var companynorooms = $('#companynorooms').val();
if(companynonight!='' &&  companypernight!=''){
var cost = Number(companynonight*companypernight*companynorooms);
$('#companycost').val(cost);
var companycgst_cost=0;
var companysgst_cost=0;
var companyigst_cost=0;
if(companycgst!=''){
companycgst_cost = Number(cost/100*companycgst);
}
if(companysgst!=''){
companysgst_cost = Number(cost/100*companysgst);
}
if(companyigst!=''){
companyigst_cost = Number(cost/100*companyigst);
}
var sototalcost = Number(cost+companycgst_cost+companysgst_cost+companyigst_cost);
$('#companytoalcost').val(sototalcost);
}
showgrossprofit();
profit();
}
<?php if($editqueryId["supplierType"]==2){ ?>
$('#suppliernorooms').val('1');
$('#companynorooms').val('1');
<?php } ?>
</script>
<?php } ?>
<?php if($_GET['action']=='invoicequeryid'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Add Invoice </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Enter Query ID <span class="redmind"></span></div>
	<input name="QueryId" type="text" class="gridfield validate" id="QueryId" onKeyUp="numericFilter(this);" value="" maxlength="5" displayname="Query ID" field_min_length="5"  />
	</label>
	<input name="addinvoice" type="hidden" id="addinvoice" value="1" />
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Continue    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='itineraryqueryid'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Create Itinerary</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Enter Query ID <span class="redmind"></span></div>
	<input name="QueryId" type="text" class="gridfield validate" id="QueryId" onKeyUp="numericFilter(this);" value="" maxlength="6" displayname="Query ID" field_min_length="6"  />
	</label>
	<input name="addItinerary" type="hidden" id="addItinerary" value="1" />
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Continue    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='quotationqueryid'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Create Quotation</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Enter Query ID <span class="redmind"></span></div>
	<input name="QueryId" type="text" class="gridfield validate" id="QueryId" onKeyUp="numericFilter(this);" value="" maxlength="5" displayname="Query ID" field_min_length="5"  />
	</label>
	<input name="addQuotation" type="hidden" id="addQuotation" value="1" />
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Continue    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } 

	
if($_GET['action']=='sendinvoiceemail' && isset($_GET['invoiceid']) ){
	if(isset($_REQUEST['invoiceid'])){
		$invoiceid = ($_REQUEST['invoiceid']);
		$invoiceQuery=GetPageRecord('*',_INVOICE_MASTER_,'id='.$invoiceid.' ');
		$invoiceData=mysqli_fetch_array($invoiceQuery);
	}
	?>
	<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
	<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
	Mail Sent Successfully</div>
	<table border="0" align="center" cellpadding="0" cellspacing="0">
	<tbody><tr>
	<td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
	</tr>
	</tbody></table>
	</div>
	<div id="sendmailfrm">
	<h1 style="text-align:left;">Send Invoice </h1>
	<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Email <span class="redmind"></span></div>
	<input name="emailsender" type="text" class="gridfield validate" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off" value="" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="Invoice No. PER<?php echo makeInvoiceId($invoiceData['id']); ?>" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
	</div>
	<input name="sendinvoicetoemail" type="hidden" id="sendinvoicetoemail" value="1" />
	<input name="attachinvoice" type="hidden" id="attachinvoice" value="<?php echo $_REQUEST['attachinvoice']; ?>" />
	<input name="sendemailinvoiceid" type="hidden" id="sendemailinvoiceid" value="<?php echo $_GET['invoiceid']; ?>" />
	</form>
	</div>
	<div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>

	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
	</tr>
	</table>
	</div>
	</div></div>
	<?php 
} ?>
<?php if($_GET['action']=='voucherqueryid'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Add Voucher</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Enter Query ID <span class="redmind"></span></div>
	<input name="QueryId" type="text" class="gridfield validate" id="QueryId" onKeyUp="numericFilter(this);" value="" maxlength="5" displayname="Query ID" field_min_length="5"  />
	</label>
	<input name="addvoucher" type="hidden" id="addvoucher" value="1" />
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Continue    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addvoucherlistsup' && $_GET['voucherid']!=''){
$voucherid=clean($_GET['voucherid']);
?>
<script>
 $(document).ready(function() {
$('#paymentreminderdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#paymentdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<div class="contentclass">
 <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
<?php
$thisshowcost=1;
$thisid='1';
$select2='*';
$where2='voucherId='.clean($voucherid).' order by companyTypeId ';
$rs2=GetPageRecord($select2,_VOUCHER_LIST_MASTER_,$where2);
while($listofsuppliers=mysqli_fetch_array($rs2)){
$companyTypeId='';
 if($listofsuppliers['supplierId']!=''){
$id=$listofsuppliers['supplierId'];
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_SUPPLIERS_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
$editassignTo=clean($editresult['assignTo']);
$editname=clean($editresult['name']);
$editcontactPerson=clean($editresult['contactPerson']);
$editcompanyTypeId=clean($editresult['companyTypeId']);
$editcountryId=clean($editresult['countryId']);
$editstateId=clean($editresult['stateId']);
$editcityId=clean($editresult['cityId']);
$edittitle=clean($editresult['title']);
$addedBy=clean($editresult['addedBy']);
$dateAdded=clean($editresult['dateAdded']);
$modifyBy=clean($editresult['modifyBy']);
$modifyDate=clean($editresult['modifyDate']);
$editaddress1=clean($editresult['address1']);
$editaddress2=clean($editresult['address2']);
$editaddress3=clean($editresult['address3']);
$editpinCode=clean($editresult['pinCode']);
$editgstn=clean($editresult['gstn']);
$editagreement=clean($editresult['agreement']);
$editid=clean($editresult['id']);
$companyTypeId=clean($editresult['companyTypeId']);
$companyTypeId2=clean($listofsuppliers['companyTypeId']);
$suppliername=clean($listofsuppliers['suppliername']);
$compsuppliername=clean($listofsuppliers['compsuppliername']);
$supplierMainType=clean($editresult['supplierMainType']);
}
?>
<div style="border:2px #ffc115 solid; margin-bottom:20px;">
<h1 style="text-align:left; padding:10px; background-color:#ffc115; margin-bottom:0px;"><?php echo $editname; ?><?php //if($supplierMainType==2){  echo ' - (DMC)'; } ?></h1>
<div style="padding:0px;">
<div style="margin-bottom:0px;  padding: 10px;  background-color: #f9f9f9;" >
<div id="dmchotel<?php echo $voucherid;  ?><?php echo $editid; ?>"></div>
<script>
$('#dmchotel<?php echo $voucherid; ?><?php echo $editid; ?>').load('loaddmchotel.php?voucherid=<?php echo $voucherid; ?>&mainsupplierId=<?php echo $editid; ?>');
</script>
</div>
<script>
 $(document).ready(function() {
$('#toDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#fromDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<h1 style="text-align:left; font-size: 13px; color: #888; margin-bottom:0px;    padding: 10px 14px; background-color:#F0F0F0; color:#666666; display:none;"><table border="0" cellpadding="0" cellspacing="0">
  <tr style="display:none;">
    <td><strong>Payment Details</strong></td>
    <td>&nbsp;</td>
   <?php if($thisshowcost==1){ ?> <td><input name="showCost" type="checkbox" id="showCost" style="display:block;" value="1" checked="checked" onclick="$('.showcosttble').toggle();" /></td>
    <td>&nbsp;Show Cost</td><?php } ?>
    </tr>
</table></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; border-top:0px;  " >
 <div style="margin-bottom:20px; margin-bottom:0px;  padding: 10px;  background-color: #fff; " >
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="display:none;">
  <!--<tr>
    <td valign="top"><table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:15px;">
      <tr>
        <td><?php if($companyTypeId==1){ ?>Check In<?php } else { ?>
          Date
          <?php } ?>:&nbsp; </td>
        <td><strong><?php echo date('d-m-Y',strtotime($listofsuppliers['fromDate'])); ?></strong></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <?php if($companyTypeId==1){ ?>  <td><?php if($companyTypeId==1){ ?>Check Out<?php } else { ?>
          Date
          <?php } ?>:&nbsp; </td>
        <td><strong><?php echo date('d-m-Y',strtotime($listofsuppliers['toDate'])); ?></strong></td><?php } ?>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td <?php if($companyTypeId!=1){ ?>style="display:none;"<?php } ?>>Room Type:&nbsp; </td>
        <td <?php if($companyTypeId!=1){ ?>style="display:none;"<?php } ?>><select id="roomType<?php echo $listofsuppliers['id']; ?>" name="roomType<?php echo $listofsuppliers['id']; ?>" class="textfieldsup"   autocomplete="off"   >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 order by name asc';
$rs=GetPageRecord($select,_ROOM_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
	   <td>SUP Confirmation No.:</td>
	   <td><input name="supplierserviceid<?php echo $listofsuppliers['id']; ?>" type="text" id="supplierserviceid<?php echo $listofsuppliers['id']; ?>" class="textfieldsup"  value="" checked="checked" maxlength="200"  style="width:100px; margin-left:5px;"/></td>
	  </tr>
    </table></td>
  </tr>-->
  <tr>
    <td valign="top" style=" border-top: 2px #ccc solid;">&nbsp;</td>
    </tr>
  <tr class="showcosttble">
    <td valign="top"><table width="50%" border="0" cellpadding="5" cellspacing="0" class="showcosttble">
  <tr>
    <td colspan="4"><strong>Cost</strong></td>
    </tr>
  <tr>
    <td><div class="textflablesup"><?php if($companyTypeId==1){ ?>Rooms<?php }  ?><?php if($companyTypeId==2){ ?>Airlines Name<?php }  ?><?php if($companyTypeId==10){ ?>Transfer Name<?php }  ?><?php if($companyTypeId==11){ ?>Sightseeing Name<?php }  ?>
        <input name="suppliernorooms<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup" id="suppliernorooms<?php echo $listofsuppliers['id']; ?>" value="<?php echo $listofsuppliers['suppliernorooms']; ?>" maxlength="3" style="<?php if($companyTypeId!=1){ ?>display:none;<?php } ?>"  />
		<input name="suppliername<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup"  displayname="Name" id="suppliername<?php echo $listofsuppliers['id']; ?>" value="<?php echo $listofsuppliers['suppliername']; ?>" maxlength="200" style="    width: 130px; display:none; <?php if($companyTypeId!=1){ ?>display:block;<?php } ?>"/>
	</div></td>
    <td><div class="textflablesup"><?php if($companyTypeId==1){ ?>No. of Nights<?php } else { ?>No of Pax<?php } ?>
	<input name="suppliernonight<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup" id="suppliernonight<?php echo $listofsuppliers['id']; ?>" onkeyup="numericFilter(this);Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();" value="<?php echo $listofsuppliers['suppliernonight']; ?>" maxlength="3"  onblur="Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();" />
	</div></td>
    <td><div class="textflablesup"><?php if($companyTypeId==1){ ?>Per Night Cost<?php } else { ?>Per Pax Cost <?php } ?>
	    <input name="supplierpernight<?php echo $listofsuppliers['id']; ?>" value="<?php echo $listofsuppliers['supplierpernight']; ?>" type="text" class="textfieldsup" id="supplierpernight<?php echo $listofsuppliers['id']; ?>"  onkeyup="numericFilter(this);Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();"  onblur="Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();" maxlength="10"/>
	</div></td>
    <td><div class="textflablesup">Cost
        <input name="suppliertotalcost<?php echo $listofsuppliers['id']; ?>" value="<?php echo $listofsuppliers['suppliertotalcost']; ?>" type="text" class="textfieldsup" id="suppliercost<?php echo $listofsuppliers['id']; ?>"  readonly="readonly" />
	</div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right"><div class="textflablesup">Tax CGST %</div> </td>
    <td><input name="suppliercgst<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup" id="suppliercgst<?php echo $listofsuppliers['id']; ?>"  onkeyup="numericFilter(this);Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();" maxlength="2" value="<?php echo $listofsuppliers['suppliercgst']; ?>"  onblur="Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right"><div class="textflablesup">SGST %</div></td>
    <td><input name="suppliersgst<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup" value="<?php echo $listofsuppliers['suppliersgst']; ?>" id="suppliersgst<?php echo $listofsuppliers['id']; ?>"  onkeyup="numericFilter(this);Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();" maxlength="2"  onblur="Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right"><div class="textflablesup">IGST %</div></td>
    <td><input name="supplierigst<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup" value="<?php echo $listofsuppliers['supplierigst']; ?>" id="supplierigst<?php echo $listofsuppliers['id']; ?>" onkeyup="numericFilter(this);Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();" maxlength="2"  onblur="Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>();"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right"><div class="textflablesup">Total Cost</div></td>
    <td><input name="suppliertoalcost<?php echo $listofsuppliers['id']; ?>" type="text" class="textfieldsup" value="<?php echo $listofsuppliers['suppliertoalcost']; ?>" id="suppliertoalcost<?php echo $listofsuppliers['id']; ?>" readonly="readonly" /></td>
  </tr>
</table> </td>
    </tr>
</table>
 </div>
  </div>
  <script>
function Suppliercalculatecost<?php echo $listofsuppliers['id']; ?>(){
var suppliernonight = $('#suppliernonight<?php echo $listofsuppliers['id']; ?>').val();
var supplierpernight = $('#supplierpernight<?php echo $listofsuppliers['id']; ?>').val();
var suppliercost = $('#suppliercost<?php echo $listofsuppliers['id']; ?>').val();
var suppliercgst = $('#suppliercgst<?php echo $listofsuppliers['id']; ?>').val();
var suppliersgst = $('#suppliersgst<?php echo $listofsuppliers['id']; ?>').val();
var supplierigst = $('#supplierigst<?php echo $listofsuppliers['id']; ?>').val();
var suppliertoalcost = $('#suppliertoalcost<?php echo $listofsuppliers['id']; ?>').val();
if(suppliernonight!='' &&  supplierpernight!=''){
var cost = Number(suppliernonight*supplierpernight);
$('#suppliercost<?php echo $listofsuppliers['id']; ?>').val(cost);
var suppliercgst_cost=0;
var suppliersgst_cost=0;
var supplierigst_cost=0;
if(suppliercgst!=''){
suppliercgst_cost = Number(cost/100*suppliercgst);
}
if(suppliersgst!=''){
suppliersgst_cost = Number(cost/100*suppliersgst);
}
if(supplierigst!=''){
supplierigst_cost = Number(cost/100*supplierigst);
}
var sototalcost = Number(cost+suppliercgst_cost+suppliersgst_cost+supplierigst_cost);
$('#suppliertoalcost<?php echo $listofsuppliers['id']; ?>').val(sototalcost);
}
}
</script></div>
</div>
  <?php $thisid++; $thisshowcost++;} ?>
  <div style="margin:10px 0px;">
   <h1 style="text-align:left;">Email</h1>
   <div style="margin-bottom:20px; margin-bottom: 20px;  padding: 10px;  background-color: #f9f9f9;  border-top: 2px #ccc solid;" >
      <table border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td>
     <input name="sendmail" type="checkbox" class="chk" id="sendmail" onclick="$('#showmultiemails').toggle();" style="display:block;"  value="1" checked="checked"/></td>
    <td>Send Mail </td>
  </tr>
</table>
<div class="mailusers" id="showmultiemails">
<?php
$select1='*';
$where1='id='.$voucherid.'';
$rs1=GetPageRecord($select1,_VOUCHER_MASTER_,$where1);
$voucherids=mysqli_fetch_array($rs1);
$select1='*';
$where1='id='.$voucherids['queryId'].'';
$rs1=GetPageRecord($select1,_QUERY_MASTER_,$where1);
$editresultQuery=mysqli_fetch_array($rs1);
$select='';
$where='';
$rs='';
$select='email';
$where='id='.$editresultQuery['assignTo'].'';
$rs=GetPageRecord($select,_USER_MASTER_,$where);
$resultpageassignemail=mysqli_fetch_array($rs);
$select='';
$where='';
$rs='';
$select='*';
$where='id=1';
$rs=GetPageRecord($select,_QUERY_MAILS_SECTION_MASTER_,$where);
$resultpageemail=mysqli_fetch_array($rs);
?>
		   <div class="mailusersbox"><strong>Client: </strong><?php if($editresultQuery['clientType']==1){ echo getPrimaryEmail($editresultQuery['companyId'],'corporate');} if($editresultQuery['clientType']==2){ echo getPrimaryEmail($editresultQuery['companyId'],'contacts');}  ?></div>
		   <div class="mailusersbox"><strong>Sales Executive: </strong><?php echo $resultpageassignemail['email']; ?></div>
		   <div class="mailusersbox"><strong>Group: </strong><?php echo $resultpageemail['queryemail']; ?></div>
	    </div>
   </div>
  </div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
<input name="voucherId" type="hidden" id="voucherId" value="<?php echo clean($voucherid); ?>" />
<input name="updatevoucherlist" type="hidden" id="updatevoucherlist" value="1" />
</form></div>
<?php } ?>
<?php if($_GET['action']=='sendvoucheremail'){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Send Voucher </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="mailusers" id="showmultiemails">
<?php
$voucherid=$_GET['vid'];
$select1='*';
$where1='id='.$voucherid.'';
$rs1=GetPageRecord($select1,_VOUCHER_MASTER_,$where1);
$voucherids=mysqli_fetch_array($rs1);
$select1='*';
$where1='id='.$voucherids['queryId'].'';
$rs1=GetPageRecord($select1,_QUERY_MASTER_,$where1);
$editresultQuery=mysqli_fetch_array($rs1);
$select='';
$where='';
$rs='';
$select='email';
$where='id='.$editresultQuery['assignTo'].'';
$rs=GetPageRecord($select,_USER_MASTER_,$where);
$resultpageassignemail=mysqli_fetch_array($rs);
$select='';
$where='';
$rs='';
$select='*';
$where='id=1';
$rs=GetPageRecord($select,_QUERY_MAILS_SECTION_MASTER_,$where);
$resultpageemail=mysqli_fetch_array($rs);
?>
		   <div class="mailusersbox"><strong>Client: </strong><?php if($editresultQuery['companyId']!=''){ if($editresultQuery['clientType']==1){ echo getPrimaryEmail($editresultQuery['companyId'],'corporate'); } if($editresultQuery['clientType']==2){ echo getPrimaryEmail($editresultQuery['companyId'],'contacts'); } } ?></div>
		   <div class="mailusersbox"><strong>Sales Executive: </strong><?php echo $resultpageassignemail['email']; ?></div>
		   <div class="mailusersbox"><strong>Group: </strong><?php echo $resultpageemail['queryemail']; ?></div>
	    </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Add More Email   </div>
	<input name="emailsender" type="text" class="gridfield" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="Booking No. <?php echo makeInvoiceId($_GET['voucherid']); ?>" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div><input name="sendvouchertoemail" type="hidden" id="sendvouchertoemail" value="1" /><input name="sendemailvoucherid" type="hidden" id="sendemailvoucherid" value="<?php echo $_GET['voucherid']; ?>" /><input name="vid" type="hidden" id="vid" value="<?php echo $_GET['vid']; ?>" />
 <input name="voucherType" type="hidden" id="voucherType" value="<?php echo $_GET['voucherType']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='sendhotelvoucheremail'){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Send Voucher </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="mailusers" id="showmultiemails">
<?php
$voucherid=$_GET['vid'];
$select1='*';
$where1='id='.$voucherid.'';
$rs1=GetPageRecord($select1,_VOUCHER_MASTER_,$where1);
$voucherids=mysqli_fetch_array($rs1);
$select1='*';
$where1='id='.$voucherids['queryId'].'';
$rs1=GetPageRecord($select1,_QUERY_MASTER_,$where1);
$editresultQuery=mysqli_fetch_array($rs1);
$select='';
$where='';
$rs='';
$select='email';
$where='id='.$editresultQuery['assignTo'].'';
$rs=GetPageRecord($select,_USER_MASTER_,$where);
$resultpageassignemail=mysqli_fetch_array($rs);
$select='';
$where='';
$rs='';
$select='*';
$where='id=1';
$rs=GetPageRecord($select,_QUERY_MAILS_SECTION_MASTER_,$where);
$resultpageemail=mysqli_fetch_array($rs);
$selecthotel='';
$wherehotel='';
$rshotel='';
$selecthotel='*';
$wherehotel='id="'.$_GET['hotelId'].'"';
$rshotel=GetPageRecord($selecthotel,_PACKAGE_BUILDER_HOTEL_MASTER_,$wherehotel);
$hotelemail=mysqli_fetch_array($rshotel);
$mailto=$hotelemail['supplierEmail'];
?>
		   <div class="mailusersbox"><strong>Hotel: </strong><?php echo $mailto;   ?></div>
		   <div class="mailusersbox"><strong>Sales Executive: </strong><?php echo $resultpageassignemail['email']; ?></div>
		   <div class="mailusersbox"><strong>Group: </strong><?php echo $resultpageemail['queryemail']; ?></div>
	    </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Add More Email   </div>
	<input name="emailsender" type="text" class="gridfield" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="Booking No. <?php echo makeInvoiceId($_GET['voucherid']); ?>" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div><input name="sendhotelvouchertoemail" type="hidden" id="sendhotelvouchertoemail" value="1" /><input name="sendemailvoucherid" type="hidden" id="sendemailvoucherid" value="<?php echo $_GET['voucherid']; ?>" /><input name="vid" type="hidden" id="vid" value="<?php echo $_GET['vid']; ?>" />
 <input name="hotelId" type="hidden" id="hotelId" value="<?php echo $_GET['hotelId']; ?>" />
 <input name="voucherType" type="hidden" id="voucherType" value="<?php echo $_GET['voucherType']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='makepaymentrequestpayment' && $_GET['queryId']!=''){ } ?>
<?php if($_GET['action']=='addqueryflightdetails' && $_GET['queryflightid']!=''){
?>
<script>
 $(document).ready(function() {
$('#departureDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#arrivalDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Flight   </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Departure Destination  <span class="redmind"></span></div>
	<select id="departureDestination" name="departureDestination" class="gridfield validate" displayname="Departure Destination" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Departure Date<span class="redmind"></span></div>
	<input onKeyUp="numericFilter(this);" name="departureDate" type="text" class="gridfield calfieldicon validate" id="departureDate"  maxlength="20"  displayname="Departure Date" autocomplete="off" readonly="readonly"  />
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Departure Time  </div>
	<select id="departureTime" name="departureTime" class="gridfield"  autocomplete="off"   >
	 <!--<option value="">Select</option>-->
 <?php
$start = "00:00";
$end = "23:45";
$tStart = strtotime($start);
$tEnd = strtotime($end);
$tNow = $tStart;
while($tNow <= $tEnd){
?>
<option value="<?php echo date("g:i a",$tNow); ?>"><?php echo date("g:i a",$tNow); ?></option>
<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
</select>
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Arrival Destination  <span class="redmind"></span></div>
	<select id="arrivalDestination" name="arrivalDestination" class="gridfield validate" displayname="Arrival Destination" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Arrival Date<span class="redmind"></span></div>
	<input onKeyUp="numericFilter(this);" name="arrivalDate" type="text" class="gridfield calfieldicon validate " id="arrivalDate"  maxlength="20"  displayname="Arrival Date" autocomplete="off" readonly="readonly"  />
	</label>
 </div>
   <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Arrival Time  </div>
	<select id="arrivalTime" name="arrivalTime" class="gridfield"  autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$start = "00:00";
$end = "23:45";
$tStart = strtotime($start);
$tEnd = strtotime($end);
$tNow = $tStart;
while($tNow <= $tEnd){
?>
<option value="<?php echo date("g:i a",$tNow); ?>"><?php echo date("g:i a",$tNow); ?></option>
<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
</select>
	</label>
 </div>
 <input name="addQueryFlight" type="hidden" id="addQueryFlight" value="1" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>

<?php
if($_GET['action']=='addcomplaint'){
?>
<script>
 $(document).ready(function() {
$('#complaintDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Complaint </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div style="text-align:center; padding:20px; text-align:center; color:#009900; font-size:15px; display:none;" id="sentfilemsg">File Sent Successfully.<br ><br ><table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table></div>
<div id="sendfilefrm">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Query Id <span class="redmind"></span></div>
	<input name="queryIdcomp" type="text" class="gridfield validate" id="queryIdcomp" onKeyUp="numericFilter(this);getsuppcomp();" value="" maxlength="6" displayname="Query ID" field_min_length="6" autocomplete="off" />
	</label>
 </div>
 <div class="griddiv" style="border-bottom:0px;"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style="width:100%;">Complaint Date <span class="redmind"></span></div>
	<input name="complaintDate" type="text" class="gridfield validate calfieldicon" id="complaintDate" style="width: 100% !important;"   value="<?php echo date('d-m-Y'); ?>" maxlength="6" displayname="Query Date"   />
	<style>
	.Zebra_DatePicker_Icon_Wrapper{width:100% !important;}
	</style>
	</label>
 </div>
 <script>
 function getsuppcomp(){
 var id = $('#queryIdcomp').val();
 $('#loadcompanyandsupplier').load('loadcompanyandsupplier.php?queryId='+id);
 $('#loadcompanyandsupplier').show();
 }
 </script>
 <div id="loadcompanyandsupplier" style="display:none;">
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="subject" type="text" class="gridfield validate" id="subject"   value="" maxlength="200" displayname="Subject"  autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status <span class="redmind"></span></div>
	<select id="status" name="status" class="textfieldsup"   autocomplete="off"   >
<option value="1">Open</option>
<option value="2">Closed</option>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  <span class="redmind"></span></div>
	<textarea name="descriptioncomp" rows="8" class="gridfield validate" id="descriptioncomp" displayname="Description" field_min_length="6"></textarea>
	</label>
 </div></div>
 <input name="addComplaint" type="hidden" id="addComplaint" value="1" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Add    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>

        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='editdmcroomtype' && $_GET['sectionId']!=''){
if($_GET['sectionId']!=''){
$id=clean($_GET['sectionId']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_DMC_HOTEL_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update DMC Hotel Room</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="dmcHotelId" id="dmcHotelId" type="hidden" value="<?php echo $editresult['id']; ?>" />
   <input name="action" id="action" type="hidden" value="updatedmcHotel" />
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Room Name<span class="redmind"></span></div>
	<input   name="roomName" type="text" class="gridfield validate" id="roomName"  maxlength="200"  displayname="Room Name" autocomplete="off"   value="<?php echo $editresult['roomName']; ?>" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Max Pax<span class="redmind"></span></div>
	<input   name="maxPax" type="text" class="gridfield validate" id="maxPax"  maxlength="5"  displayname="Max Pax" autocomplete="off"  onkeyup="numericFilter(this);" value="<?php echo $editresult['maxPax']; ?>"/>
	</label>
 </div>
	<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Max Adult<span class="redmind"></span></div>
	<input   name="maxAdult" type="text" class="gridfield validate" id="maxAdult"  maxlength="5"  displayname="Max Adult" autocomplete="off" onkeyup="numericFilter(this);" value="<?php echo $editresult['maxAdult']; ?>"  />
	</label>
 </div>
	<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Max Child</div>
	<input   name="maxChild" type="text" class="gridfield" id="maxChild"  maxlength="5"  displayname="Max Child" autocomplete="off" onkeyup="numericFilter(this);"  value="<?php echo $editresult['maxChild']; ?>"  />
	</label>
 </div>
	<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child Age</div>
	<input   name="childAge" type="text" class="gridfield" id="childAge"  maxlength="5"  displayname="Child Age" autocomplete="off"  onkeyup="numericFilter(this);"  value="<?php echo $editresult['childAge']; ?>"  />
	</label>
 </div>
 <input name="addQueryFlight" type="hidden" id="addQueryFlight" value="1" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php
// Hotel Tariff
if($_GET['action']=='editdmcroomtariff' && $_GET['tarifId']!='' ){
	if($_GET['tarifId']!=''){
	$id=clean($_GET['tarifId']);
	$select1d='*';
	$where1d='id='.$id.' order by id asc';
	$rs1d=GetPageRecord($select1d,_DMC_ROOM_TARIFF_MASTER_,$where1d);
	$dmcroommastermain=mysqli_fetch_array($rs1d);
	  $fromDatevalidity=$dmcroommastermain['fromDate'];
	  $toDatevalidity=$dmcroommastermain['toDate'];
	  $tarifType=$dmcroommastermain['tarifType'];
	  $hotelQuery=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$dmcroommastermain['serviceid'].'"'); 
      $hotelData = mysqli_fetch_array($hotelQuery);
	}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Hotel Room Tariff </h1>
  <div id="contentbox" class="addeditpagebox" style="padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   	<input name="serviceid2" id="serviceid2" type="hidden" value="<?php echo $dmcroommastermain['serviceid']; ?>" />
   	<input name="tarifId2" id="tarifId2" type="hidden" value="<?php echo $id; ?>" />
   	<input name="suppid" id="suppid" type="hidden" value="<?php echo $_REQUEST['suppid']; ?>" />
   	<input name="action" id="action" type="hidden" value="updatedmcHotelTariff" />
   	<div style="float:left;    width: 47%;">
   		 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Market Type<span class="redmind"></span></div>
	<select id="marketTypeId2" name="marketTypeId2" class="gridfield validate" displayname="Market Type" autocomplete="off"     >
	 <option value="">Select</option>
    <?php
	$rs=GetPageRecord('*','marketMaster',' status=1 and deletestatus=0 order by name asc');
	while($resListing=mysqli_fetch_array($rs)){
    ?>
    <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$dmcroommastermain['marketType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
    <?php } ?>
</select>
	</label>
 </div>
 	<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Supplier<span class="redmind"></span></div>
	<select id="activitySupplierId" name="activitySupplierId" class="gridfield validate" displayname="Supplier" autocomplete="off"     >
	 <option value="">Select</option>
    <?php
	$rs='';
	$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and companyTypeId=1 group by name order by name asc');
	while($supplierData=mysqli_fetch_array($rs)){
    ?>
    <option value="<?php echo strip($supplierData['id']); ?>" <?php if($supplierData['id']==$dmcroommastermain['supplierId']){ ?>selected="selected"<?php } ?>><?php echo strip($supplierData['name']); ?></option>
    <?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv">
		<label>
		<div class="gridlable">Pax&nbsp;Type<span class="redmind"></span></div>
		<select id="paxType2" name="paxType2" class="gridfield" style="width: 100%;"> 
 			<option value="1" <?php if(1==$dmcroommastermain['paxType']){ ?>selected="selected"<?php } ?>>GIT</option>
			<option value="2" <?php if(2==$dmcroommastermain['paxType']){ ?>selected="selected"<?php } ?>>FIT</option>				
			</select> 
			</label>
		</select>
		</label>
	</div>
   		<div class="griddiv">
		<label>
		<div class="gridlable">Tarif&nbsp;Type<span class="redmind"></span></div>
		<select id="tarifType" name="tarifType2" class="gridfield " displayname="Tarif Type" autocomplete="off" onchange="tarifTypeAction(this.value);" >
			<?php
			$rs=GetPageRecord('*','tariffTypeMaster',' deletestatus=0 order by name asc');
			while($resListing=mysqli_fetch_array($rs)){  ?>
			<option value="<?php echo strip($resListing['id']); ?>" <?php if($tarifType == strip($resListing['id'])){ ?> selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>
			<?php } ?>
		</select>
		</label>
	</div>
	<div class="griddiv">
		<label>
		<div class="gridlable">Season&nbsp;Type<span class="redmind"></span></div>
		<select id="seasonType2" name="seasonType2" class="gridfield " displayname="Season Type" autocomplete="off"   onchange="getSeasonValidityfun2();" >
			<option value="1" <?php if($dmcroommastermain['seasonType']==1){ ?>selected="selected"<?php } ?>>Summer</option>
			<option value="2" <?php if($dmcroommastermain['seasonType']==2){ ?>selected="selected"<?php } ?>>Winter</option>
			<option value="3" <?php if($dmcroommastermain['seasonType']==3){ ?>selected="selected"<?php } ?>>NA</option>	
			</select>
			</label>
		</select>
		</label>
	</div> 
	<div class="griddiv">
		<label>
		<div class="gridlable">Season&nbsp;Year<span class="redmind"></span></div>
		<?php
		$starting_year  = 2020;
		$ending_year    = 2040;
		for($starting_year; $starting_year <= $ending_year; $starting_year++) {
			if(date('Y',strtotime($fromDatevalidity)) == $starting_year ){ $seleted = "selected"; }else{ $seleted = ""; }
			$years[] = '<option value="'.$starting_year.'" '.$seleted.' >'.$starting_year.'</option>';
		}
		?>
		<select name="seasonYear2" id="seasonYear2"  class="gridfield" style="width: 100%;" onchange="getSeasonValidityfun2();">
		 <option value="0">Select</option>
		 <?php echo implode("\n\r", $years);  ?>
		</select>
		</label>
	</div>
	<div class="griddiv rateValidation"><label>
 		<!-- <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div> -->
		<div class="gridlable">From Date</div>
		<input name="fromDatevalidity" type="date" id="fromDate2" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($fromDatevalidity)); ?>" />
		</label>
	 </div>
	 <div class="griddiv rateValidation"><label>
 		<!-- <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div> -->
		<div class="gridlable">To Date</div>
		<input name="toDatevalidity" type="date" id="toDate2" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($toDatevalidity)); ?>"  />
		</label>
	</div>

	 <div class="griddiv rateValidation"><label>
 		<div class="gridlable">Status</div>
		<select id="status" name="status2" class="gridfield validate" displayname="Status" autocomplete="off"   >
			<option value="1" <?php if($dmcroommastermain['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
			<option value="0" <?php if($dmcroommastermain['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
		</select>
		</label>
	</div>
	<div id="SeasonValidity2" style="display:none;"></div>
	<script>
	function getSeasonValidityfun2(){
		var seasonType = $('#seasonType2').val();
		var seasonYear = $('#seasonYear2').val();
		//$('#SeasonValidity2').load('loadSeasonValidity.php?edit=yes&seasonType='+seasonType+'&seasonYear='+seasonYear);
	}
	getSeasonValidityfun2(1);
	function tarifTypeAction(tarifType){
		if(tarifType == 5 || tarifType == 6){
		$('.rateValidation').hide();
		$('.rateValidation input').removeClass('validate');
		$('.suplimentPriceBox').hide();
		$('.suplimentPriceBox input').removeClass('validate');
		}else if(tarifType == 4){
			$('.suplimentPriceBox').show();
			$('.suplimentPriceBox input').addClass('validate');
		}
		else{
			$('.suplimentPriceBox').hide();
			$('.suplimentPriceBox input').removeClass('validate');
			$('.rateValidation').show();
			$('.rateValidation input').addClass('validate');
		}
	}
  </script>
   	</div>
   	<div style="float:left; margin-left: 30px;    width: 48%;">
<div class="griddiv1" style="margin-bottom: 2px;"><label>
	<table>
		<tr width="100%" >
			<td width="33%"><div class="griddiv"><label>
 	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
	 <option value="">Select</option>
 <?php
 $requestedCurr = ($dmcroommastermain['currencyId']!='')?$dmcroommastermain['currencyId']:1;
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$requestedCurr){ ?>selected="selected"<?php } ?> ><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div></td>
        <td width="33%"><div class="griddiv">
	<label>
	<div class="gridlable">Room&nbsp;Type</div>
	<select id="roomType" name="roomType" class="gridfield" displayname="Room Type" autocomplete="off" style="width: 100%;">
		 <option value="">Select</option>
<?php 
$select=''; 
$where=''; 
$rs='';  
$select='*';    
	$where='1';  
	$rs=GetPageRecord($select,_ROOM_TYPE_MASTER_,$where); 
	while ($resListing=mysqli_fetch_array($rs)) {	
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$dmcroommastermain['roomType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select></label>
	</div></td>
			<td width="33%"><div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Meal Plan<span class="redmind"></span></div>
	<select id="mealPlan2" name="mealPlan2" class="gridfield validate" displayname="Meal Plan" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_MEAL_PLAN_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$dmcroommastermain['mealPlan']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 	       </td>
		</tr>
	</table>
	</label>
 </div>
 <div class="griddiv1" style="margin-bottom: 2px;">
 	 <table width="100%">
 	 	<tr>
 	 		<td width="33%">
 	 			<div class="griddiv">
 	<label>
 		<div class="gridlable">Room GST SLAB<span class="redmind"></span></div>
		<select id="roomGST2" name="roomGST2" class="gridfield " displayname="Room GST" autocomplete="off" style="width: 100%;" >
	 		 <?php 
			$rs2="";
			$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="Hotel" and status=1 order by gstSlabName asc'); 
			while($gstSlabData=mysqli_fetch_array($rs2)){
			?>
			<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id'] == $dmcroommastermain['roomGST']){ ?> selected="selected" <?php } ?>><?php echo $gstSlabData['gstSlabName'];?></option>
			<?php
			}	
			?>
		</select>
	</label>
</div>
 	 		</td>
 	 		<td width="33%"><div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Single</div>
	<input name="singleoccupancy2" type="text" class="gridfield"  id="singleoccupancy2" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['singleoccupancy']; ?>" maxlength="6"/>
	</label>
 </div></td>
 	 		<td width="33%"> <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Extra Bed(Adult)</div>
	<input name="extraBed2" type="text" class="gridfield"  id="extraBed2" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['extraBed']; ?>" maxlength="6"/>
	</label>
 </div></td>
 	 	</tr>
 	 </table>
 </div>
 <div class="griddiv1"  style="margin-bottom: 2px;">
 	<table width="100%">
 		<tr>
        	<td width="25%"><div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Double</div>
	<input name="doubleoccupancy2" type="text" class="gridfield"  id="doubleoccupancy2" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['doubleoccupancy']; ?>" maxlength="6"/>
	</label>
 </div></td>
 <td width="25%"  align="left"><div class="griddiv"><label>
		<div class="gridlable">Quad</div>
		<input name="quadRoom" type="text" class="gridfield"  id="quadRoom" value="<?php echo $dmcroommastermain['quadRoom']; ?>" maxlength="6" onkeyup="numericFilter(this);"  style="width: 100%;"/>
		</label>
		</div></td>
 			<td width="25%"><div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child CWB</div>
	<input name="childwithbed2" type="text" class="gridfield"  id="childwithbed2" maxlength="6" onkeyup="numericFilter(this);"  value="<?php echo $dmcroommastermain['childwithbed']; ?>"/>
	</label>
 </div></td>
<td width="25%">	<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child CNB</div>
	<input name="childwithoutbed2" type="text" class="gridfield"  id="childwithoutbed2" maxlength="6" onkeyup="numericFilter(this);"  value="<?php echo $dmcroommastermain['childwithoutbed']; ?>"/>
	</label>
 </div></td>
		</tr>
		
 	</table>
<tr>
	<td>
		<table width="100%">
			<tr>
 <td width="25%" align="left"   ><div class="griddiv"><label>
		<div class="gridlable">Six&nbsp;Bed&nbsp;Room</div>
		<input name="sixBedRoom" type="text" class="gridfield"  id="sixBedRoom" value="<?php echo $dmcroommastermain['sixBedRoom']; ?>" maxlength="6" onkeyup="numericFilter(this);"  style="width: 100%;"/>
		</label>
		</div></td> 
		<td width="25%" align="left"   ><div class="griddiv"><label>
		<div class="gridlable">Eight&nbsp;Bed&nbsp;Room</div>
		<input name="eightBedRoom" type="text" class="gridfield"  id="eightBedRoom" value="<?php echo $dmcroommastermain['eightBedRoom']; ?>" maxlength="6" onkeyup="numericFilter(this);"  style="width: 100%;"/>
		</label>
		</div></td> 
		<td width="25%" align="left" colspan="2"  ><div class="griddiv"><label>
		<div class="gridlable">Ten&nbsp;Bed&nbsp;Room</div>
		<input name="tenBedRoom" type="text" class="gridfield"  id="tenBedRoom" value="<?php echo $dmcroommastermain['tenBedRoom']; ?>" maxlength="6" onkeyup="numericFilter(this);"  style="width: 100%;"/>
		</label>
		</div></td> 
		<td width="25%" align="left" colspan="2"  ><div class="griddiv"><label>
		<div class="gridlable">Teen&nbsp;Room</div>
		<input name="teenRoom" type="text" class="gridfield"  id="teenRoom" value="<?php echo $dmcroommastermain['teenRoom']; ?>" maxlength="6" onkeyup="numericFilter(this);"  style="width: 100%;"/>
		</label>
		</div></td> 
 		</tr>
		 </tr>
		</table>
	
 </div>
	<div class="griddiv"><label>
	  <div class="griddiv suplimentPriceBox" style="display:none;">
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Supliment&nbsp;Price</div>
        <input name="suplimentPrice" type="text" class="gridfield "  id="suplimentPrice" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $editresult['suplimentPrice']; ?>"/>
      </div>
      <div class="griddiv1" style="margin-bottom: 2px;">
      	<table width="100%">
      		<tr>
      			<td width="33%"> <div class="griddiv">
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Breakfast(A)</div>
        <input name="breakfast2" type="text" class="gridfield"  id="breakfast2" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['breakfast']; ?>"/>
      </div></td>
      			<td width="33%"> <div class="griddiv">
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Lunch(A) </div>
        <input name="lunch2" type="text" class="gridfield"  id="lunch2" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['lunch']; ?>"/>
      </div></td>
      			<td width="33%"><div class="griddiv">
        <label> </label>
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Dinner(A)</div>
        <input name="dinner2" type="text" class="gridfield"  id="dinner" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['dinner']; ?>"/>
      </div></td>
      		</tr>
			<tr>
			<td width="10%" align="left" >
			<div class="griddiv"><label>
			<div class="gridlable">Breakfast(C)</div>
			<input name="breakfastChild" type="text" class="gridfield" value="<?php echo $dmcroommastermain['childBreakfast']; ?>"  id="breakfastChild" maxlength="6" onkeyup="numericFilter(this);"  style="width: 100%;"/>
			</label>
			</div>	</td>
		<td width="10%" align="left" valign="middle"  ><div class="griddiv"><label>
		<div class="gridlable">Lunch(C)</div>
		<input name="lunchChild" type="text" class="gridfield"  id="lunchChild" value="<?php echo $dmcroommastermain['childLunch']; ?>" style="width: 100%;" onkeyup="numericFilter(this);" maxlength="6"/>
		</label>
		</div></td>
	    <td width="10%" align="left" valign="middle"  ><div class="griddiv"><label>
		<div class="gridlable">Dinner(C)</div>
		<input name="dinnerChild" type="text" class="gridfield"  id="dinnerChild" value="<?php echo $dmcroommastermain['childDinner']; ?>" maxlength="6" onkeyup="numericFilter(this);" style="width: 100%;" />
		</label>
		</div></td>
			</tr>
      	</table>
      </div>


      <div class="griddiv1" style="margin-bottom: 2px;">
    	<table width="100%">
    		<tr>
    			<td width="50%">
    				<div class="griddiv">
					 	<label>
					 		<div class="gridlable">meal TAX SLAB<span class="redmind"></span></div>
							<select id="mealGST2" name="mealGST2" class="gridfield " displayname="Meal GST" autocomplete="off" style="width: 100%;" >
						 		<?php 
								$rs2="";
								$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="Restaurant" and status=1 order by gstSlabName asc'); 
								while($gstSlabData=mysqli_fetch_array($rs2)){
								?>
								<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id'] == $dmcroommastermain['mealGST']){ ?> selected="selected" <?php } ?>><?php echo $gstSlabData['gstSlabName'];?></option>
								<?php
								}	
								?>
							</select>
						</label>
					</div>
					</td>
    			<td width="50%">
    				<div class="griddiv">
           		<label><div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
								<div class="gridlable">TAC(%)</div>
								<input name="roomTAC2" type="text" class="gridfield"  id="roomTAC2" onkeyup="numericFilter(this);" value="<?php echo $dmcroommastermain['roomTAC']; ?>" maxlength="6"/>
							</label>
						</div>
					</td>
    		</tr>
    	</table>
    	</div>

    	<!-- markup -->
      <div class="griddiv1" style="margin-bottom: 2px;">
    	<table width="100%">
    		<tr>
    			<td width="50%">
    				<div class="griddiv">
	    				<label>
								<div class="gridlable">Markup&nbsp;Type</div>
								<select name="markupType2" id="markupType2" class="gridfield validate" displayname="Markup Type" autocomplete="off" style="width: 100%;">
								 	<option value="1" <?php if($dmcroommastermain['markupType'] == 1){ ?> selected="selected" <?php } ?>>%</option>
								 	<option value="2" <?php if($dmcroommastermain['markupType'] == 2){ ?> selected="selected" <?php } ?>>Flat</option>
								</select>
							</label>
						</div> 
					</td>
    			<td width="50%">
    				<div class="griddiv">
    					<label>
								<div class="gridlable">Markup&nbsp;Cost</div>
								<input name="markupCost2" type="text" class="gridfield" id="markupCost2" value="<?php echo $dmcroommastermain['markupCost']; ?>" maxlength="6" onkeyup="numericFilter(this);">
							</label>
						</div>
					</td>
    		</tr>
    	</table>
    	</div>


   	</div>
   	</div>
   	<div style="float:left;width: 100%;">
	 	<div class="griddiv"><label>
	<div class="gridlable">Remark</div>
	<textarea name="remarks" rows="4" class="gridfield" id="remarks"><?php echo $dmcroommastermain['remarks']; ?></textarea>
	</label>
	</div>
	 </div>
 <?php 
 $selectha22 = '*';
	$whereha22 = '';
	$rs2222 = '';
	$whereha22='hotelId="'.$dmcroommastermain['serviceid'].'" and rateId = "'.$dmcroommastermain['id'].'" and isQuoteRate=0 ';  
	$rs2222=GetPageRecord($selectha22,'dmcAdditionalHotelRate',$whereha22); 
	$maxRecord2 = mysqli_num_rows($rs2222); 
	?>
	 <div style="float:left;width: 100%;">
	 	<div class="griddiv"><label>
				<div class="gridlable">Hotel Additional Requirements</div>
				<div class="Additionalfields">
				<table cellpadding="5" cellspacing="0" border="1" borderColor="#ccc" width="100%">
					<tr>
						<td align="left" valign="middle">
							<div class="griddiv" style="width: 130px;"><label><div class="gridlable">Additional</div></label>
							</div>
						</td>
						<td align="left">
							<div class="griddiv" style="width: 130px;">
								<label><div class="gridlable">TAX&nbsp;SLAB(%)</div></label>
							</div>
						</td>
						<td>
							<div class="griddiv" style="width: 144px;">
								<label><div class="gridlable">Type</div></label>
							</div>
						</td>
						<td>
							<div class="griddiv" style="width: 100px;">
								<label><div class="gridlable">Cost</div> </label>
							</div>
						</td>
						<td width="10%" align="left" valign="middle">&nbsp;</td>
					</tr>
					<!-- additional hotel code goes herer -->
					<?php 
				if($maxRecord2>0){ 
					$cntRecords = 1;
					while ($dmcAdditionalHRate = mysqli_fetch_assoc($rs2222)) {
					?>
					<tr id="HARateDiv2<?php echo $cntRecords; ?>">
						<td align="left" valign="middle">
							<div class="griddiv" style="width: 130px;"><label>
								<select id="addtionalHotel2<?php echo $cntRecords; ?>" name="addtionalHotel2<?php echo $cntRecords; ?>" class="gridfield HAName" displayname=" Hotel Additional" autocomplete="off"  style="width: 100%;" >
									<option value="">Select Additional</option>
									<?php 
									$select=''; 
									$where=''; 
									$rs='';  
									$select='*';    
									$hotelAdditionalArray = explode(',',rtrim($hotelData['hotelAdditional'],','));
									foreach($hotelAdditionalArray as $roomArray){
										$where='id="'.$roomArray.'"';  
										$rs=GetPageRecord($select,'additionalHotelMaster',$where); 
										if(mysqli_num_rows($rs)>0){
										$additinalres=mysqli_fetch_array($rs);	
										?>
										<option value="<?php echo strip($additinalres['id']); ?>" <?php if($additinalres['id']==$dmcAdditionalHRate['additionalName']){ ?>selected="selected"<?php } ?>><?php echo strip($additinalres['name']); ?></option>
									<?php } } ?>
								</select> 
								</label>
							</div>
						</td>
						<td align="left">
							<div class="griddiv" style="width: 130px;">
								<label>
									<select id="additionalGST2<?php echo $cntRecords; ?>" name="additionalGST2<?php echo $cntRecords; ?>" class="gridfield" displayname="Additional GST" autocomplete="off" style="width: 100%;">
										<?php
										$rs2 = "";												
										$rs2 = GetPageRecord('*', 'gstMaster', ' 1 and serviceType="Restaurant" and status=1 order by gstSlabName asc');
										while ($gstSlabData = mysqli_fetch_array($rs2)) {
										?>
											<option value="<?php echo $gstSlabData['id']; ?>" <?php if($dmcAdditionalHRate['gsttax']==$gstSlabData['id']){ ?>selected="selected"<?php } ?>><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
										<?php
										}
										?>
									</select>
								</label>
							</div>
						</td>
						<td>
							<div class="griddiv" style="width: 144px;">
								<label>
									<select name="personwise2<?php echo $cntRecords; ?>" id="personwise2<?php echo $cntRecords; ?>" class="gridfield">
										<option value="1" <?php if($dmcAdditionalHRate['personWise']==1){ ?>selected="selected"<?php } ?>>Per Person Cost</option>
										<option value="2" <?php if($dmcAdditionalHRate['personWise']==2){ ?>selected="selected"<?php } ?>>Group Cost</option>
									</select>
								</label>
							</div>
						</td>
						<td>
							<div class="griddiv" style="width: 100px;">
								<label>
									<input type="text" name="additionalCost2<?php echo $cntRecords; ?>" id="additionalCost2<?php echo $cntRecords; ?>" class="gridfield" onkeyup="numericFilter(this);" value="<?php echo $dmcAdditionalHRate['additionalCost']; ?>">
								</label>
							</div>
						</td>
						<td width="10%" align="left" valign="middle">
							<?php if($cntRecords==1){ ?>
								<i class="fa fa-plus-square addMoreFields2" id="addMoreFields"  aria-hidden="true" style="font-size: 25px;color: #55a640;padding: 7px 10px;border-radius: 5px;cursor:pointer;"></i>
								<i class="fa fa-trash-o " onclick="removeHARates('<?php echo $dmcAdditionalHRate['id']; ?>','<?php echo $cntRecords; ?>')" aria-hidden="true" style="font-size: 23px;color: #ff0000;padding: 5px 11px;border-radius: 5px;cursor:pointer;"></i> 
							<input name="maxRecord2" type="hidden" id="maxRecord21" value="<?php echo $maxRecord2; ?>">	  
							<input type="hidden" name="additionalRatesNo2" id="additionalRatesNo21" value="<?php echo $maxRecord2; ?>">
							<?php }else{ ?> 
							<i class="fa fa-trash-o " onclick="removeHARates('<?php echo $dmcAdditionalHRate['id']; ?>','<?php echo $cntRecords; ?>')" aria-hidden="true" style="font-size: 23px;color: #ff0000;padding: 5px 11px;border-radius: 5px;cursor:pointer;"></i> 
							<?php } ?>
							<input name="addHotelId2<?php echo $cntRecords; ?>" type="hidden" id="addHotelId2<?php echo $cntRecords; ?>" value="<?php echo $dmcAdditionalHRate['id']; ?>">	  
						</td>
					</tr>
					<?php $cntRecords++; 
					}
				}else{ ?>
						<tr>
							<td align="left" valign="middle">
								<div class="griddiv" style="width: 130px;"><label>
									<select id="addtionalHotel21" name="addtionalHotel21" class="gridfield HAName" displayname=" Hotel Additional" autocomplete="off"  style="width: 100%;" >
										<option value="">Select Additional</option>
										<?php 
										$select=''; 
										$where=''; 
										$rs='';  
										$select='*';    
										$hotelAdditionalArray = explode(',',rtrim($hotelData['hotelAdditional'],','));
										foreach($hotelAdditionalArray as $roomArray){
											$where='id="'.$roomArray.'"';  
											$rs=GetPageRecord($select,'additionalHotelMaster',$where); 
											if(mysqli_num_rows($rs)>0){
											$additinalres=mysqli_fetch_array($rs);	
											?>
											<option value="<?php echo strip($additinalres['id']); ?>" <?php if($additinalres['id']==$dmcAdditionalHRate['additionalName']){ ?>selected="selected"<?php } ?>><?php echo strip($additinalres['name']); ?></option>
										<?php } } ?>
									</select> 
									</label>
								</div>
							</td>
							<td align="left">
								<div class="griddiv" style="width: 130px;">
									<label>
										<select id="additionalGST21" name="additionalGST21" class="gridfield" displayname="Additional GST" autocomplete="off" style="width: 100%;">
											<?php
											$rs2 = "";												
											$rs2 = GetPageRecord('*', 'gstMaster', ' 1 and serviceType="Restaurant" and status=1 order by gstSlabName asc');
											while ($gstSlabData = mysqli_fetch_array($rs2)) {
											?>
												<option value="<?php echo $gstSlabData['id']; ?>" <?php if($dmcAdditionalHRate['gsttax']==$gstSlabData['id']){ ?>selected="selected"<?php } ?>><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
											<?php
											}
											?>
										</select>
									</label>
								</div>
							</td>
							<td>
								<div class="griddiv" style="width: 144px;">
									<label>
										<select name="personwise21" id="personwise21" class="gridfield">
											<option value="1" <?php if($dmcAdditionalHRate['personWise']==1){ ?>selected="selected"<?php } ?>>Per Person Cost</option>
											<option value="2" <?php if($dmcAdditionalHRate['personWise']==2){ ?>selected="selected"<?php } ?>>Group Cost</option>
										</select>
									</label>
								</div>
							</td>
							<td>
								<div class="griddiv" style="width: 100px;">
									<label>
										<input type="text" name="additionalCost21" id="additionalCost21" class="gridfield" onkeyup="numericFilter(this);" value="<?php echo $dmcAdditionalHRate['additionalCost']; ?>">
									</label>
								</div>
							</td>
							<td width="10%" align="left" valign="middle">
									<i class="fa fa-plus-square addMoreFields2"  aria-hidden="true" style="font-size: 25px;color: #55a640;padding: 7px 10px;border-radius: 5px;cursor:pointer;"></i>
								<input type="hidden" name="maxRecord2" id="maxRecord21" value="1">	  
								<input type="hidden" name="additionalRatesNo2" id="additionalRatesNo21" value="1">
								<input type="hidden" name="addHotelId21" id="addHotelId21" value="<?php echo $dmcAdditionalHRate['id']; ?>">	  
							</td>
						</tr>
				<?php } ?>
				</table>
				
				</div>
				<div id="multipleAdditionalRate2"></div>
				<div id="SAVERATES" style="display:none;"></div>
				<script>
						function removeHARates(rateId,cntRecords){
							$('#SAVERATES').load('frmaction.php?action=removeHARates&id='+rateId+'');
							$('#HARateDiv2'+cntRecords).remove();
						}

					$(document).ready(function(){
						$(".addMoreFields2").click(function(e){
							e.preventDefault();
							var additionalRatesNo = $('#additionalRatesNo21').val();
							additionalRatesNo = Number(additionalRatesNo) + 1; 
							$('#additionalRatesNo21').val(additionalRatesNo); 
							$('#maxRecord21').val(additionalRatesNo); 

							$("#multipleAdditionalRate2").append(` <table cellpadding="5" cellspacing="0" border="1" borderColor="#ccc"  width="100%"> <tr >
								<td align="left" valign="middle">
									<div class="griddiv" style="width:130px;"><label>
											<select id="addtionalHotel2`+additionalRatesNo+`" name="addtionalHotel2`+additionalRatesNo+`" class="gridfield HAName" displayname="Hotel Additional" autocomplete="off"  style="width: 100%;" >
												<option value="">Select Additional</option>
												<?php 
												$select=''; 
												$where=''; 
												$rs='';  
												$select='*';    
												$hotelAdditionalArray = explode(',',rtrim($hotelData['hotelAdditional'],','));
												foreach($hotelAdditionalArray as $roomArray){
													$where='id="'.$roomArray.'"';  
													$rs=GetPageRecord($select,'additionalHotelMaster',$where); 
													if(mysqli_num_rows($rs)>0){
													$additinalres=mysqli_fetch_array($rs);	
													?>
													<option value="<?php echo strip($additinalres['id']); ?>" <?php if($additinalres['id']==$dmcHotelAddData['additionalName']){ ?>selected="selected"<?php } ?>><?php echo strip($additinalres['name']); ?></option>
												<?php } } ?>
											</select>
										</label>
									</div>
								</td>
								<td align="left">
									<div class="griddiv" style="width:130px;">
										<label>
											
											<select id="additionalGST2`+additionalRatesNo+`" name="additionalGST2`+additionalRatesNo+`" class="gridfield" displayname="Additional GST" autocomplete="off" style="width: 100%;" >
											<option>Select GST</option>
												<?php
												$rs2 = "";
												$rs2 = GetPageRecord('*', 'gstMaster', ' 1 and serviceType="Restaurant" and status=1 order by gstSlabName asc');
												while ($gstSlabData = mysqli_fetch_array($rs2)) {
												?>
													<option value="<?php echo $gstSlabData['id']; ?>"><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
												<?php
												}
												?>
											</select>
										</label>
									</div>
								</td>
								<td>
									<div class="griddiv" style="width:144px;">
										<label>
											
											<select name="personwise2`+additionalRatesNo+`" id="personwise2`+additionalRatesNo+`" class="gridfield">
												<option value="1">Per Person Cost</option>
												<option value="2">Group Cost</option>
											</select>
										</label>
									</div>
								</td>
								<td>
									<div class="griddiv" style="width:100px;">
										<label>
											
											<input type="text" name="additionalCost2`+additionalRatesNo+`" id="additionalCost2`+additionalRatesNo+`" class="gridfield" onkeyup="numericFilter(this);" placeholder="Cost">
										</label>
									</div>
								</td>
								<td width="10%" align="left" valign="middle" class="removeFields2"> <i class="fa fa-trash-o" aria-hidden="true" style="font-size: 23px;color: #ff0000;padding: 5px 11px;border-radius: 5px;cursor:pointer;"></i> </td>

							</tr></table> `);

							if(additionalRatesNo>1){
								$('.HAName').addClass('validate');
							}else{
								$('.HAName').removeClass('validate');
							}

						});
						$(document).on('click','.removeFields2',function(e){
							e.preventDefault(); 
							let removefields = $(this).parent().parent().parent();
							$(removefields).remove(); 
							var additionalRatesNo2 = $('#additionalRatesNo21').val();
							additionalRatesNo2 = Number(additionalRatesNo2) - 1;
							$('#additionalRatesNo21').val(additionalRatesNo2); 

							if(additionalRatesNo>1){
								$('.HAName').addClass('validate');
							}else{
								$('.HAName').removeClass('validate');
							}
							
						});

					
					});
				</script>
			</label>
		</div>
	 </div>
	<?php 
	//} ?>
 <input name="addQueryFlight" type="hidden" id="addQueryFlight" value="1" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='editdmcsightseengrate' && $_GET['sectionId']!=''){
if($_GET['sectionId']!=''){
$id=clean($_GET['sectionId']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_DMC_SIGHTSEEING_RATE_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update DMC Sightseeing Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="dmcsightseeingrateId" id="dmcsightseeingrateId" type="hidden" value="<?php echo $id; ?>" />
   <input name="suppid" id="suppid" type="hidden" value="<?php echo $_REQUEST['suppid']; ?>" />
   <input name="action" id="action" type="hidden" value="updatedmcSightSeeingRate" />
   <div class="griddiv" style="display:none;"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Sightseeing Name<span class="redmind"></span></div>
	<select id="sightseeingNameId2" name="sightseeingNameId2" class="gridfield " displayname="Sightseeing Name" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_SIGHTSEEING_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['sightseeingNameId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Per Pax Cost</div>
	<input name="ticketAdultCost" type="text" class="gridfield"  id="ticketAdultCost" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketAdultCost']; ?>" maxlength="6"/>
	</label>
 </div>
 <?php if($editresult['vehicleId']==0){ } else { ?>
 <script>
	function showmaxpax22(){
	var vehicleId = $('#vehicleId2').val();
	$('#maxpaxbox22').load('loadmaxpaxdmcbox.php?id='+vehicleId);
	}
	</script>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Vehicle Name</div>
	<select id="vehicleId2" name="vehicleId2" class="gridfield"  autocomplete="off"  onchange="showmaxpax22();"  >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_VEHICLE_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['vehicleId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div id="maxpaxbox22">
<div class="griddiv">
        <label> </label>
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Max Pax</div>
        <input name="mxp" type="text" class="gridfield"  id="mxp" maxlength="6" readonly="readonly" />
		</div>
      </div>
<div class="griddiv">
        <label> </label>
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Vehicle Cost</div>
        <input name="vehicleCost" type="text" class="gridfield"  id="vehicleCost" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $editresult['vehicleCost']; ?>"/>
      </div>
	   <script>
	 showmaxpax22();
	 </script>
	  <?php } ?>
	  <div class="griddiv">
        <label> </label>
        <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="div"></div>
        <div class="gridlable">Information</div>
        <input name="detail" type="text" class="gridfield"  id="detail" maxlength="200"   value="<?php echo $editresult['detail']; ?>"/>
      </div>
	<div class="griddiv"><label>
      <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status</div>
	<select id="status" name="status" class="gridfield validate" displayname="Tour Type" autocomplete="off"   >
<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
</select>
	</label>
 </div>
 <input name="addQueryFlight" type="hidden" id="addQueryFlight" value="1" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>

		
<!-- edit restaurant rate -->
<?php if($_GET['action']=='editRestaurantRate' && $_GET['sectionId']!=''){
	if($_GET['sectionId']!=''){
		$id=clean($_GET['sectionId']);
		$rs1=GetPageRecord('*','dmcRestaurantsMealPlanRate','id='.$id.'');
		$editresult=mysqli_fetch_array($rs1);
		
	}
	$rest = GetPageRecord('*',_INBOUND_MEALPLAN_MASTER_,'id="'.$_REQUEST['restaurantId'].'"');
    $resListing = mysqli_fetch_assoc($rest);
	?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
	
}
.griddiv{
	padding:0px !important;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Restaurant Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">

   <input name="DmcrestaurantRateId" id="DmcrestaurantRateId" type="hidden" value="<?php echo $id; ?>" />
   
   <input name="action" id="action" type="hidden" value="editRestaurantRate" />

   <div class="griddiv">
	   <label>
			<!-- <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" ></div> -->
			<div class="gridlable">Restaurant Name<span class="redmind"></span></div>
			<input type="text" id="restaurantNameId2" name="restaurantNameId2" class="gridfield" displayname="Entrance Name" value="<?php echo $resListing['mealPlanName']; ?>" autocomplete="off" readonly >
		</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Meal Type<span class="redmind"></span></div>
	<select id="mealPlanType" name="mealPlanType" class="gridfield validate" displayname="Meal Type" autocomplete="off">
                    <?php
                    $rs2 = GetPageRecord('*', 'restaurantsMealPlanMaster', '1  and status=1 and deletestatus=0');
                     while ($userss = mysqli_fetch_array($rs2)) {
                    ?>
                 		<option value="<?Php echo $userss['id']; ?>" <?php if($editresult['mealPlanId']==$userss['id']){ ?> selected="selected" <?php } ?> ><?Php echo $userss['name']; ?></option>
                    <?php } ?>
                </select>
	</label>
 </div>

	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Currency<span class="redmind"></span></div>
		
		<select id="currencyId" name="currencyId" class="gridfield validate" displayname="city" autocomplete="off">
                                        <?php

                                        $select = '';
                                        $where = '';
                                        $rs = '';
                                        $select = '*';
                                        $where = ' deletestatus=0 and status=1 order by name asc';
                                        $rs = GetPageRecord($select, _QUERY_CURRENCY_MASTER_, $where);
                                        while ($resListingc = mysqli_fetch_array($rs)) {
                                        ?>
                                            <option value="<?php echo strip($resListingc['id']); ?>" <?php if ($editresult['currencyId'] == $resListingc['id']) { ?>selected="selected" <?php } ?>><?php echo strip($resListingc['name']); ?></option>
                                        <?php } ?>
                                    </select>
						</label>
						</div>
						

 		<div class="griddiv"><label>
		<div class="gridlable">Per Pax Cost</div>
		<input type="text" class="gridfield validate" name="adultCost" id="adultCost" value="<?php echo $editresult['adultCost']; ?>">
		</label>
	 </div>
	 	<div class="griddiv"><label>
	 	<div class="">GST&nbsp;SLAB(%)<span class="redmind"></span></div>
        <select id="RestaurantGST" name="RestaurantGST" class="gridfield" displayname="Restaurant GST" autocomplete="off" style="width: 100%;">
                 <?php
                 $rs2 = "";
                 $rs2 = GetPageRecord('*', 'gstMaster', ' 1 and serviceType="Restaurant" and status=1');
                    while ($gstSlabData = mysqli_fetch_array($rs2)) {
                                        ?>
                     <option value="<?php echo $gstSlabData['id']; ?>" <?php if($editresult['RestaurantGST']==$gstSlabData['id']){ ?> selected="selected" <?php } ?> ><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </label>
                            </div>						
		</form>
		</div>
		<div id="buttonsbox"  style="text-align:center;">
		<table border="0" align="right" cellpadding="0" cellspacing="0">
			<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
				<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
			</tr>
		</table>
		</div>
		</div></div>
	<?php } ?>

	<!-- edit restaurant rate -->
 
<?php 
if($_GET['action']=='editDmcEntranceRate' && $_GET['sectionId']!=''){
	if($_GET['sectionId']!=''){
		$id=clean($_GET['sectionId']);
		$rs1=GetPageRecord('*',_DMC_ENTRANCE_RATE_MASTER_,'id='.$id.'');
		$editresult=mysqli_fetch_array($rs1);
		$entQuery=GetPageRecord('entranceName,tptType,id',_PACKAGE_BUILDER_ENTRANCE_MASTER_,' id='.$editresult['entranceNameId'].' ');
		$entranceData=mysqli_fetch_array($entQuery);

		$tptType=clean($entranceData['tptType']);
	}
	?>
	<style>
	.addeditpagebox .griddiv .gridlable {
	    width: 100%;
	}
	</style>
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
	<div class="contentclass">
			<h1 style="text-align:left;">Update <?php echo strip($entranceData['transferName']); ?> </h1>
	  	<div class="addeditpagebox addtopaboxlist">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" >
				<tr style="background-color: transparent !important;">
				  <td width="150" align="left"><div class="griddiv"><label>
							<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
							<select id="supplierId2" name="supplierId2" class="gridfield validate" displayname="Suppliers" autocomplete="off"   >
							<option value="">Select</option>
							<?php
							$where=' deletestatus=0 and name!="" and( entranceType=4 or entranceType=1 )order by name asc';
							$rs=GetPageRecord('id,name',_SUPPLIERS_MASTER_,$where);
							while($resultlists=mysqli_fetch_array($rs)){   ?>
							<option value="<?php echo strip($resultlists['id']); ?>" <?php if($editresult['supplierId']==strip($resultlists['id'])){ ?> selected="selected" <?php } ?> ><?php echo strip($resultlists['name']); ?></option>
							<?php  } ?>
							</select>
							</label>
							</div>
					</td>
					<!-- <td width="150" align="left">
					 <div class="griddiv"><label>
				   <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
						<div class="gridlable">Market Type<span class="redmind"></span></div>
						<select id="marketType2" name="marketType2" class="gridfield validate" displayname="Market Type" autocomplete="off"     >
						 <option value="">Select</option>
					    <?php
						$rs=GetPageRecord('*','marketMaster','  status=1 and deletestatus=0 order by name asc');
						while($resListing=mysqli_fetch_array($rs)){
					    ?>
					    <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['marketType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
					    <?php } ?>
					    </select>
						</label>
					 </div>
					</td> -->

					<td width="100" align="left">
						<div class="griddiv">
						<label>
						<div class="gridlable">Nationality<span class="redmind"></span></div>
						<select id="nationalityType2" name="nationalityType2" class="gridfield validate" displayname="Nationality" autocomplete="off" onchange="getCurrencyfun2(this.value);">
							<option value="1" <?php if('1'==$editresult['nationalityType']){ ?>selected="selected"<?php } ?>>Local</option>
							<option value="2" <?php if('2'==$editresult['nationalityType']){ ?>selected="selected"<?php } ?>>Foreign</option>
						</select>
						</label>
						</div> 
					</td>
					<td width="110" align="left"><div class="griddiv">
						<label>
						<div class="gridlable">Rate&nbsp;Valid&nbsp;From <span class="redmind"></span></div>
						<input name="fromDate2" type="text" class="gridfield calfieldicon validate" id="fromDate2" value="<?php echo date('d-m-Y',strtotime($editresult['fromDate'])); ?>"/>
						</label>
						</div>	
					</td>
					<td width="110" align="left"><div class="griddiv">
						<label>
						<div class="gridlable">Rate&nbsp;Valid&nbsp;To<span class="redmind"></span>  </div>
						<input name="toDate2" type="text" class="gridfield calfieldicon validate"  id="toDate2" value="<?php echo date('d-m-Y',strtotime($editresult['toDate'])); ?>"/>
						</label>
						</div>	
					</td>
					<td width="100" align="left"><div class="griddiv">
						<label>
						<div class="gridlable">Tarif Type<span class="redmind"></span></div>
						<select id="tarifType2" name="tarifType2" class="gridfield validate" displayname="Tarif Type" autocomplete="off" >
							<option value="1" <?php if('1'==$editresult['tarifType']){ ?>selected="selected"<?php } ?>>Normal</option>
							<option value="2" <?php if('2'==$editresult['tarifType']){ ?>selected="selected"<?php } ?>>Weekend</option>
						</select>
						</label>
						</div>
					</td>
					<td width="100" align="left" >
						<div class="griddiv">
						<label> 
						<div class="gridlable">Transfer Type <span class="redmind"></span></div>
						<select id="transferType2" name="transferType2" class="gridfield validate" displayname="Transfer Type" onchange="selectTransferType2(this.value);"> 
							<?php 
							// echo $tptType;
							if($tptType==1 || $tptType==0){ ?>
							<option value="1" <?php if('1'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>SIC</option>
							<?php }if($tptType==2 || $tptType==0){ ?>
							<option value="2" <?php if('2'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>PVT</option>
							
							<?php } if($tptType==3 || $tptType==0){ ?>
							<option value="3" <?php if('3'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>Ticket Only</option>
							<?php } ?>
						</select>
						</label>
						</div>	
					</td>
					<td width="100" align="left">
						<div class="griddiv">
						<label>
						<div class="gridlable">Currency<span class="redmind"></span></div>
						<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
								<option value="">Select</option>
								<?php
								$select='';
								$where='';
								$rs='';
								$select='*';
								$where=' deletestatus=0 and status=1 order by name asc';
								$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
								while($resListing=mysqli_fetch_array($rs)){
								?>
								<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
								<?php } ?>
								</select>
						</label>
						</div>	
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" >
		  	<tr style="background-color: transparent !important;">
					<td width="150" align="left"  class="PVT2">
						<div class="griddiv">
							<label>
								<div class="gridlable">Vehicle&nbsp;Name</div>
								<select id="vehicleId2" name="vehicleId2" class="gridfield" displayname="Vehicle Name" autocomplete="off" >
									<?php 
									$rs2="";
									$rs2=GetPageRecord('*',_VEHICLE_MASTER_MASTER_,' 1 and model!="" and carType!="" order by model asc '); 
									while($vehicleData=mysqli_fetch_array($rs2)){
										// echo ; 
									?>
									<option value="<?php echo $vehicleData['id'];?>" <?php if($vehicleData['id']==$editresult['vehicleId']){ ?>selected="selected"<?php } ?>><?php echo getVehicleTypeName($vehicleData['carType']) . "( " . ucfirst($vehicleData['model']);?> )</option>
									<?php
									}	
									?>
								</select>
							</label>
						</div>	
					</td>

			  	
		  	  <td width="100" align="left" ><div class="griddiv"><label>
						<div class="gridlable">Adult&nbsp;Ticket&nbsp;Cost </div>
						<input name="ticketAdultCost2" type="text" class="gridfield"  id="ticketAdultCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketAdultCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" ><div class="griddiv"><label>
						<div class="gridlable">Child&nbsp;Ticket&nbsp;Cost </div>
						<input name="ticketchildCost2" type="text" class="gridfield"  id="ticketchildCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketchildCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" ><div class="griddiv"><label>
						<div class="gridlable">Infant&nbsp;Ticket&nbsp;Cost </div>
						<input name="ticketinfantCost2" type="text" class="gridfield"  id="ticketinfantCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketinfantCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" class="SIC2"><div class="griddiv"><label>
						<div class="gridlable">Adult&nbsp;Transfer&nbsp;Cost </div>
						<input name="adultCost2" type="text" class="gridfield"  id="adultCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['adultCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" class="SIC2"><div class="griddiv"><label>
						<div class="gridlable">Child&nbsp;Transfer&nbsp;Cost </div>
						<input name="childCost2" type="text" class="gridfield"  id="childCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['childCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" class="SIC2"><div class="griddiv"><label>
						<div class="gridlable">Infant&nbsp;Transfer&nbsp;Cost </div>
						<input name="infantCost2" type="text" class="gridfield"  id="infantCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['infantCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" class="PVT2"><div class="griddiv"><label>
						<div class="gridlable">Vehicle&nbsp;Cost </div>
						<input name="vehicleCost2" type="text" class="gridfield"  id="vehicleCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['vehicleCost']; ?>"/>
						</label>
						</div>
					</td>
					<td width="100" align="left" class="ticketOnly2" ><div class="griddiv"><label>
						<div class="gridlable">Rep.&nbsp;Cost</div>
						<input name="repCost2" type="text" class="gridfield"  id="repCost2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;" value="<?php echo $editresult['repCost']; ?>" />
						</label>
						</div>
					</td>
					<td width="150" align="left" valign="middle"  ><div class="griddiv">
						<label>
						<div class="gridlable">GST/TAX Slab<span class="redmind"></span></div>
						<select id="gstTax2" name="gstTax2" class="gridfield  validate" displayname="GST" autocomplete="off" style="width: 100% !important;">
						 <?php 
						$rs2="";
						$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="entrance" and status=1 order by gstSlabName asc'); 
						while($gstSlabData=mysqli_fetch_array($rs2)){
						?>
						<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id'] == $editresult['gstTax']){ ?> selected="selected" <?php } ?>><?php echo $gstSlabData['gstSlabName'];?></option>
						<?php
						}	
						?>
						</select>
						</label>
						</div>
					</td>
				</tr>
			  <tr style="background-color: transparent !important;">	
			  	<td width="100" align="left" valign="middle"  >
						<div class="griddiv">
						<label>
						<div class="gridlable">Status</div>
						<select id="status2" name="status2" class="gridfield" displayname="Status" autocomplete="off"   >
								<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
								<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
								</select></label>
						</div>	
					</td>
		  	  <td align="left" colspan="2" valign="middle"  >
		  	  	<div class="griddiv"><label>
						<div class="gridlable">Policy </div>
						<input name="policy2" type="text" class="gridfield"  id="policy2" maxlength="220"  value="<?php echo $editresult['policy']; ?>"   style="width: 100%;"/>
						</label>
						</div> 
					</td> 
					<td align="left" colspan="2" valign="middle"  >
		  	  	<div class="griddiv"><label>
						<div class="gridlable">T&C </div>
						<input name="termAndCondition2" type="text" class="gridfield"  id="termAndCondition2" maxlength="220"  value="<?php echo $editresult['termAndCondition']; ?>"   style="width: 100%;"/>
						</label>
						</div> 
					</td>
					<td align="left" colspan="2" valign="middle"  >
		  	  	<div class="griddiv"><label>
						<div class="gridlable">Remarks </div>
						<input name="detail2" type="text" class="gridfield"  id="detail2" maxlength="220"  value="<?php echo $editresult['detail']; ?>"   style="width: 100%;"/>
						</label>
						</div>
						<input name="DmcEntranceRateId2" id="DmcEntranceRateId2" type="hidden" value="<?php echo $id; ?>" />
						<input name="action" id="action" type="hidden" value="updatedmcEntranceRate" />
					</td>
			  </tr>
			</table>
		</div>
	  <div id="buttonsbox"  style="text-align:center;">
	 		<table border="0" align="right" cellpadding="0" cellspacing="0">
		  	<tr><td  >
		  			<input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" style="display:inline-block;"/>
		  		</td>
					<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
					</td>
		  	</tr>
	   	</table>
		</div>
		<script type="text/javascript">
			// user in loadalertbox
			function selectTransferType2(value){
				if(value == 1){
					$('.SIC2').css('display','table-cell');
					$('.ticketOnly2').css('display','table-cell');
					$('.PVT2').css('display','none');
				}else if(value == 2){
					$('.PVT2').css('display','table-cell');
					$('.ticketOnly2').css('display','table-cell');
					$('.SIC2').css('display','none');
				}else{
					$('.ticketOnly2').css('display','none');
					$('.SIC2').css('display','none');
					$('.PVT2').css('display','none');
				}
			}
			$(document).ready(function() {
				$('#toDate2').Zebra_DatePicker({
					format: 'd-m-Y',
					direction: true // add this line
				});
				
				$('#fromDate2').Zebra_DatePicker({
					format: 'd-m-Y',
					direction: true, // add this line
					pair: $('#toDate2')
				});
			}); 
			<?php if($tptType==2){ ?>
			selectTransferType2(2);
			<?php }elseif($tptType==3){?>
				selectTransferType2(3);
			<?php }else{?>

			selectTransferType2(<?php echo trim($editresult['transferType']); ?>);
			<?php } ?>
			function getCurrencyfun2(nationalityType){
				// var nationalityType = ele.value;
				$('#currencyId2').load('loadCurrencyEntrance.php?nationalityType='+nationalityType);
			}
			getCurrencyfun2('<?php echo trim($editresult['nationalityType']); ?>');
		</script>
	</div>
	</form>
	<?php 
} ?>
<!-- Add Ferry Price start -->
<?php 
if($_GET['action']=='editDmcFerryRate' && $_GET['sectionId']!='' && $_REQUEST['serviceId']!=''){
	if($_GET['sectionId']!=''){
		$id=clean($_GET['sectionId']);
		$rs1=GetPageRecord('*','ferryRate','id='.$id.'');
		$editresult=mysqli_fetch_array($rs1);
		$fromDatevalidity=$editresult['fromDate'];
    $toDatevalidity=$editresult['toDate'];
	}
	?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Ferry Transfer Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="FerryRateId" id="FerryRateId" type="hidden" value="<?php echo $id; ?>" />
   <input name="serviceId2" id="serviceId2" type="hidden" value="<?php echo $_REQUEST['serviceId']; ?>" />
   <input name="action" id="action" type="hidden" value="updateFerryRate" />
   <div class="griddiv">
	   <label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" ></div>
			<div class="gridlable">Ferry Name<span class="redmind"></span></div>
			<select id="ferryNameId2" name="ferryNameId2" class="gridfield validate" displayname="Ferry Name" autocomplete="off" >
				<?php
				$bbbbbName=GetPageRecord('*','ferryNameMaster','deletestatus=0 and status=1'); 
				while($FerrycompanyName=mysqli_fetch_array($bbbbbName)){
				?>
				<option value="<?php echo $FerrycompanyName['id'];?>" <?php if($editresult['ferryNameId']== $FerrycompanyName['id']){?> selected="selected" <?php } ?>><?php echo strip($FerrycompanyName['name']);  ?></option>
				<?php } ?>
			</select>
		</label>
 	</div>

	<div class="griddiv"><label>
		<div class="gridlable">Ferry Seat <span class="redmind"></span></div>
		<select name="ferrySeat2" class="gridfield validate" displayname="Ferry Seat" id="ferrySeat2">
			<option value="">Select Ferry Seat</option>
			<?php
			$resseat = GetPageRecord('*','ferryClassMaster','deletestatus=0 and status=1');
			while($resultseat = mysqli_fetch_assoc($resseat)){
				?>
			<option value="<?php echo $resultseat['id']; ?>" <?php if($editresult['ferryClass']== $resultseat['id']){?> selected="selected" <?php } ?>> <?php echo $resultseat['name']; ?></option>
				<?php
			}
			
			?>
			</select>
		</label>
	</div>

	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Supplier<span class="redmind"></span></div>
		<select id="FerrySupplierId2" name="FerrySupplierId2" class="gridfield validate" displayname="Supplier" autocomplete="off"     >
			<option value="">Select</option>
			<?php
			$rs='';
			$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and ( ferryType=10 or ferryType=1 ) order by name asc');
			while($supplierData=mysqli_fetch_array($rs)){
			?>
			<option value="<?php echo strip($supplierData['id']); ?>" <?php if($supplierData['id']==$editresult['supplierId']){ ?>selected="selected"<?php } ?>><?php echo strip($supplierData['name']); ?></option>
			<?php } ?>
		</select>
	</label>
	</div>

	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Market Type<span class="redmind"></span></div>
		<select id="marketTypeId2" name="marketTypeId2" class="gridfield validate" displayname="Market Type" autocomplete="off"     >
			<option value="">Select</option>
			<?php
				$rs=GetPageRecord('*','marketMaster',' status=1 and deletestatus=0 order by name asc');
				while($resListing=mysqli_fetch_array($rs)){
			?>
			<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['marketType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
			<?php } ?>
		</select>
	</label>
	</div>

	<div class="griddiv rateValidation"><label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">From Date</div>
		<input name="fromDatevalidity" type="date" id="fromDatevalidity" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($fromDatevalidity)); ?>" />
		</label>
	 </div>
	 <div class="griddiv rateValidation"><label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">To Date</div>
		<input name="toDatevalidity" type="date" id="toDatevalidity" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($toDatevalidity)); ?>"  />
		</label>
	</div>
	<div class="griddiv">
	 <label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Currency<span class="redmind"></span></div>
		<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off" >
			<?php
			$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' deletestatus=0 and status=1 order by name asc');
			while($resListing=mysqli_fetch_array($rs)){
				?>
				<option value="<?php echo strip($resListing['id']); ?>" <?php if ($resListing['id']==$editresult['currencyId']  ) { ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
				<?php } ?>
		</select>
	</label>
	</div>

		<div class="griddiv"><label>
			<div class="gridlable">TAX SLAB(TAX%) <span class="redmind"></span></div>
			<select name="gstSlab2" id="gstSlab2" class="gridfield validate" displayname="GST">
				<option value="">Select GST</option>
				<?php 
				
				$rs34="";
				$rs34=GetPageRecord('*','gstMaster',' 1 and serviceType="Ferry" and status=1 order by gstSlabName asc'); 
				while($gstSlabData=mysqli_fetch_array($rs34)){
				?>
				<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id']==$editresult['gstTax']){ ?>selected="selected"<?php } ?> ><?php echo $gstSlabData['gstSlabName'];?>&nbsp;(<?php echo $gstSlabData['gstValue'];?>)</option>
				<?php
				}	
				?>
				
			</select>
		</label>
	</div>

 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Adult Cost (PP)</div>
	<input name="ticketAdultCost" type="text" class="gridfield"  id="ticketAdultCost" onkeyup="numericFilter(this);" value="<?php echo $editresult['adultCost']; ?>" maxlength="6"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child Cost (PP)</div>
	<input name="ticketchildCost" type="text" class="gridfield"  id="ticketchildCost" onkeyup="numericFilter(this);" value="<?php echo $editresult['childCost']; ?>" maxlength="6"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Infant Cost (PP)</div>
	<input name="ticketinfantCost" type="text" class="gridfield"  id="ticketinfantCost" onkeyup="numericFilter(this);" value="<?php echo $editresult['infantCost']; ?>" maxlength="6"/>
	</label>
 </div>

 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Processing Fee</div>
	<input name="Processingfe2" type="text" class="gridfield"  id="Processingfee2" onkeyup="numericFilter(this);" value="<?php echo $editresult['processingfee']; ?>" maxlength="6"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Misc. Cost</div>
	<input name="miscost2" type="text" class="gridfield"  id="miscost2" onkeyup="numericFilter(this);" value="<?php echo $editresult['miscCost']; ?>" maxlength="6"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Remark</div>
	<input name="remarks" type="text" class="gridfield"  id="remarks"  value="<?php echo $editresult['remark']; ?>"/>
	</label>
 </div>
	<div class="griddiv"><label>
      <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status</div>
	<select id="status2" name="status2" class="gridfield validate" displayname="Tour Type" autocomplete="off"   >
<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>Inactive</option>
</select>
	</label>
 </div>
 <input name="sectionId" type="hidden" id="sectionId" value="<?php echo $_GET['sectionId']; ?>" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<!-- Add Ferry Price End -->

<!-- Add Cruise Price start -->
<?php 
if($_GET['action']=='editCruiseMasterRate' && $_GET['cruiseRateId']!='' && $_REQUEST['serviceId']!=''){
	if($_GET['cruiseRateId']!=''){
		$id=clean($_GET['cruiseRateId']);
		$rs1=GetPageRecord('*','cruiseRateMaster','id="'.$id.'"');
		$editresult=mysqli_fetch_array($rs1);
		$fromDatevalidity=$editresult['fromDate'];
    	$toDatevalidity=$editresult['toDate'];
	}
	?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Cruise Package Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="cruiseRateId" id="cruiseRateId" type="hidden" value="<?php echo $id; ?>" />
   <input name="serviceId2" id="serviceId2" type="hidden" value="<?php echo $_REQUEST['serviceId']; ?>" />
   <input name="action" id="action" type="hidden" value="updateCruiseMasterRate" />

   <div class="griddiv">
	   <label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" ></div>
			<div class="gridlable">Cruise Name<span class="redmind"></span></div>
			<select id="cruiseNameId2" name="cruiseNameId2" class="gridfield validate" displayname="Cruise Name" autocomplete="off" >
				<?php
				$bbbbbName=GetPageRecord('*','cruiseNameMaster','deletestatus=0 and status=1'); 
				while($cruisecompanyName=mysqli_fetch_array($bbbbbName)){
				?>
				<option value="<?php echo $cruisecompanyName['id'];?>" <?php if($editresult['cruiseNameId']== $cruisecompanyName['id']){?> selected="selected" <?php } ?>><?php echo strip($cruisecompanyName['name']);  ?></option>
				<?php } ?>
			</select>
		</label>
 	</div>

	<div class="griddiv"><label>
		<div class="gridlable">Cabin Type <span class="redmind"></span></div>
		<select name="cabinType2" class="gridfield validate" displayname="Cabin Type" id="cabinType2">
			<option value="">Select Cabin Type</option>
			<?php
			$resseat = GetPageRecord('*','cabinTypeMaster','name!="" and status=1');
			while($resultseat = mysqli_fetch_assoc($resseat)){
				?>
			<option value="<?php echo $resultseat['id']; ?>" <?php if($editresult['cabinTypeId']== $resultseat['id']){?> selected="selected" <?php } ?>> <?php echo $resultseat['name']; ?></option>
				<?php
			}
			
			?>
			</select>
		</label>
	</div>

	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Supplier<span class="redmind"></span></div>
		<select id="cruiseSupplierId2" name="cruiseSupplierId2" class="gridfield validate" displayname="Supplier" autocomplete="off"     >
			<option value="">Select</option>
			<?php
			$rs='';
			$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and ( ferryType=10 or ferryType=1 ) order by name asc');
			while($supplierData=mysqli_fetch_array($rs)){
			?>
			<option value="<?php echo strip($supplierData['id']); ?>" <?php if($supplierData['id']==$editresult['supplierId']){ ?>selected="selected"<?php } ?>><?php echo strip($supplierData['name']); ?></option>
			<?php } ?>
		</select>
	</label>
	</div>

			<div class="griddiv" >
				<label>
					<div class="gridlable">Tariff&nbsp;Type<span class="redmind"></span></div>
						<select id="tariffType2" name="tariffType2" class="gridfield " displayname="Tariff Type" autocomplete="off" >
						<option value="1" <?php if($editresult['tariffTypeId']==1){ echo 'selected'; } ?> >Normal</option>
						<option value="2" <?php if($editresult['tariffTypeId']==2){ echo 'selected'; } ?> >Weekend</option>
						</select>
                    </label>
				</div>
	

	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Market Type<span class="redmind"></span></div>
		<select id="marketTypeId2" name="marketTypeId2" class="gridfield validate" displayname="Market Type" autocomplete="off"     >
			<option value="">Select</option>
			<?php
				$rs=GetPageRecord('*','marketMaster',' status=1 and deletestatus=0 order by name asc');
				while($resListing=mysqli_fetch_array($rs)){
			?>
			<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['marketType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
			<?php } ?>
		</select>
	</label>
	</div>

	<div class="griddiv rateValidation"><label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">From Date</div>
		<input name="fromDatevalidity" type="date" id="fromDatevalidity" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($fromDatevalidity)); ?>" />
		</label>
	 </div>
	 <div class="griddiv rateValidation"><label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">To Date</div>
		<input name="toDatevalidity" type="date" id="toDatevalidity" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($toDatevalidity)); ?>"  />
		</label>
	</div>
	<div class="griddiv">
	 <label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Currency<span class="redmind"></span></div>
		<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off" >
			<?php
			$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' deletestatus=0 and status=1 order by name asc');
			while($resListing=mysqli_fetch_array($rs)){
				?>
				<option value="<?php echo strip($resListing['id']); ?>" <?php if ($resListing['id']==$editresult['currencyId']  ) { ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
				<?php } ?>
		</select>
	</label>
	</div>

		<div class="griddiv"><label>
			<div class="gridlable">TAX SLAB(TAX%) <span class="redmind"></span></div>
			<select name="gstSlab2" id="gstSlab2" class="gridfield validate" displayname="GST">
				<option value="">Select GST</option>
				<?php 
				
				$rs34="";
				$rs34=GetPageRecord('*','gstMaster',' 1 and serviceType="Ferry" and status=1 order by gstSlabName asc'); 
				while($gstSlabData=mysqli_fetch_array($rs34)){
				?>
				<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id']==$editresult['gstTax']){ ?>selected="selected"<?php } ?> ><?php echo $gstSlabData['gstSlabName'];?>&nbsp;(<?php echo $gstSlabData['gstValue'];?>)</option>
				<?php
				}	
				?>
				
			</select>
		</label>
	</div>

 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Adult Cost (PP)</div>
	<input name="ticketAdultCost2" type="text" class="gridfield"  id="ticketAdultCost2" onkeyup="numericFilter(this);" value="<?php echo $editresult['adultCost']; ?>" maxlength="6"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child Cost (PP)</div>
	<input name="ticketchildCost2" type="text" class="gridfield"  id="ticketchildCost2" onkeyup="numericFilter(this);" value="<?php echo $editresult['childCost']; ?>" maxlength="6"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Infant Cost (PP)</div>
	<input name="ticketinfantCost2" type="text" class="gridfield"  id="ticketinfantCost2" onkeyup="numericFilter(this);" value="<?php echo $editresult['infantCost']; ?>" maxlength="6"/>
	</label>
 </div>

 	<div class="griddiv"><label>
		<div class="gridlable">MarkUp Type</div>
            <select name="markupType2" type="text" class="gridfield"  id="markupType2" maxlength="12" onkeyup="numericFilter(this);">
            <option value="1" <?php if($editresult['markupType']==1){ echo 'selected'; } ?>>%</option>
            <option value="2" <?php if($editresult['markupType']==2){ echo 'selected'; } ?>>Flat</option>
            </select>
						
		</label>
	</div>

							
	<div class="griddiv"><label>
		<div class="gridlable">MarkUp Value</div>
			<input name="markupCost2" type="text" class="gridfield" value="<?php echo $editresult['markupCost'];  ?>" id="markupCost2" />
		</label>
	</div>

 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Remark</div>
	<input name="remarks2" type="text" class="gridfield"  id="remarks2"  value="<?php echo $editresult['remark']; ?>"/>
	</label>
 </div>
	<div class="griddiv"><label>
      <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status</div>
	<select id="status2" name="status2" class="gridfield" displayname="Status" autocomplete="off"   >
<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>Inactive</option>
</select>
	</label>
 </div>

 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<!-- Add Cruise Price End -->

<?php 
if($_GET['action']=='editdmctransferrate' && $_GET['sectionId']!=''){
	if($_GET['sectionId']!=''){
		$id=clean($_GET['sectionId']);
		$rs1=GetPageRecord('*',_DMC_TRANSFER_RATE_MASTER_,'id='.$id.'');
		$editresult=mysqli_fetch_array($rs1);

		$rs222=GetPageRecord('transferName,transferCategory,id',_PACKAGE_BUILDER_TRANSFER_MASTER,' id='.$editresult['transferNameId'].' ');
		$resListing222=mysqli_fetch_array($rs222);
	}
	?>
	<style>
	.addeditpagebox .griddiv .gridlable {
	    width: 100%;
	}
	</style>
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
	<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
			<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />Mail Sent Successfully</div>
			<table border="0" align="center" cellpadding="0" cellspacing="0">
				<tbody>
				  	<tr>
				 	<td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
				  	</tr>
				</tbody>
			</table>
		</div>
		<div id="sendmailfrm">
			<h1 style="text-align:left;">Update <?php echo strip($resListing222['transferName']); ?> </h1>
	  		<div class="addeditpagebox addtopaboxlist">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" >
	<tr style="background-color: transparent !important;">
	  <td width="150" align="left"><div class="griddiv"><label>
				<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
				<select id="supplierId2" name="supplierId2" class="gridfield validate" displayname="Suppliers" autocomplete="off"   >
				<option value="">Select</option>
				<?php
				$where=' deletestatus=0 and name!="" and transferType=5 order by name asc';
				$rs=GetPageRecord('id,name',_SUPPLIERS_MASTER_,$where);
				while($resultlists=mysqli_fetch_array($rs)){   ?>
				<option value="<?php echo strip($resultlists['id']); ?>" <?php if($editresult['supplierId']==strip($resultlists['id'])){ ?> selected="selected" <?php } ?> ><?php echo strip($resultlists['name']); ?></option>
				<?php  } ?>
				</select>
				</label>
				</div>
		</td>
		<td width="10%" align="left" colspan="2"><div class="griddiv"><label>

		<div class="gridlable">Destination<span class="redmind"></span></div>

		<select id="rateDestinationId2" name="rateDestinationId2" class="gridfield validate" displayname="Destination" autocomplete="off"   > 
		 	<option value="">Select</option> 
			<?php 
			$whereD=' deletestatus=0 and name!="" and status=1 order by name asc';  
			$rs=GetPageRecord('id,name',_DESTINATION_MASTER_,$whereD);   
			while($resultlistsD=mysqli_fetch_array($rs)){   ?> 
			<option value="<?php echo strip($resultlistsD['id']); ?>" <?php if($editresult['rateDestinationId']==$resultlistsD['id']){ echo "selected"; }  ?> ><?php echo strip($resultlistsD['name']); ?></option> 
			<?php  } ?>
		</select>

		</label>

		</div></td>
	<!-- 	<td width="150" align="left">
		 <div class="griddiv"><label>
	   <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Market Type<span class="redmind"></span></div>
			<select id="marketType2" name="marketType2" class="gridfield validate" displayname="Market Type" autocomplete="off"     >
			 <option value="">Select</option>
		    <?php
			$rs=GetPageRecord('*','marketMaster','  status=1 and deletestatus=0 order by name asc');
			while($resListing=mysqli_fetch_array($rs)){
		    ?>
		    <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['marketType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
		    <?php } ?>
		    </select>
			</label>
		 </div>
		</td> -->
		<td width="80" align="left"><div class="griddiv">
			<label>
			<div class="gridlable">Rate&nbsp;Valid&nbsp;From <span class="redmind"></span></div>
			<input name="fromDate2" type="date" class="gridfield"  id="fromDate" value="<?php echo $editresult['fromDate']; ?>"/>
			</label>
			</div>	
		</td>
		<td width="80" align="left"><div class="griddiv">
			<label>
			<div class="gridlable">Rate&nbsp;Valid&nbsp;To<span class="redmind"></span>  </div>
			<input name="toDate2" type="date" class="gridfield"  id="toDate" value="<?php echo $editresult['toDate']; ?>"/>
			</label>
			</div>	
		</td>
		<td width="100" align="left"><div class="griddiv">
			<label>
			<div class="gridlable">Tarif Type<span class="redmind"></span></div>
			<select id="tarifType2" name="tarifType2" class="gridfield" displayname="Tarif Type" autocomplete="off" >
				<option value="1" <?php if('1'==$editresult['tarifType']){ ?>selected="selected"<?php } ?>>Normal</option>
				<option value="2" <?php if('2'==$editresult['tarifType']){ ?>selected="selected"<?php } ?>>Weekend</option>
			</select>
			</label>
			</div>
		</td>
		<?php if($resListing222['transferCategory']=='transportation'){ ?>
		<td width="100" align="left" style="display:none;" >
			<div class="griddiv">
			<label> 
			<div class="gridlable">Type <span class="redmind"></span></div>
			<select id="transferType2" name="transferType2" class="gridfield validate" displayname="Transfer Type" onchange="selectTransferType2(this.value);"> 
			 <!-- <option value="1" <?php if('1'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>SIC</option> -->
			<option value="2" <?php if('2'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>PVT</option>
			</select>
			</label>
			</div>	
		</td>
		<?php } if($resListing222['transferCategory']=='transfer'){ ?>
		<td width="100" align="left">
			<div class="griddiv">
			<label> 
			<div class="gridlable">Type <span class="redmind"></span></div>
			<select id="transferType2" name="transferType2" class="gridfield validate" displayname="Transfer Type" onchange="selectTransferType2(this.value);"> 
			 <option value="1" <?php if('1'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>SIC</option>
			<option value="2" <?php if('2'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>PVT</option>
			</select>
			</label>
			</div>	
		</td>
		<?php } ?>
		<td width="100" align="left">
			<div class="griddiv">
			<label>
			<div class="gridlable">Currency<span class="redmind"></span></div>
			<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
					<option value="">Select</option>
					<?php
					$select='';
					$where='';
					$rs='';
					$select='*';
					$where=' deletestatus=0 and status=1 order by name asc';
					$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
					while($resListing=mysqli_fetch_array($rs)){
					?>
					<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
					<?php } ?>
					</select>
			</label>
			</div>	
		</td>
		<td width="100" align="left" valign="middle"  >
			<div class="griddiv">
			<label>
			<div class="gridlable">Status</div>
			<select id="status2" name="status2" class="gridfield validate" displayname="Status" autocomplete="off"   >
					<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
					<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
					</select></label>
			</div>	
		</td>
	</tr>
	</table>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" >
  	<tr style="background-color: transparent !important;">
  		<td width="150" align="left"  class="PVT2">
				<div class="griddiv"><label>
				<div class="gridlable">Vehicle&nbsp;Type</div>
				<select id="vehicleType2" name="vehicleType2" class="gridfield"  autocomplete="off" onchange="getVehicleModel2();">
						<?php
				$rs=GetPageRecord('name,id','vehicleTypeMaster',' status=1 and deletestatus=0 order by name asc');
				while($resListing=mysqli_fetch_array($rs)){
				?>
				<option value="<?php echo strip($resListing['id']); ?>" <?php if($editresult['vehicleTypeId'] == strip($resListing['id'])){?> selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>
				<?php } ?>
						</select>
				</label>
				</div> 
			</td>
			<!-- <td width="150" align="left"  class="PVT2" style="display:none;">
				<div class="griddiv"><label>
				<div class="gridlable">Vehicle&nbsp;Name</div>
				<select id="vehicleModelId2" name="vehicleModelId2" class="gridfield"  autocomplete="off" >
					<?php
					$select='*';
					$where='  id="'.$editresult['vehicleModelId'].'" order by id asc';
					$rs=GetPageRecord($select,_VEHICLE_MASTER_MASTER_,$where);
					while($resListing=mysqli_fetch_array($rs)){
					?>
					<option value="<?php echo $resListing['id']; ?>" <?php if($resListing['id'] == $editresult['vehicleModelId']){ ?> selected="selected" <?php } ?>><?php echo $resListing['model']; ?></option>
					<?php } ?>
				</select>
				</label>
				</div>	
			</td>  -->
  	  <td width="100" align="left" class="SIC2"><div class="griddiv"><label>
				<div class="gridlable">Adult&nbsp;Cost </div>
				<input name="adultCost2" type="text" class="gridfield"  id="adultCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['adultCost']; ?>"/>
				</label>
				</div>
			</td>
			<td width="100" align="left" class="SIC2"><div class="griddiv"><label>
				<div class="gridlable">Child&nbsp;Cost </div>
				<input name="childCost2" type="text" class="gridfield"  id="childCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['childCost']; ?>"/>
				</label>
				</div>
			</td>
			<td width="100" align="left" class="SIC2"><div class="griddiv"><label>
				<div class="gridlable">Infant&nbsp;Cost </div>
				<input name="infantCost2" type="text" class="gridfield"  id="infantCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['infantCost']; ?>"/>
				</label>
				</div>
			</td>
			<?php if($resListing222['transferCategory']=='transportation'){ ?>
			<td width="10%" align="left" class="PVT2"><div class="griddiv">
				<label> 
				<div class="gridlable">Type <span class="redmind"></span></div>
				<select id="transferCostType2" name="transferCostType2" class="gridfield validate" displayname="Transfer Cost Type" > 
				<option value="2" <?php if('2'==$editresult['transferCostType']){ ?>selected="selected"<?php } ?>>Package Cost</option>
				 <option value="1" <?php if('1'==$editresult['transferCostType']){ ?>selected="selected"<?php } ?>>Per Day Cost</option>
				</select>
				</label>
				</div>
			</td>
			<?php } ?>
			<td width="100" align="left" class="PVT2"><div class="griddiv"><label>
				<div class="gridlable">Vehicle&nbsp;Cost </div>
				<input name="vehicleCost2" type="text" class="gridfield"  id="vehicleCost2" maxlength="10" onkeyup="numericFilter(this);" value="<?php echo $editresult['vehicleCost']; ?>"/>
				</label>
				</div>
			</td>
  	  <td width="100" align="left" class="PVT2"><div class="griddiv"><label>
				<div class="gridlable">Parking&nbsp;Fee</div>
				<input name="parkingFee2" type="text" class="gridfield"  id="parkingFee2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;"  value="<?php echo $editresult['parkingFee']; ?>"/>
				</label>
				</div>
			</td>
  	  
  	  <td width="100" align="left" class="PVT2"><div class="griddiv"><label>
				<div class="gridlable">Assistance</div>
				<input name="assistance2" type="text" class="gridfield"  id="assistance2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;" value="<?php echo $editresult['assistance']; ?>" />
				</label>
				</div>
			</td>
  		<td width="100" align="left"  class="PVT2"><div class="griddiv"><label>
				<div class="gridlable">Additional&nbsp;Allowance</div>
				<input name="guideAllowance2" type="text" class="gridfield"  id="guideAllowance2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;" value="<?php echo $editresult['guideAllowance']; ?>" />
				</label>
				</div>
			</td>
  	  <td width="100" align="left" class="PVT2" ><div class="griddiv"><label>
				<div class="gridlable">Inter&nbsp;State&nbsp;&&nbsp;Toll </div>
				<input name="interStateAndToll2" type="text" class="gridfield"  id="interStateAndToll2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;" value="<?php echo $editresult['interStateAndToll']; ?>" />
				</label>
				</div>
			</td>
  	  <td width="100" align="left" class="PVT2" ><div class="griddiv"><label>
				<div class="gridlable">Miscellaneous&nbsp;Cost</div>
				<input name="miscellaneous2" type="text" class="gridfield"  id="miscellaneous2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;" value="<?php echo $editresult['miscellaneous']; ?>" />
				</label>
				</div>
			</td>
			<td width="100" align="left" ><div class="griddiv"><label>
				<div class="gridlable">Rep.&nbsp;Cost</div>
				<input name="representativeEntryFee2" type="text" class="gridfield"  id="representativeEntryFee2" maxlength="10"  onkeyup="numericFilter(this);"  style="width: 100%;" value="<?php echo $editresult['representativeEntryFee']; ?>" />
				</label>
				</div>
			</td>
			<td width="150" align="left" valign="middle"  ><div class="griddiv">
				<label>
				<div class="gridlable">GST/TAX Slab<span class="redmind"></span></div>
				<select id="gstTax2" name="gstTax2" class="gridfield " displayname="GST" autocomplete="off" style="width: 100% !important;">
				 <?php 
				$rs2="";
				$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="Transfer" and status=1 order by gstSlabName asc'); 
				while($gstSlabData=mysqli_fetch_array($rs2)){
				?>
				<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id'] == $editresult['gstTax']){ ?> selected="selected" <?php } ?>><?php echo $gstSlabData['gstSlabName'];?></option>
				<?php
				}	
				?>
				</select>
				</label>
				</div>
			</td>
		</tr>
	  <tr style="background-color: transparent !important;">	
  	  <td align="left" colspan="11" valign="middle"  >
  	  	<div class="griddiv"><label>
				<div class="gridlable">Remarks </div>
				<input name="detail2" type="text" class="gridfield"  id="detail2" maxlength="220"  value="<?php echo $editresult['detail']; ?>"   style="width: 100%;"/>
				</label>
				</div>
				<input name="dmctransferrateId2" id="dmctransferrateId2" type="hidden" value="<?php echo $id; ?>" />
				<input name="action" id="action" type="hidden" value="updatedmctransferRate" />
			</td>
	  </tr>
	</tbody>
	</table>
	</div>
	  <div id="buttonsbox"  style="text-align:center;">
	 		<table border="0" align="right" cellpadding="0" cellspacing="0">
		  	<tr><td  >
		  			<input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" style="display:inline-block;"/>
		  		</td>
					<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
					</td>
		  </tr>
	   </table>
	</div>
	<script type="text/javascript">
	// user in loadalertbox
	function selectTransferType2(value){
		if(value == 1){
			$('.SIC2').css('display','table-cell');
			$('.PVT2').css('display','none');
		}else{
			$('.PVT2').css('display','table-cell');
			$('.SIC2').css('display','none');
		}
	}
	selectTransferType2(<?php echo $editresult['transferType']; ?>);
	function getVehicleModel2(){
	 	var vehicleType = $('#vehicleType2').val();
		$("#vehicleModelId2").load('loadvehiclemodel.php?action=loadVehicleModel&vehicleTypeId='+vehicleType);
	}
	</script>
	</div>
	</div>
	</form>
	<?php 
} ?>
<?php if($_GET['action']=='foundduplicaterecored'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['done']==1){ ?>File Import <?php } else { ?>Found <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; }else{ echo 'Duplicate'; } ?> Records<?php } if($_REQUEST['errorCount']>1){ echo '&nbsp;&nbsp;'.($_REQUEST['errorCount']-1); } ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
#dupplicaterecoreddlist{max-height:300px; overflow:auto;}
#dupplicaterecoreddlist div{padding:10px; border-bottom:1px #CCCCCC solid; font-size:14px;}
</style>
<?php if($_REQUEST['done']!=1){ ?>
<div id="dupplicaterecoreddlist">Calculating <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records</div>
<?php } else { ?>
<div style="text-align:center;">
<div style="font-size:20px; font-weight:bold; padding-bottom:10px;">File Upload Completed!!</div>
<div style="font-size:14px; font-weight:normal;">Please check the log file for more details.</div>
<div></div>
</div>
<?php } ?>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
	  <?php if($_REQUEST['moduleName']!=''){ ?>
	  <td style="padding-right:20px;"><a href="showpage.crm?module=<?php echo $_REQUEST['moduleName']; ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
	  <?php } else { ?>
        <td style="padding-right:20px;"><a href="showpage.crm?module=<?php if($_REQUEST['pagename']!=''){ echo $_REQUEST['pagename']; } else { echo 'corporate'; } ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
		  <?php } ?>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='foundduplicaterecoreds'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['done']==1){ ?>File Import Successfully<?php } else { ?>Found <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records<?php } if($_REQUEST['errorCount']>0){ echo '&nbsp;&nbsp;'.($_REQUEST['errorCount']-1); } ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
#dupplicaterecoreddlist{max-height:300px; overflow:auto;}
#dupplicaterecoreddlist div{padding:10px; border-bottom:1px #CCCCCC solid; font-size:14px;}
</style>
<?php if($_REQUEST['done']!=1){ ?>
<div id="dupplicaterecoreddlist">Calculating <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records</div>
<?php } else { ?>
<div style="text-align:center;">
<div style="font-size:20px; font-weight:bold; padding-bottom:10px;">Import Complete</div>
<div style="font-size:14px; font-weight:normal;">File is uploaded Please Refer to log file.</div>
<div></div>
</div>
<?php } ?>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
	  <?php if($_REQUEST['moduleName']!=''){ ?>
	  <td style="padding-right:20px;"><a href="showpage.crm?module=<?php echo  $_REQUEST['moduleName']; ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
	  <?php } else { ?>
        <td style="padding-right:20px;"><a href="showpage.crm?module=<?php if($_REQUEST['pagename']!=''){ echo $_REQUEST['pagename']; } else { echo 'subjectmaster'; } ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
		  <?php } ?>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='foundduplicaterecoredd'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['done']==1){ ?>File Import Successfully<?php } else { ?>Found <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records<?php } if($_REQUEST['errorCount']>0){ echo '&nbsp;&nbsp;'.($_REQUEST['errorCount']-1); } ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
#dupplicaterecoreddlist{max-height:300px; overflow:auto;}
#dupplicaterecoreddlist div{padding:10px; border-bottom:1px #CCCCCC solid; font-size:14px;}
</style>
<?php if($_REQUEST['done']!=1){ ?>
<div id="dupplicaterecoreddlist">Calculating <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records</div>
<?php } else { ?>
<div style="text-align:center;">
<div style="font-size:20px; font-weight:bold; padding-bottom:10px;">Import Complete</div>
<div style="font-size:14px; font-weight:normal;">File is uploaded Please Refer to log file</div>
<div></div>
</div>
<?php } ?>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
	  <?php if($_REQUEST['moduleName']!=''){ ?>
	  <td style="padding-right:20px;"><a href="showpage.crm?module=<?php echo  $_REQUEST['moduleName']; ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
	  <?php } else { ?>
        <td style="padding-right:20px;"><a href="showpage.crm?module=<?php if($_REQUEST['pagename']!=''){ echo $_REQUEST['pagename']; } else { echo 'itinerarydescription'; } ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
		  <?php } ?>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='foundduplicaterecoredg'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['done']==1){ ?>File Import Successfully<?php } else { ?>Found <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records<?php } if($_REQUEST['errorCount']>0){ echo '&nbsp;&nbsp;'.($_REQUEST['errorCount']-1); } ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
#dupplicaterecoreddlist{max-height:300px; overflow:auto;}
#dupplicaterecoreddlist div{padding:10px; border-bottom:1px #CCCCCC solid; font-size:14px;}
</style>
<?php if($_REQUEST['done']!=1){ ?>
<div id="dupplicaterecoreddlist">Calculating <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records</div>
<?php } else { ?>
<div style="text-align:center;">
<div style="font-size:20px; font-weight:bold; padding-bottom:10px;">Import Complete</div>
<div style="font-size:14px; font-weight:normal;">File is uploaded Please Refer to log file</div>
<div></div>
</div>
<?php } ?>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
	  <?php if($_REQUEST['moduleName']!=''){ ?>
	  <td style="padding-right:20px;"><a href="showpage.crm?module=<?php echo  $_REQUEST['moduleName']; ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
	  <?php } else { ?>
        <td style="padding-right:20px;"><a href="showpage.crm?module=<?php if($_REQUEST['pagename']!=''){ echo $_REQUEST['pagename']; } else { echo 'guidemaster'; } ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
		  <?php } ?>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='foundduplicaterecoredgs'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['done']==1){ ?>File Import Successfully<?php } else { ?>Found <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records<?php } if($_REQUEST['errorCount']>0){ echo '&nbsp;&nbsp;'.($_REQUEST['errorCount']-1); } ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
#dupplicaterecoreddlist{max-height:300px; overflow:auto;}
#dupplicaterecoreddlist div{padding:10px; border-bottom:1px #CCCCCC solid; font-size:14px;}
</style>
<?php if($_REQUEST['done']!=1){ ?>
<div id="dupplicaterecoreddlist">Calculating <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records</div>
<?php } else { ?>
<div style="text-align:center;">
<div style="font-size:20px; font-weight:bold; padding-bottom:10px;">Import Complete</div>
<div style="font-size:14px; font-weight:normal;">File is uploaded Please Refer to log file</div>
<div></div>
</div>
<?php } ?>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
	  <?php if($_REQUEST['moduleName']!=''){ ?>
	  <td style="padding-right:20px;"><a href="showpage.crm?module=<?php echo  $_REQUEST['moduleName']; ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
	  <?php } else { ?>
        <td style="padding-right:20px;"><a href="showpage.crm?module=<?php if($_REQUEST['pagename']!=''){ echo $_REQUEST['pagename']; } else { echo 'guidesubcatmaster'; } ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
		  <?php } ?>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='foundduplicaterecoreddriver'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['done']==1){ ?>File Import Successfully<?php } else { ?>Found <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records<?php } if($_REQUEST['errorCount']>0){ echo '&nbsp;&nbsp;'.($_REQUEST['errorCount']-1); } ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
#dupplicaterecoreddlist{max-height:300px; overflow:auto;}
#dupplicaterecoreddlist div{padding:10px; border-bottom:1px #CCCCCC solid; font-size:14px;}
</style>
<?php if($_REQUEST['done']!=1){ ?>
<div id="dupplicaterecoreddlist">Calculating <?php if($_REQUEST['moduleName']!=''){ echo 'Error'; } else { echo 'Duplicate'; } ?> Records</div>
<?php } else { ?>
<div style="text-align:center;">
<div style="font-size:20px; font-weight:bold; padding-bottom:10px;">Import Complete</div>
<div style="font-size:14px; font-weight:normal;">File is uploaded Please Refer to log file </div>
<div></div>
</div>
<?php } ?>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
	  <?php if($_REQUEST['moduleName']!=''){ ?>
	  <td style="padding-right:20px;"><a href="showpage.crm?module=<?php echo  $_REQUEST['moduleName']; ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
	  <?php } else { ?>
        <td style="padding-right:20px;"><a href="showpage.crm?module=<?php if($_REQUEST['pagename']!=''){ echo $_REQUEST['pagename']; } else { echo 'drivermaster'; } ?>">
          <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close"  /></a></td>
		  <?php } ?>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?> 
<?php if($_GET['action']=='adddmcpaymentrequest' && $_GET['queryId']!=''){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_DMC_PAYMENT_REQUEST_,$where1);
$editresult=mysqli_fetch_array($rs1);
$fromDate=$editresult['fromDate'];
$edittourType=$editresult['tourType'];
$gstTypeId=$editresult['gstTypeId'];
$gst=$editresult['gst'];
$paxType=$editresult['paxType'];
$description=$editresult['description'];
$pax=$editresult['pax'];
$rate=$editresult['rate'];
$subtotal=$editresult['subtotal'];
$currencyId=$editresult['currencyId'];
$referenceNo=$editresult['referenceNo'];
} else {
$fromDate=date('d-m-Y');
 }
?>
<script>
 $(document).ready(function() {
$('#fromDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> DMC Payment Request </h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
  <input name="action" id="action" type="hidden" value="adddmcpaymentrequest" />
    <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
	    <input name="editid" id="editid" type="hidden" value="<?php echo $_GET['id']; ?>" />
<div style="text-align:center; padding:20px; text-align:center; color:#009900; font-size:15px; display:none;" id="sentfilemsg">File Sent Successfully.<br ><br ><table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table></div>
<div id="sendfilefrm">
<div class="griddiv"><label>
	<div class="gridlable"  style="width:100%;">Date<span class="redmind"></span></div>
	<input name="fromDate" type="text" id="fromDate" class="gridfield calfieldicon validate"  displayname="Date"   autocomplete="off" value="<?php echo date("d-m-Y", strtotime($fromDate)); ?>" style="width:100%;"/>
	<style>
	.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
	</label>
 </div>
 <div class="griddiv" style="border-bottom:0px;"><label>
	<div class="gridlable" style="width:100%;">Service <span class="redmind"></span></div>
	<select id="tourType" name="tourType" class="gridfield validate" displayname="Tour Type" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TOUR_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$edittourType){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	<style>
	.Zebra_DatePicker_Icon_Wrapper{width:100% !important;}
	</style>
	</label>
 </div>
 <div >
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Reference No. </div>
	<input name="referenceNo" type="text" class="gridfield" id="referenceNo"   value="<?php echo $referenceNo; ?>" maxlength="200" displayname="Reference No."  autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Description </div>
	<input name="description" type="text" class="gridfield" id="description"   value="<?php echo $description; ?>" maxlength="200" displayname="Description"  autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv" style="border-bottom:0px;"><label>
  <script>
  function setgst(){
  var gstTypeId = $('#gstTypeId').val();
  $('#gst').val(gstTypeId);
  dmcpaymentrequestrate();
  }
  </script>
	<div class="gridlable" style="width:100%;">GST Type<span class="redmind"></span></div>
	<select id="gstTypeId" name="gstTypeId" class="gridfield validate" displayname="GST Type" autocomplete="off" onchange="setgst();">
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' 1 order by name asc';
$rs=GetPageRecord($select,_GST_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['gstValue']); ?>" <?php if($resListing['gstValue']==$gstTypeId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">GST %</div>
	<input name="gst" type="text" class="gridfield" id="gst"   maxlength="3" displayname="GST"  autocomplete="off" onkeyup="numericFilter(this);" value="<?php echo $gst; ?>"  />
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Pax Type<span class="redmind"></span></div>
	<select id="paxType" name="paxType" class="gridfield validate" displayname="GST Type" autocomplete="off"   >
	 <option value="">Select</option>
<option value="1" <?php if(1==$paxType){ ?>selected="selected"<?php } ?>>Adult</option>
<option value="2" <?php if(2==$paxType){ ?>selected="selected"<?php } ?>>Child</option>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Pax<span class="redmind"></span></div>
	<input name="pax"   type="text" class="gridfield validate" id="pax"   maxlength="3" displayname="Pax"  autocomplete="off" onkeyup="numericFilter(this);dmcpaymentrequestrate();" value="<?php echo $pax; ?>"  />
	</label>
 </div>
 <div class="griddiv" style="border-bottom:0px;"><label>
	<div class="gridlable" style="width:100%;">Currency  <span class="redmind"></span></div>
	<select id="currencyId" name="currencyId" class="gridfield validate" displayname="Currency" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$currencyId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Rate<span class="redmind"></span></div>
	<input name="rate"   type="text" class="gridfield" id="rate"   maxlength="6" displayname="Rate"  autocomplete="off" onkeyup="numericFilter(this);dmcpaymentrequestrate();" value="<?php echo $rate; ?>"  />
	</label>
	<script>
	function dmcpaymentrequestrate(){
	var rate = Number($('#rate').val());
	var pax = Number($('#pax').val());
	var gst = Number($('#gst').val());
	if(rate!='' && pax!='' && gst!=''){
	var totalsub=Number(pax*rate);
	var gstval = Number(totalsub*gst/100);
	$('#subtotal').val(gstval+totalsub);
	}
	}
	</script>
 </div>
  <div class="griddiv"><label>
	<div class="gridlable">Sub Total<span class="redmind"></span></div>
	<input name="subtotal" type="text" class="gridfield" id="subtotal"   maxlength="6" displayname="Sub Total"  autocomplete="off" onkeyup="numericFilter(this);" value="<?php echo $subtotal; ?>"  />
	</label>
 </div>
  </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Add    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='cancelqueryopenbox'){  ?>
<div class="contentclass">
<h1 style="text-align:left;">Cancel Query  </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; overflow:hidden; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery" style="overflow:hidden;">
 <div style="overflow:hidden;">
<table border="0" align="left" cellpadding="10" cellspacing="0" style="margin-bottom:10px; margin-top:10px;">
  <tr>
    <td colspan="3" align="left"><strong>Do you want to cancel voucher and invoice also?</strong></td>
    </tr>
  <tr>
    <td width="1" align="right"><label>
      <input name="changequerystatus2cancel" id="changequerystatus2cancel" value="20" type="radio"   onclick="$('#textareiaboxcancel').show();"/>
    </label></td>
    <td width="353" align="left" style="padding-left:0px;">Yes</td>
  </tr>
  <tr>
    <td align="right" ><label>
      <input  name="changequerystatus2cancel" id="changequerystatus2cancel"  value="nocancel" type="radio"   onclick="$('#textareiaboxcancel').hide();" checked="checked" />
    </label></td>
    <td align="left" style="padding-left:0px;">No</td>
  </tr>
  <tr>
    <td align="right" >&nbsp;</td>
    <td align="left" style="padding-left:0px;"><div style="margin-bottom: 10px; display: grid; display:none;" id="textareiaboxcancel" class="shoqhidebuttonsquery">Remark:<textarea name="queryCloseDetails" cols="" rows="" id="queryCloseDetails" style="width:100%; height:60px; padding:10px; font-family:Arial, Helvetica, sans-serif; font-size:12px; border:1px #CCCCCC solid; box-sizing:border-box;" placeholder="Enter query related details"></textarea>
</div></td>
  </tr>
</table>
 </div>
<div style="margin-bottom:10px; display:none;" id="textareiabox" class="shoqhidebuttonsquery">Remark:<textarea name="queryclosedetails" cols="" rows="" id="queryclosedetails" style="width:100%; height:60px; padding:10px; font-family:Arial, Helvetica, sans-serif; font-size:12px; border:1px #CCCCCC solid; box-sizing:border-box;" placeholder="Enter query related details"></textarea>
</div>
<div style="overflow:hidden;">
  <input name="changestausidqueryid" type="hidden" id="changestausidqueryid" value="<?php echo $_REQUEST['queryId']; ?>">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
    <td align="right" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Cancel Query    " onclick="formValidation('changestatusquery','submitbtn','0');"  /></td>
  </tr>
</table></div>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
</form>
  </div>
</div>
<style>
input[type="radio"] {
    display: block;
}
</style>
	<?php  } ?>
<?php if($_GET['action']=='selectattachementdocumentfile'){  ?>
<div class="contentclass">
<h1 style="text-align:left;">Select File</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; overflow:hidden; " >
 <div style="overflow:hidden; padding:10px;" id="loaddocumentfile">
 Loading...
 </div>
 <script>
 	function loadfolderquery(){
	$('#loaddocumentfile').load('load_queryfolderlistinner.php?thumborlist=2');
	}
	loadfolderquery();
	function showfolderorfileviewmain(id,name){
	var name = encodeURIComponent(name);
	$('#loaddocumentfile').load('load_queryfileview.php?thumborlist=2&name='+name+'&id='+id);
	}
	function loadfiles(id){
	var folderView = $('#folderView').val();
	$('#folderouter').load('load_queryfilelistinner.php?thumborlist=2&id='+id);
	}
	function removediv(id){
	$('#boxid'+id).remove();
	}
	function selecteddocumentfiles(id,name,url){
	var appendcontent = '<div style="border:1px #d8d8d8 solid; padding:10px; margin-bottom:10px;background-color: #fff;" id="boxid'+id+'"><table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td width="78%" align="left" style="font-size:14px; font-weight:bold;">'+name+'</td><td width="10%" align="right"><a href="'+url+'"  target="_blank"><input type="button" value="Download" class="documentdownloadbtn"  style="background-color: #82b767; color: #fff; padding: 5px 8px; border: 0px; cursor: pointer; outline: 0px; border-radius: 4px;"></a></td><td width="0%" align="center"><span class="filedeletedocument" onclick="removediv('+id+');" style="cursor: pointer; display:none;">Delete</span></td> </tr></table></div>';
	$('#selecteddocumentfiles').append(appendcontent);
	alertspopupopenClose();
	}
 </script>
 <style>
 .documentdownloadbtn{display:none;}
 .filedeletedocument{display:block !important;}
 </style>
<div style="margin-bottom:10px; display:none;" id="textareiabox" class="shoqhidebuttonsquery">Remark:<textarea name="queryclosedetails" cols="" rows="" id="queryclosedetails" style="width:100%; height:60px; padding:10px; font-family:Arial, Helvetica, sans-serif; font-size:12px; border:1px #CCCCCC solid; box-sizing:border-box;" placeholder="Enter query related details"></textarea>
</div>
<div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" /> </td>
    </tr>
</table>
</div>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
  </div>
</div>
<style>
input[type="radio"] {
    display: block;
}
</style>
	<?php  } ?>
<?php if($_GET['action']=='addNotes' && $_GET['queryId']!=''){ ?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Notes </h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
  <input name="action" id="action" type="hidden" value="addNotes" />
  <input name="queryId2" id="queryId2" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
  <input name="Submit3" type="button" class="greenbuttonx2" id="replybtn" value="Add Staff" style="margin-right:10px;margin-left: 75%;" onclick="$('#replymainbox').show();$('#replybtn').hide();"/>
  <div style="text-align:center; padding:20px; text-align:center; color:#009900; font-size:15px; display:none;" id="sentfilemsg">File Sent Successfully.<br ><br ><table border="0" align="center" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table></div>
<div id="sendfilefrm">
 <div >
 </div>
<div class="griddiv"><label>
	<div class="gridlable">Note<span class="redmind"></span></div>
	<textarea name="notesDescription" rows="5" class="gridfield validate" id="notesDescription" displayname="Note" autocomplete="off"><?php echo $pax; ?></textarea>
	</label>
 </div>
  </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<?php } ?>



<?php 
if($_GET['action']=='addsupplierquote' && $_GET['queryId']!=''){ ?>
	<div class="contentclass">
	<div id="sendmailfrm">
	<h1 style="text-align:left;">Supplier Communication</h1>
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
	<input name="action" id="action" type="hidden" value="addsupplierquote" />
	<input name="queryId2" id="queryId2" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
	<div class="griddiv"><label>
	<select id="companyTypeId" name="companyTypeId" class="gridfield validate" displayname="Service" onchange="selcetservicefun();" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
	<option value="">Select Supplier Type</option>
	<!--<option value="100">DMC</option>-->
	<?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' deletestatus=0 and status=1 order by id asc';
	$rs=GetPageRecord($select,_SUPPLIERS_TYPE_MASTER_,$where);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
	</select>
	<div id="supplierIdtd" style="display:none;width:100%;" ><span class="redmind" style="width: 50px;position: absolute;display: block;height: 2px;margin-top: 42px;background: red;"></span>
	<select id="supplierId" name="supplierId[]" class="validate gridfield select2" displayname="Supplier Name" multiple="multiple" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
	</select>
	<style>
	.addeditpagebox .griddiv .gridlable{
	width: 100%;
	}
	.contentclass .select2-container, .select2-container.select2-container--default.select2-container--open {
	box-sizing: border-box;
	display: inline-block;
	z-index: 99999999;
	margin: 0;
	position: relative;
	vertical-align: middle;
	}
	</style>
	<div style="margin-top:10px;"><textarea name="details" cols="" rows="" id="details" class="gridfield"  style="width:100%; height:150px;">Dear Sir,
	Please share your quotation of mentioned query below</textarea></div>
	<div style="margin-top:10px;"><label style="text-align: left; width: 100%; display: block; font-size: 12px; margin-bottom: 5px;">Add more emails</label><input type="text" name="ccSupplier" id="ccSupplier" placeholder="test@example.com,test@example.com" style="width: 96% !important; margin: 0px !important; padding: 8px 10px !important; box-shadow: inset 0 0 2px #ccc !important; border: 1px solid #ccc !important;"/></div>
	</div>
	<script type="text/javascript"  src="plugins/select2/select2.min.js"></script>
	<script>
	function selcetservicefun(){
	var companyTypeId = encodeURIComponent($('#companyTypeId').val());
	$('#supplierId').load('loadsuppliercompany_quote.php?companyTypeId='+companyTypeId);
	$('#supplierIdtd').show();
	}
	</script>
	<script>
	$(document).ready(function() {
	$('.select2').select2();
	});
	</script>
	</label>
	</div>
	</form>
	</div>
	</div>
	<div id="buttonsbox"  style="text-align:center;margin-bottom:20px;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
	</tr>
	</table>
	</div>
	</div></div>
	<?php 
} ?>


<?php 
if($_GET['action']=='sendSupplierQuotationRequest' && $_REQUEST['quotationId']!=''){  ?>
	<div class="contentclass">
		<h1 style="text-align:left;">Supplier Communication</h1>
		<div class="contentclass"  style="overflow:auto;"  id="loadSupplierQuotationRequestBox"></div>
		<script type="text/javascript">
		$('#loadSupplierQuotationRequestBox').load('loadSupplierQuotationRequest.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>&finalcategory=0');
		</script>
	</div>
	<?php 
} ?>

<?php if($_GET['action']=='dmcmakepaymentrequestpayment' && $_GET['queryId']!=''){ ?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Payment  </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="griddiv" id="boxpaymentdiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Payment Amount <span class="redmind"></span></div>
	<input onKeyUp="numericFilter(this);" name="amount" type="text" class="gridfield validate" id="amount" value=""  maxlength="20"  displayname="Payment Amount" autocomplete="off"   />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Attachment </div>
	 <input name="attachmentFile" type="file" id="attachmentFile" style="width:100%;" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="details" rows="3" class="gridfield" id="details" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div>
 <input name="adddmcpaymenttopaymentrequest" type="hidden" id="adddmcpaymenttopaymentrequest" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='additineraryplan' && $_GET['queryId']!='' && $_GET['fromDate']!=''){ ?>
	<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Plan</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div style="padding:20px;">
<a onclick="alertspopupopen('action=addhotelToitnerry&queryId=<?php echo $_GET['queryId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&destinationId=<?php echo $_REQUEST['destinationId']; ?>','700px','auto');">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add Hotel </div></a>
<a  onclick="alertspopupopen('action=addsightseeingToitnerry&queryId=<?php echo $_GET['queryId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&destinationId=<?php echo $_REQUEST['destinationId']; ?>','700px','auto');">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add Sightseeing</div></a>
<a><div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;" onclick="alertspopupopen('action=addtransferToitnerry&queryId=<?php echo $_GET['queryId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&destinationId=<?php echo $_REQUEST['destinationId']; ?>','700px','auto');">+ Add Transfer</div></a>
<a  onclick="alertspopupopen('action=additineraryflightdetails&queryId=<?php echo $_GET['queryId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&destinationId=<?php echo $_REQUEST['destinationId']; ?>','700px','auto');"><div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add Flight</div></a>
<a onclick="alertspopupopen('action=addextraToitnerry&queryId=<?php echo $_GET['queryId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&destinationId=<?php echo $_REQUEST['destinationId']; ?>','400px','auto');"><div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add Extra</div></a>
  </div>
 <input name="adddmcpaymenttopaymentrequest" type="hidden" id="adddmcpaymenttopaymentrequest" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addtransferToitnerry' && $_GET['queryId']!=''){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_ITINERARY_TRANSFER_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
  $fromDate2=$editresult['fromDate'];
$toDate2=$editresult['toDate'];
$destinationId=$editresult['destinationId'];
} else {
$destinationId=$_REQUEST['destinationId'];
$fromDate2=$_REQUEST['fromDate'];
$toDate2=$_REQUEST['toDate'];
$night2=$_REQUEST['night'];
$hotelName=$_REQUEST['hotelName'];
$hoteladdress=$_REQUEST['hotelAddress'];
$editcategoryId='';
$roomType='';
$destinationId=$_REQUEST['destinationId'];
 }
?>
<script>
 $(document).ready(function() {
 $('#toDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
 $('#fromDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
  function transferTypeSelect(){
	var transferType = $('#transferType').val();
	$('.SIC').css('display','none');
	$('.PVT').css('display','none');
	if(transferType==1){
	$('.SIC').css('display','inline-block');
	}
	if(transferType==2){
	$('.PVT').css('display','inline-block');
	}
	}
  	function showmaxpax(){
	var vehicleId = $('#vehicleId').val();
	$('#maxpaxbox').load('loadmaxpaxdmcbox2.php?id='+vehicleId);
	}
	</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['transferQuotationId']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Transfer </h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="transferItineraryId" id="transferItineraryId" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="addtransferItinerary" />
    <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Destination  </div>
	<select id="destinationId2" name="destinationId2" class="gridfield" displayname="Destination" autocomplete="off" >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$destinationId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Travel Date<span class="redmind"></span></div>
	<input name="fromDate3" type="text" id="fromDate3" class="gridfield calfieldicon validate"  displayname="From Travel Date" readonly="readonly"   autocomplete="off" value="<?php echo date("d-m-Y", strtotime($fromDate2)); ?>" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer&nbsp;Name<span class="redmind"></span></div>
	<select id="transferNameId" name="transferNameId" class="gridfield validate" displayname="Transfer Name" autocomplete="off"  >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TRANSFER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['transferNameId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Time: <span class="redmind"></span></div>
	<select id="traveltime" name="traveltime" class="gridfield Time" displayname="Travel Time" autocomplete="off"   >
  <option value="">Select</option>
 <?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    {
?>
<option value="<?php echo date('g:i A',$i); ?>"  <?php if(ltrim(date("h:i A", strtotime($editresult['traveltime'])), '0')==date('g:i A',$i)){ ?>selected="selected"<?php } ?>><?php echo date('g:i A',$i); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Transfer&nbsp;From <span class="redmind"></span></div>
	<select id="transferFromId" name="transferFromId" class="gridfield validate" displayname="Transfer From" autocomplete="off"   >
  <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TRANSFER_CATEGORY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['transferFromId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer&nbsp;To<span class="redmind"></span></div>
	<select id="transferToId" name="transferToId" class="gridfield validate" displayname="Transfer To" autocomplete="off"    >
<option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TRANSFER_CATEGORY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['transferToId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer Type<span class="redmind"></span></div>
	<select id="transferType" name="transferType" class="gridfield validate" displayname="Transfer Type" autocomplete="off"   onchange="transferTypeSelect();" >
<option value="1" <?php if('1'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>SIC</option>
<option value="2" <?php if('2'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>Private</option>
</select>
	</label>
 </div>
 <div class="griddiv PVT"><label>
	<div class="gridlable">Vehicle Name</div>
	<select id="vehicleId" name="vehicleId" class="gridfield"  autocomplete="off"  onchange="showmaxpax();"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_VEHICLE_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['vehicleId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv PVT"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Max Pax</div><div id="maxpaxbox">
	<input name="maxpaxs" type="text" class="gridfield"  id="maxpaxs" maxlength="6" readonly="readonly"/></div>
	</label>
 </div>
 <?php if($editresult['vehicleId']!=''){ ?>
 <script>
 showmaxpax();
 </script>
 <?php } ?>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Information</div>
	<input name="detail" type="text" class="gridfield"  id="detail" maxlength="500"  value="<?php echo $editresult['detail']; ?>"/>
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	 <script>
	 transferTypeSelect();
	 </script>
	<?php } ?>
<?php if($_GET['action']=='addextraToitnerry' && $_GET['queryId']!=''){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_ITINERARY_EXTRA_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
  $fromDate2=$editresult['fromDate'];
} else {
$fromDate2=$_REQUEST['fromDate'];
 }
?>
<script>
 $(document).ready(function() {
 $('#toDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
 $('#fromDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
  function transferTypeSelect(){
	var transferType = $('#transferType').val();
	$('.SIC').css('display','none');
	$('.PVT').css('display','none');
	if(transferType==1){
	$('.SIC').css('display','inline-block');
	}
	if(transferType==2){
	$('.PVT').css('display','inline-block');
	}
	}
  	function showmaxpax(){
	var vehicleId = $('#vehicleId').val();
	$('#maxpaxbox').load('loadmaxpaxdmcbox2.php?id='+vehicleId);
	}
	</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['extraQuotationId']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Extra </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="extraItineraryId" id="extraItineraryId" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="addextraItinerary" />
    <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Travel Date<span class="redmind"></span></div>
	<input name="fromDate3" type="text" id="fromDate3" class="gridfield calfieldicon validate"  displayname="From Travel Date" readonly="readonly"   autocomplete="off" value="<?php echo date("d-m-Y", strtotime($fromDate2)); ?>" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Extra<span class="redmind"></span></div>
	<select id="extra" name="extra" class="gridfield validate" displayname="Transfer Name" autocomplete="off"  >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_EXTRA_QUOTATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['name']); ?>" <?php if($resListing['name']==$editresult['name']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Time: <span class="redmind"></span></div>
	<select id="traveltime" name="traveltime" class="gridfield Time" displayname="Travel Time" autocomplete="off"   >
  <option value="">Select</option>
 <?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    {
?>
<option value="<?php echo date('g:i A',$i); ?>"  <?php if(ltrim(date("h:i A", strtotime($editresult['traveltime'])), '0')==date('g:i A',$i)){ ?>selected="selected"<?php } ?>><?php echo date('g:i A',$i); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Details</div>
	<textarea name="detail" rows="3" class="gridfield" id="detail"><?php echo $editresult['detail']; ?></textarea>
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	 <script>
	 transferTypeSelect();
	 </script>
	<?php } ?>
<?php if($_GET['action']=='addsightseeingToitnerry' && $_GET['queryId']!=''){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_ITINERARY_SIGHTSEEING_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
  $fromDate2=$editresult['fromDate'];
$toDate2=$editresult['toDate'];
$destinationId=$editresult['destinationId'];
} else {
$destinationId=$_REQUEST['destinationId'];
$fromDate2=$_REQUEST['fromDate'];
$toDate2=$_REQUEST['toDate'];
$night2=$_REQUEST['night'];
$hotelName=$_REQUEST['hotelName'];
$hoteladdress=$_REQUEST['hotelAddress'];
$editcategoryId='';
$roomType='';
$destinationId=$_REQUEST['destinationId'];
 }
?>
<script>
 $(document).ready(function() {
 $('#toDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
 $('#fromDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
  function transferTypeSelect(){
	var transferType = $('#transferType').val();
	$('.SIC').css('display','none');
	$('.PVT').css('display','none');
	if(transferType==1){
	$('.SIC').css('display','inline-block');
	}
	if(transferType==2){
	$('.PVT').css('display','inline-block');
	}
	}
  	function showmaxpax(){
	var vehicleId = $('#vehicleId').val();
	$('#maxpaxbox').load('loadmaxpaxdmcbox2.php?id='+vehicleId);
	}
	</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Sightseeing </h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="sightseeingItineraryId" id="sightseeingItineraryId" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="addsightseeingItinerary" />
    <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Destination  </div>
	<select id="destinationId2" name="destinationId2" class="gridfield" displayname="Destination" autocomplete="off" >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$destinationId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Travel Date<span class="redmind"></span></div>
	<input name="fromDate3" type="text" id="fromDate3" class="gridfield calfieldicon validate"  displayname="From Travel Date" readonly="readonly"   autocomplete="off" value="<?php echo date("d-m-Y", strtotime($fromDate2)); ?>" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Sightseeing&nbsp;Name<span class="redmind"></span></div>
	<select id="sightseeingName" name="sightseeingName" class="gridfield validate" displayname="Sightseeing Name" autocomplete="off"  >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_SIGHTSEEING_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['name']); ?>" <?php if($resListing['name']==$editresult['sightseeingName']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
	<div class="gridlable">Time: <span class="redmind"></span></div>
	<select id="traveltime" name="traveltime" class="gridfield Time" displayname="Travel Time" autocomplete="off"   >
  <option value="">Select</option>
 <?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    {
?>
<option value="<?php echo date('G:i A',$i); ?>"  <?php if(date("G:i A", strtotime($editresult['traveltime']))==date('G:i A',$i)){ ?>selected="selected"<?php } ?>><?php echo date('G:i A',$i); ?></option>
<?php } ?>
</select>
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer Type<span class="redmind"></span></div>
	<select id="transferType" name="transferType" class="gridfield validate" displayname="Transfer Type" autocomplete="off"   onchange="transferTypeSelect();" >
<option value="1" <?php if('1'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>SIC</option>
<option value="2" <?php if('2'==$editresult['transferType']){ ?>selected="selected"<?php } ?>>Private</option>
</select>
	</label>
 </div>
 <div class="griddiv PVT"><label>
	<div class="gridlable">Vehicle Name</div>
	<select id="vehicleId" name="vehicleId" class="gridfield"  autocomplete="off"  onchange="showmaxpax();"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_VEHICLE_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['vehicleId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv PVT"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Max Pax</div><div id="maxpaxbox">
	<input name="maxpaxs" type="text" class="gridfield"  id="maxpaxs" maxlength="6" readonly="readonly"/></div>
	</label>
 </div>
 <?php if($editresult['vehicleId']!=''){ ?>
 <script>
 showmaxpax();
 </script>
 <?php } ?>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Information</div>
	<input name="detail" type="text" class="gridfield"  id="detail" maxlength="500"  value="<?php echo $editresult['detail']; ?>"/>
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	 <script>
	 transferTypeSelect();
	 </script>
	<?php } ?>
<?php if($_GET['action']=='additineraryflightdetails' && $_GET['queryId']!=''){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_ITINERARY_FLIGHT_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
  $departureDate=$editresult['departureDate'];
  $arrivalDate=$editresult['arrivalDate'];
$toDate2=$editresult['toDate'];
$destinationId=$editresult['arrivalDestination'];
} else {
$destinationId=$_REQUEST['destinationId'];
$fromDate2=$_REQUEST['fromDate'];
$toDate2=$_REQUEST['toDate'];
$night2=$_REQUEST['night'];
$hotelName=$_REQUEST['hotelName'];
$hoteladdress=$_REQUEST['hotelAddress'];
$editcategoryId='';
$roomType='';
$destinationId=$_REQUEST['destinationId'];
 }
?>
<script>
$(document).ready(function() {
$('#departureDate').Zebra_DatePicker({
format: 'd-m-Y',
});
$('#arrivalDate').Zebra_DatePicker({
format: 'd-m-Y',
});
});
</script>
<style>
.addeditpagebox .griddiv .gridlable {
width: 100%;
}
</style>
<style>
	.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr>
 <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
</tr>
</tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Flight   </h1>
<div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <input name="flightItineraryId" id="flightItineraryId" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="addflightItinerary" />
    <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Departure Destination  <span class="redmind"></span></div>
<select id="departureDestination" name="departureDestination" class="gridfield validate" displayname="Departure Destination" autocomplete="off"   >
<option value="">Select</option>
<?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['departureDestination']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
</label>
</div>
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Departure Date<span class="redmind"></span></div>
<input onKeyUp="numericFilter(this);" name="departureDate" type="text" class="gridfield calfieldicon validate" id="departureDate"  maxlength="20"  displayname="Departure Date" autocomplete="off"   value="<?php  if($editresult['departureDate']==''){  echo date('d-m-Y',strtotime($_REQUEST['fromDate'])); } else { echo date('d-m-Y',strtotime($editresult['departureDate'])); } ?>" />
</label>
</div>
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Departure Time  </div>
<select id="departureTime" name="departureTime" class="gridfield"  autocomplete="off"   >
<option value="">Select</option>
<?php
$start = "00:00";
$end = "23:45";
$tStart = strtotime($start);
$tEnd = strtotime($end);
$tNow = $tStart;
while($tNow <= $tEnd){
?>
<option value="<?php echo date("g:i a",$tNow); ?>"  <?php if($editresult['departureTime']==date("g:i a",$tNow)){ ?>selected="selected"<?php } ?>><?php echo date("g:i a",$tNow); ?></option>
<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
</select>
</label>
</div>
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Arrival Destination  <span class="redmind"></span></div>
<select id="arrivalDestination" name="arrivalDestination" class="gridfield validate" displayname="Arrival Destination" autocomplete="off"   >
<option value="">Select</option>
<?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['arrivalDestination']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
</label>
</div>
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Arrival Date<span class="redmind"></span></div>
<input onKeyUp="numericFilter(this);" name="arrivalDate" type="text" class="gridfield calfieldicon validate " id="arrivalDate"  maxlength="20" value="<?php if($editresult['arrivalDate']==''){ echo date('d-m-Y',strtotime($_REQUEST['fromDate'])); } else { echo date('d-m-Y',strtotime($editresult['arrivalDate'])); } ?>"  displayname="Arrival Date" autocomplete="off"   />
</label>
</div>
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Arrival Time  </div>
<select id="arrivalTime" name="arrivalTime" class="gridfield"  autocomplete="off"   >
<option value="">Select</option>
<?php
$start = "00:00";
$end = "23:45";
$tStart = strtotime($start);
$tEnd = strtotime($end);
$tNow = $tStart;
while($tNow <= $tEnd){
?>
<option value="<?php echo date("g:i a",$tNow); ?>" <?php if($editresult['arrivalTime']==date("g:i a",$tNow)){ ?>selected="selected"<?php } ?>><?php echo date("g:i a",$tNow); ?></option>
<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
</select>
</label>
</div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Information</div>
	<input name="detail" type="text" class="gridfield"  id="detail" maxlength="500"  value="<?php echo $editresult['detail']; ?>"/>
	</label>
 </div>
</form>
</div>
<div id="buttonsbox"  style="text-align:center;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div></div>
<?php } ?>
<?php if($_GET['action']=='addhotelToitnerry' && $_GET['queryId']!=''){
if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_ITINERARY_HOTEL_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
$toDate2=date('d-m-Y',strtotime($editresult['toDate']));
$fromDate2=date('d-m-Y',strtotime($editresult['fromDate']));
$hotelName=$editresult['hotelName'];
$hoteladdress=$editresult['address'];
} else {
$destinationId=$_REQUEST['destinationId'];
$fromDate2=$_REQUEST['fromDate'];
$toDate2=$_REQUEST['toDate'];
$night2=$_REQUEST['night'];
$hotelName=$_REQUEST['hotelName'];
$hoteladdress=$_REQUEST['hotelAddress'];
$editcategoryId='';
$roomType='';
 }
?>
<script>
 $(document).ready(function() {
 $('#toDate2').Zebra_DatePicker({
  format: 'd-m-Y',
});
 $('#fromDate2').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
function changedatefunction2(){
  var fromDate = $('#fromDate2').val().split("-").reverse().join("-");
  var toDate = $('#toDate2').val().split("-").reverse().join("-");
  var fromDatestamp = toTimestamp(''+fromDate+'');
  var toDatestamp = toTimestamp(''+toDate+'');
 if(fromDate!= '' && fromDate!= '' && fromDatestamp>= toDatestamp)
    {
    alert("Please ensure that the To Travel Date is greater than From Travel Date.");
    $('#toDate2').val('');
    }
  var totaldays = showDays(toDate,fromDate);
  if(totaldays!='' || totaldays!='0'){
  $('#night2').val(totaldays);
  var night = totaldays;
  }
}
</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Hotel </h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="hotelItId" id="hotelItId" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="addHotelItinerary" />
    <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
 	<div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Hotel Name<span class="redmind"></span></div>
	<input name="hotelName" type="text" class="gridfield validate" displayname="Hotel Name"  id="hotelName"  value="<?php echo $hotelName; ?>" />
	</label>
 </div>
	<div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Hotel Address<span class="redmind"></span></div>
	<input name="address" type="text" class="gridfield validate"  displayname="Hotel Address" id="address"  value="<?php echo $hoteladdress; ?>"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Room Type  </div>
	<select id="roomType2" name="roomType2" class="gridfield validate" displayname="Room Type" autocomplete="off"   >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_ROOM_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$roomType){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
	<div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Destination  </div>
	<select id="destinationId2" name="destinationId2" class="gridfield" displayname="Destination" autocomplete="off" >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$destinationId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Star Rating  </div>
	<select id="categoryId2" name="categoryId2" class="gridfield validate" displayname="Hotel Category" autocomplete="off"   >
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_HOTEL_CATEGORY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcategoryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
<div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Travel Date<span class="redmind"></span></div>
	<input name="fromDate2" type="text" id="fromDate2" onfocus="changedatefunction2();" class="gridfield calfieldicon validate"  displayname="From Travel Date"   autocomplete="off" value="<?php echo date("d-m-Y",strtotime($fromDate2)); ?>" />
	</label>
 </div>
 <div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Check In Time  <span class="redmind"></span></div>
<select id="checkInTime" name="checkInTime" class="gridfield validate"  autocomplete="off"   >
<!--<option value="">Select</option>-->
<?php
$start = "11:00";
$end = "23:45";
$tStart = strtotime($start);
$tEnd = strtotime($end);
$tNow = $tStart;
while($tNow <= $tEnd){
?>
<option value="<?php echo date("g:i a",$tNow); ?>" <?php if($editresult['checkInTime']==date("g:i a",$tNow)){ ?>selected="selected"<?php } ?>><?php echo date("g:i a",$tNow); ?></option>
<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
</select>
</label>
</div>
 <div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">To Travel Date<span class="redmind"></span></div>
	<input name="toDate2" type="text" id="toDate2" class="gridfield calfieldicon validate" displayname="To Travel Date" autocomplete="off" value="<?php echo $toDate2; ?>" onfocus="changedatefunction2();" />
	</label>
 </div>
 <div class="griddiv"><label>
<div class="gridlable">Check Out Time  </div>
<select id="checkoutTime" name="checkoutTime" class="gridfield"  autocomplete="off"   >
<!--<option value="">Select</option>-->
<?php
$start = "11:00";
$end = "24:00";
$tStart = strtotime($start);
$tEnd = strtotime($end);
$tNow = $tStart;
while($tNow <= $tEnd){
?>
<option value="<?php echo date("g:i a",$tNow); ?>" <?php if($editresult['checkoutTime']==date("g:i a",$tNow)){ ?>selected="selected"<?php } ?>><?php echo date("g:i a",$tNow); ?></option>
<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
</select>
</label>
</div>
 <div class="griddiv notshowclass"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Nights<span class="redmind"></span></div>
	<input name="night2" type="number" class="gridfield" id="night2" maxlength="3" max="99" min="1"  displayname="Night" onKeyUp="numericFilter(this);"   value="<?php echo $editresult['night']; ?>" />
	</label>
 </div>
   <div class="griddiv notshowclass"><label>
	<div class="gridlable">Adult </div>
	<input name="adult" type="number" class="gridfield" id="adult" maxlength="3" max="99" min="1"  displayname="Adult" onKeyUp="numericFilter(this);"    value="<?php echo $editresult['adult']; ?>" />
	</label>
 </div>
   <div class="griddiv notshowclass"><label>
	<div class="gridlable">Child </div>
	<input name="child" type="number" class="gridfield" id="child" maxlength="3" max="99" min="1"  displayname="Adult" onKeyUp="numericFilter(this);"    value="<?php echo $editresult['child']; ?>" />
	</label>
 </div>
 <div class="griddiv notshowclass"><label>
	<div class="gridlable">Rooms </div>
	<input name="rooms" type="number" class="gridfield" id="rooms" maxlength="3" max="99" min="1"  displayname="Adult" onKeyUp="numericFilter(this);"  value="<?php echo $editresult['rooms']; ?>" />
	</label>
 </div>
 <div class="griddiv notshowclass"><label>
	<div class="gridlable">Extra Bed  </div>
	<input name="extrabad" type="extrabad" class="gridfield" id="rooms" maxlength="3" max="99" min="1"  displayname="Adult" onKeyUp="numericFilter(this);"  value="<?php echo $editresult['rooms']; ?>" />
	</label>
 </div>
  <div class="griddiv notshowclass"><label>
	<div class="gridlable">Details </div>
	<input name="detail" type="text" class="gridfield" id="detail"   value="<?php echo strip($editresult['detail']); ?>" maxlength="500" />
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='senditinearyemail' && $_REQUEST['queryId']!=''){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Send Itineary </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Email <span class="redmind"></span></div>
	<input name="emailsender" type="text" class="gridfield validate" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="Day Wise Plan - <?php echo makeInvoiceId($_GET['queryId']); ?>" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div><input name="senditinerarytoemail" type="hidden" id="senditinerarytoemail" value="1" /><input name="sendemailitineraryid" type="hidden" id="sendemailitineraryid" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addsupaddress' && $_REQUEST['supid']!=''){
 if($_GET['id']!=''){
$id=clean($_GET['id']);
$select1='*';
$where1='id='.$id.'';
$rs1=GetPageRecord($select1,_ADDRESS_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
$editcountryId=$editresult['countryId'];
$editstateId=$editresult['stateId'];
$editcityId=$editresult['cityId'];
$editaddress1=$editresult['address'];
$editpinCode=$editresult['pinCode'];
$editgstn=$editresult['gstn'];
}
?>
<style>
	.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Address  </h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
    <input name="action" id="action" type="hidden" value="addsupaddress" />
    <input name="supid" id="supid" type="hidden" value="<?php echo $_GET['supid']; ?>" />
<div class="griddiv">
	<label>
	<div class="gridlable">Country<span class="redmind"></span></div>
	<select id="countryId2" name="countryId2" class="gridfield validate" displayname="Country" autocomplete="off" onchange="selectstate();" >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_COUNTRY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select></label>
	</div>
	<div class="griddiv">
	<label>
	<div class="gridlable">State </div>
	<select id="stateId2" name="stateId2" class="gridfield" displayname="State" autocomplete="off" onchange="selectcity();" >
</select></label>
	</div>
	<div class="griddiv">
	<label>
	<div class="gridlable">City  </div>
	<select id="cityId2" name="cityId2" class="gridfield" displayname="City" autocomplete="off" >
	<?php if($_GET['id']!=''){ ?> 
	<option value="0">Select City</option>  
 <?php   
$whereKKKK=' deletestatus=0 and status=1 and stateId="'.$editstateId.'" order by name asc';  
$resListingCityq=GetPageRecord('id,name','cityMaster',$whereKKKK); 
while($resListingCity=mysqli_fetch_array($resListingCityq)){  
?>
<option value="<?php echo strip($resListingCity['id']); ?>" <?php if($resListingCity['id']==$editcityId){ ?>selected="selected"<?php } ?>><?php echo strip($resListingCity['name']); ?></option>
<?php } ?> 
	<?php } ?>
    </select></label>
	</div>
	<script> 
	function selectstate(){
	var countryId = $('#countryId2').val();
	$('#stateId2').load('loadstate.php?action=loadCorporateState&id='+countryId+'&selectedId=<?php echo $editstateId; ?>');
	}
	function selectcity(){
	var stateId = $('#stateId2').val();
	$('#cityId2').load('loadcity.php?id='+stateId+'&selectId=<?php echo $editcityId; ?>');
	}
	
	 <?php
	if($_GET['id']!=''){
	?>
	selectstate(); 
	<?php } ?>
	</script>
	<div class="griddiv"><label>
	<div class="gridlable">Address</div>
	<input name="address1" type="text" class="gridfield" id="address1" value="<?php echo $editaddress1; ?>" maxlength="250" />
	</label>
	</div>
 <div class="griddiv"><label>
	<div class="gridlable">Pin Code </div>
	<input name="pinCode" type="text" class="gridfield" id="pinCode" value="<?php echo $editpinCode; ?>" maxlength="15" />
	</label>
	</div>
 <div class="griddiv"><label>
	<div class="gridlable">GSTN</div>
	<input name="gstn" type="text" class="gridfield" id="gstn" value="<?php echo $editgstn; ?>" maxlength="50" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Primary Address</div>
	<select id="primaryAddress" name="primaryAddress" class="gridfield" displayname="Primary Address" autocomplete="off" >
	  <option value="1" <?php if($editresult['primaryAddress']==1){ ?>selected="selected"<?php } ?>>Yes</option>
	  <option value="0" <?php if($editresult['primaryAddress']==0){ ?>selected="selected"<?php } ?>>No</option>
    </select>
	</label>
	</div>
 <input name="senditinerarytoemail" type="hidden" id="senditinerarytoemail" value="1" /><input name="sendemailitineraryid" type="hidden" id="sendemailitineraryid" value="<?php echo $_GET['queryId']; ?>" /><input name="addressType" type="hidden" id="addressType" value="<?php if($_REQUEST['addressType']!=''){ echo $_REQUEST['addressType']; } if($_REQUEST['addressType']==''){ echo 'supplier'; } ?>" />
 <input name="editid" type="hidden" id="editid" value="<?php echo $_GET['id']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>

	
<?php if($_GET['action']=='selectsupplierstate' && $_REQUEST['supplierid']!='' && $_REQUEST['paymentid']!='' && $_REQUEST['night']!='' && $_REQUEST['companyTypeId']!=''){
 if($_REQUEST['night']!=''){
$select1='*';
$where1='id='.$_REQUEST['night'].'';
$rs1=GetPageRecord($select1,_QUERY_MASTER_,$where1);
$editqueryId=mysqli_fetch_array($rs1);
}
 ?>
<style>
	.newtowrobox .griddiv{    width: 46% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Select State</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
    <input name="action" id="action" type="hidden" value="addsupaddress" />
    <input name="companyTypeId" id="companyTypeId" type="hidden" value="<?php echo $_REQUEST['companyTypeId']; ?>" />
    <input name="supid" id="supid" type="hidden" value="<?php echo $_GET['supid']; ?>" />
<div class="griddiv">
	<label>
	<div class="gridlable" style="width:100%;">Company / Client State </div>
	<select id="companystateId" name="companystateId" class="gridfield" displayname="State" autocomplete="off"   >
	<?php
	if($editqueryId['clientType']==1){
$select='';
$where='';
$rs='';
$select='*';
$where=' addressType="corporate" and addressParent='.$editqueryId['companyId'].'  order by primaryAddress desc';
$rs=GetPageRecord($select,_ADDRESS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
$select1='*';
$where1='id='.$resListing['stateId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$editState=mysqli_fetch_array($rs1);
?>
<option value="<?php echo strip($resListing['id']); ?>"  <?php if($editState['id']==$resListing['stateId']){ ?>selected="selected"<?php } ?>><?php echo strip($editState['name']); ?></option>
<?php } } else {
$select='*';
$where='id='.$editqueryId['companyId'].'';
$rs=GetPageRecord($select,_CONTACT_MASTER_,$where);
$editContact=mysqli_fetch_array($rs);
$select1='*';
$where1='id='.$editContact['stateId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$editState=mysqli_fetch_array($rs1);
?>
<option value="<?php echo strip($editState['id']); ?>"><?php echo strip($editState['name']); ?></option>
<?php } ?>
</select></label>
	</div>
	<div class="griddiv">
	<label>
	<div class="gridlable" style="width:100%;">Supplier State </div>
	<select id="supplierstateId" name="supplierstateId" class="gridfield" displayname="State" autocomplete="off"   >
	<?php
$select='';
$where='';
$rs='';
$select='*';
$where=' addressType="supplier" and addressParent='.$_REQUEST['supplierid'].'  order by primaryAddress desc';
$rs=GetPageRecord($select,_ADDRESS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
$select1='*';
$where1='id='.$resListing['stateId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$editState=mysqli_fetch_array($rs1);
?>
<option value="<?php echo strip($editState['id']); ?>"  <?php if($editState['id']==$resListing['stateId']){ ?>selected="selected"<?php } ?>><?php echo strip($editState['name']); ?></option>
<?php } ?>
</select></label>
	</div>
	<div class="griddiv">
	<label>
	<div class="gridlable" style="width:100%;">Self State </div>
	<select id="selfId" name="selfId" class="gridfield" displayname="State" autocomplete="off"   >
	<?php
$select='';
$where='';
$rs='';
$select='*';
$where=' addressType="invoicesetting" and addressParent=1  order by primaryAddress desc';
$rs=GetPageRecord($select,_ADDRESS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
$select1='*';
$where1='id='.$resListing['stateId'].'';
$rs1=GetPageRecord($select1,_STATE_MASTER_,$where1);
$editState=mysqli_fetch_array($rs1);
?>
<option value="<?php echo strip($editState['id']); ?>"  <?php if($editState['id']==$resListing['stateId']){ ?>selected="selected"<?php } ?>><?php echo strip($editState['name']); ?></option>
<?php } ?>
</select></label>
	</div>
 <input name="senditinerarytoemail" type="hidden" id="senditinerarytoemail" value="1" /><input name="sendemailitineraryid" type="hidden" id="sendemailitineraryid" value="<?php echo $_GET['queryId']; ?>" /><input name="addressType" type="hidden" id="addressType" value="<?php if($_REQUEST['addressType']!=''){ echo $_REQUEST['addressType']; } if($_REQUEST['addressType']==''){ echo 'supplier'; } ?>" />
 <input name="editid" type="hidden" id="editid" value="<?php echo $_GET['id']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Continue    " onclick="selectstatemainfunc();" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
 <script>
 function selectstatemainfunc(){
 var companystateId = $('#companystateId').val();
 var supplierstateId = $('#supplierstateId').val();
 var selfId = $('#selfId').val();
 alertspopupopen('action=addsupplierinpaymentrequest&supplierid=<?php echo ($_REQUEST['supplierid']); ?>&paymentid=<?php echo $_REQUEST['paymentid']; ?>&companystateId='+companystateId+'&supplierstateId='+supplierstateId+'&selfId='+selfId+'&night=<?php echo $_REQUEST['night']; ?>&companyTypeId=<?php echo $_REQUEST['companyTypeId']; ?>','900px','auto');
 }
 </script>
	<?php } ?>
<?php if($_GET['action']=='changecheckliststatus' && $_GET['queryId']!='' && $_GET['editstatusid']!=''){ ?>
	<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Select Status </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div style="padding:20px;">
<a onclick="editstatusloadchecklistfun(<?php echo $_REQUEST['editstatusid']; ?>,1);">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">Pending</div></a>
<a  onclick="editstatusloadchecklistfun(<?php echo $_REQUEST['editstatusid']; ?>,2);">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">In Process</div></a>
<a>
<a  onclick="editstatusloadchecklistfun(<?php echo $_REQUEST['editstatusid']; ?>,3);">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">DONE</div>
</a>
  </div>
 <input name="adddmcpaymenttopaymentrequest" type="hidden" id="adddmcpaymenttopaymentrequest" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel2" type="button" class="whitembutton" id="Cancel2" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addleadevents' && $_GET['eventid']!='' && $_REQUEST['clientType']!='' && $_REQUEST['cid']!=''){
$pageid=encode($_GET['eventid']);
$rpage=encode('showpage.crm?module=leads&view=yes&id='.$pageid.'');
?>
	<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Activity</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div style="padding:20px;">
<a href="showpage.crm?module=calls&add=yes&cid=<?php echo encode($_REQUEST['cid']); ?>&clientType=<?php echo $_REQUEST['clientType']; ?>&rpage=<?php echo $rpage; ?>&queryId=<?php echo encode($_GET['eventid']); ?>&parentType=query">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add Call </div>
</a>
<a href="showpage.crm?module=meetings&add=yes&cid=<?php echo encode($_REQUEST['cid']); ?>&clientType=<?php echo $_REQUEST['clientType']; ?>&rpage=<?php echo $rpage; ?>&queryId=<?php echo encode($_GET['eventid']); ?>&parentType=query">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add meeting </div>
</a>
<a href="showpage.crm?module=tasks&add=yes&cid=<?php echo encode($_REQUEST['cid']); ?>&clientType=<?php echo $_REQUEST['clientType']; ?>&rpage=<?php echo $rpage; ?>&queryId=<?php echo encode($_GET['eventid']); ?>&parentType=query">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">+ Add task </div>
</a>
  </div>
 <input name="adddmcpaymenttopaymentrequest" type="hidden" id="adddmcpaymenttopaymentrequest" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addqueryTransferdetails' && $_GET['queryflightid']!=''){
?>
<script>
 $(document).ready(function() {
$('#departureDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#sightseeingDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Transfer   </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Destination  <span class="redmind"></span></div>
	<select id="destination" name="destination" class="gridfield validate" displayname="Destination" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer Date<span class="redmind"></span></div>
<input onKeyUp="numericFilter(this);" name="sightseeingDate" type="text" class="gridfield calfieldicon validate" id="sightseeingDate"  maxlength="20"  displayname="Transfer Date" autocomplete="off" readonly="readonly"  />
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer Name </div>
	<select id="sightseeingId" name="sightseeingId" class="gridfield validate" displayname="Transfer Name" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TRANSFER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer From </div>
	<select id="transferFromId" name="transferFromId" class="gridfield" displayname="Transfer From" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TRANSFER_CATEGORY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer To </div>
	<select id="transferToId" name="transferToId" class="gridfield" displayname="Transfer To" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_TRANSFER_CATEGORY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Transfer Type   <span class="redmind"></span></div>
	<select id="sightseeingType" name="sightseeingType" class="gridfield validate" displayname="Transfer Type" autocomplete="off"   >
	 <option value="1">SIC</option>
<option value="2">Private</option>
</select>
	</label>
 </div>
 <div class="griddiv" style="display:block;" id="pickuptime"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" ></div>
	<div class="gridlable">Pickup Time<span class="redmind"></span></div>
	<select id="pickupTime" name="pickupTime" class="gridfield validate" displayname="Pickup Time" autocomplete="off"   >
 <option value="">Select</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>"><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Remark </div>
	<input  name="remark" type="text" class="gridfield" id="remark"  maxlength="200"  displayname="Remark" autocomplete="off"  />
	</label>
 </div>
 <input name="addQueryTransfer" type="hidden" id="addQueryTransfer" value="1" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addquerysightseeingdetails' && $_GET['queryflightid']!=''){
?>
<script>
 $(document).ready(function() {
$('#departureDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#sightseeingDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Sightseeing   </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Destination  <span class="redmind"></span></div>
	<select id="destination" name="destination" class="gridfield validate" displayname="Destination" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Sightseeing Date<span class="redmind"></span></div>
<input onKeyUp="numericFilter(this);" name="sightseeingDate" type="text" class="gridfield calfieldicon validate" id="sightseeingDate"  maxlength="20"  displayname="Sightseeing Date" autocomplete="off" readonly="readonly"  />
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Sightseeing Name </div>
	<select id="sightseeingId" name="sightseeingId" class="gridfield validate" displayname="Sightseeing Name" autocomplete="off"   >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_SIGHTSEEING_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editcountryId){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Sightseeing Type   <span class="redmind"></span></div>
	<select id="sightseeingType" name="sightseeingType" class="gridfield validate" displayname="Sightseeing Type" autocomplete="off"   >
	 <option value="1">SIC</option>
<option value="2">Private</option>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;"  ></div>
	<div class="gridlable">Pickup Type<span class="redmind"></span></div>
	<select id="pickupType" name="pickupType" class="gridfield validate" autocomplete="off" onchange="pickuptimefun();">
	 <option value="1">Yes</option>
<option value="2">No</option>
</select>
	</label>
 </div>
 <script>
 function pickuptimefun(){
 var pickupType = $('#pickupType').val();
 if(pickupType==1){
 $('#pickuptime').show();
 } else {
 $('#pickuptime').hide();
 }
 }
 </script>
  <div class="griddiv" style="display:block;" id="pickuptime"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" ></div>
	<div class="gridlable">Pickup Time<span class="redmind"></span></div>
	<select id="pickupTime" name="pickupTime" class="gridfield " displayname="Pickup Time" autocomplete="off"   >
 <option value="">Select</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>"><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Remark </div>
	<input  name="remark" type="text" class="gridfield" id="remark"  maxlength="200"  displayname="Remark" autocomplete="off"  />
	</label>
 </div>
 <input name="addQuerySightseeing" type="hidden" id="addQuerySightseeing" value="1" />
 <input name="LastQueryId" type="hidden" id="LastQueryId" value="<?php echo $_GET['queryflightid']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='Remittancemakepaymentrequestpayment' && $_GET['queryId']!=''){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Payment  </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="currencyId" name="currencyId" class="gridfield"  autocomplete="off">
 <?php
 $select2='';
$where2='';
$rs2='';
$select2='*';
$where2='  queryId="'.$_REQUEST['queryId'].'" group by currencyId order by id asc';
$rs2=GetPageRecord($select2,_DMC_PAYMENT_REQUEST_,$where2);
while($resListing=mysqli_fetch_array($rs2)){
$select='';
$where='';
$rs='';
$select='*';
$where=' id='.$resListing['currencyId'].' order by name asc';
$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
<?php } } ?>
</select>
	</label>
 </div>
<div class="griddiv" id="boxpaymentdiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Payment Amount <span class="redmind"></span></div>
	<input onKeyUp="numericFilter(this);" name="amount" type="text" class="gridfield validate" id="amount" value=""  maxlength="20"  displayname="Payment Amount" autocomplete="off"   />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Attachment </div>
	 <input name="attachmentFile" type="file" id="attachmentFile" style="width:100%;" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="details" rows="3" class="gridfield" id="details" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div>
 <input name="Remittancemakepaymentrequestpayment" type="hidden" id="Remittancemakepaymentrequestpayment" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='supplementarymakepaymentrequestpayment' && $_GET['queryId']!=''){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Payment  </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="currencyId" name="currencyId" class="gridfield"  autocomplete="off">
 <?php
 $select2='';
$where2='';
$rs2='';
$select2='*';
$where2='  queryId="'.$_REQUEST['queryId'].'" group by currencyId order by id asc';
$rs2=GetPageRecord($select2,_DMC_PAYMENT_REQUEST_,$where2);
while($resListing=mysqli_fetch_array($rs2)){
$select='';
$where='';
$rs='';
$select='*';
$where=' id='.$resListing['currencyId'].' order by name asc';
$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
<?php } } ?>
</select>
	</label>
 </div>
<div class="griddiv" id="boxpaymentdiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Payment Amount <span class="redmind"></span></div>
	<input onKeyUp="numericFilter(this);" name="amount" type="text" class="gridfield validate" id="amount" value=""  maxlength="20"  displayname="Payment Amount" autocomplete="off"   />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Attachment </div>
	 <input name="attachmentFile" type="file" id="attachmentFile" style="width:100%;" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="details" rows="3" class="gridfield" id="details" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div>
 <input name="addsupplementarypaymenttopaymentrequest" type="hidden" id="addsupplementarypaymenttopaymentrequest" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='opensavequerysuplier' && $_GET['queryId']!=''){
?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Suplier Type  </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">Select Supplier Type   <span class="redmind"></span></div>
	<select id="supplierType" name="supplierType" class="gridfield validate" displayname="Supplier Type" autocomplete="off"   >
	  <option value="">Select</option>
	  <option value="1">Individual</option>
	 <!--<option value="2">DMC</option>-->
</select>
	</label>
 </div>
 <input name="action" type="hidden" id="action" value="savequerysuplier" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 <input name="id" type="hidden" id="id" value="<?php echo $_GET['id']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<!----------------------------------- Package Builder Start------------------------------------------->
<?php if($_GET['action']=='addeditoptional' && $_GET['packageId']!=''){ ?>
<script>
 $(document).ready(function() {
 $('#toDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
 $('#fromDate3').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 15% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Optional</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="optional" id="optional" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="addOptional" />
    <input name="packageId" id="packageId" type="hidden" value="<?php echo $_GET['packageId']; ?>" />
	<input name="optionalId" id="optionalId" type="hidden" value="<?php echo $editresult['id']; ?>" />
 <!--<div style="text-align:right; margin-right:53%;" ><input name="addnewuserbtn" type="button" class="bluembutton" id="addnewuserbtn" value="+ Add Transfer" onclick="masters_alertspopupopen('action=addedit_transfermaster&sectiontype=transfermaster','400px','auto');" /></div>-->
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Name</div>
	<input name="sightseeing" type="text" class="gridfield"  id="sightseeing" maxlength="100"  value="<?php echo $editresult['sightseeing']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Information</div>
	<input name="information" type="text" class="gridfield"  id="information" maxlength="100"  value="<?php echo $editresult['information']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Inclusion</div>
	<input name="inclusion" type="text" class="gridfield"  id="inclusion" maxlength="100"  value="<?php echo $editresult['inclusion']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Duration</div>
	<input name="duration" type="text" class="gridfield"  id="duration" maxlength="100"  value="<?php echo $editresult['duration']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">3 Star Cost</div>
	<input name="cost" type="text" class="gridfield"  id="cost" maxlength="100"  value="<?php echo $editresult['cost']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">4 Star Cost</div>
	<input name="costfour" type="text" class="gridfield"  id="costfour" maxlength="100"  value="<?php echo $editresult['costfour']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">5 Star Cost</div>
	<input name="costfive" type="text" class="gridfield"  id="costfive" maxlength="100"  value="<?php echo $editresult['costfive']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Supplier</div>
	<select id="supplierId" name="supplierId" class="gridfield" displayname="Supplier" autocomplete="off" >
	<option value="0">Select Supplier</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where='1 and name!="" and deletestatus=0 order by name asc';
$rs=GetPageRecord($select,_SUPPLIERS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$sightseeing){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<?php } ?>
	<?php if($_GET['action']=='addMarkup' && $_GET['add']=='1'){
	$select1='*';
$where1='id='.($_REQUEST['packageId']).'';
$rs1=GetPageRecord($select1,_PACKAGE_DETAIL_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Markup </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addmark" target="actoinfrm"  id="addmark">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">B2C Markup Type</div>
	<select  name="b2cmarkupType" class="gridfield" autocomplete="off" >
<option value="1" <?php if($editresult['b2cmarkupType']=='1'){ ?>selected="selected"<?php } ?>>Fixed Amount</option>
<option value="2" <?php if($editresult['b2cmarkupType']=='2'){ ?>selected="selected"<?php } ?>>Percent</option>
</select>
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">B2C Markup</div>
	<input name="b2cmarkup" type="text" class="gridfield " value="<?php echo $editresult['b2cMarkup']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">B2C GST</div>
	<input name="b2cGst" type="text" class="gridfield " value="<?php echo $editresult['b2cGst']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">B2B Markup Type</div>
	<select name="b2bmarkupType" class="gridfield" autocomplete="off" >
<option value="1" <?php if($editresult['b2bmarkupType']=='1'){ ?>selected="selected"<?php } ?>>Fixed Amount</option>
<option value="2" <?php if($editresult['b2bmarkupType']=='2'){ ?>selected="selected"<?php } ?>>Percent</option>
</select>
	</label>
 </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">B2B Markup</div>
	<input name="b2bmarkup" type="text" class="gridfield"   value="<?php echo $editresult['b2bMarkup']; ?>"/>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width:100%;">B2B GST</div>
	<input name="b2bGst" type="text" class="gridfield " value="<?php echo $editresult['b2bGst']; ?>"/>
	</label>
 </div>
 <input name="action" type="hidden" id="action" value="addMarkup" />
 <input name="packageId" type="hidden" id="packageId" value="<?php echo $_GET['packageId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton savemark" id="addnewuserbtn" value="    Save    " onclick="formValidation('addmark','savemark','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='sendpackage'){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Send Package </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Email <span class="redmind"></span></div>
	<input name="emailsender" type="text" class="gridfield validate" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="<?php echo str_replace('%20',' ',$_REQUEST['packageName']); ?>" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6">Dear Sir,
Good day, and I hope you are well!
Thank you for choosing <?php echo $clientnameglobal; ?>. Over the years, we have helped people create beautiful travel memories, just like we hope to do for you.
After reviewing your preferences and the available options, we are proposing the below package which we believe best matches your requirements. Kindly review the attached, and feel free to propose any amendments as desired.
It has been our pleasure to help you with your vacation arrangements, and we hope that it will bring you a wonderful holiday experience!</textarea>
	</label>
 </div><input name="sendpackagetoemail" type="hidden" id="sendpackagetoemail" value="1" /><input name="pid" type="hidden" id="pid" value="<?php echo $_GET['pid']; ?>" />
 <?php if($_REQUEST['type']==2){ ?>
 <input name="attfile" id="attfile" type="hidden" value="PACKAGE-<?php echo $_REQUEST['filename']; ?>.pdf" />
 <input name="newPackageType" id="newPackageType" type="hidden" value="2" />
 <?php }else{ ?>
 <input name="attfile" id="attfile" type="hidden" value="PACKAGE-<?php echo $_REQUEST['filename']; ?>.pdf" />
 <?php } ?>
 <iframe style="display:none;" src="tcpdf/examples/getpdf.php?pageurl=<?php echo $fullurl; ?>packagehtmlb2c.php?id=<?php echo encode($_REQUEST['pid']); ?>=&savetoserver=1&filename=PACKAGE-<?php echo $_REQUEST['filename']; ?>"></iframe>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='selectSupplierpackage'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Select Supplier </h1>
<div style="margin-bottom:5px;">
<input name="searchcompanyname" type="text" id="searchcompanyname" style="padding:10px; border:1px  #CCCCCC solid; width:100%; box-sizing:border-box;" placeholder="Enter Supplier Name" onkeyup="searchcompanynamefunc();" autocomplete="off"/>
</div>
  <div   style="max-height:340px; overflow:auto; text-align:left;" id="loadcorporatecompany">
  <div style="text-align:center; color:#CCCCCC; padding:30px 0px;">Search Supplier Name</div>
  </div>
  <div style="margin:20px 0px;">
<a href="showpage.crm?module=suppliers&add=yes" target="_blank">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px;">+ Add New Supplier </div>
</a></div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td  ><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
	<script>
	function selectCorporate(name,email,phone,id){
	$('#companyName').val(name);
	$('#agentb2cmail').val(email);
	$('#agentb2cnumber').val(phone);
	$('#companyId').val(id);
	alertspopupopenClose();
	}
	function searchcompanynamefunc(){
	var searchcompanyname = encodeURIComponent($('#searchcompanyname').val());
	$('#loadcorporatecompany').load('loadsupplier.php?supplier=1&searchcompanyname='+searchcompanyname);
	}
	</script>
	<?php } ?>
<?php if($_GET['action']=='loadPackage' && $_REQUEST['packageQueryId'] ){ ?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">All Packages</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
    <input name="action" id="action" type="hidden" value="loadPackage" />
    <input name="packageQueryId" id="packageQueryId" type="hidden" value="<?php echo $_REQUEST['packageQueryId']; ?>" />
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Packages</div>
	<select id="packageId" name="packageId" class="gridfield" displayname="package ID " autocomplete="off" >
	<option value="0">Select Package</option>
 <?php
$select='*';
$where=' 1  order by pacakageName asc';
$rs=GetPageRecord($select,_PACKAGE_DETAIL_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option  value="<?php echo $resListing['id']; ?>"><?php echo strip($resListing['pacakageName']); ?>&nbsp;&nbsp;(<?php echo countlisting('id',_PACKAGE_BUILDER_DAYS_MASTER_,' where packageId='.$resListing['id'].' ')-1; ?>&nbsp;Nights)</option>
<?php } ?>
</select>
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<?php } ?>
	<?php if($_GET['action']=='GenerateInvoice'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Select Invoice </h1>
<div style="margin-bottom:5px;">
<div style="margin-bottom:20px;">
<select id="invoiceType" name="invoiceType" class="gridfield validate" displayname="Invoice Type"  autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
 <option value="1">Performa Invoice</option>
 <option value="2">Text Invoice</option>
</select>
</div>
</div>
<div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="invoicedmc();$('#invoicetop').show();alertspopupopenClose();" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
	<?php } ?>
	<?php if($_REQUEST['action']=='changepackageitnery'){
?>
<div class="contentclass">
<h1 style="text-align:left;">Select <?php echo $_REQUEST['type']; ?> </h1>
<?php if($_REQUEST['type']=='Hotel'){ ?>
<div style="margin-bottom:0px; max-height:500px; overflow:auto;">
 <?php
$select='';
$where='';
$rs='';
$select='*';
 $where='hotelCity = "'.str_replace('%20',' ',$_REQUEST['destinationName']).'" and hotelCategoryId='.$_REQUEST['category'].' and id in (select serviceid from '._DMC_ROOM_TARIFF_MASTER_.' where roomType='.$_REQUEST['roomType'].' and mealPlan='.$_REQUEST['mealPlan'].' ) and id!='.$_REQUEST['hotelid'].' and status=1 order by hotelName asc';
$rs=GetPageRecord($select,_PACKAGE_BUILDER_HOTEL_MASTER_,$where);
while($editresult=mysqli_fetch_array($rs)){
$select1='*';
$where1='serviceid='.$editresult['id'].' and roomType='.$_REQUEST['roomType'].' and mealPlan='.$_REQUEST['mealPlan'].' order by singleoccupancy asc ';
$rs1=GetPageRecord($select1,_DMC_ROOM_TARIFF_MASTER_,$where1);
$hotellisting=mysqli_fetch_array($rs1);

$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'id="'.$editresult['hotelCategoryId'].'"');   
$hcD=mysqli_fetch_array($rr2);

?>
<div style="border-bottom:1px solid #ccc; padding:5px 0px; margin-bottom:5px;">
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="left" style="font-size:13px;"><strong><?php echo strip($editresult['hotelName']);  ?></strong></td>
    <td width="11%" rowspan="4" align="left" valign="top" style="font-size:15px;">
	<?php if($hotellisting['singleoccupancy']-$_REQUEST['price']<1){ ?>
	<strong style="color:#009900;"><?php  echo $hotellisting['singleoccupancy']-$_REQUEST['price'];  ?></strong>
	<?php } else { ?>
	<strong style="color:#CC3300;">+<?php  echo $hotellisting['singleoccupancy']-$_REQUEST['price'];  ?></strong>
	<?php } ?>	</td>
<td width="11%" rowspan="4" align="right" valign="top" style="font-size:15px;">
<a href="javascript:void(0);" onclick="$('#loadallquotations').load('<?php if($_REQUEST['query']==1){ ?>loadall_query_quotations.php<?php } else { ?>loadallquotations.php<?php } ?>?packageid=<?php echo $_REQUEST['packageid']; ?>&packagetype=<?php echo $_REQUEST['pacakageSection']; ?>&mainid=<?php echo $_REQUEST['mainid']; ?>&hotelId=<?php echo $hotellisting['serviceid']; ?>&hotelCost=<?php echo $hotellisting['singleoccupancy']; ?>&action=changehotel&dayid=<?php echo $_REQUEST['dayid']; ?>');alertspopupopenClose();"  style="font-size: 12px; padding: 4px 10px; background-color: #23589a; color: #fff !important; float: right; border-radius: 3px;">Select</a>
	</td>
    </tr>
  <tr align="left">
    <td colspan="2" align="left"><?php echo trim($hcD['hotelCategory']); ?> Star <span><!--<?php
	$select1='*';
$where1='id='.$hotellisting['roomType'].'';
$rs1=GetPageRecord($select1,_ROOM_TYPE_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
echo $editresult['name'];
?>, <?php
	$select1='*';
$where1='id='.$hotellisting['mealPlan'].'';
$rs1=GetPageRecord($select1,_MEAL_PLAN_MASTER_,$where1);
$editresult=mysqli_fetch_array($rs1);
echo $editresult['name'];
?>--></span></td>
    </tr>
 </table>
</div>
<?php } ?>
</div>
<?php } ?>
<?php if($_REQUEST['type']=='Sightseeing'){ ?>
<div style="margin-bottom:0px; max-height:500px; overflow:auto;">
 <?php
$select='';
$where='';
$rs='';
$select='*';
 $where=' sightseeingCity="'.str_replace('%20',' ',$_REQUEST['sightseeingCity']).'" and id!='.$_REQUEST['sightseeingId'].'  and id in (select serviceid from '._DMC_SIGHTSEEING_RATE_MASTER_.' where sightseeingType = "'.$_REQUEST['sightseeingType'].'"  ) and status=1 order by sightseeingName asc';
$rs=GetPageRecord($select,_PACKAGE_BUILDER_SIGHTSEEING_MASTER_,$where);
while($editresult=mysqli_fetch_array($rs)){
$select1='*';
$where1='serviceid='.$editresult['id'].' and sightseeingType='.$_REQUEST['sightseeingType'].' order by adultCost asc ';
$rs1=GetPageRecord($select1,_DMC_SIGHTSEEING_RATE_MASTER_,$where1);
$hotellisting=mysqli_fetch_array($rs1);
?>
<div style="border-bottom:1px solid #ccc; padding:5px 0px; margin-bottom:5px;">
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="left" style="font-size:13px;"><strong><?php echo strip($editresult['sightseeingName']);  ?></strong></td>
    <td width="11%" rowspan="3" align="left" valign="top" style="font-size:15px;">
	<?php if($hotellisting['adultCost']+$hotellisting['ticketAdultCost']-$_REQUEST['price']<1){ ?>
	<strong style="color:#009900;"><?php  echo $hotellisting['adultCost']+$hotellisting['ticketAdultCost']-$_REQUEST['price'];  ?></strong>
	<?php } else { ?>
	<strong style="color:#CC3300;">+<?php  echo $hotellisting['adultCost']+$hotellisting['ticketAdultCost']-$_REQUEST['price'];  ?></strong>
	<?php } ?>	</td>
<td width="11%" rowspan="3" align="right" valign="top" style="font-size:15px;">
<a href="javascript:void(0);" onclick="$('#loadallquotations').load('<?php if($_REQUEST['query']==1){ ?>loadall_query_quotations.php<?php } else { ?>loadallquotations.php<?php } ?>?packageid=<?php echo $_REQUEST['packageid']; ?>&packagetype=<?php echo $_REQUEST['pacakageSection']; ?>&mainid=<?php echo $_REQUEST['mainid']; ?>&action=changesightseeing&dayid=<?php echo $_REQUEST['dayid']; ?>&sightseeingid=<?php echo $editresult['id']; ?>');alertspopupopenClose();"  style="font-size: 12px; padding: 4px 10px; background-color: #23589a; color: #fff !important; float: right; border-radius: 3px;">Select</a>	</td>
    </tr>
 </table>
</div>
<?php } ?>
</div>
<?php } ?>
<?php if($_REQUEST['type']=='Transfer'){ ?>
<div style="margin-bottom:0px; max-height:500px; overflow:auto;">
 <?php
$select='';
$where='';
$rs='';
$select='*';
 $where=' transferCity="'.str_replace('%20',' ',$_REQUEST['transferCity']).'" and id!='.$_REQUEST['transferId'].'  and id in (select serviceid from '._DMC_TRANSFER_RATE_MASTER_.' where transferType = "'.$_REQUEST['transferType'].'" and AdultCost!=0 ) and status=1 order by transferName asc';
$rs=GetPageRecord($select,_PACKAGE_BUILDER_TRANSFER_MASTER,$where);
while($editresult=mysqli_fetch_array($rs)){
$select1='*';
$where1='serviceid='.$editresult['id'].' and transferType='.$_REQUEST['transferType'].' order by adultCost asc ';
$rs1=GetPageRecord($select1,_DMC_TRANSFER_RATE_MASTER_,$where1);
$hotellisting=mysqli_fetch_array($rs1);
?>
<div style="border-bottom:1px solid #ccc; padding:5px 0px; margin-bottom:5px;">
<table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="left" style="font-size:13px;"><strong><?php echo strip($editresult['transferName']);  ?></strong></td>
    <td width="11%" rowspan="3" align="left" valign="top" style="font-size:15px;">
	<?php if($hotellisting['adultCost']-$_REQUEST['price']<1){ ?>
	<strong style="color:#009900;"><?php  echo $hotellisting['adultCost']-$_REQUEST['price'];  ?></strong>
	<?php } else { ?>
	<strong style="color:#CC3300;">+<?php  echo $hotellisting['adultCost']-$_REQUEST['price'];  ?></strong>
	<?php } ?>	</td>
<td width="11%" rowspan="3" align="right" valign="top" style="font-size:15px;">
<a href="javascript:void(0);" onclick="$('#loadallquotations').load('<?php if($_REQUEST['query']==1){ ?>loadall_query_quotations.php<?php } else { ?>loadallquotations.php<?php } ?>?packageid=<?php echo $_REQUEST['packageid']; ?>&packagetype=<?php echo $_REQUEST['pacakageSection']; ?>&mainid=<?php echo $_REQUEST['mainid']; ?>&action=changetransfer&dayid=<?php echo $_REQUEST['dayid']; ?>&transferid=<?php echo $editresult['id']; ?>');alertspopupopenClose();"  style="font-size: 12px; padding: 4px 10px; background-color: #23589a; color: #fff !important; float: right; border-radius: 3px;">Select</a>	</td>
    </tr>
 </table>
</div>
<?php } ?>
</div>
<?php } ?>
<div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" style="margin-top: 10px;">
      <tr>
        <td  ><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
	<?php } ?>
<?php if($_GET['action']=='addFollow_upAgentPaymentRequest'){ ?>
<script>
 $(document).ready(function() {
$('#followupagentpaymentdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
	.newtowrobox .griddiv{    width: 100% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<?php
$select1='*';
$where1='  queryId="'.$_REQUEST['queryId'].'" order by id asc';
$rs1=GetPageRecord($select1,_DMC_PAYMENT_REQUEST_,$where1);
$dmcroommastermain=mysqli_fetch_array($rs1);
$selectime = $dmcroommastermain['follow_upTime'];
 ?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Follow-up Agent Payment Request</h1>
<div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <input name="action" type="hidden" id="action" value="addfollowupagentpayment" />
  <input name="queryid" type="hidden" id="queryid" value="<?php echo $_REQUEST['queryId']; ?>" />
  <input name="old_date" type="hidden" id="old_date" value="<?php echo $dmcroommastermain['follow_upDate']; ?>" />
  <input name="old_time" type="hidden" id="old_time" value="<?php echo $dmcroommastermain['follow_upTime']; ?>" />
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Follow Up Date<span class="redmind"></span></div>
<input onKeyUp="numericFilter(this);" name="followupagentpaymentdate" type="text" class="gridfield calfieldicon validate" id="followupagentpaymentdate"  maxlength="20"  displayname="Follow up Date" autocomplete="off"   value="<?php echo $dmcroommastermain['follow_upDate']; ?>" />
</label>
</div>
<div class="griddiv">
	<div class="gridlable">Time <span class="redmind"></span></div>
	 <select id="followupagentpaymenttime" name="followupagentpaymenttime" class="gridfield validate"  autocomplete="off"  displayname="Followup Time" style="width: 100%; height: 37px; "  >
	<option value="">Select</option>
	<?php
	$start = "00:00";
	$end = "23:45";
	$tStart = strtotime($start);
	$tEnd = strtotime($end);
	$tNow = $tStart;
	while($tNow <= $tEnd){
	?>
	<option value="<?php echo date("g:i a",$tNow); ?>" <?php if($selectime==date("g:i a",$tNow)){ ?>selected="selected"<?php } ?>><?php echo date("g:i a",$tNow); ?></option>
	<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
	</select>
	 </div>
</form>
</div>
<div id="buttonsbox"  style="text-align:center;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div></div>
<?php } ?>
<?php if($_GET['action']=='addFollow_upClientPaymentRequest'){ ?>
<script>
 $(document).ready(function() {
$('#followupagentpaymentdate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
	.newtowrobox .griddiv{    width: 100% !important;
    display: inline-block;
    margin: 8px;}
	.newtowrobox .gridlable{    width: 100% !important; }
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<?php
$select1='*';
$where1=' id="'.$_REQUEST['clientId'].'" order by id asc';
$rs1=GetPageRecord($select1,_PAYMENT_SUPPLIER_LIST_MASTER_,$where1);
$dmcroommastermain=mysqli_fetch_array($rs1);
$selectime = $dmcroommastermain['follow_upTime'];
 ?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Follow-up Client Payment Request</h1>
<div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <input name="action" type="hidden" id="action" value="addfollowupclientpayment" />
  <input name="queryid" type="hidden" id="queryid" value="<?php echo $_REQUEST['queryId']; ?>" />
  <input name="clientId" type="hidden" id="clientId" value="<?php echo $_REQUEST['clientId']; ?>" />
  <input name="old_date" type="hidden" id="old_date" value="<?php echo $dmcroommastermain['follow_upDate']; ?>" />
  <input name="old_time" type="hidden" id="old_time" value="<?php echo $dmcroommastermain['follow_upTime']; ?>" />
<div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable">Follow Up Date<span class="redmind"></span></div>
<input onKeyUp="numericFilter(this);" name="followupagentpaymentdate" type="text" class="gridfield calfieldicon validate" id="followupagentpaymentdate"  maxlength="20"  displayname="Follow up Date" autocomplete="off"   value="<?php echo $dmcroommastermain['follow_upDate']; ?>" />
</label>
</div>
<div class="griddiv">
	<div class="gridlable">Time <span class="redmind"></span></div>
	 <select id="followupagentpaymenttime" name="followupagentpaymenttime" class="gridfield validate"  autocomplete="off"  displayname="Followup Time" style="width: 100%; height: 37px; "  >
	<option value="">Select</option>
	<?php
	$start = "00:00";
	$end = "23:45";
	$tStart = strtotime($start);
	$tEnd = strtotime($end);
	$tNow = $tStart;
	while($tNow <= $tEnd){
	?>
	<option value="<?php echo date("g:i a",$tNow); ?>" <?php if($selectime==date("g:i a",$tNow)){ ?>selected="selected"<?php } ?>><?php echo date("g:i a",$tNow); ?></option>
	<?php  $tNow = strtotime('+15 minutes',$tNow);} ?>
	</select>
	 </div>
</form>
</div>
<div id="buttonsbox"  style="text-align:center;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div></div>
<?php } ?>
<?php if($_GET['action']=='addstage'){
if($_REQUEST['id']!=''){
$select1='*';
$where1=' id="'.$_REQUEST['id'].'" ';
$rs1=GetPageRecord($select1,'salesStageMaster',$where1);
$stage=mysqli_fetch_array($rs1);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_GET['id']==''){ echo 'Add'; } else { echo 'Edit'; } ?>  Stage   </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Name </div>
	<input  name="name" type="text" class="gridfield validate" id="name"  maxlength="50"  displayname="Name" autocomplete="off" value="<?php echo stripslashes($stage['name']); ?>"  />
	</label>
 </div>
  <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Probability (%)</div>
	<input  name="probability" type="number" class="gridfield validate" id="probability"   displayname="Probability" autocomplete="off"  value="<?php echo stripslashes($stage['probability']); ?>"  />
	</label>
 </div>
     <div class="griddiv">
	<div class="gridlable">Status  </div>
	 <select id="status" name="status" class="gridfield"  autocomplete="off"   style="width: 100%; height: 37px; "  >
	<option value="1" <?php if($stage['status']=='1'){ ?>selected="selected"<?php } ?>>Active</option>
	<option value="0" <?php if($stage['status']=='0'){ ?>selected="selected"<?php } ?>>Inactive</option>
	</select>
	 </div>
 <input name="action" type="hidden" id="action" value="addstage" />
 <input name="editId" type="hidden" id="editId" value="<?php echo $_GET['id']; ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addexpenses'){
if($_REQUEST['id']!=''){
$select1='*';
$where1=' id="'.$_REQUEST['id'].'"';
$rs1=GetPageRecord($select1,'expensesMaster',$where1);
$expensesdata=mysqli_fetch_array($rs1);
}
?>
<script>
 $(document).ready(function() {
$('#dueDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#invoiceDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
</script>
<style>
.gridlable .Zebra_DatePicker_Icon_Wrapper{width:100% !important;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Expenses</h1>
<div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <input name="action" type="hidden" id="action" value="<?php if($_REQUEST['id']!=''){ echo 'editdexpenses'; } else { echo 'addexpenses'; } ?>" />
   <input name="id" type="hidden" id="id" value="<?php echo $expensesdata['id']; ?>" />
   <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2"><div class="griddiv"><label>
<div class="gridlable">Vender<span class="redmind"></span></div>
<select name="venderId" size="1" class="gridfield"  id="venderIdAdd"   autocomplete="off" displayname="Vender" onchange="loadsamecity();" >
 	 <option value="">Select</option>
  <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and name!=""  and otherType=13  order by name asc';
$rs=GetPageRecord($select,_SUPPLIERS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" ><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
</label>
</div></td>
    <td width="50%"><div class="griddiv" style="display:none;"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable" style="width:100%;">Spending Type<span class="redmind"></span></div>
<select name="expensesType"   class="gridfield"  id="expensesType"   autocomplete="off" displayname="Spending Type" >
<option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' 1 order by name asc';
$rs=GetPageRecord($select,'expensesType',$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" ><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
</label>
</div></td>
  </tr>
</table>
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
<td colspan="2"><div class="griddiv"><label>
<div class="gridlable" style="width:100%;">Invoice Number  <span class="redmind"></span></div>
<input name="invoiceNumber" type="text" class="gridfield" id="invoiceNumber"  value="" displayname="Invoice Number">
</label>
</div></td>
    <td colspan="2"><div class="griddiv"><label>
<div class="gridlable" style="width:100%;">Invoice Date  <span class="redmind"></span></div>
<input name="invoiceDate" type="text" class="gridfield validate" id="invoiceDate"  value="" displayname="Invoice Date">
</label>
</div></td>
    <td width="33%"><div class="griddiv"><label>
<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
<div class="gridlable" style="width:100%;">Due Date<span class="redmind"></span></div>
<input name="dueDate" type="text" class="gridfield validate" id="dueDate"   value="" displayname="Due Date">
</label>
</div></td>
  </tr>
</table>
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2"><div class="griddiv"><label>
<div class="gridlable">Amount   <span class="redmind"></span></div>
<input name="totalAmount" type="number" class="gridfield validate" id="totalAmount"  value="" displayname="Amount" onkeyup="changegst();" >
</label>
</div></td>
    <td width="20%"><div class="griddiv"><label>
<div class="gridlable" style="width:100%;">GST %   </div>
<select name="gst" size="1" class="gridfield"  id="gst"   autocomplete="off"  onchange="changegst();" >
 	 <option value="0">No GST</option>
 	 <option value="18">18%</option>
 	 <option value="5">5%</option>
 </select>
<div id="divcity" style="display:none;"></div>
 <script>
 function loadsamecity(){
 var venderId = $('#venderIdAdd').val();
 $('#divcity').load('loadsamecitygetexpences.php?id='+venderId);
 }
 function changegst(){
 var gst = Number($('#gst').val());
 var totalAmount = Number($('#totalAmount').val());
 var samecity = Number($('#samecity').val());
 var gstvalue = Number(gst/2);
 if(totalAmount==''){
 totalAmount=0;
 }
	if(gst!=0 && totalAmount!=0){
	if(samecity==1){
	var cgst = Number(totalAmount*gstvalue/100);
	var sgst = Number(totalAmount*gstvalue/100);
		$('#cgst').val(cgst);
		$('#sgst').val(sgst);
		$('#igst').val('0');
	}
	if(samecity==2){
	var igst = Number(totalAmount*gst/100);
		$('#cgst').val('0');
		$('#sgst').val('0');
		$('#igst').val(igst);
	}
	}
 }
 </script>
</label>
</div></td>
    <td width="20%"><div class="griddiv"><label>
<div class="gridlable">CGST    </div>
<input name="cgst" type="number" class="gridfield" id="cgst"  value="0" readonly="" >
</label>
</div></td>
    <td width="20%"><div class="griddiv"><label>
<div class="gridlable">SGST    </div>
<input name="sgst" type="number" class="gridfield" id="sgst"  value="0" readonly="" >
</label>
</div></td>
    <td width="20%"><div class="griddiv"><label>
<div class="gridlable" style="width:100%;">IGST </div>
<input name="igst" type="text" class="gridfield " id="igst"   value="0" readonly=""  >
<input name="samecity" id="samecity" type="hidden" value="1" />
</label>
</div></td>
  </tr>
</table>
<div class="griddiv"><label>
<div class="gridlable">Note   </div>
<textarea name="remark" class="gridfield" id="remark" ></textarea>
</label>
</div>
<div class="griddiv"><label>
<div class="gridlable">Attachment   </div>
 <input name="attachment" id="attachment" type="file" class="gridfield" />
</label>
</div>
</form>
</div>
<div id="buttonsbox"  style="text-align:center;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='selectPackageType'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Select Package Type</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
 	<table width="100%" border="0" cellspacing="0" cellpadding="10">
  <tr>
    <td width="50%" align="center"><a href="showpage.crm?module=packagebuilder&add=yes&type=2" style="padding:30px; text-align:center; font-size:16px; background-color:#E7FED6; border:1px solid #33CC00; display:block; border-radius: 4px; color:#333333 !important;"><i class="fa fa-user" aria-hidden="true" style="font-size: 27px; padding-bottom: 10px;"></i><br />B2C Package</a></td>
    <td width="50%" align="center"><a href="showpage.crm?module=packagebuilder&add=yes" style="padding:30px; text-align:center; font-size:16px; background-color:#FFF0F0; border:1px solid #EC798D; display:block; color:#333333 !important; border-radius: 4px;"><i class="fa fa-industry" aria-hidden="true"  style="font-size: 27px; padding-bottom: 10px;"></i><br />B2B Package</a></td>
  </tr>
</table>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
		<?php 
if($_GET['action']=='addDocumentSubFolder' && $_GET['folderid']!=''){
		$folderid=decode($_GET['folderid']);
		$id=decode($_GET['id']);
		if($id!=''){
		$select='';
		$where='';
		$rs='';
		$select='name';
		$where='id='.$id.'';
		$rs=GetPageRecord($select,_DOCUMENT_SUBFOLDER_MASTER_,$where);
		$resultfolderSetting=mysqli_fetch_array($rs);
		}
		?>
		<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
		<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
		Mail Sent Successfully</div>
		<table border="0" align="center" cellpadding="0" cellspacing="0">
		  <tbody><tr>
		     <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
		  </tr>
		</tbody></table>
		</div>
		<div id="sendmailfrm">
		<h1 style="text-align:left;">Create Sub Folder  </h1>
		<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
		<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Folder Name  <span class="redmind"></span></div>
		<input name="folderName" type="text" class="gridfield validate" id="folderName" value="<?php echo $resultfolderSetting['name']; ?>" maxlength="40"  displayname="Folder Name" autocomplete="off"  />
		</label>
		</div>
		<input name="addSubFolder" type="hidden" id="addSubFolder" value="1" />
		<input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
		<input name="folderId" type="hidden" id="folderId" value="<?php echo $folderid; ?>" />
		</form>
		</div>
		<div id="buttonsbox"  style="text-align:center;">
		<table border="0" align="right" cellpadding="0" cellspacing="0">
		  <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Create    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		    <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		  </tr>
		</table>
		</div>
		</div></div>
	<?php 
} ?>
	
<?php 
if($_GET['action']=='addDocumentSubFiles' && $_GET['folderid']!='' && $_GET['subfolderid']!=''){
		 $folderId=($_GET['folderid']);
		 $subfolderId=($_GET['subfolderid']);
		?>
		<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
		<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
		Mail Sent Successfully</div>
		<table border="0" align="center" cellpadding="0" cellspacing="0">
		      <tbody><tr>
		         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
		      </tr>
		   </tbody></table>
		</div>
		<div id="sendmailfrm">
		<h1 style="text-align:left;">Upload File</h1>
		  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
				<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
					<div class="griddiv">
						<label>
							<div class="gridlable">File Title  <span class="redmind"></span></div>
							<input name="fileName" type="text" class="gridfield validate" id="fileName" value="" maxlength="40"  displayname="File Title" autocomplete="off"  />
						</label>
					</div>
					<div class="griddiv">
						<label>
							<div class="gridlable">File&nbsp;Type<span class="redmind"></span></div>
								<select id="fileType" name="fileType" class="gridfield" autocomplete="off" onchange="fileTypeChange(this.value);" >
									<option value="IMG">IMAGE</option>
									<option value="OTHER">OTHER</option>
								</select>
						</label>
						<script type="text/javascript">
							function fileTypeChange(fileTypeVal){
								// var fileType = fileTypeVal;
								// alert(fileTypeVal);
								if(fileTypeVal=='IMG'){
									$('#fileSizeBox').show();
								}else{
									$('#fileSizeBox').hide();
								}
							}
							fileTypeChange('IMG');
						</script>
					</div>
					<div class="griddiv" id="fileSizeBox" style="display:none;">
						<label>
							<div class="gridlable">IMG&nbsp;File&nbsp;Size<span class="redmind"></span></div>
								<select id="fileSize" name="fileSize" class="gridfield" autocomplete="off" >
									<option value="380x246">380x246</option>
									<option value="992x248">992x248</option>
									<option value="1160x432">1160x432</option>
									<option value="1518x706">1518x706</option>
								</select>
						</label>
					</div>
					<!-- 		
					<div class="griddiv">
						<label>
							<div class="gridlable">Referance<span class="redmind"></span></div>
							<input name="ref" type="text" class="gridfield validate" id="ref" value="" maxlength="40"  displayname="Referance" autocomplete="off"  />
						</label>
					</div> -->
					<div class="griddiv">
						<label>
							<div class="gridlable">Select File<span class="redmind"></span></div>
							<input name="uploadFolderfile" type="file" id="uploadFolderfile" style=" margin-top:3px; width:100%;" />
						</label>
					</div>
					<input name="action" type="hidden" id="action" value="addsubfile" />
					<input name="subfolderId" type="hidden" id="subfolderId" value="<?php echo $subfolderId; ?>" />
					<input name="filefolderId" type="hidden" id="filefolderId" value="<?php echo $folderId; ?>" />
				</form>
		  </div>
		  <div id="buttonsbox"  style="text-align:center;">
		 <table border="0" align="right" cellpadding="0" cellspacing="0">
		      <tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Upload" onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		      </tr>
		   </table>
		</div>
		</div></div>
	<?php 
} 
?>


<?php if($_GET['action']=='expensespayment'){
  ?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Payment - <?php  $select1='*'; $where1=' id="'.$_REQUEST['venderId'].'"';   $rs1=GetPageRecord($select1,_SUPPLIERS_MASTER_,$where1);  $data=mysqli_fetch_array($rs1); echo $data['name']; ?></h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellpadding="0" cellspacing="0" style=" border-bottom: 0px;">
<?php
$totalpaid=0;
$s=1;
$select2='*';
$where2='paymentRequestId='.$_REQUEST['id'].' order by id ASC';
$rs2=GetPageRecord($select2,'expensesPayment',$where2);
while($listofpayment=mysqli_fetch_array($rs2)){ ?>
  <tr>
    <td class="paymentboxtable">
	<?php
	if($listofpayment['supplierId']!='0'){
	$select1='*';
$where1='id='.$listofpayment['supplierId'].'';
$rs1=GetPageRecord($select1,_SUPPLIERS_MASTER_,$where1);
$editresultname=mysqli_fetch_array($rs1);
?><?php echo clean($editresultname['name']);
} else { echo 'All Supplier'; }
 ?>	</td>
    <td class="paymentboxtable"><?php if($listofpayment['paymentType']==1){ echo 'Full&nbsp;Payment'; } if($listofpayment['paymentType']==2){  echo 'Partial&nbsp;Payment'; } if($listofpayment['paymentType']==4){  echo 'Direct Payment'; } if($listofpayment['paymentType']==3){  echo 'On Credit'; }  ?></td>
    <td class="paymentboxtable"><?php echo $listofpayment['amount']; $totalpaid=$listofpayment['amount']+$totalpaid; ?></td>
    <td class="paymentboxtable"><?php if($listofpayment['attachmentFile']!=''){ ?><a href="download/<?php echo $listofpayment['attachmentFile']; ?>" target="_blank">Attachment</a><?php } ?></td>
    <td class="paymentboxtable"><?php if($listofpayment['paymentType']==3 || $listofpayment['paymentType']==4){} else {  echo clean($listofpayment['paymentBy']); } ?></td>
    <td class="paymentboxtable"><?php echo clean($listofpayment['details']); ?></td>
    <td class="paymentboxtable"><div><?php
$select='';
$where='';
$rs='';
$select='firstName,lastName';
$where='id="'.$listofpayment['addedBy'].'"';
$rs=GetPageRecord($select,_USER_MASTER_,$where);
while($userss=mysqli_fetch_array($rs)){
echo $userss['firstName'].' '.$userss['lastName'];
}
?></div><div style="font-size:12px; margin-top:2px; color:#999999;"><?php echo showdatetime($listofpayment['dateAdded'],$loginusertimeFormat);?></div></td>
    </tr>
	<?php $s++; } ?>
</table>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='cancelvoucher' && $_GET['queryId']!=''){ ?>
<script>
setTimeout(function(){
window.location.href = 'logout.crm';
}, 12000000);
</script>
<?php
$queryId = decode($_REQUEST['queryId']);
$rs=GetPageRecord('displayId,id',_QUERY_MASTER_,'id="'.$queryId.'" and moduleType=1');
$queryData=mysqli_fetch_array($rs);

$finalStatus= '';
$rs1=GetPageRecord('*',_QUOTATION_MASTER_,'queryId="'.$queryId.'" and status=2 and deletestatus=0');

$quotationCount=mysqli_num_rows($rs1);

$rs2=GetPageRecord('*',_PAYMENT_REQUEST_MASTER_,'queryid="'.$queryId.'" and deletestatus=0 order by id asc limit 1');
$paymentData=mysqli_fetch_array($rs2);
$paymentCount=mysqli_num_rows($rs2);

$rs3=GetPageRecord('*',_VOUCHER_MASTER_,'queryId="'.$queryId.'" and deletestatus=0');

$voucherCount=mysqli_num_rows($rs3);

$rs4=GetPageRecord('*',_INVOICE_MASTER_,'queryId="'.$queryId.'" and deletestatus=0');

$invoiceCount=mysqli_num_rows($rs4);

$rs5=GetPageRecord('*',_INVOICE_MASTER_,'queryId="'.$queryId.'" and deletestatus=1');

$invoiceCount1=mysqli_num_rows($rs5);

if($invoiceCount > 0){ $finalStatus = 2; } else if($invoiceCount1 > 0 && $quotationCount > 0  && $paymentCount > 0){ $finalStatus = 1; } else{ $finalStatus = 0;	}
?>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Query Cancellation - QUERY ID <?php echo makeQueryId($queryData['id']); ?></h1>
  <form action="" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd"><div id="contentbox" class="addeditpagebox" style=" padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
 <div style="border-top:1px #ccc solid; padding:10px 0px; margin-bottom:0px;">
 <div style=" margin-bottom:3px;">Reason for Query Cancellation</div>
 <textarea name="noteDetails" cols="" rows="4" id="noteDetails" class="" style="padding:5px; width:100%; box-sizing:border-box; border: 1px solid #ccc;"  displayname="Note" ></textarea>
 <input type="hidden" name="finalStatus" id="finalStatus" value="<?php echo $finalStatus ?>">
 </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Save" onclick="cancelQuery();" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>

   <script> 
   	function cancelQuery(){
   		var noteDetails = encodeURIComponent($('#noteDetails').val());
   		var finalStatus = $('#finalStatus').val();
   		var queryId = <?php echo $queryId  ?>;
   		if(finalStatus == 0){
   $('#queryCancellation').load('frm_action.crm?action=queryCancellation&queryId='+queryId+'&noteDetails='+noteDetails);
   		}
   		if(finalStatus == 1){
   			alertspopupopen('action=cancelfinalquotVouchers&queryId='+queryId+'&noteDetails='+noteDetails,'600px','auto');
   		}
   		if(finalStatus == 2){
   			parent.window.location.href='showpage.crm?module=paymentrequest&view=yes&id=<?php echo encode($paymentData['id']); ?>&dmc=1&alert=1';
   		}

}
   </script>
</div>
  </div>
</form>
</div>
</div>
<div id="queryCancellation"></div>
<?php } ?>
	<?php if($_GET['action']=='addnotesinquery' && $_GET['queryId']!='' && $_GET['type']!=''){ ?>
 <script src="js/zebra_datepicker.js"></script>  
 <script>
 $(document).ready(function() {   
$('#noteDate').Zebra_DatePicker({ 
  format: 'd-m-Y',  
}); 
  });
setTimeout(function(){ 
window.location.href = 'logout.crm';
}, 12000000);
 
</script>
<div class="contentclass">
 
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Note - QUERY ID <?php echo makeQueryId($_REQUEST['queryId']); ?></h1>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd"><div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
 <div style="margin-bottom:10px;">
   <table width="100%" border="0" cellpadding="0" cellspacing="0">
     <tr>
       <td colspan="2" align="center" valign="top">
	   <?php if($_REQUEST['type']=='1'){ $title="Traveler not reachable"; ?>
	   <div style="width: 40px;height: 40px; margin-bottom: 10px;border: 2px #4CAF50 solid;border-radius: 100px;"> <i class="fa fa-volume-control-phone" aria-hidden="true" style="font-size: 25px;color: #4CAF50;margin-top: 7px;"></i></div>
	   <?php } ?>
	   
	   
	   
	<?php if($_REQUEST['type']=='2'){ $title="Internal Note"; ?>
	<div style="width: 40px;height: 40px;margin-bottom: 10px;border: 2px #4CAF50 solid;border-radius: 100px;"><i class="fa fa-thumbs-down" aria-hidden="true" style="font-size: 25px;color: #4CAF50;margin-top: 7px;"></i></div>
	 <?php } ?>
	   
	   
	<?php if($_REQUEST['type']=='3'){ $title="Talk in progress with traveler"; ?>
	<div style="width: 40px;height: 40px;margin-bottom: 10px;border: 2px #4CAF50 solid;border-radius: 100px;"><i class="fa fa-bullhorn" aria-hidden="true" style="font-size: 25px;color: #4CAF50;margin-top: 7px;"></i></div>
	<?php } ?>
		 
		 
	<?php if($_REQUEST['type']=='4'){  $title="Traveler will finalize and is 'My Hot'"; ?>
	<div style="width: 40px;height: 40px;margin-bottom: 10px;border: 2px #4CAF50 solid;border-radius: 100px;"><i class="fa fa-thumbs-up" aria-hidden="true" style="font-size: 25px; color: #4CAF50; margin-top: 7px;"></i></div>
		 
	 <?php } ?>
	   
	   
	   <input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
	   <input name="assignTo" type="hidden" id="assignTo" value="<?php echo $_REQUEST['assignTo']; ?>" />
	     <input name="title" type="hidden" id="title" value="<?php echo $title; ?>" />
		 <input name="action" type="hidden" id="action" value="addquerynotes" />
		 </td>
       <td width="94%" align="left" valign="top" style="padding-left:15px;">
	   <div style="margin-bottom:10px; font-size:16px; font-weight:500;"><?php echo $title; ?></div>
	   <?php
	   if($_REQUEST['type']=='1'){
	   ?>
	   <table border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio"  style="display:block !important;" value="Phone number doesn't work" checked="checked" /></td>
    <td>Phone number doesn't work </td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio" value="Couldn't talk to traveler this time, try again later"  style="display:block !important;" /></td>
    <td>Couldn't talk to traveler this time, try again later </td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio" value="Tried enough, leave the lead"  style="display:block !important;" /></td>
    <td>Tried enough, leave the lead  </td>
  </tr>
</table>
		<?php } ?>
		
		
		<?php
	   if($_REQUEST['type']=='2'){
	   ?>
	   <table border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio"  style="display:none !important;" value="Traveler is not sure about the plan/cancelled plan " checked="checked" /></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio" value="Traveler booked with someone else "  style="display:none !important;" /></td>
    <td>&nbsp;</td>
  </tr>
   
</table>
		<?php } ?>
		
		<?php
	   if($_REQUEST['type']=='3'){
	   ?>
	   <table border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio"  style="display:block !important;" value="Initial stage only - Quote not seen" checked="checked" /></td>
    <td>Initial stage only - Quote not seen   </td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio" value="Getting Quote/package customized"  style="display:block !important;" /></td>
    <td>Getting Quote/package customized </td>
  </tr> <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio" value="Traveler interested, but will book after few weeks"  style="display:block !important;" /></td>
    <td>Traveler interested, but will book after few weeks</td>
  </tr>
   
</table>
		<?php } ?>
	   
	   
	   <?php
	   if($_REQUEST['type']=='4'){
	   ?>
	   <table border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio"  style="display:block !important;" value="Negotiating / Will finalize in 2 to 3 days" checked="checked" /></td>
    <td>Negotiating / Will finalize in 2 to 3 days</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="subtitle" type="radio" value="Invoice sent to traveler"  style="display:block !important;" /></td>
    <td>Invoice sent to traveler</td>
  </tr>  
   
</table>
		<?php } ?>
	   
	   
	   </td>
     </tr>
   </table>
 </div>
 <div style="border-top:1px #ccc solid; padding:10px 0px; margin-bottom:0px;">
 <div style=" margin-bottom:3px;">Your Note</div>
 <textarea name="noteDetails" cols="" rows="4" id="noteDetails" class="validate" style="padding:5px; width:100%; box-sizing:border-box;    border: 1px solid #ccc;"  displayname="Note" ></textarea>
 </div>
 
 <div style="border-top:1px #ccc solid; padding:10px 0px; margin-bottom:0px;">
 <div style=" margin-bottom:3px;">Reminder</div>
  <table width="200" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td style="padding-left:0px;"><input name="reminderDate" type="date" id="reminderDate" onchange="frot();" style="padding:5px; width:150px;  border:1px solid #CCCCCC;" /></td>
    <td> <select id="reminderTime" name="reminderTime" class="gridfield" autocomplete="off"  style="padding:8px; width:100px; border:1px solid #CCCCCC;"  > 
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('H:i:s',$i); ?>" <?php if('10:00 AM'==date('g:i A',$i) && $_REQUEST['id']==''){ ?> selected="selected"<?php } ?> <?php if($editstarttime==date('g:i A',$i)){ ?> selected="selected"<?php } ?>><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
 
    </select></td>
    </tr>
</table>
 </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Save" onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
   
  </div>
  
</form>
</div></div>
	 
	
	<?php } ?>
<?php if($_GET['action']=='selectQuotationPackage' && $_GET['queryId']!='' ){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Select Quotation</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
     <div class="griddiv">
	<div class="gridlable">Quotation<span class="redmind"></span></div>
	 <select id="quotationId" name="quotationId" class="gridfield validate"  displayname="Quotation"  autocomplete="off"   style="width: 100%; height: 37px; "  >
	 	<option value="0">Select</option>
 	 <?php
	 $select1='id,pacakageName';
$where1=' queryId="'.decode($_REQUEST['queryId']).'" ';
$rs1=GetPageRecord($select1,_PACKAGE_DETAIL_MASTER_,$where1);
while($stage=mysqli_fetch_array($rs1)){
	  ?>
	<option value="<?php echo $stage['id']; ?>" ><?php echo $stage['pacakageName']; ?></option>
	<?php } ?>
	</select>
	 </div>
 <input name="action" type="hidden" id="action" value="selectQuotationPackage" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo decode($_GET['queryId']); ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addmicehotel' && $_GET['id']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Hotel</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
	 <div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Hotel Category</div>
	 <select id="hotelCategory" name="hotelCategory" class="gridfield" displayname="Hotel Category" autocomplete="off" onchange="changehotelcat();"   >
	<option value="0">Select</option>
	<?php 
	$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,' deletestatus=0 and status=1 order by hotelCategory asc');   
	while($hcD=mysqli_fetch_array($rr2)){

	?>
	<option value="<?php  echo $hcD['id'];?>"><?php  echo $hcD['hotelCategory'];?> Star</option>
	<?php 
	} 
	?> 
</select>
<script>
function changehotelcat(){
var hotelCategory = $('#hotelCategory').val();
$('#Fhotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Shotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Thotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
}
</script>
	 </div></td>
    <td width="27%" align="left" valign="top"><label>
	<div class="gridlable">P1 </div>
	<select name="Fhotel" size="1" class="gridfield select2" id="Fhotel"  autocomplete="off"  style="width:100%;" placeholder="Select"   >
	 <option value="0">Select</option>
</select>
	</label></td>
    <td width="27%" align="left" valign="top"><label>
	<div class="gridlable">P2</div>
	<select name="Shotel" size="1" class="gridfield select2" id="Shotel"  autocomplete="off"  style="width:100%;" placeholder="Select"   >
	 <option value="0">Select</option>
</select>
	</label></td>
    <td width="27%" align="left" valign="top"><label>
	<div class="gridlable">P3</div>
	<select name="Thotel" size="1" class="gridfield select2" id="Thotel" autocomplete="off"  style="width:100%;" placeholder="Select"   >
	 <option value="0">Select</option>
</select>
	</label></td>
  </tr>
  <tr>
    <td   align="left" valign="top"><div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Single  </div>
	<input name="single" type="number" class="gridfield" id="single" value="" maxlength="40"   autocomplete="off"  />
	</label>
 </div></td>
    <td align="left" valign="top"><div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Double  </div>
	<input name="double" type="number" class="gridfield" id="double" value="" maxlength="40"  autocomplete="off"  />
	</label>
 </div></td>
    <td align="left" valign="top"><div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Triple
	  <input name="triple" type="number" class="gridfield" id="triple" value="" maxlength="40" autocomplete="off"  />
	</div>
	</label>
 </div></td>
    <td align="left" valign="top"><div class="griddiv">
	<label>
	<div class="gridlable"> Add to Same City </div>
	<select id="addtosamecity" name="addtosamecity" class="gridfield" displayname="Package Type" autocomplete="off"  >
	 <option value="0">No</option>
	 <option value="1">Yes</option>
</select></label>
	</div></td>
  </tr>
</table>
	</div>
 <input name="action" type="hidden" id="action" value="addmicehotel" />
<input name="destinationName" type="hidden" id="destinationName" value="<?php echo $_REQUEST['destinationName']; ?>" />
 <input name="id" type="hidden" id="id" value="0" />
 <input name="destinationId" type="hidden" id="destinationId" value="<?php echo $destinationId; ?>" />
 <input name="fromDate" type="hidden" id="fromDate" value="<?php echo $fromDate; ?>" />
<input name="parentId" type="hidden" id="parentId" value="<?php echo $id; ?>" />
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='addmiceairline' && $_GET['id']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Airline </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
  <div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="20%"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">On Board Meal<input name="miceairline<?php echo $_REQUEST['id']; ?>" id="miceairline<?php echo $_REQUEST['id']; ?>" type="hidden" value="1" /></div>
	 <select id="onboardmeal<?php echo $_REQUEST['id']; ?>" name="onboardmeal" class="gridfield"   autocomplete="off"  style="width: 80px; padding: 7px;  border: 1px solid #dcdcdc;" >
	<option value="0" <?php if($airline['onboardmeal']==''){ ?> selected="selected"<?php } ?>>Select</option>
	 <option value="1" <?php if($airline['onboardmeal']=='1'){ ?> selected="selected"<?php } ?>>Yes</option>
	 <option value="0" <?php if($airline['onboardmeal']=='0'){ ?> selected="selected"<?php } ?>>No</option>
</select>
<script>
function changehotelcat(){
var hotelCategory = $('#hotelCategory').val();
$('#Fhotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Shotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Thotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
}
</script>
	 </div></td>
    <td width="20%" align="left" valign="top"><label>
	<div class="gridlable">Preferred Timing </div>
	<select id="preferredTiming<?php echo $_REQUEST['id']; ?>" name="preferredTiming" class="gridfield"   autocomplete="off"    style="width: 150px; padding: 7px;  border: 1px solid #dcdcdc;" >
	<option value="0">Select</option>
	<option value="Early Morning" <?php if($airline['preferredTiming']=='Early Morning'){ ?> selected="selected"<?php } ?>>Early Morning</option>
	 <option value="Afternoon" <?php if($airline['preferredTiming']=='Afternoon'){ ?> selected="selected"<?php } ?>>Afternoon</option>
	 <option value="Evening" <?php if($airline['preferredTiming']=='Evening'){ ?> selected="selected"<?php } ?>>Evening</option>
	 <option value="Late Night" <?php if($airline['preferredTiming']=='Late Night'){ ?> selected="selected"<?php } ?>>Late Night</option>
</select>
	</label></td>
    <td width="12%" align="left" valign="top"><label>
	<div class="gridlable">Preferred Airline </div>
	<select id="preferredAirline<?php echo $_REQUEST['id']; ?>" name="preferredAirline" class="gridfield"   autocomplete="off"   style="width: 150px; padding: 7px;  border: 1px solid #dcdcdc;" >
	<option value="0">Select</option>
	<?php
$select2='*';
$where2='status=1 and flightCity = "'.$destinationname['name'].'" order by flightName';
$rs2=GetPageRecord($select2,'packageBuilderAirlinesMaster',$where2);
while($flight=mysqli_fetch_array($rs2)){
?>
	<option value="<?php echo $flight['flightName']; ?>" <?php if($flight['flightName']==$airline['preferredAirline']){ ?> selected="selected"<?php } ?>><?php echo $flight['flightName']; ?></option>
	<?php } ?>
</select>
	</label></td> 
    <td width="12%" align="left" valign="top" style="display:none;"><div class="gridlable">Pax </div><input type="text" id="paxAirline<?php echo $_REQUEST['id']; ?>" style="width:60px; box-sizing:border-box;  padding: 7px;  border: 1px solid #dcdcdc;" placeholder=""  value=""  /></td>
  </tr>
</table>
</div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="addflightloadmicedaysfun(<?php echo $_REQUEST['id']; ?>);" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addmicetransfer' && $_GET['id']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Transfer</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="20%"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Transfer</div>
	 <select name="transferId" size="1" class="gridfield validate " id="transferId" displayname="transfer" autocomplete="off"   style="width:100%;"  placeholder="Select">
      <option value="0">Select</option>
      <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' status=1 order by transferName asc';
$rs=GetPageRecord($select,_PACKAGE_BUILDER_TRANSFER_MASTER,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
      <option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['transferName']); ?></option>
      <?php } ?>
    </select>
<script>
function changehotelcat(){
var hotelCategory = $('#hotelCategory').val();
$('#Fhotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Shotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Thotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
}
</script>
	 </div></td>
    <td width="20%" align="left" valign="top"><label>
	<div class="gridlable">Vehicle </div>
	<select name="vehicleId" size="1" class="gridfield validate" id="vehicleId"  autocomplete="off"  style="width:100%;" placeholder="Select"   >
	 <option value="">Select</option>
<?php
$select='';
$where='';
$rs='';
$select='*';
//$where=' deletestatus=0 and status=1 and id in (select vehicleId from dmcsightseeingRate where sightseeingNameId='.$_REQUEST['signtseeingid'].' ) order by name asc';
$where=' deletestatus=0 and status=1   order by name asc';
$rs=GetPageRecord($select,_VEHICLE_MASTER_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$_REQUEST['roomType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label></td>
    <td width="12%" align="left" valign="top"><label>
	<div class="gridlable">No. of Vehicle </div>
	<input name="pax" type="number" class="gridfield" id="pax" value="" maxlength="40" autocomplete="off"  />
	</label></td>
    <td width="12%" align="left" valign="top"><label>
	<div class="gridlable">Pickup Time  </div>
	<select id="transferstartTime<?php echo $resListing['id']; ?>" name="start_Time"  class="gridfield validate" autocomplete="off"    >
		  <option value="0" >Start Time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>" ><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
        </select>
	</label></td>
    <td width="12%" align="left" valign="top" style="display:none;"><div class="gridlable">End Time </div><select id="transferendTime<?php echo $resListing['id']; ?>" name="end_Time"  class="gridfield " autocomplete="off"  >
 <option value="0" >End Time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>" ><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
        </select></td>
    <td width="12%" align="left" valign="top"><label>
	<div class="gridlable">Cost</div>
	<input name="cost" type="text" class="gridfield" id="cost" value="" maxlength="40" autocomplete="off"  />
	</label></td>
  </tr>
</table>
</div>
 <input name="action" type="hidden" id="action" value="addmicetransfer" />
<input name="destinationName" type="hidden" id="destinationName" value="<?php echo $_REQUEST['destinationName']; ?>" />
 <input name="id" type="hidden" id="id" value="0" />
 <input name="destinationId" type="hidden" id="destinationId" value="<?php echo $destinationId; ?>" />
 <input name="fromDate" type="hidden" id="fromDate" value="<?php echo $fromDate; ?>" />
<input name="parentId" type="hidden" id="parentId" value="<?php echo $id; ?>" />
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
	<?php if($_GET['action']=='addmicesightseeing' && $_GET['id']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Sightseeing </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="5%"   align="left" valign="top"><div class="griddiv" style="width: 200px;  margin-top: 11px;">
	<div class="gridlable">Sightseeing</div>
	 <select name="sightseeingId" size="1" class="select2 gridfield validate " id="sightseeingId" displayname="Sightseeing" autocomplete="off"   style="width:100%;"  placeholder="Select">
      <option value="0">Select</option>
<?php
$select='';
$where='';
$rs='';
$select='*';
$where=' sightseeingCity="'.$_REQUEST['destinationName'].'"  order by sightseeingName asc';
$rs=GetPageRecord($select,_PACKAGE_BUILDER_SIGHTSEEING_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['sightseeingName']); ?></option>
<?php } ?>
    </select>
<style>
.select2-container{z-index: 999999999 !important;}
</style>
<script src="plugins/select2/select2.full.min.js"></script>
<script>
  $(document).ready(function() {
  $('.select2').select2();
  });
  </script>
<script>
function changehotelcat(){
var hotelCategory = $('#hotelCategory').val();
$('#Fhotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Shotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Thotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
}
</script>
	 </div></td>
    <td width="20%" align="left" valign="top"><label>
	<div class="gridlable">Start Time </div>
	<select id="transferstartTime<?php echo $resListing['id']; ?>" name="start_Time"  class="gridfield validate" autocomplete="off"    >
		  <option value="0" >Start Time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>" ><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
        </select>
	</label></td>
    <td width="20%" align="left" valign="top"><div class="gridlable">End Time </div><select id="transferendTime<?php echo $resListing['id']; ?>" name="end_Time"  class="gridfield validate" autocomplete="off"  >
 <option value="0" >End Time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>" ><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
        </select></td>
    <td width="12%" align="left" valign="top"><label>
	<div class="gridlable">Pax</div>
	<input name="pax" type="text" class="gridfield" id="pax" value="" maxlength="40" autocomplete="off"  />
	</label></td>
    <td width="12%" align="left" valign="top"><label>
	<div class="gridlable">Cost</div>
	<input name="cost" type="text" class="gridfield" id="cost" value="" maxlength="40" autocomplete="off"  />
	</label></td>
  </tr>
</table>
</div>
 <input name="action" type="hidden" id="action" value="addmicesightseeing" />
<input name="destinationName" type="hidden" id="destinationName" value="<?php echo $_REQUEST['destinationName']; ?>" />
 <input name="id" type="hidden" id="id" value="0" />
 <input name="destinationId" type="hidden" id="destinationId" value="<?php echo $destinationId; ?>" />
 <input name="fromDate" type="hidden" id="fromDate" value="<?php echo $fromDate; ?>" />
<input name="parentId" type="hidden" id="parentId" value="<?php echo $id; ?>" />
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addliquor' && $_GET['id']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Liquor </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="16%"   align="left" valign="top"><div class="griddiv"  >
	<div class="gridlable">Liquor Type</div>
	 <select name="liquorType" size="1" class="gridfield validate" id="liquorType"   autocomplete="off"   style="width:100%;" >
      <option value="On Actual">On Actual</option>
      <option value="Per Pax Cost">Per Pax Cost</option>
    </select>
<style>
.select2-container{z-index: 999999999 !important;}
</style>
<script src="plugins/select2/select2.full.min.js"></script>
<script>
  $(document).ready(function() {
  $('.select2').select2();
  });
  </script>
<script>
function changehotelcat(){
var hotelCategory = $('#hotelCategory').val();
$('#Fhotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Shotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Thotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
}
</script>
	 </div></td>
    <td width="16%" align="left" valign="top"><label>
	<div class="gridlable">Start Time </div>
	<select id="transferstartTime<?php echo $resListing['id']; ?>" name="start_Time"  class="gridfield validate" autocomplete="off"    >
		  <option value="0" >Start Time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>" ><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
        </select>
	</label></td>
    <td width="16%" align="left" valign="top"><div class="gridlable">End Time </div><select id="transferendTime<?php echo $resListing['id']; ?>" name="end_Time"  class="gridfield validate" autocomplete="off"  >
 <option value="0" >End Time</option>
<?php
$start=strtotime('00:00');
   $end=strtotime('23:30');
    for ($i=$start;$i<=$end;$i = $i + 15*60)
    { ?>
   <option value="<?php echo date('g:i A',$i); ?>" ><?php echo date('g:i A',$i); ?></option>;
    <?php  }  ?>
        </select></td>
    <td width="16%" align="left" valign="top"><label>
	<div class="gridlable">Pax</div>
	<input name="pax" type="number" class="gridfield" id="pax" value="" maxlength="40" autocomplete="off"  />
	</label></td>
    <td width="16%" align="left" valign="top"><label>
	<div class="gridlable">Cost</div>
	<input name="cost" type="number" class="gridfield" id="cost" value="" maxlength="40" autocomplete="off"  />
	</label></td>
    <td width="16%" align="left" valign="top"><label>
	<div class="gridlable">Remark</div>
	<input name="remark" type="text" class="gridfield" id="remark" value=""  autocomplete="off"  />
	</label></td>
  </tr>
</table>
</div>
 <input name="action" type="hidden" id="action" value="addmiceliquor" />
<input name="destinationName" type="hidden" id="destinationName" value="<?php echo $_REQUEST['destinationName']; ?>" />
 <input name="id" type="hidden" id="id" value="0" />
 <input name="destinationId" type="hidden" id="destinationId" value="<?php echo $destinationId; ?>" />
 <input name="fromDate" type="hidden" id="fromDate" value="<?php echo $fromDate; ?>" />
<input name="parentId" type="hidden" id="parentId" value="<?php echo $id; ?>" />
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addAdditional' && $_GET['id']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Add Additional Requirement </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="20%"   align="left" valign="top"><div class="griddiv"  >
	<div class="gridlable">Remark</div>
	 <input name="remark" type="text" class="gridfield" id="remark" value=""  autocomplete="off"  />
<style>
.select2-container{z-index: 999999999 !important;}
</style>
<script src="plugins/select2/select2.full.min.js"></script>
<script>
  $(document).ready(function() {
  $('.select2').select2();
  });
  </script>
<script>
function changehotelcat(){
var hotelCategory = $('#hotelCategory').val();
$('#Fhotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Shotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
$('#Thotel').load('loadMicehotellist.php?cityname=<?php echo $_REQUEST['destinationName']; ?>&hotelCategory='+hotelCategory);
}
</script>
	 </div></td>
    <td width="20%" align="left" valign="top"><label>
	<div class="gridlable">Pax</div>
	<input name="pax" type="number" class="gridfield" id="pax" value="" maxlength="40" autocomplete="off"  />
	</label></td>
    <td width="20%" align="left" valign="top"><label>
	<div class="gridlable">Cost</div>
	<input name="cost" type="number" class="gridfield" id="cost" value="" maxlength="40" autocomplete="off"  />
	</label></td>
    </tr>
</table>
</div>
 <input name="action" type="hidden" id="action" value="addAdditional" />
<input name="destinationName" type="hidden" id="destinationName" value="<?php echo $_REQUEST['destinationName']; ?>" />
 <input name="id" type="hidden" id="id" value="0" />
 <input name="destinationId" type="hidden" id="destinationId" value="<?php echo $destinationId; ?>" />
 <input name="fromDate" type="hidden" id="fromDate" value="<?php echo $fromDate; ?>" />
<input name="parentId" type="hidden" id="parentId" value="<?php echo $id; ?>" />
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
 </form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
	<!--------------------------------------------------------------------------MICE SUPPLIER COMMUNICATION -------------------------------------->
<?php if($_GET['action']=='addmicesupplierquote' && $_GET['queryId']!=''){
?>
<script src="js/jquery-1.11.3.min.js"></script>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.select2-container {
    box-sizing: border-box;
    display: inline-block;
    z-index: 99999999;
    margin: 0;
    position: relative;
    vertical-align: middle;
	    margin-top: 3px !important;
}
#alertnotificationsmainbox #buttonsbox {
    overflow: hidden;
    margin-top: 5px; }
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Supplier Quotation</h1>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
  <input name="action" id="action" type="hidden" value="addmicesupplierquote" />
  <input name="queryId2" id="queryId2" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
<div class="griddiv"><label>
	<select id="companyTypeId" name="companyTypeId" class="gridfield validate" displayname="Service" onchange="selcetservicefun();" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
 <option value="">Select Supplier Type</option>
 <option value="100">Select All</option>
<?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_SUPPLIERS_TYPE_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php if(strip($resListing['id'])==1){ echo 'Accommodation';}else{ echo strip($resListing['name']);} ?></option>
 <?php } ?>
<option value="1">Conference</option>
<option value="1">Liquor</option>
</select>
    <div id="supplierIdtd" style="display:none;"><select id="supplierId" name="supplierId[]" multiple="multiple" class="gridfield select2" displayname="Service type" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" >
  <option value="">Select</option>
</select>
	<script type="text/javascript"  src="plugins/select2/select2.min.js"></script>
<script>
  $(document).ready(function() {
  $('.select2').select2();
  });
</script>
<div style="margin-top:10px;"><textarea name="details" cols="" rows="" id="details" class="gridfield"  style="width:100%; height:150px;">Dear Sir,
Please share your quotation of mentioned query below</textarea></div>
</div>
<script>
	function selcetservicefun(){
	var companyTypeId = encodeURIComponent($('#companyTypeId').val());
		$('#supplierId').load('loadsuppliercompany_quote.php?companyTypeId='+companyTypeId);
		$('#supplierIdtd').show();
		}
	</script>
	</label>
 </div>
</form>
  </div>
</div>
  <div id="buttonsbox"  style="text-align:center;margin-bottom:20px;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<!--------------------------------------------------------------------------MICE SUPPLIER COMMUNICATION -------------------------------------->
<?php if($_GET['action']=='addguestbook' && $_GET['queryId']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
if($_REQUEST['id']!=''){
$where1='queryId='.decode($_GET['queryId']).' and id='.$_REQUEST['id'].'';
$rs1=GetPageRecord('*','guestList',$where1);
$querydata=mysqli_fetch_array($rs1);
}
$select='*';
$id=clean(decode($_GET['queryId']));
$where='id='.$id.'';
$rsmice=GetPageRecord($select,'miceMaster',$where);
$resultpageMice=mysqli_fetch_array($rsmice);
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Guest List</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addguestlist">
<div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
    <td  width="33%" align="left" valign="top">
	<div class="griddiv">
	<div class="gridlable">Title</div>
		<select id="title" name="title" class="gridfield validate" autocomplete="off"  displayname="Title"  >
		<option value="Mr" <?php if($querydata['gender']=='Mr'){ ?> selected="selected"<?php } ?>>Mr</option>
		<option value="Mrs" <?php if($querydata['gender']=='Mrs'){ ?> selected="selected"<?php } ?>>Mrs</option>
		<option value="Ms" <?php if($querydata['gender']=='Ms'){ ?> selected="selected"<?php } ?>>Ms</option>
		</select>
	 </div></td>
 	<td width="33%"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">First Name</div>
	 <input name="fname" type="text" id="fname" class="gridfield validate" displayname="First Name" autocomplete="off" value="<?php echo stripslashes($querydata['fname']); ?>"  style=" width:100%;">
	 </div></td>
 	<td width="33%"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Last Name</div>
	 <input name="lname" type="text" id="lname" class="gridfield validate" displayname="Last Name" autocomplete="off" value="<?php echo stripslashes($querydata['lname']); ?>"  style=" width:100%;">
	</div>
	</td>
</tr>
  <tr>
  	<td width="33%" align="left" valign="top"><label>
		<div class="gridlable">Age</div>
			<input name="age" type="email" id="age" class="gridfield" displayname="Age" autocomplete="off" value="<?php echo stripslashes($querydata['age']); ?>"  style=" width:100%;">
		</label></td>
    <td width="25%"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Gender</div>
		<select id="gender" name="gender" class="gridfield validate"  autocomplete="off">
		<option value="">Select</option>
		<option value="Male" <?php if($querydata['gender']=='Male'){ ?>selected="selected"<?php } ?>>Male</option>
		<option value="Female" <?php if($querydata['gender']=='Female'){ ?>selected="selected"<?php } ?>>Female</option>
		</select>
	 </div></td>
    <td width="25%" align="left" valign="top"><div class="griddiv"><label>
	<div class="gridlable">Meal Preference</div>
		<select id="mealPreference" name="mealPreference" class="gridfield" displayname="Meal Preference" autocomplete="off"    >
		<option value="">Select</option>
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' 1 order by id asc';
		$rs=GetPageRecord($select,'mealPreference',$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$querydata['mealPreference']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
		<?php } ?>
		</select>
	</label>
	</div></td>
</tr>
<tr>
    <td width="25%" align="left" valign="top"><div class="griddiv"><label>
	<div class="gridlable">Special Assistance</div>
	<select id="physicalCondition" name="physicalCondition" class="gridfield" displayname="Physical Condition" autocomplete="off"    >
		<option value="">Select</option>
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' 1 order by id asc';
		$rs=GetPageRecord($select,'physicalCondition',$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$querydata['physicalCondition']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
		<?php } ?>
		</select>
		</label>
		</div></td>
    <td width="25%" align="left" valign="top"><div class="griddiv"><label>
	<div class="gridlable">Seat Preference </div>
	<select id="seatPreference" name="seatPreference" class="gridfield" displayname="Seat Preference" autocomplete="off"    >
	 <option value="">Select</option>
	 <option value="Window Seat"  <?php if('Window Seat'==$querydata['seatPreference']){ ?>selected="selected"<?php } ?>>Window Seat</option>
	 <option value="Aisle"  <?php if('Aisle'==$querydata['seatPreference']){ ?>selected="selected"<?php } ?>>Aisle</option>
</select>
	</label>
	</div></td>

	<td width="25%" align="left" valign="top">
		<div class="griddiv">
			<label>
				<div class="gridlable">Country </div>
				<select id="country" name="country" class="validate gridfield" displayname="country" autocomplete="off"    >
	 					<option value="">Select</option>
						<?php
							$select='';
							$where='';
							$rs='';
							$select='id,name';
							$where=' deletestatus=0 and name!="" order by name asc';
							$rs=GetPageRecord($select,_COUNTRY_MASTER_,$where);
							while($resListing=mysqli_fetch_array($rs)){

						?>
							<option value="<?php echo strip($resListing['id']); ?>" <?php if($querydata['countryId']!='' && $resListing['id']==$querydata['countryId']){echo "selected";}  ?> ><?php echo strip($resListing['name']); ?></option>
						<?php } ?>
				</select>
			</label>
		</div>
	</td>		
	</tr>
	<tr>							
     <td colspan='3'  align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Address</div>
	 <input name="address" type="text" id="address" class="gridfield validate" displayname="Address" autocomplete="off" value="<?php echo stripslashes($querydata['address']); ?>"  style=" width:100%;">
	 </div>   </td>
    </tr>
</table>
	</div>
 <input name="action" type="hidden" id="action" value="addguestbook" />
 <input name="id" type="hidden" id="id" value="<?php echo $_REQUEST['id']; ?>" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo decode($_REQUEST['queryId']); ?>" />
</form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addguestlist','addguestlist','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addguestbook_old' && $_GET['queryId']!='' ){
$destinationId=$_REQUEST['destinationId'];
$fromDate=$_REQUEST['fromDate'];
$id=$_REQUEST['id'];
$destinationName=$_REQUEST['destinationName'];
if($_REQUEST['id']!=''){
$where1='queryId='.decode($_GET['queryId']).' and id='.$_REQUEST['id'].'';
$rs1=GetPageRecord('*','guestList',$where1);
$querydata=mysqli_fetch_array($rs1);
}
$select='*';
$id=clean(decode($_GET['queryId']));
$where='id='.$id.'';
$rsmice=GetPageRecord($select,'miceMaster',$where);
$resultpageMice=mysqli_fetch_array($rsmice);
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Guest List</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addguestlist">
<div class="griddiv">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="33%"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Name</div>
	 <input name="name" type="text" id="name" class="gridfield" displayname="Name" autocomplete="off" value="<?php echo stripslashes($querydata['name']); ?>"  style=" width:100%;">
	 </div></td>
    <td width="33%" align="left" valign="top"><label>
	<div class="gridlable">Email</div>
		 <input name="email" type="email" id="email" class="gridfield" displayname="Email" autocomplete="off" value="<?php echo stripslashes($querydata['email']); ?>"  style=" width:100%;">
	</label></td>
    <td width="33%" align="left" valign="top"><label>
	<div class="gridlable">Phone</div>
	<input name="phone" type="text" id="phone" class="gridfield" displayname="Phone" autocomplete="off" value="<?php echo stripslashes($querydata['phone']); ?>"  style=" width:100%;">
	</label></td>
  </tr>
  <tr>
    <td colspan="3"   align="left" valign="top"><div class="griddiv">
	<div class="gridlable">Address</div>
	 <input name="address" type="text" id="address" class="gridfield" displayname="Name" autocomplete="off" value="<?php echo stripslashes($querydata['address']); ?>"  style=" width:100%;">
	 </div>   </td>
    </tr>
</table>
	</div>
 <input name="action" type="hidden" id="action" value="addguestbook" />
 <input name="id" type="hidden" id="id" value="<?php echo $_REQUEST['id']; ?>" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo decode($_REQUEST['queryId']); ?>" />
</form>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addguestlist','addguestlist','0');" /></td>
        <td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
  </div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='addguestdocuments' && $_GET['queryId']!='' && $_GET['id']!='' ){
if($_REQUEST['id']!=''){
$where1='queryId='.decode($_GET['queryId']).' and id='.$_REQUEST['id'].'';
$rs1=GetPageRecord('*','guestListDocuments',$where1);
$querydata=mysqli_fetch_array($rs1);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;"><?php echo $_REQUEST['name']; ?>'s Documents</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<div id="loadguestdocuments"></div>
<script>
function funloadguestdocuments(){
$('#loadguestdocuments').load('loadguestfiles.php?id=<?php echo $_REQUEST['id']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>');
$('#name').val('');
}
funloadguestdocuments();
function deletefunloadguestdocuments(id){
$('#loadguestdocuments').load('loadguestfiles.php?id=<?php echo $_REQUEST['id']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>&dltid='+id);
}
</script>
<div style="padding:10px; background-color:#F7FFEC; border:1px solid #CCFFB7; margin-bottom:20px;">
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
<td><div class="griddiv" style="margin-bottom:0px;">
	  <select name="documentType" class="gridfield" id="documentType" style=" width:100px; padding: 11px !important;" >
	    <option value="ID Proof">ID Proof</option>
	    <option value="Address Proof">Address Proof</option>
	    <option value="Passport">Passport</option>
	    <option value="Visa">Visa</option>
	  </select>
	 </div></td>
    <td><div class="griddiv" style="margin-bottom:0px;"><span class="griddiv" style="margin-bottom:0px;">
      <input name="name" type="text" id="name" class="gridfield" displayname="Name" autocomplete="off" value="" placeholder="Name" style=" width:100%; padding: 11px !important;" />
    </span></div></td>
    <td><div class="griddiv" style="margin-bottom:0px;">
	  <input name="guestattachpostsubmit" id="guestattachpostsubmit" type="file"  class="gridfield"/>
    </div></td>
    <td><input name="addnewuserbtn" type="submit" class="bluembutton saveflight" id="addnewuserbtn" value="    Upload    "   />
	 <input name="id" type="hidden" id="id" value="<?php echo $_REQUEST['id']; ?>" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo decode($_REQUEST['queryId']); ?>" />
  <input name="action" type="hidden" id="action" value="uploadguestlistfile" /> </td>
  </tr>
</table>
</form>
</div>
  <div id="buttonsbox"  style="text-align:center;">
	 	<table border="0" align="right" cellpadding="0" cellspacing="0">
			<tr>
				<td> </td>
				<td style="padding-right:0px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
			</tr>
	  </table>
	</div>
  </div>
</div></div>
	<?php 
} ?>
<!--=========================================== Edit Multidestination ==================================================-->
<?php if($_GET['action']=='editMultidestination' && $_GET['multiDestinationId']!='' ){
$id=$_GET['multiDestinationId'];
$select='*';
$where='id='.$id.' order by srdate asc';
$rs=GetPageRecord($select,'newQuotationDays',$where);
$destlst=mysqli_fetch_array($rs);
?>
 <script src="js/zebra_datepicker.js"></script>
<div class="contentclass">
<h1 style="text-align:left;">Edit Destination</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
    <div class="griddiv">
    	<label>
	<div class="gridlable">Destination<span class="redmind"></span></div>
	<select name="travelfromdestinationId" size="1" class="gridfield" id="travelfromdestinationId"   displayname="From Destination" autocomplete="off"  >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($destlst['cityId']==$resListing['id']){ ?> selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
	</div>
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top"><div class="griddiv"><label>
	<div class="gridlable"> Date <span class="redmind"></span></div>
	<input name="fromDatedest" type="text" id="fromDatedest" class="gridfield calfieldicon" displayname=" Travel Date" autocomplete="off" value="<?php echo date('d-m-Y',strtotime($destlst['srdate'])); ?>" />
	</label>
	</div></td>
  </tr> 
</table>
 <input name="action" type="hidden" id="action" value="editMultidestination" />
 <input name="qid" type="hidden" id="qid" value="<?php echo $destlst['queryId']; ?>" />
 <input name="multiDestinationId" type="hidden" id="multiDestinationId" value="<?php echo $_GET['multiDestinationId']; ?>" />
 <input name="destinationId" type="hidden" id="destinationId" value="<?php echo $_GET['destinationId']; ?>" />
</form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div></div>
 <script>
$('#fromDatedest').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#toDatedest').Zebra_DatePicker({
  format: 'd-m-Y',
});
</script>
	<?php } ?>
<?php 
if($_GET['action']=='sentcreatequerymail'){
	$editId = $_GET['QueryId'];
	$attachitinerary=$_GET['attachitinerary'];
	$savenew=$_GET['savenew'];
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where='  id="'.$editId.'"  ';
	$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
	$resultpages=mysqli_fetch_array($rs);
	$servicePrice=$resultpages['servicePrice'];
	$assignTo=$resultpages['assignTo'];
	$clientType=$resultpages['clientType'];
	$companyId=$resultpages['companyId'];
	$select='';
	$where='';
	$rs='';
	$select='name';
	$where='id="'.$resultpages['tourType'].'"';
	$rs=GetPageRecord($select,_TOUR_TYPE_MASTER_,$where);
	$resultpagestourtype=mysqli_fetch_array($rs);
	$tourtypename=$resultpagestourtype['name'];
	$queryHtml='';
	$downloadLink='';
	if($attachitinerary=='2'){
	  $queryHtml=url_get_contents($fullurl.'mailbodyQueryhtml.php?id='.encode($editId).'&servicePrice='.$servicePrice.'');
	} 
	$wheretem = 'isDefault="1"';
	$rsEMAIL=GetPageRecord('*',_EMAIL_TEMPLATE_MASTER_,$wheretem);
	$resltthankmsg=mysqli_fetch_array($rsEMAIL);
	$thankyouMSG = $resltthankmsg['mailbody'];
	$querythanksmsg= $thankyouMSG;
	
	// 'Dear Sir/Ma\'am <br> Greeting from <strong>'.$clientnameglobal.'</strong>.<br>While replying to this query, please don\'t change the subject line.<br><br>';
 	$select='*';
	 $where=' queryId="'.$editId.'" order by srdate asc';
	$rs=GetPageRecord($select,'packageQueryDays',$where);

	$multipleDestinationMail = "";
	$multipleDestinationMail.="<tr>";
	$multipleDestinationMail.="<td width='100' align='center' bgcolor='#999999' style='color:#FFFFFF;'><span class='gridlable'>S.N.</span></td>";
	if($resultpages['dayWise'] != 2){
		$multipleDestinationMail.="<td width='100' align='center' bgcolor='#999999' style='color:#FFFFFF;'><span class='gridlable'>Date</span></td>";
	}
	$multipleDestinationMail.="<td width='100' align='center' bgcolor='#999999' style='color:#FFFFFF;'><span class='gridlable'>Destination<span class='redmind'></span> </span></td>";
		$multipleDestinationMail.="</tr>";
	$srn = 1;

	while($resListing=mysqli_fetch_array($rs)){
		$multipleDestinationMail.="<tr>";
		$multipleDestinationMail.="<td width='100' align='center' bgcolor='#FFFFFF'>".$srn."</td>";
		if($resultpages['dayWise'] != 2){
			$multipleDestinationMail.="<td width='100' align='center' bgcolor='#FFFFFF'>".date('d-m-Y',strtotime($resListing['srdate']))."</td>";
		}
		$multipleDestinationMail.="<td width='100' align='center' bgcolor='#FFFFFF'>".getDestination($resListing['cityId'])."</td>";
		$multipleDestinationMail.="</tr>";
		$srn++;
	}

	$selectquery='';
	$wherequery='';
	$rsquery='';
	$selectquery='*';
	$wherequery='id="'.$editId.'"  ';
	$rsquery=GetPageRecord($selectquery,_QUERY_MASTER_,$wherequery);
	$resultqueryies=mysqli_fetch_array($rsquery);
	if($attachitinerary=='1'){
	$queryHtml.="<img src='".$fullurl."client_read_mail.php?queryId=".$editId."' width='0' height='0'><div style='margin:20px 0px; border:1px #CCCCCC solid; width:795px !important;'>
	<div style='margin-bottom:10px; font-size:16px; padding:10px;'>QueryId: <strong>#".makeQueryId($resultqueryies['id'])."</strong></div>
	<table width='100%' border='1' cellpadding='6' cellspacing='0' bordercolor='#CCCCCC'>
	<tr>
	<td width='420' bgcolor='#666666' style='color:#FFFFFF;'>Subject</td>
	<td width='101' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Adult</td>
	<td width='102' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Child</td>
	<td width='101' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Infant</td>
	</tr>
	<tr>
	<td width='420'>".$resultqueryies['subject']."</td>
	<td width='101' align='center'>".$resultqueryies['adult']."</td>
	<td width='102' align='center'>".$resultqueryies['child']."</td>
	<td width='101' align='center'>".$resultqueryies['infant']."</td>
	</tr>
	<tr>
	<td colspan='4' align='left' bgcolor='#666666' style='color:#FFFFFF;'>Destinations</td>
	</tr>
	<tr>
	<td colspan='4' align='left'>
	<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999'> ".$multipleDestinationMail." </table></td>
	</tr>
	</table> 
	</div> ";
	}
	$subject=$resultqueryies['subject'];
	$optionquery.=$queryHtml.$description;
	$select='emailsignature';
	$where='id="'.$_SESSION['userid'].'" and email="'.$_SESSION['username'].'"';
	$rs=GetPageRecord($select,_USER_MASTER_,$where);
	$LoginUserDetails=mysqli_fetch_array($rs);
	$description=addslashes($querythanksmsg.$optionquery);
	$description2=stripslashes(str_replace('client_read_mail.php','',$description));
	$subject='#'.makeQueryId($resultqueryies['id']).' '.$subject;


	// $namevalue ='subject="'.$subject.'",description="'.$description2.'",attachmentFile="'.$attachmentvar.'",adddate="'.date('Y-m-d H:i:s').'",multiemails="'.$multiemails.'",queryid="'.$editId.'",qmailId=1';
	// $ads = addlisting(_QUERYMAILS_MASTER_,$namevalue);

	$select='';
	$where='';
	$rs='';
	$select='*';
	$where='id=1';
	$rs=GetPageRecord($select,_QUERY_MAILS_SECTION_MASTER_,$where);
	$resultpageemail=mysqli_fetch_array($rs);
	$select='';
	$where='';
	$rs='';
	$select='email';
 	$where='id="'.$assignTo.'"';
	$rs=GetPageRecord($select,_USER_MASTER_,$where);
	$resultpageassignemailOppsperson=mysqli_fetch_array($rs);
	$corporatesalesperson='';
	if($clientType==1){
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where='id="'.$companyId.'"';
	$rs=GetPageRecord($select,_CORPORATE_MASTER_,$where);
	$resultpageassignemail=mysqli_fetch_array($rs);
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where='id="'.$resultpageassignemail['assignTo'].'"';
	$rs=GetPageRecord($select,_USER_MASTER_,$where);
	$resultpageassignemail=mysqli_fetch_array($rs);
	$corporatesalesperson=$resultpageassignemail['email'];
	}

	//=======================================================
	$rsdes=GetPageRecord('description,id,multiemails',_QUERYMAILS_MASTER_,'queryid="'.$editId.'"');
	$getDesc=mysqli_fetch_array($rsdes);
	// $description4=$getDesc['description'].'<img src="'.$fullurl.'readmail.php?id='.$getDesc['id'].'" width="0"  style="opacity: 0; filter: alpha(opacity=0);"  >';
	//=======================================================

	if($clientType==1){
		$mailto=(getPrimaryEmail($companyId,'corporate'));
	}
	if($clientType==2){
		$mailto=getPrimaryEmail($companyId,'contacts');
	}
	if($clientType==1){
		$mailtoMulti=(getMultiPrimaryEmail($companyId,'corporate'));
	}
	if($clientType==2){
		$mailtoMulti=getMultiPrimaryEmail($companyId,'contacts');
	}
	if($multiemails!=''){
		$multiemails=','.$multiemails;
	} else {
		$multiemails='';
	}

 	$ccmail=$resultpageemail['queryemail'].','.$corporatesalesperson.','.$resultpageassignemailOppsperson['email'].''.$multiemails.','.$mailtoMulti;
	$fromemail='';
	$mailto=$mailto;
	$mailsubject=$subject;
	$maildescription=stripslashes($description2).stripslashes($LoginUserDetails['emailsignature']);
	//send_template_mail($fromemail,$mailto,$mailsubject,$maildescription,$ccmail);

  ?>
  <div class="contentclass">
  <div id="sendmailaction" style="display:none;">
  <div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
  Mail Sent Successfully</div>
  <table border="0" align="center" cellpadding="0" cellspacing="0">
        <tbody><tr>
           <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
        </tr>
     </tbody></table>
  </div>
  <div id="sendmailfrm">
  <h1 style="text-align:left;">Preview</h1>
    <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
  <div class="mailusers" id="showmultiemails">
  		   <div class="mailusersbox"><strong>Client: </strong><?php echo $mailto; ?></div>
  		   <div class="mailusersbox"><strong>Operation Person: </strong><?php echo $resultpageassignemailOppsperson['email']; ?></div>
  		   <div class="mailusersbox"><strong>Sales Person: </strong><?php echo $corporatesalesperson; ?></div>
  		   <div class="mailusersbox"><strong>Group: </strong><?php echo $resultpageemail['queryemail'].', '.$getDesc['multiemails']; ?></div>
  	    </div>
   <div>Subject : <?php echo $subject; ?></div>
    <div>Description : <?php echo $description2; ?></div>
   <!--<div class="griddiv"><label>
   <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
  	<div class="gridlable">Add More Email   </div>
  	<input name="emailsender" type="text" class="gridfield" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
  	</label>
   </div>-->
   <input name="savenew" type="hidden" id="savenew" value="<?php echo $savenew;?>" />
   
   
  <input name="sendaddquerytoemail" type="hidden" id="sendaddquerytoemail" value="1" />
  <input name="attachitinerary" type="hidden" id="attachitinerary" value="<?php echo $attachitinerary; ?>" />
  <input name="queryid" type="hidden" id="queryid" value="<?php  echo $editId; ?> " />
   </form>
    </div>
    <div id="buttonsbox"  style="text-align:center;">
   <table border="0" align="right" cellpadding="0" cellspacing="0">
        <tr><td   style="position: relative;left:-60px;"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		
          <td style="padding-right:20px;"><a href="showpage.crm?module=query&daterange=<?php echo date('01-m-Y')."+-+".date('d-m-Y'); ?>"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" /></a>
  		</td>
        </tr>
     </table>
  </div>
  </div></div>
  	<?php 
}

if($_GET['action']=='sendQueryclientemail'){
  $editId = $_GET['QueryId'];
  $attachitinerary=$_GET['attachitinerary'];
  $select='';
  $where='';
  $rs='';
  $select='*';
  $where='  id="'.$editId.'"  ';
  $rs=GetPageRecord($select,_QUERY_MASTER_,$where);
  $resultpages=mysqli_fetch_array($rs);
  $servicePrice=$resultpages['servicePrice'];
  $assignTo=$resultpages['assignTo'];
  $clientType=$resultpages['clientType'];
  $companyId=$resultpages['companyId'];
  $select='';
  $where='';
  $rs='';
  $select='name';
  $where='id="'.$resultpages['tourType'].'"';
  $rs=GetPageRecord($select,_TOUR_TYPE_MASTER_,$where);
  $resultpagestourtype=mysqli_fetch_array($rs);
  $tourtypename=$resultpagestourtype['name'];
  $queryHtml='';
  $downloadLink='';
  if($attachitinerary=='2'){
    $queryHtml=url_get_contents($fullurl.'mailbodyQueryhtml.php?id='.encode($editId).'&servicePrice='.$servicePrice.'');
  }
  /*if($servicePrice=='2'){
  echo	$queryHtml=url_get_contents($fullurl.'mailbodyQueryhtml.php?id='.encode($editId).'&servicePrice='.$servicePrice.'');
  }*/
  $querythanksmsg= $thankyouMSG;
	// 'Dear Sir/Ma\'am <br> Greeting from <strong>'.$clientnameglobal.'</strong>.<br>While replying to this query, please don\'t change the subject line.<br><br>';
  if($servicePrice=='2' && $attachitinerary=='1'){
     $daydatae=1;
     $n=1;
     $daysfrom=1;
     $totalday=0;
     $select='';
     $where='';
     $rs='';
     $select='*';
     $where=' packageId="'.$editId.'" order by id asc';
     $rs=GetPageRecord($select,_PACKAGE_QUERY_DAYS_,$where);
     $daylisting=mysqli_fetch_array($rs);
  	$daysfrom=1;
  	$totalday=0;
  	$select22='';
  	$where22='';
  	$rs22='';
  	$select22='*';
  	$where22=' packageId="'.$editId.'" and dayId="'.$daylisting['id'].'" group by hotelId,roomType,mealPlan,dayId order by id desc';
  	$rs22=GetPageRecord($select,_PACKAGE_QUERY_HOTEL_,$where22);
  	$hotellisting=mysqli_fetch_array($rs22);
  	$select1='*';
  	$where1='id="'.$hotellisting['hotelId'].'"';
  	$rs1=GetPageRecord($select1,_PACKAGE_BUILDER_HOTEL_MASTER_,$where1);
  	$hoteldetail=mysqli_fetch_array($rs1);
  	$hotelName = strip($hoteldetail['hotelName']);
  	$select23='*';
  	$where23='id="'.$hotellisting['roomType'].'"';
  	$rs23=GetPageRecord($select23,_ROOM_TYPE_MASTER_,$where23);
  	$roomtype=mysqli_fetch_array($rs23);
  	$roomtypeName = $roomtype['name'];
  	$select24='*';
  	$where24='id="'.$hotellisting['mealPlan'].'"';
  	$rs24=GetPageRecord($select24,_MEAL_PLAN_MASTER_,$where24);
  	$mealplan=mysqli_fetch_array($rs24);
  	$mealplanName = $mealplan['name'];
  	$noofroom = $hotellisting['noOfRoom']+$hotellisting['doublenoOfRoom'];
  	if($hotellisting['childwithoutbedvalue']==0 || $hotellisting['childwithoutbedvalue']==''){} else {
  		$childwithbad=$hotellisting['childwithoutbed']*$hotellisting['childwithoutbedvalue'];
  	}
  	if($hotellisting['childwithoutbedvalue']==0 || $hotellisting['childwithoutbedvalue']==''){} else {
  		$childwithoutbad=$hotellisting['childwithoutbed']*$hotellisting['childwithoutbedvalue'];
  	}
  	if($hotellisting['noExtraAdult']==0 || $hotellisting['noExtraAdult']==''){} else {
  		$noExtraAdult=$hotellisting['hotelExtraCost']*$hotellisting['noExtraAdult'];
  	}
  	if($hotellisting['noOfRoom']==0 || $hotellisting['noOfRoom']==''){} else {
  		$hotelCost=$hotellisting['noOfRoom']*$hotellisting['hotelCost'];
  	}
  	if($hotellisting['doublenoOfRoom']==0 || $hotellisting['doublenoOfRoom']==''){} else {
  		$doubleRoomCost=$hotellisting['doublenoOfRoom']*$hotellisting['doubleRoomCost'];
  	}
  	$totalcostmain = $hotelCost+$doubleRoomCost+$childwithbad+$childwithoutbad+$noExtraAdult;
  	$servicePriceshow="<table width='100%' border='1' cellpadding='6' cellspacing='0' bordercolor='#CCCCCC'>
    <tr>
      <td width='182' bgcolor='#666666' align='center' style='color:#FFFFFF;'>Hotel Name</td>
  	<td width='420' bgcolor='#666666' style='color:#FFFFFF;'>Room Type</td>
      <td width='101' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Meal Plan</td>
      <td width='102' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Rooms</td>
      <td width='101' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Cost</td>
    </tr>
    <tr>
      <td width='182' align='center'>".$hotelName."</td>
      <td width='420'>".$roomtypeName."</td>
      <td width='101' align='center'>".$mealplanName."</td>
      <td width='102' align='center'>".$noofroom."</td>
      <td width='101' align='center'>".$totalcostmain."</td>
    </tr>
    </table>";
  }
  $selectquery='';
  $wherequery='';
  $rsquery='';
  $selectquery='*';
  $wherequery='id="'.$editId.'"  ';
  $rsquery=GetPageRecord($selectquery,_QUERY_MASTER_,$wherequery);
  $resultqueryies=mysqli_fetch_array($rsquery);
   	if($attachitinerary=='1'){
   	$srn = 1;
  	$select='*';
  	$where=' queryId="'.$editId.'" order by srdate asc';
  	$rs=GetPageRecord($select,'packageQueryDays',$where);
  	while($resListing=mysqli_fetch_array($rs)){
  		if($resultqueryies['dayWise'] == 1){
  			$dayWieDate2 = "  <td width='100' align='center' bgcolor='#FFFFFF'>".date('d-m-Y',strtotime($resListing['srdate']))."</td>";
  		}
  		 $multipleDestinationMail.="<tr>
  		  <td width='100' align='center' bgcolor='#FFFFFF'>".$srn."</td>".$dayWieDate2."<td width='100' align='center' bgcolor='#FFFFFF'>".getDestination($resListing['cityId'])."</td>
  		</tr>";
  	$srn++;
  	}
    if($resultqueryies['dayWise'] == 1){
    	$dayWieDate = " <td width='100' align='center' bgcolor='#999999' style='color:#FFFFFF;'><span class='gridlable'>Date</td>";
    }
   $queryHtml.="<img src='".$fullurl."client_read_mail.php?queryId=".$editId."' width='0' height='0'><div style='margin:20px 0px; border:1px #CCCCCC solid; width:795px !important;'>
  <div style='margin-bottom:10px; font-size:16px; padding:10px;'>Query Id  <strong>#".makeQueryId($resultqueryies['id'])."</strong></div>
  <table width='100%' border='1' cellpadding='6' cellspacing='0' bordercolor='#CCCCCC'>
    <tr>
  	<td width='420' bgcolor='#666666' style='color:#FFFFFF;'>Subject</td>
      <td width='101' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Adult</td>
      <td width='102' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Child</td>
      <td width='101' align='center' bgcolor='#666666' style='color:#FFFFFF;'>Infant</td>
    </tr>
    <tr>
      <td width='420'>".$resultqueryies['subject']."</td>
      <td width='101' align='center'>".$resultqueryies['adult']."</td>
      <td width='102' align='center'>".$resultqueryies['child']."</td>
      <td width='101' align='center'>".$resultqueryies['infant']."</td>
    </tr>
    <tr>
      <td colspan='4' align='left' bgcolor='#666666' style='color:#FFFFFF;'>Destinations</td>
    </tr>
  <tr>
        <td colspan='4' align='left'><table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999'>
          <tr>
            <td width='100' align='center' bgcolor='#999999' style='color:#FFFFFF;'><span class='gridlable'>S.N.</span></td>".$dayWieDate."<td width='100' align='center' bgcolor='#999999' style='color:#FFFFFF;'><span class='gridlable'>Destination<span class='redmind'></span> </span></td>
          </tr>".$multipleDestinationMail."
        </table></td>
      </tr>
  </table>".$servicePriceshow."
  </div>
  ";
  }
  $subject=$resultqueryies['subject'];
  $optionquery.=$queryHtml.$description;
  $select='emailsignature';
  $where='id="'.$_SESSION['userid'].'" and email="'.$_SESSION['username'].'"';
  $rs=GetPageRecord($select,_USER_MASTER_,$where);
  $LoginUserDetails=mysqli_fetch_array($rs);
  $description=addslashes($querythanksmsg.$optionquery);
  $description2=stripslashes(str_replace('client_read_mail.php','',$description));
  $subject='#'.makeQueryId($resultqueryies['id']).' '.$subject;
  //$namevalue ='subject="'.$subject.'",description="'.$description2.'",attachmentFile="'.$attachmentvar.'",adddate="'.date('Y-m-d H:i:s').'",multiemails="'.$multiemails.'",queryid="'.$editId.'",qmailId=1';
  //$ads = addlisting(_QUERYMAILS_MASTER_,$namevalue);
  $select='';
  $where='';
  $rs='';
  $select='*';
  $where='id=1';
  $rs=GetPageRecord($select,_QUERY_MAILS_SECTION_MASTER_,$where);
  $resultpageemail=mysqli_fetch_array($rs);
  $select='';
  $where='';
  $rs='';
  $select='email';
  $where='id='.$assignTo.'';
  $rs=GetPageRecord($select,_USER_MASTER_,$where);
  $resultpageassignemailOppsperson=mysqli_fetch_array($rs);
  $corporatesalesperson='';
  if($clientType==1){
  $select='';
  $where='';
  $rs='';
  $select='*';
  $where='id='.$companyId.'';
  $rs=GetPageRecord($select,_CORPORATE_MASTER_,$where);
  $resultpageassignemail=mysqli_fetch_array($rs);
  $select='';
  $where='';
  $rs='';
  $select='*';
  $where='id='.$resultpageassignemail['assignTo'].'';
  $rs=GetPageRecord($select,_USER_MASTER_,$where);
  $resultpageassignemail=mysqli_fetch_array($rs);
  $corporatesalesperson=$resultpageassignemail['email'];
  }
  if($clientType==1){
  $mailto=getPrimaryEmail($companyId,'corporate');
  }
  if($clientType==2){
  $mailto=getPrimaryEmail($companyId,'contacts');
  }
  if($clientType==1){
  $mailtoMulti=getMultiPrimaryEmail($companyId,'corporate');
  }
  if($clientType==2){
  $mailtoMulti=getMultiPrimaryEmail($companyId,'contacts');
  }
  if($multiemails!=''){
  $multiemails=','.$multiemails;
  } else {
  $multiemails='';
  }
  //$ccmail=$resultpageemail['queryemail'].','.$corporatesalesperson.','.$resultpageassignemailOppsperson['email'].''.$multiemails.','.$mailtoMulti;
  $ccmail=$resultpageemail['queryemail'].','.$corporatesalesperson.','.$resultpageassignemailOppsperson['email'].''.$multiemails.','.$mailtoMulti;
  $fromemail='';
  $mailto=$mailto;
  $mailsubject=$subject;
  $maildescription=stripslashes($description2).stripslashes($LoginUserDetails['emailsignature']);
  //send_template_mail($fromemail,$mailto,$mailsubject,$maildescription,$ccmail);
  ?>
  <div class="contentclass">
  <div id="sendmailaction" style="display:none;">
  <div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
  Mail Sent Successfully</div>
  <table border="0" align="center" cellpadding="0" cellspacing="0">
        <tbody><tr>
           <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
        </tr>
     </tbody></table>
  </div>
  <div id="sendmailfrm">
  <h1 style="text-align:left;">Preview</h1>
    <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
  <div class="mailusers" id="showmultiemails">
  		   <div class="mailusersbox"><strong>Client: </strong><?php echo $mailto; ?></div>
  		   <div class="mailusersbox"><strong>Operation Person: </strong><?php echo $corporatesalesperson; ?></div>
  		   <div class="mailusersbox"><strong>Sales Person: </strong><?php echo $corporatesalesperson; ?></div>
  		   <div class="mailusersbox"><strong>Group: </strong><?php echo $resultpageemail['queryemail']; ?></div>
  	    </div>
   <div>Subject : <?php echo $subject; ?></div>
    <div>Description : <?php echo $description2; ?></div>
   <!--<div class="griddiv"><label>
   <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
  	<div class="gridlable">Add More Email   </div>
  	<input name="emailsender" type="text" class="gridfield" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
  	</label>
   </div>-->
  <input name="sendquerytoemail" type="hidden" id="sendquerytoemail" value="1" />
  <input name="attachitinerary" type="hidden" id="attachitinerary" value="<?php echo $attachitinerary; ?>" />
  <input name="queryid" type="hidden" id="queryid" value="<?php  echo $editId; ?> " />
   </form>
    </div>
    <div id="buttonsbox"  style="text-align:center;">
   <table border="0" align="right" cellpadding="0" cellspacing="0">
        <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
          <td style="padding-right:20px;"><a href="showpage.crm?module=query"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" /></a></td>
        </tr>
     </table>
  </div>
  </div></div>
  	<?php 
} ?>
<?php 
if($_GET['action']=='queryStatus' && $_GET['queryId']!='' && $_GET['status']!=''){
	if($_GET['queryId']!=''){
		$id=($_GET['queryId']);
		$status=($_GET['status']);
		$as = GetPageRecord('queryCloseDetails',_QUERY_MASTER_,'id="'.$id.'"');
		$noteData = mysqli_fetch_assoc($as);
		?>
		<div class="contentclass">
		<h1 style="text-align:left;">Change  Status Query <?php  
		if($_GET['status']==6){ echo 'Quote&nbsp;Sent';  } 
		if($_GET['status']==3){ echo 'Confirmed';} 
		if($_GET['status']==4){ echo ' Lost';  } 
		if($_GET['status']==5){ echo 'Time Limit Booking'; }  

		?></h1>
	  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
	<div style="margin-bottom:10px;" id="textareiabox" class="shoqhidebuttonsquery">Remark:
	<textarea name="queryclosedetails" cols="" rows="" id="queryclosedetails" style="width:100%; height:60px; padding:10px; font-family:Arial, Helvetica, sans-serif; font-size:12px; border:1px #CCCCCC solid; box-sizing:border-box;" placeholder="Enter query related details"><?php echo $noteData['queryCloseDetails']; ?></textarea>
	</div>
		<?php if($_GET['status']=='5'){ ?>
		<div class="griddiv">
		<div class="gridlable"  style="width:100%;">Follow-Up Date
			<input name="followupdate" type="text" id="followupdate" class="gridfield calfieldicon"  displayname="Date"   autocomplete="off" value="" style="width:100%;"/>
			</div>
			</div>
			<div class="griddiv">
			<div class="gridlable"  style="width:100%; margin-top:5px;">Follow-Up Time
			<select id="endtime" name="endtime" class="gridfield" autocomplete="off"   >
				<?php
				$start=strtotime('00:00');
		   	$end=strtotime('23:30');
		    for ($i=$start;$i<=$end;$i = $i + 15*60) { ?>
				<option value="<?php echo date('g:i A',$i); ?>" <?php if('11:00 AM'==date('g:i A',$i) && $_REQUEST['id']=='' || $editendtime==date('g:i A',$i)){ ?> selected <?php } ?>><?php echo date('g:i A',$i); ?></option>
					<?php  }  ?>
			</select>
			</div>
			</div>
			<div id="followquerydate" style="display:none;padding:0px !important;" >
			<div class="griddiv"><label>
		  <script>
		 $(document).ready(function() {
		$('#followupdate').Zebra_DatePicker({
		  format: 'd-m-Y',
		});
		  });
		</script>
			<style>
			.newtowrobox .griddiv{    width: 46% !important;
		    display: inline-block;
		    margin: 8px;}
			.newtowrobox .gridlable{    width: 100% !important; }
		.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
		    width: 100% !important;
		}
		</style>
			</label>
		 </div>
		</div>
		<?php }?>
	<div style="overflow:hidden;">
	<input name="action" type="hidden" id="action" value="changeStatusId" />
	  <input name="statusId" type="hidden" id="statusId" value="<?php echo $id; ?>">
	  <input name="status" type="hidden" id="status" value="<?php echo $status; ?>">
	  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
	  <tr>
	    <td >
	     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
	 </td>
	    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Change Status    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
	  </tr>
	</table></div>
	 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
	</form>
	  </div>
	</div>
	<style>
	input[type="radio"] {
	    display: block;
	}
	</style>
	<?php 
} 
} ?>
<?php if($_GET['action']=='changepassword' ){ ?>
<div class="contentclass">
<h1 style="text-align:left;">Change Password</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
    <div class="griddiv">
    	<label>
	<div class="gridlable">Old Password <span class="redmind"></span></div>
	<input name="oldpassword" type="password" class="gridfield" id="oldpassword" value="" maxlength="20" displayname="Old Password" autocomplete="off" />
	</label>
	</div>
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top"><div class="griddiv"><label>
	<div class="gridlable">New Password <span class="redmind"></span></div>
	<input name="newpassword" type="password" id="newpassword" class="gridfield" displayname="New Password"  maxlength="20" autocomplete="off" value="" />
	</label>
	</div></td>
  </tr>
  <tr>
    <td width="49%" valign="top"><div class="griddiv">
    	<label>
	<div class="gridlable">Confirm Password <span class="redmind"></span></div>
	<input name="confirmpassword" type="password" id="confirmpassword" class="gridfield" displayname="Confirm Password"  maxlength="20" autocomplete="off" value="" />
	</label>
	</div></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="changepassword" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Update    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='addhotelfromquery' ){?>
<div class="contentclass">
<h1 style="text-align:left;">Add Hotel</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
   <div style="overflow:hidden;"> <div class="griddiv" style="width:60%;float:left;">
    	<label>
	<div class="gridlable">Hotel Name <span class="redmind"></span></div>
	<input name="hotelname" type="text" class="gridfield" id="hotelname" value="" maxlength="200" displayname="Hotel Name" autocomplete="off" />
	</label>
	</div>
	 <div class="griddiv" style="width:37%; float:right;">
    	<label>
	<div class="gridlable">Destination <span class="redmind"></span></div>
	<select id="hotelCity" name="hotelCity" class="gridfield validate" displayname="city" autocomplete="off"   >
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' 1 and id='.$_REQUEST['destinationid'].' order by name asc';
		$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo ($resListing['name']); ?>" <?php if($resListing['name']==$editresult['hotelCity']){ ?>selected="selected"<?php } ?>><?php echo ($resListing['name']); ?></option>
		<?php } ?>
	</select>
	</label>
	</div>
	</div>
	 <div style="overflow:hidden;">
	<div class="griddiv" style="width:45%; float:left;"><label>
	<div class="gridlable"style="width:100%;">Category<span class="redmind"></span></div>
	<select id="hotelCategory" name="hotelCategory" class="gridfield validate" autocomplete="off"  displayname="Hotel Category"  >
	 <option value="1" <?php if($editresult['hotelCategory']==1){ ?> selected="selected"<?php } ?>>1 Star</option>
	 <option value="2" <?php if($editresult['hotelCategory']==2){ ?> selected="selected"<?php } ?>>2 Star</option>
	 <option value="3" <?php if($editresult['hotelCategory']==3){ ?> selected="selected"<?php } ?>>3 Star</option>
	 <option value="4" <?php if($editresult['hotelCategory']==4){ ?> selected="selected"<?php } ?>>4 Star</option>
	 <option value="5" <?php if($editresult['hotelCategory']==5){ ?> selected="selected"<?php } ?>>5 Star</option>
</select>
	</label>
	</div>
	<div class="griddiv" style="float:right; width:52%;"><label>
	<div class="gridlable" style="width:100%;">Room Type <span class="redmind"></span></div>
<select id="roomType" name="roomType" class="gridfield validate" displayname="city" autocomplete="off"   >
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' 1  order by name asc';
		$rs=GetPageRecord($select,_ROOM_TYPE_MASTER_,$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo ($resListing['id']); ?>"><?php echo ($resListing['name']); ?></option>
		<?php } ?>
	</select>
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top">
	<div style="overflow:hidden;">
	<div class="griddiv"  style="float:left; width:60%;">
    	<label>	<div class="gridlable" style="width: 100%;">Supplier <span class="redmind"></span></div>
	<select id="supplierId" name="supplierId" class="gridfield validate" displayname="Supplier" autocomplete="off"    >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and companyTypeId=1 order by id asc';
$rs=GetPageRecord($select,_SUPPLIERS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
	</div>
	<div class="griddiv"  style="float:right; width:35%;">
    	<label>	<div class="gridlable" style="width: 100%;">Meal Plan <span class="redmind"></span></div>
	<select id="mealPlan" name="mealPlan" class="gridfield validate" displayname="Meal Plan" autocomplete="off"    >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by id asc';
$rs=GetPageRecord($select,_MEAL_PLAN_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
	</div>
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv"   style="width:60%; float:left;"  >
    	<label>	<div class="gridlable" style="width: 100%;">Address </div>
	<input name="hotelAddress" type="text" class="gridfield" id="hotelAddress" value="">
	</label>
	</div>
	<div class="griddiv"  style="width:35%; float:right;"   >
    	<label>	<div class="gridlable" style="width: 100%;">Upload Photo </div>
	<input name="hotelImage" type="file" class="gridfield" id="hotelImage" style="padding:5px;">
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="49%" valign="top"></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="quickhoteladd" />
<input name="dayid" type="hidden" id="dayid" value="<?php echo $_REQUEST['dayid']; ?>" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Update    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='addsightseeingfromquery' ){?>
<div class="contentclass">
<h1 style="text-align:left;">Add Sightseeing</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
   <div style="overflow:hidden;"> <div class="griddiv" style="width:60%;float:left;">
    	<label>
	<div class="gridlable">Name <span class="redmind"></span></div>
	<input name="sightseeingName" type="text" class="gridfield" id="sightseeingName" value="" maxlength="200" displayname="Sightseeing Name" autocomplete="off" />
	</label>
	</div>
	 <div class="griddiv" style="width:37%; float:right;">
    	<label>
	<div class="gridlable">Destination <span class="redmind"></span></div>
	<select id="hotelCity" name="hotelCity" class="gridfield validate" displayname="city" autocomplete="off"   >
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' 1 and id='.$_REQUEST['destinationid'].' order by name asc';
		$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo ($resListing['name']); ?>" <?php if($resListing['name']==$editresult['hotelCity']){ ?>selected="selected"<?php } ?>><?php echo ($resListing['name']); ?></option>
		<?php } ?>
	</select>
	</label>
	</div>
	</div>
	 <div style="overflow:hidden;">
	 <div class="griddiv"  style="float:left; width:45%;">
    	<label>	<div class="gridlable" style="width: 100%;">Supplier <span class="redmind"></span></div>
	<select id="supplierId" name="supplierId" class="gridfield validate" displayname="Supplier" autocomplete="off"    >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and companyTypeId=1 order by id asc';
$rs=GetPageRecord($select,_SUPPLIERS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
	</div>
	 <input name="sightseeingType" type="hidden" id="sightseeingType" value="1" />
	 <script>
	 var sightseeingType = $('#sightseeingType<?php echo $_REQUEST['dayid'];?>').val();
	 $('#sightseeingType').val(sightseeingType);
	 </script>
	 <div class="griddiv"  style="width:52%; float:right;"   >
    	<label>	<div class="gridlable" style="width: 100%;">Upload Photo </div>
	<input name="hotelImage" type="file" class="gridfield" id="hotelImage" style="padding:5px;">
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top">
	<div style="overflow:hidden;">
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv"     >
    	<label>	<div class="gridlable" style="width: 100%;">Details </div>
	    <textarea name="sightseeingDetail" rows="2" class="gridfield" id="sightseeingDetail"></textarea>
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="49%" valign="top"></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="quicksightseeingadd" />
<input name="dayid" type="hidden" id="dayid" value="<?php echo $_REQUEST['dayid']; ?>" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Update    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='addtransferfromquery' ){?>
<div class="contentclass">
<h1 style="text-align:left;">Add Transfer</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
   <div style="overflow:hidden;"> <div class="griddiv" style="width:60%;float:left;">
    	<label>
	<div class="gridlable">Name <span class="redmind"></span></div>
	<input name="transferName" type="text" class="gridfield" id="transferName" value="" maxlength="200" displayname="Transfer Name" autocomplete="off" />
	</label>
	</div>
	 <div class="griddiv" style="width:37%; float:right;">
    	<label>
	<div class="gridlable">Destination <span class="redmind"></span></div>
	<select id="hotelCity" name="hotelCity" class="gridfield validate" displayname="city" autocomplete="off"   >
		<?php
		$select='';
		$where='';
		$rs='';
		$select='*';
		$where=' 1 and id='.$_REQUEST['destinationid'].' order by name asc';
		$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
		while($resListing=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo ($resListing['name']); ?>" <?php if($resListing['name']==$editresult['hotelCity']){ ?>selected="selected"<?php } ?>><?php echo ($resListing['name']); ?></option>
		<?php } ?>
	</select>
	</label>
	</div>
	</div>
	 <div style="overflow:hidden;">
	 <div class="griddiv"  style="float:left; width:45%;">
    	<label>	<div class="gridlable" style="width: 100%;">Supplier <span class="redmind"></span></div>
	<select id="supplierId" name="supplierId" class="gridfield validate" displayname="Supplier" autocomplete="off"    >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and companyTypeId=1 order by id asc';
$rs=GetPageRecord($select,_SUPPLIERS_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
	</div>
	 <input name="transferType" type="hidden" id="transferType" value="1" />
	 <script>
	 var transferType = $('#transferType<?php echo $_REQUEST['dayid'];?>').val();
	 $('#transferType').val(transferType);
	 </script>
	 <div class="griddiv"  style="width:52%; float:right;"   >
    	<label>	<div class="gridlable" style="width: 100%;">Upload Photo </div>
	<input name="hotelImage" type="file" class="gridfield" id="hotelImage" style="padding:5px;">
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top">
	<div style="overflow:hidden;">
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv"     >
    	<label>	<div class="gridlable" style="width: 100%;">Details </div>
	    <textarea name="transferDetail" rows="2" class="gridfield" id="transferDetail"></textarea>
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="49%" valign="top"></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="quicktransferadd" />
<input name="dayid" type="hidden" id="dayid" value="<?php echo $_REQUEST['dayid']; ?>" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Update    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='adduploadinvoice'&& $_REQUEST['QueryId']!='' ){?>
<div class="contentclass">
<h1 style="text-align:left;">Create / Upload Invoice</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<div style="margin:0px 0px; overflow:hidden; margin-top:15px;">
<div id="showuploadbtn">
<a href="frmaction.php?QueryId=<?php echo $_REQUEST['QueryId']; ?>&addinvoice=1" target="actoinfrm" style="padding:15px; text-align:center;  font-weight:500; color:#FFFFFF; text-align:center; display:block; background-color:#0066CC; margin-bottom: 10px; border: 1px solid #0066CC; border-radius: 3px;"><i class="fa fa-plus-square" aria-hidden="true"></i> Create Invoice</a>
<a href="#" onclick="$('#showuploadfield').show();$('#showuploadbtn').hide();" style="padding:15px; text-align:center; font-weight:500; color:#FFFFFF; text-align:center; display:block; background-color:#0066CC; border-radius: 3px; border: 1px solid #0066CC; margin-bottom:10px;"><i class="fa fa-upload" aria-hidden="true"></i> Upload Invoice</a>
</div>
<div id="showuploadfield" style="display:none; padding:20px 0px; padding-top:0px;">
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="savefilefrm" target="actoinfrm" id="savefilefrm">
  <input name="QueryId" type="hidden" value="<?php echo $_REQUEST['QueryId']; ?>" />
  <input name="addinvoice" type="hidden" value="1" />
  <div style="text-align:left; margin-bottom:5px; font-size:13px;">Select File</div>
  <input name="uploadinvoicedoc" id="uploadinvoicedoc" type="file" style="width:100%; box-sizing:border-box;" onchange="$('#savefilefrm').submit();" />
  </form>
  </div>
<a href="#" onclick="alertspopupopenClose();" style="padding:15px; text-align:center;  font-weight:500; color:#000; text-align:center; display:block; background-color:#EFEFEF; border-radius: 3px; border: 1px solid #d0d0d0;">Cancel</a>
</div>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='addconferencespages' ){
if($_REQUEST['id']!=''){
$select1='*';
$where1='id='.$_REQUEST['id'].' ';
$rs1=GetPageRecord($select1,'conferencesPagesMaster',$where1);
$resultlists=mysqli_fetch_array($rs1);
}
?>
<script src="tinymce/tinymce.min.js"></script>
<script type="text/javascript">
    tinymce.init({
        selector: "#detailspage",
        themes: "modern",
        plugins: [
            "advlist autolink lists link image charmap print preview anchor",
            "searchreplace visualblocks code fullscreen"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
    });
    </script>
<div class="contentclass">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit';} else { echo 'Add';} ?> Conference Page</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top">
	<div class="griddiv"><label>
	<div class="gridlable">Parent Page<span class="redmind"></span>  </div>
	<select id="parentPage" name="parentPage" class="gridfield validate" displayname="Supplier" autocomplete="off"    >
	 <option value="0">No Parent</option>
	<?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' 1 and cid='.$_REQUEST['cid'].' and  parentPage=0 order by sr asc';
	$rs=GetPageRecord($select,'conferencesPagesMaster',$where);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$resultlists['parentPage']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
</select>
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Page Name<span class="redmind"></span>  </div>
	<input name="name" type="text" class="gridfield" id="name" value="<?php echo strip($resultlists['name']); ?>" displayname="Page Name" maxlength="100" />
	</label>
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv"     >
    	<label>	<div class="gridlable" style="width: 100%;">Page Details </div>
	    <textarea name="detailspage" rows="8" class="gridfield" id="detailspage"><?php echo strip($resultlists['details']); ?></textarea>
	</label>
	</div>
	</div>
	</td>
  </tr>
  <tr>
    <td width="49%" valign="top"></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="addcpages" />
<input name="id" type="hidden" id="id" value="<?php echo $_REQUEST['id']; ?>" />
<input name="cid" type="hidden" id="cid" value="<?php echo $_REQUEST['cid']; ?>" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="submit" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='showabstractsubmit' && $_GET['id']!=''){
$select1='*';
$where1='id='.$_REQUEST['id'].' ';
$rs1=GetPageRecord($select1,'conferencesAbstractForm',$where1);
$resultlists=mysqli_fetch_array($rs1);
?>
<div class="contentclass">
<h1 style="text-align:left;">Submission View</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<style>
.ourtfieldsbx{overflow:hidden; font-size:13px;}
.ourtfieldsbx .lable{margin-bottom:5px;}
.ourtfieldsbx .textfieldclass{border:1px solid #ccc; padding:10px; width:100%; box-sizing:border-box;}
</style>
 <table width="100%" border="0" cellpadding="20" cellspacing="0" style="margin:15px 0px;">
  <tr>
    <td align="left" valign="top" bgcolor="#F5F5F5">
	<div class="ourtfieldsbx">
	 <div class="lable"><strong>Name of presenting author:  	 </strong></div>
	  <?php echo stripslashes($resultlists['nameOfPerson']); ?>
	</div>	</td>
    <td width="50%" align="left" valign="top" bgcolor="#F5F5F5"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Affiliation of Presenting author:</strong></div>
	 <?php echo stripslashes($resultlists['nameOfCoAuthors']); ?>
	</div></td>
  </tr>
  <tr>
    <td align="left" valign="top"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Postal Address:  </strong></div>
	 <?php echo stripslashes($resultlists['address']); ?>
	</div></td>
    <td align="left" valign="top"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Mobile:  </strong></div>
	 <?php echo stripslashes($resultlists['mobile']); ?>
	</div></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#F5F5F5"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Email:  </strong></div>
	 <?php echo stripslashes($resultlists['email']); ?>
	</div></td>
    <td align="left" valign="top" bgcolor="#F5F5F5"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Names and affiliations of co-authors:</strong></div>
	 <?php echo stripslashes($resultlists['nameOfCoAuthors']); ?>
	</div></td>
  </tr>
  <tr>
    <td align="left" valign="top"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Type of presentation:  </strong></div>
	   <?php echo stripslashes($resultlists['typeOfPersentation']); ?>
    </div></td>
    <td align="left" valign="top"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Title of paper:  </strong></div>
	  <?php echo stripslashes($resultlists['titleOfpaper']); ?>
	</div></td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" bgcolor="#F5F5F5"><div class="ourtfieldsbx">
	 <div class="lable"><strong>Body of abstract:</strong></div>
	 <?php echo stripslashes($resultlists['details']); ?>
	</div></td>
    </tr>
</table>
<div style="overflow:hidden;">
 <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /> </td>
    </tr>
</table>
</div>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='addconferencesfee' && $_GET['cid']!='' ){
if($_REQUEST['id']!=''){
$select1='*';
$where1='id='.$_REQUEST['id'].' ';
$rs1=GetPageRecord($select1,'conferencesFee',$where1);
$resultlists=mysqli_fetch_array($rs1);
}
?>
<script src="tinymce/tinymce.min.js"></script>
<script type="text/javascript">
    tinymce.init({
        selector: "#detailspage",
        themes: "modern",
        plugins: [
            "advlist autolink lists link image charmap print preview anchor",
            "searchreplace visualblocks code fullscreen"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
    });
    </script>
<div class="contentclass">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit';} else { echo 'Add';} ?> Registration Fee</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top">
	<div class="griddiv"><label>
	<div class="gridlable">Type<span class="redmind"></span>  </div>
	<select id="name" name="name" class="gridfield validate" displayname="feeType" autocomplete="off"    >
	 <option value="0">Select</option>
	<?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' 1  order by id asc';
	$rs=GetPageRecord($select,'confrenceFeeCategory',$where);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$resultlists['feeType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
</select>
	</label>
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv"     >
    	<label>	<div class="gridlable" style="width: 100%;">Fee </div>
	    <input name="fee" type="number" class="gridfield" id="fee" value="<?php echo strip($resultlists['fee']); ?>" />
	</label>
	</div>
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv"     >
    	<label>	<div class="gridlable" style="width: 100%;">From </div>
	    <input name="startDate" type="text" class="gridfield" id="startDate" value="<?php if($resultlists['startDate']!=''){  echo date('d-m-Y',strtotime($resultlists['startDate'])); } else { echo date('d-m-Y'); } ?>" />
	</label>
	</div>
	</div>
	<div style="overflow:hidden; width:100%;">
	<div class="griddiv" >
    	<label>	<div class="gridlable" style="width: 100%;">To </div>
	    <input name="endDate" type="text" class="gridfield" id="endDate" value="<?php if($resultlists['startDate']!=''){  echo date('d-m-Y',strtotime($resultlists['endDate'])); } else { echo date('d-m-Y'); } ?>" />
	</label>
	</div>
	</div>
	<script>
	 $(document).ready(function() {
$('#startDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
$('#endDate').Zebra_DatePicker({
  format: 'd-m-Y',
});
  });
	</script>
	</td>
  </tr>
  <tr>
    <td width="49%" valign="top"></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="addconferencesfee" />
<input name="id" type="hidden" id="id" value="<?php echo $_REQUEST['id']; ?>" />
<input name="cid" type="hidden" id="cid" value="<?php echo $_REQUEST['cid']; ?>" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="submit" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?>
<?php if($_GET['action']=='viewaccommodationconfrence' && $_GET['cid']!='' && $_GET['userId']!='' ){
?>
<div class="contentclass">
<h1 style="text-align:left;">View Accommodation</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="1" cellpadding="10" cellspacing="0" bordercolor="#E2E2E2" id="showhoteltbl">
  <tr>
    <td width="13%" bgcolor="#E9E9E9">&nbsp;</td>
    <td colspan="2" bgcolor="#E9E9E9"><strong>Hotel Name </strong></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><strong>From Date </strong></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><strong>To Date </strong></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><strong>Nights</strong></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><strong>Occupancy</strong></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><strong>Guest</strong></td>
    <td width="12%" align="right" bgcolor="#E9E9E9"><strong>Cost (INR) </strong></td>
    </tr>
   <?php
	 $k=1;
		$select='*';
		$where='  confrenceId="'.$_REQUEST['cid'].'" and userId='.$_GET['userId'].' order by id asc';
		$rs=GetPageRecord($select,'confrenceHotelMaster',$where);
		while($datad=mysqli_fetch_array($rs)){
			$select1='*';
			$where1='id='.$datad['hotel'].' ';
			$rs1=GetPageRecord($select1,_PACKAGE_BUILDER_HOTEL_MASTER_,$where1);
			$hanme=mysqli_fetch_array($rs1);
			$select1='*';
			$where1='serviceid='.$hanme['id'].' and singleoccupancy!="0" and doubleoccupancy!="0" and tripleoccupancy!="0" order by singleoccupancy asc ';
			$rs1=GetPageRecord($select1,'dmcroomTariff',$where1);
			$roomrate=mysqli_fetch_array($rs1);
		?>
  <tr>
    <td><?php if($hanme['hotelImage']!=''){ ?><img src="<?php echo $fullurl; ?>packageimages/<?php echo $hanme['hotelImage']; ?>" width="105" height="91" /><?php } ?></td>
    <td colspan="2"><?php echo $hanme['hotelName']; ?><br />
<strong><?php echo $datad['category']; ?> Star</strong></td>
    <td align="center"><?php echo date('d/m/Y',strtotime($datad['fromDate'])); ?></td>
    <td align="center"><?php echo date('d/m/Y',strtotime($datad['toDate'])); ?></td>
    <td align="center">
	<?php
	$date1 = strtotime($datad['fromDate']);
$date2 = strtotime($datad['toDate']);
echo $finalnights=round(abs($date2 - $date1) / (60*60*24),0);
?>	</td>
    <td align="center"><?php if($datad['occupancy']=='1'){ echo 'Single'; } if($datad['occupancy']=='2'){ echo 'Double'; }if($datad['occupancy']=='3'){ echo 'Triple'; } ?></td>
    <td align="center"><?php echo $datad['guest']; ?></td>
    <td align="right"><?php if($datad['occupancy']=='1'){
	echo  $finalnights*$datad['guest']*$roomrate['singleoccupancy'];
	 } if($datad['occupancy']=='2'){
 $doublecost=0;
	 $doublecost = ceil($datad['guest']/$datad['occupancy']);
	 $roomratefianle=$roomrate['doubleoccupancy']*$doublecost;
	 echo round($finalnights*$roomratefianle);
	  }if($datad['occupancy']=='3'){
	   $doublecost=0;
	 $doublecost = ceil($datad['guest']/$datad['occupancy']);
	 $roomratefianle=$roomrate['tripleoccupancy']*$doublecost;
	 echo round($finalnights*$roomratefianle);
	  } ?>	 </td>
    </tr>  <?php $k++; } ?>
 <?php if($k>'1'){ ?>
<?php } ?>
</table>
  <table width="100%" border="1" cellpadding="10" cellspacing="0" bordercolor="#E2E2E2" id="showhoteltbl">
  <tr>
    <td colspan="2" bgcolor="#E9E9E9"><strong>Transfer </strong></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><strong>From Date </strong></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><strong>To Date </strong></td>
    <td width="20%" align="center" bgcolor="#E9E9E9"><strong>Vehicle</strong></td>
    <td width="20%" align="left" bgcolor="#E9E9E9"><strong>No. of Vehicle</strong></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><strong>Guest</strong></td>
    <td width="12%" align="left" bgcolor="#E9E9E9"><strong>Pickup Time </strong></td>
    </tr>
   <?php
	 $k=1;
		$select='*';
		$where='  confrenceId="'.$_REQUEST['cid'].'" and userId='.$_GET['userId'].' order by id asc';
		$rs=GetPageRecord($select,'confrenceCarMaster',$where);
		while($datad=mysqli_fetch_array($rs)){
	$select1='*';
			$where1='id='.$datad['transferId'].' ';
			$rs1=GetPageRecord($select1,_PACKAGE_BUILDER_TRANSFER_MASTER,$where1);
			$hanme=mysqli_fetch_array($rs1);
			$select1='*';
			$where1='id='.$datad['vehicleId'].' ';
			$rs1=GetPageRecord($select1,_VEHICLE_MASTER_MASTER_,$where1);
			$vehicle=mysqli_fetch_array($rs1);
		?>
  <tr>
    <td colspan="2"><?php echo $hanme['transferName']; ?>      </strong></td>
    <td align="center"><?php echo date('d/m/Y',strtotime($datad['fromDate'])); ?></td>
    <td align="center"><?php echo date('d/m/Y',strtotime($datad['toDate'])); ?></td>
    <td width="20%" align="center">
	<?php echo $vehicle['name']; ?>	</td>
    <td width="20%" align="left"><?php echo $datad['pax']; ?></td>
    <td align="center"><?php echo $datad['guest']; ?></td>
    <td align="left"><?php echo $datad['start_Time']; ?>	 </td>
    </tr>  <?php $k++; } ?>
  <?php if($k>'1'){ ?> <?php } ?>
</table>
  <table width="100%" border="1" cellpadding="10" cellspacing="0" bordercolor="#E2E2E2" id="showhoteltbl">
  <tr>
    <td colspan="2" bgcolor="#E9E9E9"><strong>On Board Meal </strong></td>
    <td width="12%" align="center" bgcolor="#E9E9E9"><strong>From Date </strong></td>
    <td width="10%" align="center" bgcolor="#E9E9E9"><strong>To Date </strong></td>
    <td width="20%" align="center" bgcolor="#E9E9E9"><strong>Preferred Timing</strong></td>
    <td width="20%" align="left" bgcolor="#E9E9E9"><strong>Preferred Airline</strong></td>
    <td width="8%" align="center" bgcolor="#E9E9E9"><strong>Guest</strong></td> 
    </tr>
   <?php
	 $k=1;
		$select='*';
		$where='   confrenceId="'.$_REQUEST['cid'].'" and userId='.$_GET['userId'].' order by id asc';
		$rs=GetPageRecord($select,'confrenceAirlineMaster',$where);
		while($datad=mysqli_fetch_array($rs)){
		?>
  <tr>
    <td colspan="2"><?php if($datad['onboardmeal']==1){ echo 'Yes'; } else { echo 'No'; }?> </strong></td>
    <td align="center"><?php echo date('d/m/Y',strtotime($datad['fromDate'])); ?></td>
    <td align="center"><?php echo date('d/m/Y',strtotime($datad['toDate'])); ?></td>
    <td width="20%" align="center">
	<?php echo $datad['preferredTiming']; ?>	</td>
    <td width="20%" align="left"><?php echo $datad['preferredAirline']; ?></td>
    <td align="center"><?php echo $datad['guest']; ?></td> 
    </tr>  <?php $k++; } ?>
 <?php if($k>'1'){ ?> <?php } ?>
</table>
<div style="overflow:hidden;">
 <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="Close" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();" /></td>
  </tr>
</table></div>
  </div>
</div>
	<?php }  ?>
	<?php if($_GET['action']=='changePIN' ){ ?>
<div class="contentclass">
<h1 style="text-align:left;">Change PIN</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="changestatusquery" target="actoinfrm" id="changestatusquery">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="50%" valign="top">
    <div class="griddiv">
    	<label>
	<div class="gridlable">Old PIN <span class="redmind"></span></div>
	<input name="oldpin" type="password" class="gridfield" id="oldpin" value="" maxlength="20" displayname="Old PIN" autocomplete="off" />
	</label>
	</div>
	</td>
  </tr>
  <tr>
    <td width="1%" valign="top"><div class="griddiv"><label>
	<div class="gridlable">New PIN <span class="redmind"></span></div>
	<input name="newpin" type="password" id="newpin" class="gridfield" displayname="New PIN"  maxlength="20" autocomplete="off" value="" />
	</label>
	</div></td>
  </tr>
  <tr>
    <td width="49%" valign="top"><div class="griddiv">
    	<label>
	<div class="gridlable">Confirm PIN <span class="redmind"></span></div>
	<input name="confirmpin" type="password" id="confirmpin" class="gridfield" displayname="Confirm PIN"  maxlength="20" autocomplete="off" value="" />
	</label>
	</div></td>
    </tr>
	 <tr>
    <td width="49%" valign="top"> </td>
    </tr>
</table>
<div style="overflow:hidden;">
<input name="action" type="hidden" id="action" value="changePIN" />
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" />
 </td>
    <td align="" style="padding-right:0px; " class="shoqhidebuttonsquery"><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Update    " onclick="formValidation('changestatusquery','submitbtn','0');" /></td>
  </tr>
</table></div>
</form>
  </div>
</div>
	<?php }  ?> 
<?php
//query history tab
if($_GET['action']=='querystatushistory' && $_GET['queryId']!=''){
if($_GET['queryId']!=''){
$id=($_GET['queryId']);
$subject=decode(($_GET['subject']));
?>
<div class="contentclass">
<h1 style="text-align:left;">Query History</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<div class="queryhistory">
<p class="mb-2 font-size-base" style="font-size: 16px; font-weight: 500; margin: 0px; color: #e9954e; margin-bottom: 10px; display: block;">#<?php echo $id; ?> <?php echo $subject; ?></p>
<div class="card" style="max-height: 430px;overflow-y: scroll;">
<?php
$selectbb='*';
$wherebb='queryId='.$id.' order by id desc';
$rsbb=GetPageRecord($selectbb,'queryHistoryMaster',$wherebb);
$countrows=mysqli_num_rows($rsbb);
if($countrows=='0'){ ?>
<div class="card-body" style="margin-bottom: 5px;">
<blockquote class="blockquote blockquote-bordered py-2 pl-3 mb-0" style="margin: 5px;text-align:center;font-size:15px;">
No History Found!!!
</blockquote>
</div>
<?php }
while($queryHistory=mysqli_fetch_array($rsbb)){
?>
<div class="card-body" style="margin-bottom: 5px;">
<blockquote class="blockquote blockquote-bordered py-2 pl-3 mb-0" style="margin: 5px;">
<p class="mb-2 font-size-base" style="font-size: 13px; font-weight: 500; line-height: 5px;"><?php echo $queryHistory['notes']; ?></p>
<footer class="blockquote-footer"><i class="fa fa-user" aria-hidden="true" style="margin-right: 5px; color: #5d5d5d;"></i>
<?php echo getUserName($queryHistory['addedBy']); ?> , <cite title="Source Title"><?php echo date('d M, Y - h:i A',$queryHistory['dateAdded']); ?></cite></footer>
</blockquote>
</div>
<?php } ?>
</div>
</div>
<style>
.queryhistory{
    margin-top: 10px;
    width: 100%;
    display: block;
}
.queryhistory .card-body {
    border: 1px solid rgba(0,0,0,.125);
    background: #f7f7f7;
    padding: 10px;
}
.queryhistory .card{
	position: relative;
	display: -ms-flexbox;
	display: flex;
	-ms-flex-direction: column;
	flex-direction: column;
	min-width: 0;
	word-wrap: break-word;
	background-color: #fff;
	background-clip: border-box;
	border-radius: .1875rem;
	margin-bottom: 1.25rem;
	box-shadow: 0 1px 2px rgba(0,0,0,.05);
}
</style>
<div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
  </tr>
</table></div>
  </div>
</div>
	<?php } } ?>
	<?php
//query history tab
if($_GET['action']=='hotelcombo' && $_GET['quotationId']!='' && $_GET['queryId']!=''){
?>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="contentclass">
<h1 style="text-align:left;">Hotel Combo</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<?php
$n=1;
$where16='';
$rs16='';
$select16='*';
$where16=' queryId='.$_REQUEST['quotationId'].' and hotelQuotatoinType=0 group by fromDate  order by fromDate asc';
$rs16=GetPageRecord($select16,_QUOTATION_HOTEL_MASTER_,$where16);
while($listSupplier=mysqli_fetch_array($rs16)){
?>
   <div style="border:1px solid #ccc; margin-bottom:10px;">
   <div style="background-color:#F0F0F0; font-size:14px; font-weight:600; padding:10px;"><?php echo date('d/m/Y',strtotime($listSupplier['fromDate'])); ?> - <?php echo date('d/m/Y',strtotime($listSupplier['toDate'])); ?></div>
   <table width="100%" border="0" cellpadding="10" cellspacing="0" id="myForm">
  <?php
$kk=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id in (select supplierId from '._QUOTATION_HOTEL_MASTER_.' where queryId='.$_REQUEST['quotationId'].' and fromDate="'.$listSupplier['fromDate'].'" and hotelQuotatoinType=0)');
while($hotelname=mysqli_fetch_array($kk)){
 
	$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,' id='.$hotelname['hotelCategoryId'].'');   
	 $hcD=mysqli_fetch_array($rr2);
 ?>
  <tr>
    <td colspan="2" align="center" style="padding:10px; border-bottom:1px solid #ccc;">
	<script>
	function radiocheckfun<?php echo $hotelname['id']; ?>(){
	var newcheck='';
	$("#myForm input[type=radio]:checked").each(function() {
	 newcheck += $(this).val()+',';
	});
	$('#hotelId').val(newcheck);
	}
	</script>
	<input name="hotelcheck<?php echo $listSupplier['id']; ?>" id="hotelcheck<?php echo $hotelname['id']; ?>" onclick="radiocheckfun<?php echo $hotelname['id']; ?>();" value="<?php echo $hotelname['id']; ?>" type="radio"  style="    display: block;" /></td>
    <td width="70%"  style="padding:10px; border-bottom:1px solid #ccc;"><?php echo strip($hotelname['hotelName']); ?> </td>
    <td width="30%"  style="padding:10px; border-bottom:1px solid #ccc;"><?php echo trim($hcD['hotelCategory']); ?> Star</td>
  </tr>
  <?php } ?>
</table>
   </div>
<?php } ?>
<div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" style="margin-right:10px;" />
     <input name="Save" type="submit" class="bluembutton" id="Cancel" value="Save"  />
 </td>
  </tr>
</table></div>
  </div>
</div>
 <input name="hotelId" id="hotelId" type="hidden" value="" />
 <input name="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
  <input name="quotationId" type="hidden" value="<?php echo $_GET['quotationId']; ?>" />
  <input name="action" type="hidden" value="hotelcombo" />
</form>
	<?php
}
if($_GET['action']=='createliveitinerary' && $_GET['quotationId']!=''){   ?>
  	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
		<div class="contentclass">
			<h3 style="text-align:left;margin-bottom: 10px;color: #233a49;text-transform: uppercase;">Itinerary</h3>
			<div id="loadcreateitinerary"  style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >Loading...</div>
			<script>
 			$('#loadcreateitinerary').load('loadcreateitinerary.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>');
 			</script>
		</div>
  	</form>
 	<?php
}
if($_GET['action']=='createlivevoucher' && $_GET['qid']!='' && $_GET['queryId']!=''){   ?>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="contentclass"><span style="float:right;"><input name="Cancel" type="button" style="background-color: #cccccc !important; border-radius: 3px; padding: 4px; margin: 2px;  " id="Cancel" value="Close" onclick="alertspopupopenClose();" /> </span>
<h1 style="text-align:left;">Voucher</h1>
  <div id="loadcreateitinerary"  style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >Loading...</div>
  <script>
  $('#loadcreateitinerary').load('loadcreatevoucher.php?queryId=<?php echo $_REQUEST['queryId']; ?>&qid=<?php echo $_REQUEST['qid']; ?>');
  </script>
  <div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
  </tr>
</table></div>
</div>
</form>
	<?php }
if($_GET['action']=='createlivevouchersupplier' && $_GET['qid']!='' && $_GET['queryId']!=''){   ?>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="contentclass">
 <span style=" float: right; margin: 3px; padding: 3px; background-color: #ccc !important; "><input name="Cancel" type="button"  id="Cancel" value="Close" onclick="alertspopupopenClose();" /> </span>
<h1 style="text-align:left;">Supplier Confirmation</h1>
  <div id="loadcreateitinerary"  style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >Loading...</div>
  <script>
  $('#loadcreateitinerary').load('loadcreateconfirmation.php?queryId=<?php echo $_REQUEST['queryId']; ?>&qid=<?php echo $_REQUEST['qid']; ?>');
  </script>
  <div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
  </tr>
</table></div>
</div>
</form>
	<?php } ?>

<?php if($_GET['action']=='editdmcotherActivityRate' && $_GET['sectionId']!=''){
if($_GET['sectionId']!=''){
$id=clean($_GET['sectionId']);
$select1='*';
$where1='id="'.$id.'"';
$rs1=GetPageRecord($select1,'dmcotherActivityRate',$where1);
$editresult=mysqli_fetch_array($rs1);
$fromDatevalidity=$editresult['fromDate'];
$toDatevalidity=$editresult['toDate'];
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Sightseeing Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="otherActivityNameId2" id="otherActivityNameId" type="hidden" value="<?php echo $id; ?>" />
    <input name="action" id="action" type="hidden" value="editdmcotherActivityRate" />
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
	 <option value="">Select</option>
 <?php
$select='';
$where='';
$rs='';
$select='*';
$where=' deletestatus=0 and status=1 order by name asc';
$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
while($resListing=mysqli_fetch_array($rs)){
?>
<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
<?php } ?>
</select>
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Supplier<span class="redmind"></span></div>
	<select id="activitySupplierId2" name="activitySupplierId2" class="gridfield validate" displayname="Supplier" autocomplete="off"     >
	 <option value="">Select</option>
    <?php
	$rs='';
	$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and activityType=3 group by name order by name asc');
	while($supplierData=mysqli_fetch_array($rs)){
    ?>
    <option value="<?php echo strip($supplierData['id']); ?>" <?php if($supplierData['id']==$editresult['supplierId']){ ?>selected="selected"<?php } ?>><?php echo strip($supplierData['name']); ?></option>
    <?php } ?>
</select>
	</label>
 </div>

 <div class="griddiv rateValidation"><label>
 		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">From Date</div>
		<input name="fromDate2" type="date" id="fromDate2" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($fromDatevalidity)); ?>" />
		</label>
	 </div>
	 <div class="griddiv rateValidation"><label>
 		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">To Date</div>
		<input name="toDate2" type="date" id="toDate2" class="gridfield validate" displayname="To Travel Date" autocomplete="off" value="<?php echo date('Y-m-d',strtotime($toDatevalidity)); ?>"  />
		</label>
	</div>

			<div class="griddiv"><label>

		<div class="gridlable">Transfer&nbsp;Type</div>

		<select id="ActransferTypeId" name="ActransferType2" class="gridfield " autocomplete="off" onchange="selectTransferTypeSP();">

			<?php if($transferType==0 || $transferType==1){ ?>
			<option value="1" <?php if ($editresult['transferType'] == '1') { ?> selected="selected" <?php } ?>>SIC</option>
			<?php } if($transferType==0 || $transferType==2){ ?>
			<option value="2" <?php if ($editresult['transferType'] == '2') { ?> selected="selected" <?php } ?>>PVT</option>
			<?php } if($transferType==0 || $transferType==3){ ?>
			<option value="3" <?php if ($editresult['transferType'] == '3') { ?> selected="selected" <?php } ?>>VIP</option>
			<?php } if($transferType==0 || $transferType==4){ ?>
			<option value="4" <?php if ($editresult['transferType'] == '4') { ?> selected="selected" <?php } ?>>Ticket Only</option>
			<?php } ?>
		</select>

		</label>

		</div>

		<div class="griddiv"><label>
		<div class="gridlable">Adult Ticket Cost</div>
			<input name="tickettptAdultCost2" type="text" class="gridfield"  id="tickettptAdultCost2" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketAdultCost']; ?>" />
			</label>
		</div>
							
		<div class="griddiv"><label>
			<div class="gridlable">Child Ticket Cost</div>
				<input name="tickettptchildCost2" type="text" class="gridfield"  id="tickettptchildCost2" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketchildCost']; ?>" />
			</label>
		</div>
					

					
		<div class="griddiv"><label>
			<div class="gridlable">Infant Ticket Cost</div>
				<input name="tickettptinfantCost2" type="text" class="gridfield"  id="tickettptinfantCost2" maxlength="6" onkeyup="numericFilter(this);" value="<?php echo $editresult['ticketinfantCost']; ?>" />
			</label>
		</div>
	
									<div class="griddiv tptPVT" style="display:none;">
										<label>
											<div class="gridlable">Vehicle&nbsp;Name</div>
											<select id="vehicleId2" name="vehicleId2" class="gridfield" displayname="Vehicle Name" autocomplete="off" >
											<?php 
											$rs2="";
											$rs2=GetPageRecord('*',_VEHICLE_MASTER_MASTER_,' 1 and model!="" and carType!="" order by model asc ');
											while($vehicleData=mysqli_fetch_array($rs2)){
											?>
											<option value="<?php echo $vehicleData['id'];?>" <?php if($vehicleData['id']==$editresult['vehicleId']){ echo "selected"; } ?> ><?php echo getVehicleTypeName($vehicleData['carType']) . "( " . ucfirst($vehicleData['model']);?> ) </option>
											<?php
											}
											?>
											</select>
										</label>
									</div>
								
								
									<div class="griddiv tptPVT" style="display:none;">
										<label>
											<div class="gridlable">Vehicle Cost</div>
											<input name="vehicleCost2" type="text" class="gridfield" id="vehicleCost2" style="width: 99%;" value="<?php echo $editresult['vehicleCost']; ?>">
										</label>
									</div>
								
								<!-- SIC TYPE -->
								
									<div class="griddiv tptSIC" style="display:block;">
										<label>
											<div class="gridlable">Adult Transfer Cost</div>
											<input name="adulttptCost2" type="text" class="gridfield" id="adulttptCost2" style="width: 99%;" value="<?php echo $editresult['adultCost']; ?>">
										</label>
									</div>
								
							
									<div class="griddiv tptSIC" style="display:block;">
										<label>
											<div class="gridlable">Child Transfer Cost</div>
											<input name="childtptCost2" type="text" class="gridfield" id="childtptCost2" style="width: 99%;" value="<?php echo $editresult['childCost']; ?>">
										</label>
									</div>
								
								
									<div class="griddiv tptSIC" style="display:block;">
										<label>
											<div class="gridlable">Infant Transfer Cost</div>
											<input name="infanttptCost2" type="text" class="gridfield" id="infanttptCost2" style="width: 99%;" value="<?php echo $editresult['childCost']; ?>">
										</label>
									</div>
								
									<div class="griddiv ticketOnly">
										<label>
											<div class="gridlable">Rep.&nbsp;Cost</div>
											<input name="repCost2" type="text" class="gridfield" id="repCost2" style="width: 99%;" value="<?php echo $editresult['repCost']; ?>">
										</label>
									</div>
								
									<div class="griddiv">
										<label>
											<div class="gridlable">Markup Type</div>
											<select name="markupType2" id="markupType2" class="gridfield validate" displayname="Markup Type" autocomplete="off" style="width: 100%;" >
											 	<option value="1" <?php if($editresult['markupType']==1){ echo "selected"; } ?>>%</option>
											 	<option value="2" <?php if($editresult['markupType']==2){ echo "selected"; } ?> >Flat</option>
											</select>
										</label>
									</div>
								
									<div class="griddiv">
										<label>
											<div class="gridlable">Markup Cost</div>
											<input name="markupCost2" type="text" class="gridfield" id="markupCost2" style="width: 99%;" value="<?php echo $editresult['markupCost']; ?>">
										</label>
									</div>
								
								
									<div class="griddiv">
										<label>
											<div class="gridlable">TAX&nbsp;SLAB(%)</div>
											<select id="gstTax2" name="gstTax2" class="gridfield" displayname="GST" autocomplete="off" >
												<?php 
												$rs2="";
												$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="entrance" and status=1'); 
												while($gstSlabData=mysqli_fetch_array($rs2)){
												?>
												<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id']==$editresult['gstTax']){ echo "selected"; } ?> ><?php echo $gstSlabData['gstSlabName'];?>&nbsp;(<?php echo $gstSlabData['gstValue'];?>)</option>
												<?php
												}	
												?>
											</select>
										</label>
									</div>
							
	  <div class="griddiv">
        <label> </label>
        <div style="color:#CC0000; margin:10px 0px; text-align:left;" id="div"></div>
        <div class="gridlable">Remarks</div>
        <input name="remarks2" type="text" class="gridfield"  id="remarks2" maxlength="200"   value="<?php echo $editresult['remarks']; ?>"/>
      </div>
	<div class="griddiv"><label>
      <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status</div>
	<select id="status2" name="status2" class="gridfield" displayname="Status" autocomplete="off"   >
<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
</select>
	</label>
 </div>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div><div id="calprice"></div>
<script>
// function getPerPaxCost2(){
// 		var activityCost = $('#activityCost2').val();
// 		var maxpax = $('#maxpax2').val();
// 		var ppCost = Math.round(activityCost/maxpax);
// 		$('#perPaxCost2').val(activityCost);
// 		$('#perPaxCost2').val(ppCost);
	
// 	}


	function selectTransferTypeSP(){
		var ActransferType = $("#ActransferTypeId").val();

	if(ActransferType == 1){
		$('.tptSIC').css('display','block');
		$('.ticketOnly').css('display','block');
		$('.tptPVT').css('display','none');
	}else if(ActransferType == 2  || ActransferType == 3){
		$('.tptPVT').css('display','block');
		$('.ticketOnly').css('display','block');
		$('.tptSIC').css('display','none');
	}else{
		$('.tptPVT').css('display','none');
		$('.tptSIC').css('display','none');
		$('.ticketOnly').css('display','none');
	}
}

selectTransferTypeSP()

</script>
<?php } ?>

<!-- Visa cost start -->

<?php if($_GET['action']=='editVisaRate' && $_GET['sectionId']!=''){
if($_GET['sectionId']!=''){
$id=clean($_GET['sectionId']);
$select1='*';
$where1='id="'.$id.'"';
$rs1=GetPageRecord($select1,'visaRateMaster',$where1);
$editresult=mysqli_fetch_array($rs1);
$fromDatevalidity=$editresult['fromDate'];
$toDatevalidity=$editresult['toDate'];
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Visa Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="visaNameId" id="visaNameId" type="hidden" value="<?php echo $id; ?>" />

    <input name="action" id="action" type="hidden" value="editVisaRate"/>
	<div class="griddiv"> 
	<label> 
	<div class="gridlable">Visa&nbsp;Name<span class="redmind"></span></div> 
		<input type="text" name="visaName2" id="visaName2" class="validate gridfield" value="<?php echo $editresult['name']; ?>" readonly >
	</label>  
	</div>

	<div class="griddiv"> 
	<label> 
	<div class="gridlable">Visa&nbsp;Type<span class="redmind"></span></div> 
		<select id="visaTypeId2" name="visaTypeId2"  displayname="Visa Type" class="validate gridfield" autocomplete="off" > 
				<?php   
				$rs='';   
				$rs1=GetPageRecord('*','visaTypeMaster',' deletestatus=0 and name!="" and status=1 order by name asc'); 
				while($visaType=mysqli_fetch_array($rs1)){   
				?>
				<option value="<?php echo strip($visaType['id']); ?>" <?php if($visaType['id']==$visaCostData['visaType']){ ?> selected="selected" <?php }; ?> ><?php echo strip($visaType['name']); ?></option>
				<?php } ?>
				</select>
	</label>  
	</div>
	<div class="griddiv" >
				<label> 
				<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
				<select id="supplierId2" name="supplierId2"  displayname="Supplier Name" class="validate gridfield" autocomplete="off" > 
				<?php   
				$rs='';   
				$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and status=1 and guideType=2  order by name asc'); 
				while($supplierData=mysqli_fetch_array($rs)){   
				?>
				<option value="<?php echo strip($supplierData['id']); ?>" ><?php echo strip($supplierData['name']); ?></option>
				<?php } ?>
				</select></label>
				</div>
				<div class="griddiv" >
				<div class="gridlable">Rate&nbsp;Valid&nbsp;From <span class="redmind"></span></div>
	<input name="fromDate2" type="text" id="fromDate2"  class="gridfield calfieldicon validate" displayname="Rate Valid From" style="width: 100%;" value="<?php echo date('d-m-Y',strtotime($editresult['fromDate'])) ?>" />
	</label>
	</div>
	
	<div class="griddiv">
	<label>
	<div class="gridlable">Rate&nbsp;Valid&nbsp;To<span class="redmind"></span>  </div>
	<input name="toDate2" type="text" id="toDate2" class="gridfield calfieldicon validate" displayname="Rate Valid To" style="width: 100%;"  value="<?php echo date('d-m-Y',strtotime($editresult['toDate'])) ?>" />
	</label>
	</div>

	<div class="griddiv">
					<label>  
					<div class="gridlable">Currency<span class="redmind"></span></div>
					<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"    >
					 <option value="">Select</option>
						<?php 
						
						$select=''; 
						$where=''; 
						$rs='';  
						$select='*';    
						$where=' deletestatus=0 and status=1 order by name asc';  
						$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where); 
						while($resListing=mysqli_fetch_array($rs)){   
						?>
						<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
						<?php } ?>
						</select>
					</label>
				</div>			
			
				<div class="griddiv">
					<label>
						<div class="gridlable">TAX&nbsp;SLAB(%)</div>
						<select id="gstTax2" name="gstTax2" class="gridfield" displayname="GST" autocomplete="off" >
							<?php 
								$rs2="";
								$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="hotel" and status=1'); 
								while($gstSlabData=mysqli_fetch_array($rs2)){
									?>
								<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id']==$editresult['gstTax']){ ?>selected="selected"<?php } ?> ><?php echo $gstSlabData['gstSlabName'];?>&nbsp;(<?php echo $gstSlabData['gstValue'];?>)</option>
								<?php
								}	
								?>
						</select>
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Adult&nbsp;Cost<span class="redmind"></span></div>
						<input type="text" name="adultCost2" id="adultCost2" class="gridfield validate" value="<?php echo $editresult['adultCost'] ?>" displayname="Adult Cost">
					</label>
				</div>
		
				<div class="griddiv">
					<label>
						<div class="gridlable">Child&nbsp;Cost</div>
						<input type="text" name="childCost2" id="childCost2" class="gridfield" value="<?php echo $editresult['childCost'] ?>" displayname="Child Cost">
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Infant&nbsp;Cost</span></div>
						<input type="text" name="infantCost2" id="infantCost2" class="gridfield" value="<?php echo $editresult['infantCost']; ?>" displayname="Infant Cost">
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">MarkUp&nbsp;Type<span class="redmind"></span></div>
						<select name="visaMarkup2" id="visaMarkup2" class="gridfield validate" >
							<option value="1" <?php if($editresult['markupType']==1){ ?> selected="selected" <?php } ?> >%</option>
							<option value="2" <?php if($editresult['markupType']==2){ ?> selected="selected" <?php } ?> >Flat</option>
						</select>
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Processing&nbsp;Fee</div>
						<input type="text" name="processingFee2" id="processingFee2" class="gridfield" value="<?php echo $editresult['processingFee']; ?>" displayname="Processing Fee">
					</label>
				</div>

				
				<div class="griddiv">
					<label>
						<div class="gridlable">Embassy&nbsp;Fee</div> 
						<input type="text" name="embassyFee2" id="embassyFee2" value="<?php echo $editresult['embassyFee']; ?>" class="gridfield" displayname="Embassy Fee">
					</label>
				</div>
		
			
				<div class="griddiv">
					<label>
						<div class="gridlable">VFS&nbsp;Charges</div>
						<input type="text" name="vfsCharges2" id="vfsCharges2" value="<?php echo $editresult['vfsCharges']; ?>" class="gridfield" displayname="VFS Charges">
					</label>
				</div>
		
			
				<div class="griddiv">
					<label>  
						<div class="gridlable">Status</div>
						<select id="status2" name="status2" class="gridfield" displayname="Status" autocomplete="off" >  
							<option value="1" <?php if($editresult['status']==1){ ?> selected="selected" <?php } ?> >Active</option>
							<option value="0" <?php if($editresult['status']==0){ ?> selected="selected" <?php } ?> >In Active</option>
						</select>
					</label>
				</div>
			
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>

</div></div>

<script>
	$(document).ready(function() {  
	$('#toDate2').Zebra_DatePicker({ 
	  	format: 'd-m-Y',  
	}); 
	
	$('#fromDate2').Zebra_DatePicker({ 
	  	format: 'd-m-Y',  
		pair: $('#toDate')
	});  
});
</script>


<?php } ?>

<!-- Visa cost end -->


<!-- Insurance cost start -->

<?php if($_GET['action']=='editInsuranceRate' && $_GET['sectionId']!=''){
if($_GET['sectionId']!=''){
$id=clean($_GET['sectionId']);
$select1='*';
$where1='id="'.$id.'"';
$rs1=GetPageRecord($select1,'insuranceRateMaster',$where1);
$editresult=mysqli_fetch_array($rs1);
$fromDatevalidity=$editresult['fromDate'];
$toDatevalidity=$editresult['toDate'];
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Insurance Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="insuranceNameId" id="insuranceNameId" type="hidden" value="<?php echo $id; ?>" />

    <input name="action" id="action" type="hidden" value="editInsuranceRate"/>
	<div class="griddiv"> 
	<label> 
	<div class="gridlable">Insurance&nbsp;Name<span class="redmind"></span></div> 
		<input type="text" name="InsuranceName2" id="InsuranceName2" class="validate gridfield" value="<?php echo $editresult['name']; ?>" readonly >
	</label>  
	</div>

	<div class="griddiv"> 
	<label> 
	<div class="gridlable">Insurance&nbsp;Type<span class="redmind"></span></div> 
		<select id="visaTypeId2" name="insuranceTypeId2"  displayname="Visa Type" class="validate gridfield" autocomplete="off" > 
				<?php   
				$rs='';   
				$rs1=GetPageRecord('*','visaTypeMaster',' deletestatus=0 and name!="" and status=1 order by name asc'); 
				while($insuranceType=mysqli_fetch_array($rs1)){   
				?>
				<option value="<?php echo strip($insuranceType['id']); ?>" <?php if($insuranceType['id']==$editresult['insuranceTypeId']){ ?> selected="selected" <?php }; ?> ><?php echo strip($insuranceType['name']); ?></option>
				<?php } ?>
				</select>
	</label>  
	</div>
	<div class="griddiv" >
				<label> 
				<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
				<select id="supplierId2" name="supplierId2"  displayname="Supplier Name" class="validate gridfield" autocomplete="off" > 
				<?php   
				$rs='';   
				$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and status=1 and guideType=2  order by name asc'); 
				while($supplierData=mysqli_fetch_array($rs)){   
				?>
				<option value="<?php echo strip($supplierData['id']); ?>" ><?php echo strip($supplierData['name']); ?></option>
				<?php } ?>
				</select></label>
				</div>
				<div class="griddiv" >
				<div class="gridlable">Rate&nbsp;Valid&nbsp;From <span class="redmind"></span></div>
	<input name="fromDate2" type="text" id="fromDate2"  class="gridfield calfieldicon validate" displayname="Rate Valid From" style="width: 100%;" value="<?php echo date('d-m-Y',strtotime($editresult['fromDate'])) ?>" />
	</label>
	</div>
	
	<div class="griddiv">
	<label>
	<div class="gridlable">Rate&nbsp;Valid&nbsp;To<span class="redmind"></span>  </div>
	<input name="toDate2" type="text" id="toDate2" class="gridfield calfieldicon validate" displayname="Rate Valid To" style="width: 100%;"  value="<?php echo date('d-m-Y',strtotime($editresult['toDate'])) ?>" />
	</label>
	</div>

	<div class="griddiv">
					<label>  
					<div class="gridlable">Currency<span class="redmind"></span></div>
					<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"    >
					 <option value="">Select</option>
						<?php 
						
						$select=''; 
						$where=''; 
						$rs='';  
						$select='*';    
						$where=' deletestatus=0 and status=1 order by name asc';  
						$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where); 
						while($resListing=mysqli_fetch_array($rs)){   
						?>
						<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
						<?php } ?>
						</select>
					</label>
				</div>			
			
				<div class="griddiv">
					<label>
						<div class="gridlable">TAX&nbsp;SLAB(%)</div>
						<select id="gstTax2" name="gstTax2" class="gridfield" displayname="GST" autocomplete="off" >
							<?php 
								$rs2="";
								$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="hotel" and status=1'); 
								while($gstSlabData=mysqli_fetch_array($rs2)){
									?>
								<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id']==$editresult['gstTax']){ ?>selected="selected"<?php } ?> ><?php echo $gstSlabData['gstSlabName'];?>&nbsp;(<?php echo $gstSlabData['gstValue'];?>)</option>
								<?php
								}	
								?>
						</select>
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Adult&nbsp;Cost<span class="redmind"></span></div>
						<input type="text" name="adultCost2" id="adultCost2" class="gridfield validate" value="<?php echo $editresult['adultCost'] ?>" displayname="Adult Cost">
					</label>
				</div>
		
				<div class="griddiv">
					<label>
						<div class="gridlable">Child&nbsp;Cost</div>
						<input type="text" name="childCost2" id="childCost2" class="gridfield" value="<?php echo $editresult['childCost'] ?>" displayname="Child Cost">
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Infant&nbsp;Cost</span></div>
						<input type="text" name="infantCost2" id="infantCost2" class="gridfield" value="<?php echo $editresult['infantCost']; ?>" displayname="Infant Cost">
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">MarkUp&nbsp;Type<span class="redmind"></span></div>
						<select name="visaMarkup2" id="visaMarkup2" class="gridfield validate" >
							<option value="1" <?php if($editresult['markupType']==1){ ?> selected="selected" <?php } ?> >%</option>
							<option value="2" <?php if($editresult['markupType']==2){ ?> selected="selected" <?php } ?> >Flat</option>
						</select>
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Processing&nbsp;Fee</div>
						<input type="text" name="processingFee2" id="processingFee2" class="gridfield" value="<?php echo $editresult['processingFee']; ?>" displayname="Processing Fee">
					</label>
				</div>
			
				<div class="griddiv">
					<label>  
						<div class="gridlable">Status</div>
						<select id="status2" name="status2" class="gridfield" displayname="Status" autocomplete="off" >  
							<option value="1" <?php if($editresult['status']==1){ ?> selected="selected" <?php } ?> >Active</option>
							<option value="0" <?php if($editresult['status']==0){ ?> selected="selected" <?php } ?> >In Active</option>
						</select>
					</label>
				</div>
			
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>

</div></div>

<script>
	$(document).ready(function() {  
	$('#toDate2').Zebra_DatePicker({ 
	  	format: 'd-m-Y',  
	}); 
	
	$('#fromDate2').Zebra_DatePicker({ 
	  	format: 'd-m-Y',  
		pair: $('#toDate')
	});  
});
</script>


<?php } ?>

<!-- Visa cost end -->



<!-- ======================= Edit Passport cost ============================ -->

<?php if($_GET['action']=='editPassportRate' && $_GET['sectionId']!=''){
if($_GET['sectionId']!=''){
$id=clean($_GET['sectionId']);
$select1='*';
$where1='id="'.$id.'"';
$rs1=GetPageRecord($select1,'passportRateMaster',$where1);
$editresult=mysqli_fetch_array($rs1);
$fromDatevalidity=$editresult['fromDate'];
$toDatevalidity=$editresult['toDate'];
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
</style>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Update Insurance Rate </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="passportNameId" id="passportNameId" type="hidden" value="<?php echo $id; ?>" />

    <input name="action" id="action" type="hidden" value="editPassportRate"/>
	<div class="griddiv"> 
	<label> 
	<div class="gridlable">Passport&nbsp;Name<span class="redmind"></span></div> 
		<input type="text" name="passportName2" id="passportName2" class="validate gridfield" value="<?php echo $editresult['name']; ?>" readonly >
	</label>  
	</div>

	<div class="griddiv"> 
	<label> 
	<div class="gridlable">Passport&nbsp;Type<span class="redmind"></span></div> 
		<select id="passportTypeId2" name="passportTypeId2"  displayname="Passport Type" class="validate gridfield" autocomplete="off" > 
				<?php   
				$rs='';   
				$rs1=GetPageRecord('*','passportTypeMaster',' deletestatus=0 and name!="" and status=1 order by name asc'); 
				while($passportType=mysqli_fetch_array($rs1)){   
				?>
				<option value="<?php echo strip($passportType['id']); ?>" <?php if($passportType['id']==$editresult['passportTypeId']){ ?> selected="selected" <?php }; ?> ><?php echo strip($passportType['name']); ?></option>
				<?php } ?>
				</select>
	</label>  
	</div>
	<div class="griddiv" >
				<label> 
				<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
				<select id="supplierId2" name="supplierId2"  displayname="Supplier Name" class="validate gridfield" autocomplete="off" > 
				<?php   
				$rs='';   
				$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and status=1 and guideType=2  order by name asc'); 
				while($supplierData=mysqli_fetch_array($rs)){   
				?>
				<option value="<?php echo strip($supplierData['id']); ?>" ><?php echo strip($supplierData['name']); ?></option>
				<?php } ?>
				</select></label>
				</div>
				<div class="griddiv" >
				<div class="gridlable">Rate&nbsp;Valid&nbsp;From <span class="redmind"></span></div>
	<input name="fromDate2" type="text" id="fromDate2"  class="gridfield calfieldicon validate" displayname="Rate Valid From" style="width: 100%;" value="<?php echo date('d-m-Y',strtotime($editresult['fromDate'])) ?>" />
	</label>
	</div>
	
	<div class="griddiv">
	<label>
	<div class="gridlable">Rate&nbsp;Valid&nbsp;To<span class="redmind"></span>  </div>
	<input name="toDate2" type="text" id="toDate2" class="gridfield calfieldicon validate" displayname="Rate Valid To" style="width: 100%;"  value="<?php echo date('d-m-Y',strtotime($editresult['toDate'])) ?>" />
	</label>
	</div>

	<div class="griddiv">
					<label>  
					<div class="gridlable">Currency<span class="redmind"></span></div>
					<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"    >
					 <option value="">Select</option>
						<?php 
						
						$select=''; 
						$where=''; 
						$rs='';  
						$select='*';    
						$where=' deletestatus=0 and status=1 order by name asc';  
						$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where); 
						while($resListing=mysqli_fetch_array($rs)){   
						?>
						<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
						<?php } ?>
						</select>
					</label>
				</div>			
			
				<div class="griddiv">
					<label>
						<div class="gridlable">TAX&nbsp;SLAB(%)</div>
						<select id="gstTax2" name="gstTax2" class="gridfield" displayname="GST" autocomplete="off" >
							<?php 
								$rs2="";
								$rs2=GetPageRecord('*','gstMaster',' 1 and serviceType="hotel" and status=1'); 
								while($gstSlabData=mysqli_fetch_array($rs2)){
									?>
								<option value="<?php echo $gstSlabData['id'];?>" <?php if($gstSlabData['id']==$editresult['gstTax']){ ?>selected="selected"<?php } ?> ><?php echo $gstSlabData['gstSlabName'];?>&nbsp;(<?php echo $gstSlabData['gstValue'];?>)</option>
								<?php
								}	
								?>
						</select>
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Adult&nbsp;Cost<span class="redmind"></span></div>
						<input type="text" name="adultCost2" id="adultCost2" class="gridfield validate" value="<?php echo $editresult['adultCost'] ?>" displayname="Adult Cost">
					</label>
				</div>
		
				<div class="griddiv">
					<label>
						<div class="gridlable">Child&nbsp;Cost</div>
						<input type="text" name="childCost2" id="childCost2" class="gridfield" value="<?php echo $editresult['childCost'] ?>" displayname="Child Cost">
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Infant&nbsp;Cost</span></div>
						<input type="text" name="infantCost2" id="infantCost2" class="gridfield" value="<?php echo $editresult['infantCost']; ?>" displayname="Infant Cost">
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">MarkUp&nbsp;Type<span class="redmind"></span></div>
						<select name="visaMarkup2" id="visaMarkup2" class="gridfield validate" >
							<option value="1" <?php if($editresult['markupType']==1){ ?> selected="selected" <?php } ?> >%</option>
							<option value="2" <?php if($editresult['markupType']==2){ ?> selected="selected" <?php } ?> >Flat</option>
						</select>
					</label>
				</div>
			
				<div class="griddiv">
					<label>
						<div class="gridlable">Processing&nbsp;Fee</div>
						<input type="text" name="processingFee2" id="processingFee2" class="gridfield" value="<?php echo $editresult['processingFee']; ?>" displayname="Processing Fee">
					</label>
				</div>
			
				<div class="griddiv">
					<label>  
						<div class="gridlable">Status</div>
						<select id="status2" name="status2" class="gridfield" displayname="Status" autocomplete="off" >  
							<option value="1" <?php if($editresult['status']==1){ ?> selected="selected" <?php } ?> >Active</option>
							<option value="0" <?php if($editresult['status']==0){ ?> selected="selected" <?php } ?> >In Active</option>
						</select>
					</label>
				</div>
			
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>

</div></div>

<script>
	$(document).ready(function() {  
	$('#toDate2').Zebra_DatePicker({ 
	  	format: 'd-m-Y',  
	}); 
	
	$('#fromDate2').Zebra_DatePicker({ 
	  	format: 'd-m-Y',  
		pair: $('#toDate')
	});  
});
</script>


<?php } ?>

<!-- Edit Passport cost end -->

<?php 
if($_GET['action']=='editGuidePorterPrice' && $_GET['tariffId']!=''){
	if($_GET['tariffId']!=''){
	$id=clean($_GET['tariffId']);
	$select1='*';
	$where1='id="'.$id.'"';
	$rs1=GetPageRecord($select1,'dmcGuidePorterRate',$where1);
	$editresult=mysqli_fetch_array($rs1);
	$aaaaaa=GetPageRecord('*',_GUIDE_SUB_CAT_MASTER_,' id="'.$editresult['serviceid'].'"');
	$subCatData=mysqli_fetch_array($aaaaaa);
	}
	?>
	<style>
	.addeditpagebox .griddiv .gridlable {
	  width: 100%;
	}
	</style>
	<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
	<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
	Mail Sent Successfully</div>
	<table border="0" align="center" cellpadding="0" cellspacing="0">
	    <tbody><tr>
	       <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
	    </tr>
	 </tbody></table>
	</div>
	<div id="sendmailfrm">
	<h1 style="text-align:left;">Update Guide/Porter Rate </h1>
	<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="editguideRate" target="actoinfrm"  id="editguideRate">
	 <input name="serviceid2" id="serviceid2" type="hidden" value="<?php echo $editresult['serviceid']; ?>" />
	 <input name="supplierId2" id="supplierId2" type="hidden" value="<?php echo $editresult['supplierId']; ?>" />
	 <input name="tariffId2" id="tariffId2" type="hidden" value="<?php echo $editresult['id']; ?>" />
	 <input name="action" id="action" type="hidden" value="editGuidePorterPrice" />
	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
	<select id="supplierId2" name="supplierId2"  displayname="Supplier Name" class="validate gridfield" autocomplete="off" >
	<?php
	$rs='';
	$rs=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and guideType=2  order by name asc');
	while($supplierData=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($supplierData['id']); ?>" <?php if($editresult['supplierId'] == strip($supplierData['id']) ){ echo "selected='selected'"; } ?> ><?php echo strip($supplierData['name']); ?></option>
	<?php } ?>
	</select>
	</label>
	</div>
	<!-- <div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Market Type<span class="redmind"></span></div>
	<select id="marketTypeId2" name="marketTypeId2" class="gridfield validate" displayname="Market Type" autocomplete="off"     >
	 <option value="">Select</option>
	  <?php
	$rs=GetPageRecord('*','marketMaster',' status=1 and deletestatus=0 order by name asc');
	while($resListing=mysqli_fetch_array($rs)){
	  ?>
	  <option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['marketType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	  <?php } ?>
	</select>
	</label>
	</div> -->

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Date</div>
	<input name="fromDate2" type="date" id="fromDate2"  class="gridfield calfieldicon validate"  displayname="Rate Valid From" value="<?php echo date('Y-m-d',strtotime($editresult['fromDate'])); ?>"  autocomplete="off"  style="width: 100%;" />
	</label>
	</div>
	  <div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">To Date</div>
	<input name="toDate2" type="date" id="toDate2"  class="gridfield calfieldicon validate"  displayname="Rate Valid To"   autocomplete="off" value="<?php echo date('Y-m-d',strtotime($editresult['toDate'])); ?>"  style="width: 100%;" />
	</label>
	</div>
		<?php if($subCatData['serviceType'] == "0"){ ?>
	<td width="100" align="left"  >
		<div class="griddiv">
			<label>
				<div class="gridlable">Pax&nbsp;Range<span class="redmind"></span></div>
				<select id="paxRange2" name="paxRange2" class="gridfield " autocomplete="off" >
					<option value="0">All</option> 
					<option value="1_5" >1-5 Pax</option> 
					<option value="6_14" >6-14 Pax</option> 
					<option value="15_40" >15-40 Pax</option> 
				</select> 
			</label>
		</div>			</td>
	<?php } ?> 
	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Day Type</div>
			<select id="dayType2" name="dayType2" class="gridfield" displayname="Day Type" autocomplete="off" >
			<option value="fullday" <?php if($editresult['dayType'] == 'fullday'){ ?> selected="selected" <?php } ?>>Full Day</option>
			<option value="halfday" <?php if($editresult['dayType'] == 'halfday'){ ?> selected="selected" <?php } ?>>Half Day</option>
			</select>
		</label>
		</div>
	<div class="griddiv">
		<label>
			<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Universal&nbsp;Cost<span class="redmind"></span></div>
		<select id="universalCost2" name="universalCost2" class="gridfield " autocomplete="off" onchange="showGuide(this.value);"  >
			<option value="0" <?php if($editresult['universalCost'] == '0'){ ?> selected="selected" <?php } ?>>Yes</option>
			<option value="1" <?php if($editresult['universalCost'] == '1'){ ?> selected="selected" <?php } ?>>No</option>
		</select>
		</label>
		</div>
	<div class="griddiv"  id="guidePorterDiv2" style="display:none;">
		<label>
			<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Select&nbsp;Guide/Porter<span class="redmind"></span></div>
		<select id="guidePorterId2" name="guidePorterId2" class="gridfield " autocomplete="off"   >
			<option value="">None</option>
			<?php
			$rs2=GetPageRecord('*',_GUIDE_MASTER_,' 1 and serviceType = "'.trim($subCatData['serviceType']).'" order by name asc');
			while($guideData=mysqli_fetch_array($rs2)){
			?>
			<option value="<?php echo $guideData['id']; ?>" ><?php echo $guideData['name'];?></option>
			<?php } ?>
		</select>
		</label>
		</div>
	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
	 <option value="">Select</option>
	<?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' deletestatus=0 and status=1 order by name asc';
	$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
	</select>
	</label>
	</div>
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Cost</div>
	<input name="price2" type="text" class="gridfield"  id="price2" onkeyup="numericFilter(this);" value="<?php echo $editresult['price']; ?>" maxlength="6"/>
	</label>
	</div>
	<div class="griddiv" style="display:none">
	      <label> </label>
	      <div style="color:#CC0000; margin:10px 0px; text-align:left;" id="div"></div>
	      <div class="gridlable">Remarks</div>
	      <input name="remarks2" type="text" class="gridfield"  id="remarks2" maxlength="200"   value="<?php echo $editresult['remarks']; ?>"/>
	    </div>
	<div class="griddiv"><label>
	    <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Status</div>
		<select id="status2" name="status2" class="gridfield " displayname="Status" autocomplete="off"   >
		<option value="1" <?php if($editresult['status']==1){ ?>selected="selected"<?php } ?>>Active</option>
		<option value="0" <?php if($editresult['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
		</select>
		</label>
		 </div>
	</form>
	</div>
	<div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	    <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('editguideRate','saveflight','0');" /></td>
	      <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
	    </tr>
	 </table>
	</div>
	</div></div>
	<script>
	showGuide(<?php echo $editresult['universalCost']; ?>);
	function showGuide(id){
	if(id == 1){
		$('#guidePorterDiv2').show();
	}else{
		$('#guidePorterId2').val('');
		$('#guidePorterDiv2').hide();
	}
	}
	</script>
	<?php 
} 

if($_GET['action']=='editDmcAirlineRate' && $_GET['tariffId']!=''){
	if($_GET['tariffId']!=''){
	$id=clean($_GET['tariffId']);
	$flightRateQuery2=GetPageRecord('*','dmcAirlineMasterRate','id="'.$id.'"');
	$flightRateData2=mysqli_fetch_array($flightRateQuery2);

	$flightQuery2=GetPageRecord('*',_PACKAGE_BUILDER_AIRLINES_MASTER_,' id="'.$flightRateData2['serviceId'].'"');
	$flightData2=mysqli_fetch_array($flightQuery2);
	}
	?>
	<style>
	.addeditpagebox .griddiv .gridlable {
	  width: 100%;
	}
	</style>
	<div class="contentclass">
	<div id="sendmailfrm">
	<h1 style="text-align:left;">Update Airline Rate </h1>

	<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="editDmcFlightRate" target="actoinfrm"  id="editDmcFlightRate">
	<input name="dmcServiceId2" id="dmcServiceId2" type="hidden" value="<?php echo $flightRateData2['serviceId']; ?>" />
	<input name="dmcSupplierId2" id="dmcSupplierId2" type="hidden" value="<?php echo $flightRateData2['supplierId']; ?>" />
	<input name="dmcTariffId2" id="dmcTariffId2" type="hidden" value="<?php echo $flightRateData2['id']; ?>" />
	<input name="action" id="action" type="hidden" value="editDmcAirlineRate" />
	<!-- 
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Date</div>
	<input name="fromDate2" type="date" id="fromDate2"  class="gridfield calfieldicon validate"  displayname="Rate Valid From" value="<?php echo date('Y-m-d',strtotime($flightRateData2['fromDate'])); ?>"  autocomplete="off"  style="width: 100%;" />
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">To Date</div>
	<input name="toDate2" type="date" id="toDate2"  class="gridfield calfieldicon validate"  displayname="Rate Valid To"   autocomplete="off" value="<?php echo date('Y-m-d',strtotime($flightRateData2['toDate'])); ?>"  style="width: 100%;" />
	</label>
	</div>
	-->

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Flight&nbsp;Number</div>
	<input name="dmcFlightNumber2" type="text" class="gridfield validate" displayname="Flight Number"  id="dmcFlightNumber2" onkeyup="numericFilter(this);" value="<?php echo $flightRateData2['flightNumber']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Flight&nbsp;Class</div>
	<select id="dmcFlightClass2" name="dmcFlightClass2" class="gridfield validate" displayname="Flight Class" autocomplete="off">
		<option value="First_Class" <?php if($flightRateData2['flightClass'] == 'First_Class') ?>>First Class</option>
		<option value="Business_Class" <?php if($flightRateData2['flightClass'] == 'Business_Class') ?>>Business Class</option>
		<option value="Economy_Class" <?php if($flightRateData2['flightClass'] == 'Economy_Class') ?>>Economy Class</option>
		<option value="Premium_Economy_Class" <?php if($flightRateData2['flightClass'] == 'Premium_Economy_Class') ?>>Premium Economy Class</option>
	</select>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="dmcCurrencyId2" name="dmcCurrencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
	<option value="">Select</option>
	<?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' deletestatus=0 and status=1 order by name asc';
	$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$flightRateData2['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
	</select>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Adult&nbsp;Cost</div>
	<input name="dmcAdultCost2" type="text" class="gridfield" displayname="Adult Cost" id="dmcAdultCost2" onkeyup="numericFilter(this);" value="<?php echo $flightRateData2['adultCost']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child&nbsp;Cost</div>
	<input name="dmcChildCost2" type="text" class="gridfield"  id="dmcChildCost2" onkeyup="numericFilter(this);" value="<?php echo $flightRateData2['childCost']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Infant&nbsp;Cost</div>
	<input name="dmcInfantCost2" type="text" class="gridfield"  id="dmcInfantCost2" onkeyup="numericFilter(this);" value="<?php echo $flightRateData2['infantCost']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Baggage&nbsp;Allowance</div>
	<input name="dmcBaggageAllowance2" type="text" class="gridfield"  id="dmcBaggageAllowance2" onkeyup="numericFilter(this);" value="<?php echo $flightRateData2['baggageAllowance']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv" >
	<label> </label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="div"></div>
	<div class="gridlable">Remarks</div>
	<input name="dmcRemarks2" type="text" class="gridfield"  id="dmcRemarks2" maxlength="200"   value="<?php echo $flightRateData2['remarks']; ?>"/>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status</div>
	<select id="dmcStatus2" name="dmcStatus2" class="gridfield " displayname="Status" autocomplete="off"   >
	<option value="1" <?php if($flightRateData2['status']==1 || $flightRateData2['status']!=0){ ?>selected="selected"<?php } ?>>Active</option>
	<option value="0" <?php if($flightRateData2['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
	</select>
	</label>
	</div>

	</form>
	</div>

	<div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveFlightRateBtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('editDmcFlightRate','saveFlightRateBtn','0');" /></td>
	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
	</tr>
	</table>
	</div>

	</div>
	</div>
	<?php 
} 

if($_GET['action']=='editDmcTrainRate' && $_GET['tariffId']!=''){
	if($_GET['tariffId']!=''){
	$id=clean($_GET['tariffId']);
	$trainRateQuery2=GetPageRecord('*','dmcTrainMasterRate','id="'.$id.'"');
	$trainRateData2=mysqli_fetch_array($trainRateQuery2);

	$trainQuery2=GetPageRecord('*',_PACKAGE_BUILDER_AIRLINES_MASTER_,' id="'.$trainRateData2['serviceId'].'"');
	$trainData2=mysqli_fetch_array($trainQuery2);
	}
	?>
	<style>
	.addeditpagebox .griddiv .gridlable {
	  width: 100%;
	}
	</style>
	<div class="contentclass">
	<div id="sendmailfrm">
	<h1 style="text-align:left;">Update Train Rate </h1>

	<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="editDmcTrainRate" target="actoinfrm"  id="editDmcTrainRate">
	<input name="dmcServiceId2" id="dmcServiceId2" type="hidden" value="<?php echo $trainRateData2['serviceId']; ?>" />
	<input name="dmcSupplierId2" id="dmcSupplierId2" type="hidden" value="<?php echo $trainRateData2['supplierId']; ?>" />
	<input name="dmcTariffId2" id="dmcTariffId2" type="hidden" value="<?php echo $trainRateData2['id']; ?>" />
	<input name="action" id="action" type="hidden" value="editDmcTrainRate" />
	<!-- 
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">From Date</div>
	<input name="fromDate2" type="date" id="fromDate2"  class="gridfield calfieldicon validate"  displayname="Rate Valid From" value="<?php echo date('Y-m-d',strtotime($trainRateData2['fromDate'])); ?>"  autocomplete="off"  style="width: 100%;" />
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">To Date</div>
	<input name="toDate2" type="date" id="toDate2"  class="gridfield calfieldicon validate"  displayname="Rate Valid To"   autocomplete="off" value="<?php echo date('Y-m-d',strtotime($trainRateData2['toDate'])); ?>"  style="width: 100%;" />
	</label>
	</div>
	-->

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Train&nbsp;Number</div>
	<input name="dmcTrainNumber2" type="text" class="gridfield validate" displayname="Train Number"  id="dmcTrainNumber2" value="<?php echo $trainRateData2['trainNumber']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
		<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Journey&nbsp;Type<span class="redmind"></span></div>
		<select id="dmcJourneyType2" name="dmcJourneyType2" class="gridfield validate" displayname="Journey Type" >  
			<option value="day_journey" <?php if($trainRateData2['journeyType']=='day_journey'){ ?>selected="selected"<?php } ?> >day_journey</option>
			<option value="overnight_journey" <?php if($trainRateData2['journeyType']=='overnight_journey'){ ?>selected="selected"<?php } ?> >overnight_journey</option>
		</select>
	</label>
	</div>			

	<div class="griddiv">
		<label>
			<div class="gridlable" style="width:100%;">Train&nbsp;Classes</div>
			<select id="dmcTrainClass2" name="dmcTrainClass2" class="gridfield validate" displayname="Train Class" autocomplete="off">
				<option value="AC First Class" <?php if($trainRateData2['trainClass']=='AC First Class'){ ?>selected="selected"<?php } ?>>AC First Class</option>
				<option value="AC 2-Tier" <?php if($trainRateData2['trainClass']=='AC 2-Tier'){ ?>selected="selected"<?php } ?>>AC 2-Tier</option>
				<option value="AC 3-Tier" <?php if($trainRateData2['trainClass']=='AC 3-Tier'){ ?>selected="selected"<?php } ?>>AC 3-Tier	</option>
				<option value="First Class" <?php if($trainRateData2['trainClass']=='First Class'){ ?>selected="selected"<?php } ?>>First Class	</option>
				<option value="AC Chair Car" <?php if($trainRateData2['trainClass']=='AC Chair Car'){ ?>selected="selected"<?php } ?>>AC Chair Car</option>
				<option value="Second Sitting" <?php if($trainRateData2['trainClass']=='Second Sitting'){ ?>selected="selected"<?php } ?>>Second Sitting</option>
				<option value="Sleeper" <?php if($trainRateData2['trainClass']=='Sleeper'){ ?>selected="selected"<?php } ?>>Sleeper</option>
			</select>
		</label> 
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Currency<span class="redmind"></span></div>
	<select id="dmcCurrencyId2" name="dmcCurrencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"     >
	<option value="">Select</option>
	<?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' deletestatus=0 and status=1 order by name asc';
	$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$trainRateData2['currencyId']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
	</select>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Adult&nbsp;Cost</div>
	<input name="dmcAdultCost2" type="text" class="gridfield" displayname="Adult Cost" id="dmcAdultCost2" onkeyup="numericFilter(this);" value="<?php echo $trainRateData2['adultCost']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Child&nbsp;Cost</div>
	<input name="dmcChildCost2" type="text" class="gridfield"  id="dmcChildCost2" onkeyup="numericFilter(this);" value="<?php echo $trainRateData2['childCost']; ?>" maxlength="6"/>
	</label>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Infant&nbsp;Cost</div>
	<input name="dmcInfantCost2" type="text" class="gridfield"  id="dmcInfantCost2" onkeyup="numericFilter(this);" value="<?php echo $trainRateData2['infantCost']; ?>" maxlength="6"/>
	</label>
	</div>
	<!-- 
	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Baggage&nbsp;Allowance</div>
	<input name="dmcBaggageAllowance2" type="text" class="gridfield"  id="dmcBaggageAllowance2" onkeyup="numericFilter(this);" value="<?php echo $trainRateData2['baggageAllowance']; ?>" maxlength="6"/>
	</label>
	</div>
	-->
	<div class="griddiv" >
	<label> </label>
	<div style="color:#CC0000; margin:10px 0px; text-align:left;" id="div"></div>
	<div class="gridlable">Remarks</div>
	<input name="dmcRemarks2" type="text" class="gridfield"  id="dmcRemarks2" maxlength="200"   value="<?php echo $trainRateData2['remarks']; ?>"/>
	</div>

	<div class="griddiv"><label>
	<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Status</div>
	<select id="dmcStatus2" name="dmcStatus2" class="gridfield " displayname="Status" autocomplete="off"   >
	<option value="1" <?php if($trainRateData2['status']==1 || $trainRateData2['status']!=0){ ?>selected="selected"<?php } ?>>Active</option>
	<option value="0" <?php if($trainRateData2['status']==0){ ?>selected="selected"<?php } ?>>In Active</option>
	</select>
	</label>
	</div>

	</form>
	</div>

	<div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveTrainRateBtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('editDmcTrainRate','saveTrainRateBtn','0');" /></td>
	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
	</tr>
	</table>
	</div>

	</div>
	</div>
	<?php 
} 

?>
<?php 
if($_GET['action']=='addnewititnery' && $_GET['queryId']!=''){
	$rs1=GetPageRecord('dayWise',_QUERY_MASTER_,'id='.$_GET['queryId'].'');
	$editresult=mysqli_fetch_array($rs1);
	$dayWise=$editresult['dayWise'];
	$namevalue ='queryId="'.$_REQUEST['queryId'].'",datetime="'.date('Y-m-d H:i:s').'",status="1"';
	$packageId = addlistinggetlastid(_PACKAGE_QUERY_ITINERARY_QUOTATION_,$namevalue);
	$itineraryId2=$packageId;
	?>
	<script src="js/jquery-1.11.3.min.js"></script>
	<script src="js/zebra_datepicker.js"></script>
	<script>
	$('#fromDate').Zebra_DatePicker({
	format: 'd-m-Y',
	direction: true,
	pair: $('#toDate')
	});
	$('#toDate').Zebra_DatePicker({
	format: 'd-m-Y',
	});
	</script>
	<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
	<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
	Mail Sent Successfully</div>
	<table border="0" align="center" cellpadding="0" cellspacing="0">
	  <tbody><tr>
	     <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
	  </tr>
	</tbody></table>
	</div>
	<div id="sendmailfrm">
	<h1 style="text-align:left;">Add Itinerary / Quotation</h1>
	<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
	<td colspan="5"><div id="loaddestinationitinerary"></div></td>
	</tr>
	<tr>
	<td colspan="5">&nbsp;</td>
	</tr>
	<tr>
	<?php if($dayWise==1){ ?>
	<td width="100"><input name="fromDate" type="text" id="fromDate" class="gridfield" displayname="From Travel Date" dateformat="d M y" autocomplete="off" value=""  style="height: 24px !important;padding-left: 5px; border: 1px solid #ccc !important; width: 125px;" placeholder="From Date" /></td>
	<?php } ?>
	<td <?php if($dayWise==2){ ?> width="200" <?php }else{ ?> width="100" <?php } ?> >
	<?php if($dayWise==1){ ?>
	<input name="toDate" type="text" id="toDate" class="gridfield" displayname="From Travel Date" autocomplete="off" value=""  style="height: 24px !important;padding-left: 5px; border: 1px solid #ccc !important; width: 125px;" placeholder="To Date" >
	<?php   } ?>
	<?php if($dayWise==2){ ?>
	<input name="night1" type="text" class="gridfield validate" id="night1"  style="width: 84px !important; padding: 6px; border-radius: 2px; float: right; margin-right: 24px;" maxlength="3" max="99" min="1"  displayname="Night" placeholder="Night" value="<?php  echo $night; ?>" onkeyup="changenights();" /><input name="fromDate" type="hidden" id="fromDateDayWise" class="gridfield" value="<?php echo date('Y-m-d'); ?>" /><input name="toDate" type="hidden" id="toDateDayWise" class="gridfield" value="" >
	<?php } ?>
	</td>
	<script>
	function changenights(){
	var night = Number($('#night1').val());
	var someDate = new Date($('#fromDateDayWise').val());
	someDate.setDate(someDate.getDate() + night);
	var dateFormated = someDate.toISOString().substr(0,10);
	var findate = dateFormated.split("-").reverse().join("-");
	$('#toDateDayWise').val(findate);
	}
	$(document).on("input", "#night1", function() {
	this.value = this.value.replace(/\D/g,''); });
	</script>
	<td width="100"><select name="cityId" size="1" class="gridfield select2 " id="cityIdquery" displayname="Hotel City" autocomplete="off" style="padding: 6px; border: 1px solid #ccc; ">
	  <option value="">Select Destination</option>
	  <?php
	$select='';
	$where='';
	$rs='';
	$select='*';
	$where=' deletestatus=0 and status=1 order by name asc';
	$rs=GetPageRecord($select,_DESTINATION_MASTER_,$where);
	$newdata = explode(',', $editresult['detinationCovered']);
	while($resListing=mysqli_fetch_array($rs)){
	?>
	  <option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
	  <?php } ?>
	</select></td>
	<td width="100"><select name="visaSatus" size="1" class="gridfield select2" id="visaSatus" autocomplete="off" style="padding: 6px; border: 1px solid #ccc; display:none; " >
	<option value="2">Visa No</option>
	<option value="1">Visa Yes</option>
	</select></td>
	<td width="100" valign="top"><input name="addnewuserbtn2" type="button" class="bluembutton submitbtn" id="addnewuserbtn2" value="+ Add City" onclick="addItineraryCity();" style="float:right;" /></td>
	</tr>
	<tr>
	<td colspan="5">&nbsp;</td>
	</tr>
	</table>
	<input name="action" type="hidden" id="action" value="addnewititnery" />
	<input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
	</form>
	<div id="actiondivsavedestination" style="display:none;"></div>
	<script>
	function loadalldest(id){
	$('#loaddestinationitinerary').load('loaditineraryDestination.php?itineraryId2='+id);
	}
	function addItineraryCity(){
	var cityId = $('#cityIdquery').val();
	var visaSatus = Number($('#visaSatus').val());
	<?php if($dayWise==1){ ?>
	var fromDate = $('#fromDate').val();
	var toDate = $('#toDate').val();
	var dates = fromDate;
	var dates1 = dates.split("-");
	var newDate = dates1[1]+"/"+dates1[0]+"/"+dates1[2];
	var fromDateTimestamp = new Date(newDate).getTime();
	<?php } ?>
	<?php if($dayWise==2){ ?>
	var fromDate = $('#fromDateDayWise').val();
	var toDate = $('#toDateDayWise').val();
	var dates = fromDate;
	var dates1 = dates.split("-");
	var newDate = dates1[1]+"/"+dates1[2]+"/"+dates1[0];
	var fromDateTimestamp = new Date(newDate).getTime();
	<?php } ?>
	var todates = toDate;
	var todates1 = todates.split("-");
	var tonewDate = todates1[1]+"/"+todates1[0]+"/"+todates1[2];
	var toDateTimestamp = new Date(tonewDate).getTime();
	var nights = Math.round((toDateTimestamp-fromDateTimestamp)/(1000*60*60*24));
	if(cityId!='' && cityId>0 && nights!='' && nights>0 && fromDate!='' && toDate!='') {
	$('#actiondivsavedestination').load('frmaction.php?cityId='+cityId+'&nights='+nights+'&fromDate='+fromDate+'&visaSatus='+visaSatus+'&toDate='+toDate+'&action=addqueryQuotationItinerary&packageId=<?php echo $itineraryId2; ?>');
	var newtoDate = $('#toDate').val();
	$('#fromDate').val(newtoDate);
	$('#toDate').val('');
	}else{
	alert('Please Fill All Fields..');
	}
	}
	loadalldest('<?php echo $itineraryId2; ?>');
	</script>
	</div>
	<div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	  <tr><td id="saveitibtn" style="display:none;" ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="masters_alertspopupopenClose();parent.makeitinerary('<?php echo $itineraryId2; ?>');" /></td>
	    <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
	  </tr>
	</table>
	</div>
	</div></div>
	<?php 
} ?>
<?php if($_GET['action']=='sendmailItineraryQuotation' && $_GET['ItineraryQuotationId']!='' && $_GET['queryId']!=''){
$select='guest1email';
$where='id='.$_GET['queryId'].'';
$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
$resultpage=mysqli_fetch_array($rs);
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Send Itinerary / Quotation</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Email <span class="redmind"></span></div>
	<input name="emailsender" type="text" class="gridfield validate" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off" value="<?php echo $resultpage['guest1email']; ?>" />
	</label>
 </div>
 <!--<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Itinerary<span class="redmind"></span></div>
		<select id="sendType" name="sendType" class="gridfield validate" displayname="Supplier" autocomplete="off"    >
		<option value="2">Quotation</option>
		<option value="1">Itinerary</option>
		</select>
	</label>
 </div>-->
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div>
 <input name="action" type="hidden" id="action" value="sendmailItineraryQuotation" />
 <input name="sendType" type="hidden" id="sendType" value="1" />
 <input name="ItineraryQuotationId" type="hidden" id="ItineraryQuotationId" value="<?php echo $_REQUEST['ItineraryQuotationId']; ?>" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php if($_GET['action']=='roominglist' && $_GET['queryId']!=''){
	$select='*';
	$where='id='.decode($_GET['queryId']).'';
	$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
	$resultpage=mysqli_fetch_array($rs);
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"  ');
	$resultpageQuotation=mysqli_fetch_array($rsp);

	?>
	<div class="contentclass">
	<h1 style="text-align:left; position:relative;"> Hotel&nbsp;Rooming&nbsp;List</h1>
	<div style="text-align:left;" id="finalquote"></div>
	<script>
	$('#finalquote').load('load_roominglist.php?queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	</script>
	<div style="overflow:hidden; margin-top:20px;">
	<input name="changestausidqueryid" type="hidden" id="changestausidqueryid" value="VFdwWk5VMTNQVDA9">
	<table border="0" align="right" cellpadding="5" cellspacing="0">
	<tbody><tr>
	<td>
	 <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();">
	</td>
	</tr>
	</tbody></table></div>
	</div>
<?php } ?>
<?php if($_GET['action']=='travelArrangement' && $_GET['queryId']!=''){
	$select='*';
	$where='id='.decode($_GET['queryId']).'';
	$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
	$resultpage=mysqli_fetch_array($rs);
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"  ');
	$resultpageQuotation=mysqli_fetch_array($rsp);
	?>
	<div class="contentclass">
	<h1 style="text-align:left; position:relative;"> Travel&nbsp;Arrangement&nbsp;List</h1>
	<div style="text-align:left;" id="finalquote"></div>
	<script>
	$('#finalquote').load('load_travelArrangement.php?queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	</script>
	<div style="overflow:hidden; margin-top:20px;">
	<input name="changestausidqueryid" type="hidden" id="changestausidqueryid" value="VFdwWk5VMTNQVDA9">
	<table border="0" align="right" cellpadding="5" cellspacing="0">
	<tbody><tr>
	<td>
	<input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();">
	</td>
	</tr>
	</tbody></table></div>
	</div>
<?php } ?>
<?php 
if($_GET['action']=='travelArrangementNew' && $_GET['queryId']!=''){
	$select='*';
	$where='id='.decode($_GET['queryId']).'';
	$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
	$resultpage=mysqli_fetch_array($rs);
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"  ');
	$resultpageQuotation=mysqli_fetch_array($rsp);
	$where1='queryId="'.decode($_GET['queryId']).'"';
	$rs1=GetPageRecord('*','guestList',$where1);
	$totGuest=mysqli_num_rows($rs1);
	?>
	<div class="contentclass">
	<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#828f8b" style="color:#ffffff; font-weight:500;">
	<tr>
	<td width="44%" align="left">Travel&nbsp;Arrangement&nbsp;List</td>
	<td width="40%" align="left">Total Guest <?php echo $totGuest; ?></td>
	<td width="16%" align="right"><i class="fa fa-times" style="padding: 5px; cursor: pointer;" onclick="alertspopupopenClose();"></i>&nbsp;&nbsp;</td>
	</tr>
	</table>
	<div id="successmsg" style=" display:none; color: #ffffff; font-size: 14px; background-color: #ff6a00; padding: 5px 100px; border-radius: 3px;">Sub Group is added successfully...</div>
	<div style="text-align:left;" id="finalquote"></div>
	<div style="margin-top:20px; border-bottom:2px dashed #ff8d00;" ></div>
	<div style="text-align:left; margin-top:10px;" id="loadAddedArrangement"></div>
	<div style="margin-top:20px; border-bottom:2px dashed #ff8d00;" ></div>
	<script>
	function loadTravelArrangementListfun(){
	$('#finalquote').load('loadTravelArrangementList.php?queryId=<?php echo $_GET['queryId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	}
	loadTravelArrangementListfun();
	function loadAddedArrangementfun(){
	$('#loadAddedArrangement').load('loadAddedArrangement.php?queryId=<?php echo $_GET['queryId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	}
	loadAddedArrangementfun();
	</script>
	<div style="overflow:hidden; margin-top:20px;">
	<table border="0" align="right" cellpadding="5" cellspacing="0">
	<tbody><tr>
	<td>
	 <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();">
	</td>
	</tr>
	</tbody></table></div>
	</div>
	<?php 
} ?>



<!-- expense entry code started -->
<?php 
if($_GET['action']=='expenseMaster' && $_GET['queryId']!=''){
	
	?>
	<script src="js/jquery-1.11.3.min.js"></script>

<script src="js/zebra_datepicker.js"></script>
	<style>
		.gridfield{
			padding:8px;
		}
	</style>
	<div class="contentclass">
	<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#828f8b" style="color:#ffffff;">
	<tr>
	<td width="44%" align="left" style="background-color:#668e9e;">Create New Expense</td>
	<!-- <td width="40%" align="left">Total Guest <?php echo $totGuest; ?></td> -->
	<td width="16%" align="right" style="background-color:#668e9e;"><i class="fa fa-times" style="padding: 5px; cursor: pointer;" onclick="alertspopupopenClose();"></i>&nbsp;&nbsp;</td>
	</tr>
	</table>
	<form action="frm_action.crm" method="post" name="addexpenses" id="addexpenses" target="actoinfrm">
	<table width="100%" cellpadding="5" cellspacing="0" style="padding-top: 15px;">
		<tr>
			<td align="left" style="width: 14%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Expense Date<span class="redmind"></span></div>
						<input type="text" name="expenseDate" class="gridfield validate calfieldicon" id="expenseDate" value="<?php echo date("d-m-Y"); ?>" displayname="Expense Date" style="width: 100px;">
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Expense Type</div>
						<select id="expenseType" name="expenseType" class="gridfield" displayname="Expense Type">
							<option value="">Select</option>
							<?php
						
							$where = ' deletestatus=0 and status=1 order by name asc';
							$rs = GetPageRecord('*', 'expenseTypeMaster',$where);
							while ($resListing = mysqli_fetch_array($rs)) {
							?>
								<option value="<?php echo strip($resListing['id']); ?>" <?php if ($resListing['id'] == $editcountryId) { ?>selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>

							<?php } ?>

						</select>
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Currency</div>
						<select name="CurrencyId" class="gridfield" id="CurrencyId" displanyname="Currency" style="width: 83px;">
								<?php
								
							$whereC = 'deletestatus=0 and status=1 order by name asc';
							$res1 = GetPageRecord('*', 'queryCurrencyMaster',$whereC);
							while ($Listing = mysqli_fetch_array($res1)) {
							?>
								<option value="<?php echo strip($Listing['id']); ?>" <?php if ($Listing['country'] == "101") { ?>selected="selected" <?php } ?>><?php echo strip($Listing['name']); ?></option>

								<?php
							}
								?>
						</select>
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Amount<span class="redmind"></span></div>
						<input type="text" name="expenseAmount" class="gridfield validate" id="expenseAmount" value="" style="width: 130px;" displayname="Amount">
					</label>
				</div>
			</td>
			<td align="left">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable" >Narration</div>
						<input type="text" name="expenseNarration" class="gridfield" id="expenseNarration" value="">
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Paid To</div>
						<input type="text" name="expensePaidTo" class="gridfield" id="expensePaidTo" value="">
					</label>
				</div>
			</td>
			
			<td align="left" style="width: 8%;">
			<input type="hidden" name="action" class="gridfield" id="action" value="addEdit_Expenses" >
			<input type="hidden" name="queryId" class="gridfield" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>">
			<input type="hidden" name="quotationId" class="gridfield" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable" style="text-align:center;padding-bottom: 6px;">Action</div>
						<input type="button" value="Save" class="submitbtn" onclick="formValidation('addexpenses','submitbtn','0');" style="padding: 5px 14px;border-radius: 5px;cursor:pointer; background:#7a96ff !important;color: #fff; font-size: 15px;">

					</label>
				</div>
			</td>
		</tr>
	</table>
</form>
	<div style="background-color: #668e9e; color: #ffffff; padding: 12px;text-align: center;margin-top:25px;"><h4>Expense List</h4></div>
	<div id="loadExpenseList" style="display:block;"></div>
	<script>
    function loadExpense(){
    
      $('#loadExpenseList').load('expensesList.php?action=loadExpenseList&quotationId=<?php echo $_REQUEST['quotationId']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>');

    }
	loadExpense();


			$('#expenseDate').Zebra_DatePicker({
				format: 'd-m-Y',
			});
	</script>
	<table border="0" align="right" cellpadding="5" cellspacing="0" style="margin-top: 20px;padding: 10px 0px;">
	<tr><td>
	 <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();">
	</td></tr>
	</table>
	</div>
	<?php 
} ?>
<!-- expense entry code ended -->

<!-- Update Expenses -->

<?php 
if($_GET['action']=='updateExpesesList' && $_GET['queryId']!='' && $_GET['expenseId']!=''){

	$expenseId = $_GET['expenseId'];
	$queryId = $_GET['queryId'];

	$res = GetPageRecord('*','quotationExpensesMaster','queryId="'.$queryId.'" and id="'.$expenseId.'"');
    $resListing=mysqli_fetch_assoc($res);

	$expenseDate = date("d-m-Y", strtotime($resListing['expenseDate']));

	?>
	<script src="js/jquery-1.11.3.min.js"></script>

<script src="js/zebra_datepicker.js"></script>
	<style>
		.gridfield{
			padding:8px;
		}
	</style>
	<div class="contentclass" id="updateExpense">
	<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#828f8b" style="color:#ffffff;">
	<tr>
	<td width="44%" align="left" style="background-color:#668e9e;">Update Expense</td>
	<!-- <td width="40%" align="left">Total Guest <?php echo $totGuest; ?></td> -->
	<td width="16%" align="right" style="background-color:#668e9e;"><i class="fa fa-times" style="padding: 5px; cursor: pointer;" onclick="hideExpense();"></i>&nbsp;&nbsp;</td>
	</tr>
	</table>
	<form action="frm_action.crm" method="post" name="addexpenses" id="addexpenses" target="actoinfrm">
	<table width="100%" cellpadding="5" cellspacing="0" style="padding-top: 15px;">
		<tr>
			<td align="left" style="width: 14%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Expense Date<span class="redmind"></span></div>
						<input type="text" name="expenseDate" class="gridfield validate calfieldicon" id="expenseDate" value="<?php echo $expenseDate; ?>" displayname="Expense Date" style="width: 100px;">
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Expense Type</div>
						<select id="expenseType" name="expenseType" class="gridfield" displayname="Expense Type">
							<option value="">Select</option>
							<?php
						
							$where = ' deletestatus=0 and status=1 order by name asc';
							$rs = GetPageRecord('*', 'expenseTypeMaster',$where);
							while ($Listing = mysqli_fetch_array($rs)) {
							?>
								<option value="<?php echo strip($Listing['id']); ?>" <?php if ($Listing['id'] == $resListing['expenseTypeId']){ ?> selected="selected" <?php } ?>><?php echo strip($Listing['name']); ?></option>
							<?php } ?>

						</select>
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Currency</div>
						<select name="CurrencyId" class="gridfield" id="CurrencyId" displanyname="Currency" style="width: 83px;">
								<?php
								
							$whereC = 'deletestatus=0 and status=1 order by name asc';
							$res1 = GetPageRecord('*', 'queryCurrencyMaster',$whereC);
							while ($List = mysqli_fetch_array($res1)) {
							?>
								<option value="<?php echo strip($List['id']); ?>" <?php if ($List['id'] == $resListing['currencyId']){ ?>selected="selected" <?php } ?>><?php echo strip($List['name']); ?></option>

								<?php
							}
								?>
						</select>
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Amount<span class="redmind"></span></div>
						<input type="text" name="expenseAmount" class="gridfield validate" id="expenseAmount" value="<?php echo $resListing['expenseAmount']; ?>" style="width: 130px;" displayname="Amount">
					</label>
				</div>
			</td>
			<td align="left">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable" >Narration</div>
						<input type="text" name="expenseNarration" class="gridfield" id="expenseNarration" value="<?php echo $resListing['remarks']; ?>">
					</label>
				</div>
			</td>
			<td align="left" style="width: 16%;">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable">Paid To</div>
						<input type="text" name="expensePaidTo" class="gridfield" id="expensePaidTo" value="<?php echo $resListing['paidTo']; ?>">
					</label>
				</div>
			</td>
			
			<td align="left" style="width: 8%;">
			<input type="hidden" name="action" class="gridfield" id="action" value="addEdit_Expenses">
			<input type="hidden" name="queryId" class="gridfield" id="queryId" value="<?php echo encode($queryId) ;?>">
			<input type="hidden" name="editId" class="gridfield" id="editId" value="<?php echo $expenseId ;?>">
				<div class="griddiv" >
    				<label>	
						<div class="gridlable" style="text-align:center;padding-bottom: 6px;">Action</div>
						<input type="button" value="Update" class="submitbtn" onclick="formValidation('addexpenses','submitbtn','0');" style="padding: 5px 14px;border-radius: 5px;cursor:pointer; background:#7a96ff !important;color: #fff; font-size: 15px;">

					</label>
				</div>
			</td>
		</tr>
	</table>
</form>

	<script>
			$('#expenseDate').Zebra_DatePicker({
				format: 'd-m-Y',
			});
	</script>
	<table border="0" align="right" cellpadding="5" cellspacing="0" style="margin-top: 20px;padding: 10px 0px;">
	<tr><td>
	 <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="hideExpense();">
	</td></tr>
	</table>
	</div>
	<script>
		function hideExpense(){
			// $("#updateExpense").hide();
			parent.alertspopupopen('action=expenseMaster&queryId=<?php echo encode($queryId); ?>','1000px','auto');
		}
		
	</script>
	<?php 
} 
?>


<!-- block starts -->
<?php if($_GET['action']=='selectItineraryType'  && $_GET['queryId']!=''){ 
	$rs="";
	$rs=GetPageRecord('*',_QUERY_MASTER_,' id = "'.$_GET['queryId'].'"'); 
	$queryData = mysqli_fetch_array($rs); 
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Select 
	<?php if($_REQUEST['moduleType'] == 1) { ?> Quotation  <?php } ?>
	<?php if($_REQUEST['moduleType'] == 2) { ?> Series<?php } ?>
	<?php if($_REQUEST['moduleType'] == 3) { ?> Fix&nbsp;Departure<?php } ?>	
	<?php if($_REQUEST['moduleType'] == 4) { ?> Package<?php } ?>	
	</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="makeQuotation" target="actoinfrm"  id="makeQuotation">

 <div class="griddiv">
 	<label>
 		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable" style="width: 100%;">Quotation&nbsp;Title<span class="redmind"></span></div>
		<input name="quotationSubject" placeholder="Subject" type="text" class="gridfield"  id="quotationSubject" value="<?php  if($queryData['subject']!=''){echo $queryData['subject'];}  ?>"  />
	</label>
 </div>

 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable"> Hotel&nbsp;Category&nbsp;Type 
	<span class="redmind"></span></div>
		<select id="quotationType" name="quotationType" class="gridfield validate" displayname="Quotation Type" autocomplete="off" onchange="selecthotelfun();<?php if($_REQUEST['moduleType'] == 1 ) { ?>loadsuggestedpackage();<?php } ?>">
		<?php //if($queryData['paxType'] != 1) { ?>
		<option value="1">Single Hotel Category</option>
		<?php //} ?>
		<option value="2">Multiple Hotel Category</option>
		</select>
	</label>
 </div>
 <div class="griddiv"><label>
	 <div style="color:#CC0000; margin:10px 0px; text-align:left;" id="addpaymentreqesmsg"></div>
		<div class="gridlable">Select Slab&nbsp;Type
		<span class="redmind"></span></div>
			<select id="slabAndRoomType" name="slabAndRoomType" class="gridfield validate" displayname="Quotation Type" autocomplete="off" >
			<option value="1">Single&nbsp; Slab</option>
			<option value="2">Multiple&nbsp; Slab</option>
			</select>
		</label>
	 </div>
 <?php if($_REQUEST['moduleType'] == 4 || $_REQUEST['moduleType'] == 1) { ?>
	 <div class="griddiv"><label>
		<div class="gridlable">Calculation&nbsp;Type<span class="redmind"></span></div>
			<select id="calculationType" name="calculationType" class="gridfield validate" displayname="Calculation Type" autocomplete="off" >
				<option value="1">Service Wise</option>
				<!-- <option value="2">Package Wise</option> -->
				<option value="3">Complete Package Wise</option>
				</select>
		</label>
	 </div>
	<?php } ?>
 <script>
 function selecthotelfun(){
 	var qt = $('#quotationType :selected').val();
	if(qt==2){
		$('#hotelCate').show();
	}else{
		$('#hotelCate').hide();
	}
 }
function validate_form(){
	valid = true;
	var qt = $('#quotationType :selected').val();
	if($('input[type=checkbox]:checked').length == 0 && qt==2)
	{
		alert ( "ERROR! Please select at least one Hotel Category..." );
		return false;
	}
}
 </script>
 <div class="griddiv" id="hotelCate" style="display:none;"><label>
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
	  <tr>
	  	<?php
	  	$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'deletestatus=0 and status=1 order by hotelCategory asc');
			while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){ ?>
			<td align="left"><input name="hotCategory[]" id="<?php echo $hotelCategoryData['id'];?>Star" type="checkbox" style="display:inline;margin:0;" value="<?php echo $hotelCategoryData['id'];?>" class="hotCategory" <?php if($_REQUEST['moduleType'] == 1) { ?>onchange="loadsuggestedpackage()" <?php } ?>/>&nbsp;<?php echo $hotelCategoryData['hotelCategory'];?> Star</td>
		<?php } ?>
	  </tr>
	</table>
	</label>
 </div>
 <!-- Package -->
 <?php if($_REQUEST['moduleType'] == 1 ) { ?> 
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable" style=" width: 100%;">Select Inbuilt Packages</div>
		<select id="packageId" name="packageId" class="gridfield " displayname="Package" autocomplete="off" >
		<option value="0">None</option>
		<?php 
		$rs="";
		$rs=GetPageRecord('*','quotationMaster','quotationType=1 and isPackage=1 and queryType=4 order by id asc');
		while($suggPackagList=mysqli_fetch_array($rs)){
		?>
		<option value="<?php echo $suggPackagList['id'];?>"><?php echo $suggPackagList['quotationSubject'];?></option>
		<?php } ?>
		</select>
	</label>
 </div>
  <script>
	function loadsuggestedpackage(){
		var quotationType=$('#quotationType').val();
		
		if(quotationType == 2){
			var hotCategory = [];
			$('.hotCategory:checked').each(function(i){
			  hotCategory[i] = $(this).val();
			}); 
		}else{
			var hotCategory = 0;
		}
		$('#packageId').load('loadsuggestedpackage.php?queryId=<?php echo $_GET['queryId']; ?>&quotationType='+quotationType+'&hotCategory='+hotCategory);
	}
	loadsuggestedpackage(); 
	</script>
 <?php } ?>
 

 <?php if($_REQUEST['moduleType'] == 2 || $_REQUEST['moduleType'] == 3) { 
	

	$roomrs = GetPageRecord('*','roomMaster','roomName="quadroom"');
	$roomQuad = mysqli_fetch_assoc($roomrs);
	
	$roomrs1 = GetPageRecord('*','roomMaster','roomName="sixbedroom"');
	$roomSix = mysqli_fetch_assoc($roomrs1);
	
	$roomrs2 = GetPageRecord('*','roomMaster','roomName="eightbedroom"');
	$roomEight = mysqli_fetch_assoc($roomrs2);
	
	$roomrs3 = GetPageRecord('*','roomMaster','roomName="tenbedroom"');
	$roomTen = mysqli_fetch_assoc($roomrs3);
	
	$roomrs4 = GetPageRecord('*','roomMaster','roomName="teenbed"');
	$roomTeen = mysqli_fetch_assoc($roomrs4);
	
	?>
	
 	<div class="griddiv"><label>
	<div class="gridlable" style="width: 100%;">Total&nbsp;PAX<span class="redmind"></span></div>
		<input name="totalpax" type="number" class="gridfield"  id="totalpax" value="" />
	</label>
 </div>
	
 <div class="griddiv"  >
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="25%">
<label>
<div class="gridlable" style="width:100%;">Single</div>
<input type="number" class="gridfield" id="newSingle" name="newSingle" value="" >
</label>
</td>
<td width="25%">
<label><div class="gridlable" style="width:100%;">Double</div>
<input type="number" class="gridfield" id="newDouble" name="newDouble" value="" >
</label>
</td>
<td width="25%">
<label>
<div class="gridlable" style="width:100%;">Twin</div>
<input type="number" class="gridfield" id="newTwin" name="newTwin" value="" >
</label>
</td>
<td width="25%">
<label>
<div class="gridlable" style="width:100%;">Triple</div>
<input type="number" class="gridfield" id="newTriple" name="newTriple" value="" >
</label>
</td>

 </tr>
 <tr>
 
<?php if($roomQuad['status']==1){ ?> 
 <td width="25%">
<label>
<div class="gridlable" style="width:100%;">Quad</div>
<input type="number" class="gridfield" id="newQuad" name="newQuad" value="" >
</label>
</td>
<?php } if($roomSix['status']==1){ ?>
	<td width="25%">
	<label>
		<div class="gridlable" style="width:100%;">SixBed</div>
		<input type="number" class="gridfield" id="newSixBed" name="newSixBed" value="" >
		</label>
	</td>
	<?php } if($roomEight['status']==1){ ?>
	<td width="25%">
	<label>
		<div class="gridlable" style="width:100%;">EightBed</div>
		<input type="number" class="gridfield" id="newEightBed" name="newEightBed" value="" >
		</label>
	</td>
	<?php } if($roomTen['status']==1){ ?>
	<td width="25%">
	<label>
		<div class="gridlable" style="width:100%;">TenBed</div>
		<input type="number" class="gridfield" id="newTenBed" name="newTenBed" value="" >
		</label>
	</td>
	<?php } ?>
 </tr>
 <tr>
 <td>
<label>
<div class="gridlable" style="width:100%;">EBed(Adult)</div>
<input type="number" class="gridfield" id="newEBedA" name="newEBedA" value="" >
</label>
</td>
<td>
<label>
<div class="gridlable" style="width:100%;">CWBed(Child)</div>
<input type="number" class="gridfield" id="newEBedC" name="newEBedC" value="" >
</label>
</td>
<td>
<label>
<div class="gridlable" style="width:100%;">CNBed(Child)</div>
<input type="number" class="gridfield" id="newENBedC" name="newENBedC" value="" >
</label>
</td>
<?php if($roomTeen['status']==1){ ?>

<td>
<label>
<div class="gridlable" style="width:100%;">Teen</div>
<input type="number" class="gridfield" id="newTeenRoom" name="newTeenRoom" value="" >
</label>
</td>
<?php } ?>
</tr> 
</table>
</div>
<?php } ?>

 <input name="action" type="hidden" id="" value="createmultiquotation" />
 <input name="qtype" type="hidden" id="qtype" value="<?php echo $queryData['queryType']; ?>" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value=" Save" onclick="formValidation('makeQuotation','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
</div>
<?php } ?>

<?php if($_GET['action']=='finalQuotation' && $_REQUEST['id']!='' && $_REQUEST['status']!=''){
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['id'].'"');
	$quotationData=mysqli_fetch_array($rsp);
	$rs=GetPageRecord('*',_QUERY_MASTER_,'id="'.$quotationData['queryId'].'"');
	$queryData=mysqli_fetch_array($rs);
	?>
	<div class="contentclass">
	<h1 style="text-align:left;">Final&nbsp;Quotation&nbsp;|&nbsp;<?php echo makeQueryId($queryData['id']).'-'.$quotationData['quotationNo']; ?></h1>
	<form action="loadalertbox.php" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
	     <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
	  		<table width="100%" border="0" cellpadding="5" cellspacing="0">
	  <tr>
	    <td align="left" valign="top" style="display:noned;">
		<table width="100%" border="0" cellpadding="5" cellspacing="0" style="font-size:12px;">
	      <tr>
		  <?php
			$hotCategory = explode(',',$quotationData['hotCategory']);
			foreach($hotCategory as $val2){ 
				$rsname1=GetPageRecord('*','hotelCategoryMaster','id='.$val2.'');
				$hotelCatData1=mysqli_fetch_array($rsname1);
			?>
		    <td><input name="finalcategory" type="radio" value="<?php echo $hotelCatData1['id']; ?>" style="display:block;" /></td>
	        <td><label for="finalcategory"><?php echo $hotelCatData1['hotelCategory']; ?>&nbsp;Star</label></td>
			<?php } ?>
	 		</tr>
	    </table>
		</td>
	    </tr>
	  <tr>
	    <td align="left" valign="top">
		 	<input name="quotationType" type="hidden" id="quotationType" value="2" />
	 		<input name="status" type="hidden" id="status" value="<?php echo $_REQUEST['status']; ?>" />
			<input name="action" type="hidden" id="action" value="chooseSupplimentServices" />
			<input name="queryid" type="hidden" id="queryid" value="<?php echo $quotationData['queryId']; ?>" />
			<input name="quotationId" type="hidden" id="quotationId" value="<?php echo $quotationData['id']; ?>" />
		  </td>
	  </tr>
	</table>
	  	</div>
	  </form>
	  	<div id="buttonsbox"  style="text-align:center;">
	 	<table border="0" align="center" cellpadding="0" cellspacing="0">
	      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value=" Save " onclick="chooseSupplimentServices();" /></td>
	        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
	      </tr>
	   </table>
	   <script type="text/javascript">
			function chooseSupplimentServices() { 
				var finalcategory = $("input[type='radio'][name='finalcategory']:checked").val();
	 		  	alertspopupopen('action=finalQuotation&status=1&action=chooseSupplimentServices&quotationType=2&finalcategory='+finalcategory+'&queryId=<?php echo $quotationData['queryId']; ?>&quotationId=<?php echo $quotationData['id']; ?>','800px','auto'); 
			}
			driverDetails();
		</script>
		</div>
	</div>
	<?php 
} 


if($_GET['action']=='selectCostSheet' && $_GET['quotationId']!=''){
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"');
	$quotationData=mysqli_fetch_array($rsp);
	$rs=GetPageRecord('*',_QUERY_MASTER_,'id="'.$quotationData['queryId'].'"');
	$queryData=mysqli_fetch_array($rs);
	?>
	<div class="contentclass">
		<h1 style="text-align:left;">Select&nbsp;CostSheet&nbsp;|&nbsp;<?php echo makeQueryId($queryData['id']).'-'.$quotationData['quotationNo']; ?></h1>
		<div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<table width="100%" border="0" cellpadding="5" cellspacing="0">
			  <tr>
			    <td align="left" valign="top" style="display:noned;">
				<table width="100%" border="0" cellpadding="5" cellspacing="0" style="font-size:12px;">
				  <?php
					$hotCategory = explode(',',$quotationData['hotCategory']);
					foreach($hotCategory as $val2){ 
						$rsname1=GetPageRecord('*','hotelCategoryMaster',' deletestatus=0 and status=1 and id="'.$val2.'" ');
						$hotelCatData1=mysqli_fetch_array($rsname1);
						?>
						<tr>
					    <td width="100%" align="center">
							<div onclick="alertspopupopen('action=addCostSheet&finalcategory=<?php echo $hotelCatData1['id']; ?>&quotationId=<?php echo $quotationData['id']; ?>','1300px','auto');" class="saveasbtn"  style="margin-right: 5px;float: none!important;" >
								<label style="color: #000; line-height: 24px; text-transform: uppercase;" for="finalcategory<?php echo $hotelCatData1['id']; ?>" ><?php echo $hotelCatData1['hotelCategory']; ?>&nbsp;Star&nbsp;Cost&nbsp;Sheet&nbsp;&nbsp;</label>
							</div></td>
				 		</tr>
					<?php } ?>
					<tr><td>&nbsp;</td></tr>
			    </table>
				</td>
			    </tr>
			</table>
	  </div>
	  <div id="buttonsbox"  style="text-align:center;">
	 		<table border="0" align="center" cellpadding="0" cellspacing="0">
	      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Save" onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
	        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
	      </tr>
	   	</table>
		</div>
	</div>
	<?php 
} 

?>

<?php
if($_REQUEST['action']=='addCostSheet' && $_REQUEST['quotationId']!=''){ 
	$rsp='';
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"');
	$quotationData=mysqli_fetch_array($rsp);
	$rs=GetPageRecord('*',_QUERY_MASTER_,'id="'.$quotationData['queryId'].'"');
	$queryData=mysqli_fetch_array($rs);
	?>
	<div class="contentclass" style="overflow:auto;" id="loadSingleCostBox"></div>
	<script>
	<?php 
	if($queryData['travelType']==2){
		$costsheetNM = '_domestic';
	}

	if($quotationData['quotationType']==2 && $_REQUEST['finalcategory']>0 ){ ?>
		$('#loadSingleCostBox').load('loadCostSheet<?php echo $costsheetNM; ?>.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>&finalcategory=<?php echo $_REQUEST['finalcategory']; ?>');
	<?php } else{  ?>
		$('#loadSingleCostBox').load('loadCostSheet<?php echo $costsheetNM; ?>.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>&finalcategory=0');
	<?php } ?>
	</script>
	<?php 
}  
  
if($_REQUEST['action']=='addFinalCostSheet' &&  $_REQUEST['quotationId']!=''  ){ ?>
	<div class="contentclass"  style="overflow:auto;"  id="loadSingleCostBox"></div>
	<script>
	$('#loadSingleCostBox').load('loadCostSheet.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>&finalcategory=0');
	</script>
	<?php 
}  

if($_REQUEST['action']=='addCostSheet_packagewise' &&  $_REQUEST['quotationId']!=''  ){ ?>
	<div class="contentclass"  style="overflow:auto;"  id="loadSingleCostBox"></div>
	<script>
	$('#loadSingleCostBox').load('loadPackageWiseCostSheet.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	</script>
	<?php 
}  
// Multiple services Cost Sheet
if($_REQUEST['action']=='addCostSheet_MultiServices' &&  $_REQUEST['quotationId']!=''  ){ ?>
	<div class="contentclass"  style="overflow:auto;"  id="loadSingleCostBox"></div>
	<script>
	$('#loadSingleCostBox').load('loadMultiServicesCostSheet.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	</script>
	<?php 
}  

if($_REQUEST['action']=='addCostSheet_completepackage' &&  $_REQUEST['quotationId']!=''  ){ ?>
	<div class="contentclass"  style="overflow:auto;"  id="loadSingleCostBox"></div>
	<script>
	$('#loadSingleCostBox').load('loadCompletePackageCostSheet.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>&package=<?php echo $_REQUEST['package']; ?>');
	</script>
	<?php 
}  


if($_REQUEST['action']=='addeDriverExcursionReport12' && $_REQUEST['id']!='' && $_REQUEST['serviceType']!=''){


	?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #ff860a !important;">Select Driver</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="id" id="id" type="hidden" value="<?php echo $_GET['id']; ?>" />
   <input name="serviceType" id="serviceType" type="hidden" value="<?php echo $_GET['serviceType']; ?>" />
   <input name="displayId" id="displayId" type="hidden" value="<?php echo $_GET['displayId']; ?>" />
   <input name="fromDate" id="fromDate" type="hidden" value="<?php echo $_GET['fromDate']; ?>" />
   <input name="toDate" id="toDate" type="hidden" value="<?php echo $_GET['toDate']; ?>" />
   <input name="quotationId" id="quotationId" type="hidden" value="<?php echo $_GET['quotationId']; ?>" />
    <input name="action" id="action" type="hidden" value="addeDriverExcursionReport" />
 <table width="100%" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td width="30%"><select id="driverId" name="driverId" class="gridfield" displayname="Driver" autocomplete="off" style="padding: 8px;width: 249px;" onchange="driverDetails()">
		<?php
		$rs=GetPageRecord('*',_DRIVER_MASTER_MASTER_,' 1 order by name');
		while($resultlists=mysqli_fetch_array($rs)){ ?>
	 <option value="<?php echo $resultlists['id']; ?>" <?php if($resultlists['id']==$_REQUEST['driverId']){ ?>selected="selected"<?php  } ?>><?php echo $resultlists['name']; ?></option>
	 <?php } ?>
</select></td>
<style type="text/css">
.addBtn {
    background-color: #cccccc5c!important;
    padding: 8px;
    color: bloack;
    border: 1px solid #8080806b;
}
</style>
    <td width="70%"><div style="font-size:12px; padding:0px;position:relative;width: 84px;">
	<div class="addBtn" onclick="alertspopupopen('action=addDrivertomaster&id=<?php echo $_REQUEST['id']; ?>&serviceType=transfer&fromDate=<?php echo $_REQUEST['fromDate']; ?>&toDate=<?php echo $_REQUEST['toDate']; ?>&driverId=<?php echo $_REQUEST['driverId']; ?>&displayId=<?php echo $_REQUEST['displayId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>','400px');" style=" right: 14px; top: 8px; ">+&nbsp;Add New</div>
	</div></td>
    </tr>
</table>
<div id="driverDetail" style="margin-top: 15px;"></div>
<script type="text/javascript">
	function driverDetails() {
	  var driverId = $('#driverId').val();
	  var displayId = $('#displayId').val();
	  var fromDate = $('#fromDate').val();
	  var toDate = $('#toDate').val();
	$("#driverDetail").load("driverdetails.php?driverId="+driverId+"&displayId="+displayId+"&fromDate="+fromDate+"&toDate="+toDate);
	}
	driverDetails();
</script>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save" onclick="formValidation('addflight','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>
<?php if($_GET['action']=='addDrivertomaster'){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #ff860a !important;">Add Driver</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
  <div class="griddiv"><label>
	<div class="gridlable">Driver Name<span class="redmind"></span></div>
	<input name="name" type="text" class="gridfield validate" id="name" displayname="Name" value="" maxlength="100" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Mobile No<span class="redmind"></span></div>
	<input name="mobileNo" type="text" class="gridfield validate" id="mobileNo" displayname="Mobile No" value="" maxlength="100" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Whatsapp No<span class="redmind"></span></div>
	<input name="whatappNo" type="text" class="gridfield validate" id="whatappNo" displayname="Whatsapp No" value="" maxlength="100" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Details<span class="redmind"></span></div>
	<textarea name="description" rows="3" class="gridfield " displayname="Details" id="description"></textarea>
	</label>
	</div>
    <input name="action" type="hidden" id="action" value="addedit_driver" />
    <input name="id" type="hidden" id="id" value="<?php echo $_REQUEST['id']; ?>" />
    <input name="serviceType" type="hidden" id="serviceType" value="<?php echo $_REQUEST['serviceType']; ?>" />
    <input name="fromDate" type="hidden" id="fromDate" value="<?php echo $_REQUEST['fromDate']; ?>" />
    <input name="toDate" type="hidden" id="toDate" value="<?php echo $_REQUEST['toDate']; ?>" />
    <input name="driverId" type="hidden" id="driverId" value="<?php echo $_REQUEST['driverId']; ?>" />
    <input name="quotationId" type="hidden" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>" />
    <input name="displayId" type="hidden" id="displayId" value="<?php echo $_REQUEST['displayId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save" onclick="formValidation('addflight','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Back To Driver" type="button" class="whitembutton" id="Cancel" value="Back To Driver" onclick="alertspopupopen('action=addeDriverExcursionReport12&id=<?php echo $_REQUEST['id']; ?>&serviceType=<?php echo $_REQUEST['serviceType']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&toDate=<?php echo $_REQUEST['toDate']; ?>&driverId=<?php echo $_REQUEST['driverId']; ?>&displayId=<?php echo $_REQUEST['displayId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>','800px','auto');" /></td>
      </tr>
   </table>
</div>
</div></div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>	
<?php if($_GET['action']=='addeDriverExcursionReport' && $_GET['id']!='' && $_GET['serviceType']!=''){

?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #ff860a !important;">Add Driver</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="id" id="id" type="hidden" value="<?php echo $_GET['id']; ?>" />
   <input name="serviceType" id="serviceType" type="hidden" value="<?php echo $_GET['serviceType']; ?>" />
    <input name="action" id="action" type="hidden" value="addeDriverExcursionReport" />
 <table width="100%" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td width="40%"><select id="driverId" name="driverId" class="gridfield" displayname="Driver" autocomplete="off" style="padding: 8px; width: 100%;" onchange="driverDetails('<?php echo $_GET['fromDate']; ?>')">
		<?php $rs=GetPageRecord('*',_DRIVER_MASTER_MASTER_,'1 order by name');
		while($resultlists=mysqli_fetch_array($rs)){ ?>
	 <option value="<?php echo $resultlists['id']; ?>" <?php if($resultlists['id']=='1'){ ?>selected="selected"<?php  } ?>><?php echo $resultlists['name']; ?></option>
	 <?php } ?>
</select></td>
    </tr>
</table>
<div id="driverDetail"></div>
<script type="text/javascript">
	function driverDetails(fromDate) {
	  var driverId = $('#driverId').val();
	$("#driverDetail").load("driverdetails.php?driverId="+driverId+"&fromdate="+fromDate);
	}
</script>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>
<?php if($_GET['action']=='addeVehicleExcursionReport12' && $_GET['id']!='' && $_GET['serviceType']!=''){
if($_GET['id']!=''){
$selecttime='*';
$wheretime=' transferQuoteId="'.$_GET['id'].'"';
$rstimet=GetPageRecord($selecttime,'quotationTransferTimelineDetails',$wheretime);
$dtime=mysqli_fetch_array($rstimet);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #45b558 !important;">Add P&D Time</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="padding: 16px;
    overflow: auto;
    text-align: left;
    border: 1px solid #80808052;
    margin-bottom: 24px;
    background-color: #8080800f;" >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile">
   <input name="transferQuoteId" id="transferQuoteId" type="hidden" value="<?php echo $_GET['id']; ?>" />
   <input name="fromDate" id="fromDate" type="hidden" value="<?php echo $_GET['fromDate']; ?>" />
   <input name="toDate" id="toDate" type="hidden" value="<?php echo $_GET['toDate']; ?>" />
    <input name="action" id="action" type="hidden" value="addVehicleExcursionReport" />
<table  width="100%" border="0" cellpadding="3" cellspacing="0">
				<thead>
				</thead>
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="13%">
						<div class="griddiv" style="position:static;color: #333333;">
						<label for="CityName" style="font-size:12px;"><strong>Arrival From</strong></label><br>
						<input name="CityName" type="text" class="gridfield" id="CityName" value="<?php echo $dtime['arrivalFrom']; ?>" >
						</div>
					</td>
					<td width="10%">
						<div class="griddiv" style="position:static;color: #333333;">
						<label for="CityName" style="font-size:12px;"><strong>Mode</strong></label><br>
						<select id="mode" name="mode" class="gridfield validate" displayname="Meal Plan" autocomplete="off" onchange="transferMode()">
						<option value="">Select Mode</option>
						<option value="Flight" selected="" <?php if ($dtime['mode'] == 'Flight') { echo ' selected="selected"';} ?>>Flight</option>
						<option value="Train" <?php if ($dtime['mode'] == 'Train') { echo ' selected="selected"';} ?>>Train</option>
						</select>
						</div>
					</td>
					<td width="15%">
						<div class="griddiv" id="flightName">
							<label for="flightName" style="font-size:12px;color: #333333;"><strong>Flight&nbsp; Name</strong></label><br>
 								<input name="flightName" type="text" class="gridfield" id="flightName" value="<?php echo $dtime['flightName']; ?>">
						</div>
						<div class="griddiv"  id="trainName" style="display: none;">
							<label for="flightName" style="font-size:12px;color: #333333;"><strong>Train&nbsp; Name</strong></label><br>
 								<input name="trainName" type="text" class="gridfield" id="trainName" value="<?php echo $dtime['trainName']; ?>">
						</div>
						<div class="griddiv" id="vehicleName" style="display: none;">
					</td>
					<td width="15%">
						<div class="griddiv"  id="flightNumber">
							<label for="flightName" style="font-size:12px;color: #333333;"><strong>Flight&nbsp; Number</strong></label><br>
 								<input name="flightNumber" type="text" class="gridfield" id="flightNumber" value="<?php echo $dtime['flightNumber']; ?>">
						</div>
						<div class="griddiv" style="display: none;" id="TrainNumber">
							<label for="flightName" style="font-size:12px;color: #333333;"><strong>Train&nbsp; Number</strong></label><br>
 								<input name="TrainNumber" type="text" class="gridfield" id="TrainNumber" value="<?php echo $dtime['trainNumber']; ?>">
						</div>
					</td>
					<td width="15%">
					 <div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Arrival&nbsp;Time</strong></label><br>
                       <input type="time" id="ArribleTime" name="ArribleTime" class="gridfield" value="<?php if(!empty($dtime['arrivalTime'])){ echo date('H:i:s',strtotime($dtime['arrivalTime'])); } ?>" min="10:00" max="18:00" >
                     </div>
                    </td>
                    <td width="15%"><div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Pick Up&nbsp;Time</strong></label><br>
                       <input type="time" name="pickupTime"class="gridfield" value="<?php if(!empty($dtime['pickupTime'])){ echo date('H:i:s',strtotime($dtime['pickupTime'])); } ?>" min="10:00" max="18:00" >
                       </div>
                    </td>
                    <td width="15%"><div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Drop&nbsp;Time</strong></label><br>
                       <input type="time" name="dropTime" class="gridfield" value="<?php if(!empty($dtime['dropTime'])){ echo date('H:i:s',strtotime($dtime['dropTime'])); } ?>" min="10:00" max="18:00" >
                       </div>
                    </td>
					<td >
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
  					</td>
					  
                    <script type="text/javascript">
                    	function transferMode()
                    	{
                    		var mode = $('#mode').val();
                    		if (mode == 'train') {
                    		   $('#trainName').show();
                    		   $('#TrainNumber').show();
                    		   $('#flightName').hide();
                    		   $('#flightNumber').hide();
                    		}
                    		if (mode == 'flight') {
                    		   $('#flightName').show();
                    		   $('#flightNumber').show();
                    		   $('#trainName').hide();
                    		   $('#TrainNumber').hide();
                    		}
                    	}
                    </script>
			  	</tr>
				</tbody>
			</table>
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>
<?php if($_GET['action']=='addeVehicleAllocation' && $_GET['id']!='' && $_GET['serviceType']!=''){
if($_GET['modelId']!=''){
  $selveh='id,model';
  $whereveh='id="'.$_GET['modelId'].'"';
  $rsveh=GetPageRecord($selveh,_VEHICLE_MASTER_MASTER_,$whereveh);
  $vehicalname=mysqli_fetch_array($rsveh);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #2bb0dd!important;">Select Vehicle</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile">
   <input name="transferQuoteId" id="transferQuoteId" type="hidden" value="<?php echo $_GET['id']; ?>" />
   <input name="fromDate" id="fromDate" type="hidden" value="<?php echo $_GET['qfromDate']; ?>" />
   <input name="toDate" id="toDate" type="hidden" value="<?php echo $_GET['qtoDate']; ?>" />
   <input name="fromDate1" id="fromDate1" type="hidden" value="<?php echo $_GET['fromDate']; ?>" />
   <input name="toDate1" id="toDate1" type="hidden" value="<?php echo $_GET['toDate']; ?>" />
   <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
    <input name="action" id="action" type="hidden" value="selectModeltransfer" />
<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
   <tr>
   	  <td width="30%">
   	  	 <select id="vehicleId" name="vehicleId" class="gridfield" displayname="Driver" autocomplete="off" style="padding: 8px;width: 249px;" onchange="vehicleDetails()">
		<?php
		$selvehd='*';
          $wherevehd='1 order by id desc';
           $rsvehd=GetPageRecord($selvehd,_VEHICLE_MASTER_MASTER_,$wherevehd);
            while ($vehicalnamed=mysqli_fetch_array($rsvehd)) {?>
	         <option value="<?php echo $vehicalnamed['id']; ?>,vehicle" <?php if($vehicalnamed['id']==$vehicalname['id']){ ?>selected="selected"<?php  } ?>><?php echo $vehicalnamed['model']; ?></option>
	     <?php } ?>
        </select>
   	  </td>
<style type="text/css">
.addBtn {
    background-color: #cccccc5c!important;
    padding: 8px;
    color: bloack;
    border: 1px solid #8080806b;
}
</style>
   	   <td width="70%"><div style="font-size:12px; padding:0px;position:relative;width: 84px;">
	<div class="addBtn" onclick="alertspopupopen('action=addVehicletomaster&id=<?php echo $_REQUEST['id']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&toDate=<?php echo $_REQUEST['toDate']; ?>&modelId=<?php echo $_REQUEST['modelId']; ?>&displayId=<?php echo $_REQUEST['queryId']; ?>&qfromDate=<?php echo $_REQUEST['qfromDate']; ?>&qtoDate=<?php echo $_REQUEST['qtoDate']; ?>&serviceType=transfer','400px');" style=" right: 14px; top: 8px; ">+&nbsp;Add New</div>
	</div></td>
   </tr>   
</table>
<div id="vehicleDetail" style="margin-top: 15px;"></div>
</div>
</div>
<script>
	function vehicleDetails(){
	  var vehicleId = $('#vehicleId').val();
	  var queryId = $('#queryId').val();
	  var fromDate = $('#fromDate').val();
	  var toDate = $('#toDate').val();
	  $("#vehicleDetail").load("vehicledetails.php?vehicleId="+vehicleId+"&queryId="+queryId+"&fromDate="+fromDate+"&toDate="+toDate);
	}
	vehicleDetails();
	</script>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Select" onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>
<?php if($_GET['action']=='addVehicletomaster' && $_GET['id']!='' && $_GET['serviceType']!=''){
if($_GET['modelId']!=''){
  $selveh='id,model';
  $whereveh='id="'.$_GET['modelId'].'"';
  $rsveh=GetPageRecord($selveh,_VEHICLE_MASTER_MASTER_,$whereveh);
  $vehicalname=mysqli_fetch_array($rsveh);
}
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #2bb0dd!important">Add Vehicle</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile">
 <input type="hidden" name="action" id="action" value="addedit_vehicle">
 <input type="hidden" name="transferQuoteId" id="transferQuoteId" value="<?php echo $_REQUEST['id']; ?>">	
 <input type="hidden" name="fromDate" id="fromDate" value="<?php echo $_REQUEST['fromDate']; ?>">	
 <input type="hidden" name="toDate" id="toDate" value="<?php echo $_REQUEST['toDate']; ?>">	
 <input type="hidden" name="modelId" id="modelId" value="<?php echo $_REQUEST['modelId']; ?>">	
 <input type="hidden" name="displayId" id="displayId" value="<?php echo $_REQUEST['displayId']; ?>">	
 <input type="hidden" name="qfromDate" id="qfromDate" value="<?php echo $_REQUEST['qfromDate']; ?>">	
 <input type="hidden" name="qtoDate" id="qtoDate" value="<?php echo $_REQUEST['qtoDate']; ?>">
 <input type="hidden" name="serviceType" id="serviceType" value="<?php echo $_REQUEST['serviceType']; ?>">	
  <div class="griddiv" style="display: none;"><label>
	<div class="gridlable">Vehicle Type   </div>
	<select id="vehicleType" name="vehicleType" class="gridfield " displayname="Title" autocomplete="off">  
		<?php    
	$rs=GetPageRecord('name,id','vehicleTypeMaster',' 1 order by name asc'); 
	while($resListing=mysqli_fetch_array($rs)){  
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($vehicleType==strip($editresult['carType'])){ ?> selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
</select>
	</label>
	</div>
	<div class="griddiv" style="display: none;">
	<label>
	<div class="gridlable">Brand Name<span class="redmind"></span></div>
	<select id="brand" name="brand" class="gridfield " displayname="Title" autocomplete="off">
	<option value="">None</option>
	<?php 
	$select=''; 
	$where=''; 
	$rs='';  
	$select='*';    
	$where=' name!="" and deletestatus=0 and status=1 order by id asc';  
	$rs=GetPageRecord($select,_VEHICLE_BRAND_MASTER_,$where); 
	while($resListing=mysqli_fetch_array($rs)){  
	?>
	<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$editresult['brand']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
	<?php } ?>
		</select></label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Vehicle Name</div>
	<input name="model" type="text" class="gridfield validate" id="model" value="" displayname="Vehicle Name" maxlength="100">
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Registration No</div>
	<input name="registrationNo" type="text" class="gridfield validate" id="registrationNo" value="" displayname="Registration No" maxlength="100">
	</label>
	</div>
</div>
</div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save" onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Back To Vehicle" onclick="alertspopupopen('action=addeVehicleAllocation&id=<?php echo $_REQUEST['id']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&toDate=<?php echo $_REQUEST['toDate']; ?>&modelId=<?php echo $_REQUEST['modelId']; ?>&displayId=<?php echo $_REQUEST['displayId']; ?>&qfromDate=<?php echo $_REQUEST['qfromDate']; ?>&qtoDate=<?php echo $_REQUEST['qtoDate']; ?>&serviceType=transfer','800px');" /></td>
      </tr>
   </table>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>
<?php
if(trim($_REQUEST['action'])=='addtransferMode'){ ?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Select Mode</span>
		<i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer;" onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_transferMode2" target="actoinfrm" id="add_transferMode2">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody> <?php
				$modeSql=GetPageRecord('*','modemaster',' 1 order by name');
				$modeData=mysqli_fetch_array($modeSql);
				?>
				<tr style="background-color:transparent !important;">
					<td width="30" align="left">
						<div class="griddiv labelbox">
							<input name="mode" type="radio" id="surface" value="surface" <?php if($modeData['name'] == 'surface'){ echo "checked";} ?> >
							<label class="label" for="surface">Surface</label>
						</div>
					</td>
					<td width="30" align="left">
						<div class="griddiv labelbox">
							<input name="mode" type="radio" id="train" value="train" <?php if($modeData['name'] == 'train'){ echo "checked";} ?> >
							<label class="label" for="train">Train</label>
						</div>
					</td>
					<td width="30" align="left">
						<div class="griddiv labelbox">
							<input name="mode" type="radio" id="flight" value="flight" <?php if($modeData['name'] == 'flight'){ echo "checked";} ?> >
							<label class="label" for="flight">Flight</label>
						</div>
					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td  align="right" colspan="3" style="    border-bottom: #ffffff 1px solid;">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_transferMode2','submitbtn','0');">
 						<input name="action" type="hidden" id="action" value="add_transferMode2">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>
	<style>
	.labelbox{
	    border-radius: 5px;
		border: 1px solid;
		overflow: hidden;
	    border-bottom: 3px #7a96ff solid!important;
		text-align: center;
	}
	.labelbox input + .label {
		color: #000!important;
		background-color: #fff;
	}
	.labelbox input:checked + .label {
		color: #fff!important;
		background-color: #233a49;
	}
	.labelbox input{
		position: absolute;
    	visibility: hidden;
	}
	.labelbox .label {
		display: inline-block;
		max-width: 100%;
		width: 100%;
		font-size: 12px;
		height: 20px;
		padding: 7px 0 0;
	}
	</style>
	<?php
}
	?>
<?php if($_GET['action']=='addeAmendmentExcursionReport' && $_GET['id']!=''){

?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #ff860a !important;">Add Amendment</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <input name="id" id="id" type="hidden" value="<?php echo $_GET['id']; ?>" />
   <input name="serviceType" id="serviceType" type="hidden" value="<?php echo $_GET['serviceType']; ?>" />
    <input name="action" id="action" type="hidden" value="addeDriverExcursionReport" />
    <table width="100%" border="0" cellspacing="0" cellpadding="5" style=" border-bottom:1px solid #ccc;">
	      <tr>
        <td colspan="3"><input name="staff" type="text" class="gridfield"  id="staff" value="" style="width: 100%; padding: 5px; border-radius: 3px;" placeholder="Staff" /></td>
        <td width="1%" align="center" valign="middle">&nbsp;</td>
        <td width="7%" rowspan="2" align="center" valign="middle"><div style="padding: 0px 10px; font-size: 34px; font-weight: 400; cursor: pointer;">+</div></td>
      </tr>
      <tr>
        <td colspan="3"><textarea name="amendment" id="amendment" style="width: 100%; padding: 5px; border-radius: 3px;">Amendment</textarea></td>
        <td>&nbsp;</td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
</form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    " onclick="formValidation('addflight','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>
<?php
if($_GET['action']=='addedittask'){ ?>
<div class="contentclass">
<h1 style="text-align:left;"><?php if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?> Task</h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
 <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" valign="top">
    <div class="griddiv">
    	<label>
	<div class="gridlable">Task Name<span class="redmind"></span></div>
	<input name="taskName" type="text" class="gridfield validate" id="taskName" displayname="task Name" value="" maxlength="100" />
	</label>
	</div>
	 </td>
  </tr>
</table>
 <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
	  <input name="action" type="hidden" id="action" value="<?php if($_REQUEST['id']!=''){ echo 'edittask'; } else { echo 'addtask'; } ?>" />
	  <input name="sectionType" type="hidden" id="sectionType" value="<?php echo $_REQUEST['sectionType']; ?>" />
</form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
<?php }
 if($_GET['action']=='changetodolidtstatus' && $_GET['queryId']!='' && $_GET['editstatusid']!=''){ ?>
	<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Select Status </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <div style="padding:20px;">
<a onclick="editstatusloadtodolistfun(<?php echo $_REQUEST['editstatusid']; ?>,1);">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">Pending</div></a>
<a  onclick="editstatusloadtodolistfun(<?php echo $_REQUEST['editstatusid']; ?>,2);">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">In Process</div></a>
<a>
<a  onclick="editstatusloadtodolistfun(<?php echo $_REQUEST['editstatusid']; ?>,3);">
<div class="addguestbutton" style="margin: 0px; padding: 10px; font-size: 16px; margin-bottom:5px;">DONE</div>
</a>
  </div>
 <input name="adddmcpaymenttopaymentrequest" type="hidden" id="adddmcpaymenttopaymentrequest" value="1" />
 <input name="queryId" type="hidden" id="queryId" value="<?php echo $_GET['queryId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  > </td>
        <td style="padding-right:20px;"><input name="Cancel2" type="button" class="whitembutton" id="Cancel2" value="Close" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php }
if($_GET['action']=='createliveSupplierVoucher' && $_GET['qid']!='' && $_GET['queryId']!=''){   ?>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="contentclass"><span style="float:right;"><input name="Cancel" type="button" style="background-color: #cccccc !important; border-radius: 3px; padding: 4px; margin: 2px;  " id="Cancel" value="Close" onclick="alertspopupopenClose();" /> </span>
<h1 style="text-align:left;">Suppplier Voucher</h1>
  <div id="loadcreateitinerary"  style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >Loading...</div>
  <script>
  $('#loadcreateitinerary').load('loadcreateSupplierVoucher.php?queryId=<?php echo $_REQUEST['queryId']; ?>&qid=<?php echo $_REQUEST['qid']; ?>');
  </script>
  <div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
  </tr>
</table>
</div>
</div>
</form>
<?php }	?>
<?php if($_REQUEST['action']=='serviceUpdatePayment' && $_REQUEST['scheduleId']!=''){
	$r21=GetPageRecord('*','supplierSchedulePaymentMaster','id="'.$_REQUEST['scheduleId'].'"');
	$scheduleData = mysqli_fetch_array($r21);
	$r3=GetPageRecord('*','supplierPaymentMaster',' scheduleId="'.$scheduleData['id'].'" and paymentStatus=1');
	$paymentData = mysqli_fetch_array($r3);
	$fianlSuppQuery=GetPageRecord('*','finalQuotSupplierStatus',' id="'.$scheduleData['supplierStatusId'].'"'); 
	$supplierStatusData=mysqli_fetch_array($fianlSuppQuery);
	$b="";
	$b=GetPageRecord('*',_SUPPLIERS_MASTER_,'id="'.$supplierStatusData['supplierId'].'"');
	$suppData=mysqli_fetch_array($b);

	$bb=GetPageRecord('sum(amount) as paidamount','supplierPaymentMaster','supplierStatusId="'.$scheduleData['supplierStatusId'].'"');
	$supppaid=mysqli_fetch_array($bb);
	
	$dueAmount = $supplierStatusData['totalSupplierCost']-$supppaid['paidamount'];
	?>
	<script type="text/javascript">
	$(document).ready(function() {
       $('#paymentDate').Zebra_DatePicker({
        format: 'd-m-Y',
    });
  });
</script>
	<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
			<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />Mail Sent Successfully</div>
			<table border="0" align="center" cellpadding="0" cellspacing="0">
			   <tbody>
			   <tr>
					 <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
				  </tr>
			   </tbody>
			</table>
		</div>
		<div id="sendmailfrm">
			<h1 style="text-align:left;">Update Payment  </h1>
			<div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<form action="loadSave_SupplierPayment.php" method="post" enctype="multipart/form-data" name="loadSave_SupplierPayment" target="actoinfrm"  id="loadSave_SupplierPayment">
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Supplier&nbsp;Name<span class="redmind"></span></div>
					<input type="text" class="gridfield" value="<?php echo $suppData['name']; ?>"  maxlength="20"  displayname="Supplier Name" disabled  />
				</label>
			</div>
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Payment Type <span class="redmind"></span></div>
					<select id="paymentType" name="paymentType" class="gridfield" autocomplete="off" onchange="paymentBySet(this.value);" >
					<option value="1" <?php if($scheduleData['paymentType'] == 1){ ?> selected="selected" <?php } ?>>On Credit</option>
					<option value="2" <?php if($scheduleData['paymentType'] == 2){ ?> selected="selected" <?php } ?>>Advanced Payment</option>
					<option value="3" <?php if($scheduleData['paymentType'] == 3){ ?> selected="selected" <?php } ?>>Direct&nbsp;Payment</option>
					<option value="0" <?php if($scheduleData['paymentType'] == 0){ ?> selected="selected" <?php } ?>>Full Payment</option>
					</select>
				</label>
			</div>
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Due Amount <span class="redmind"></span></div>
					<input onKeyUp="numericFilter(this);" name="dueAmount" type="text" class="gridfield validate" id="dueAmount" value="<?php echo round($dueAmount); ?>" cursor="not-allowed" readonly  maxlength="20"  displayname="Payment Amount"  />
				</label>
			</div>
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Payable Amount <span class="redmind"></span></div>
					<input onKeyUp="numericFilter(this);" name="amount" type="text" class="gridfield validate" id="amount" value="<?php echo round($scheduleData['amount']); ?>"  maxlength="20"  displayname="Payment Amount"  />
				</label>
			</div>
			<div class="griddiv" id="paymentBydiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Payment Info</div>
					<select id="paymentBy" name="paymentBy" class="gridfield" displayname="Payment Through" autocomplete="off">
						<option value="NEFT">NEFT</option>
						<option value="IMPS">IMPS</option>
						<option value="Credit Card">Credit Card</option>
						<option value="Payment">Payment</option>
						<option value="Google Pay">Google Pay</option>
						<option value="Paytm">Paytm</option>
						<option value="EBS">EBS</option>
						<option value="Cash">Cash</option>
						<option value="Paid at Resort">Paid at Resort</option>
						<option value="Paid at RMR Office">Paid at RMR Office</option>
						<option value="Others">Others</option>
						
					</select>
				</label>
			</div>
		    <div class="griddiv" id="boxpaymentdiv">
				<table width="100%" >
					<tr>
						<td width="49%" ><label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable" style="width: 36%;">Payment By</div>
					<input  name="paymentBy" type="text" class="gridfield " id="paymentBy" value="<?php echo $scheduleData['paymentBy']; ?>"  maxlength="20"  displayname="Payment By"    />
				</label></td>
				<td width="1%" ></td>
						<td width="50%" ><label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable" style="width: 41%;">Payment Date</div>
					<input name="paymentDate" type="text" id="paymentDate" placeholder="Payment Date"  style="padding:10px; border:1px  #CCCCCC solid;     width: 227px !important; box-sizing:border-box;"   class="textfieldsup calfieldicon"  displayname="Payment Date"   autocomplete="off" value="<?php if(!empty($paymentData['paymentDate'])){ echo date('d-m-Y',strtotime($paymentData['paymentDate'])); }else{ echo date('d-m-Y'); } ?>"/>
				</label></td>
					</tr>
				</table>
			</div>
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Attachement</div>
				<input  name="fileUpload" type="file" class="gridfield " id="fileUpload" value="<?php echo $scheduleData['paidBy']; ?>"  maxlength="20"  displayname="Attachement"/>
				</label>
			</div>
			<div class="griddiv"><label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Description</div>
				<textarea name="details" rows="3" class="gridfield" id="details" displayname="Email Subject" field_min_length="6"></textarea>
				</label>
			</div>
			<input name="action" type="hidden"  value="serviceUpdatePayment" />
			<input type="hidden"  name="scheduleId"  id="scheduleId" value="<?php echo $scheduleData['id']; ?>" />
			<input type="hidden"  name="lastscheduleId"  id="lastscheduleId" value="<?php echo $_REQUEST['lastscheduleId']; ?>" />
			<input type="hidden"  name="lastscheduleamount"  id="lastscheduleamount" value="<?php echo $_REQUEST['lastscheduleamount']; ?>" />
	  	</form>
		</div>
			<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
			<tr><td>
			<input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('loadSave_SupplierPayment','submitbtn','0');" /></td>
			<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
			</tr>
			</table>
		</div>
		</div>
		<script>
		function paymentBySet(val){
			if(val==1){
				document.getElementById("paymentBydiv").style.display = 'none';
 			}else{
				document.getElementById("paymentBydiv").style.display = 'block';
			}
		}
		</script>
	</div>
	<?php 
} 
?>
<?php if($_REQUEST['action']=='agentUpdatePayment' && $_REQUEST['scheduleId']!=''){
	$r21=GetPageRecord('*','agentSchedulePaymentMaster','id="'.$_REQUEST['scheduleId'].'"');
	$scheduleData = mysqli_fetch_array($r21);
	$fianlSuppQuery=GetPageRecord('*',_PAYMENT_REQUEST_MASTER_,' id="'.$scheduleData['paymentId'].'" ');
	$paymentRequestData=mysqli_fetch_array($fianlSuppQuery);


	$quotQuery='';    
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id='.clean($paymentRequestData['quotationId']).''); 
	$quoutData=mysqli_fetch_array($quotQuery);
	$currencyName = getCurrencyName($quoutData['currencyId']); 
	$quotationId = $quoutData['id'];
	$currencyId = ($quoutData['currencyId'])>0 ? $quoutData['currencyId']:$baseCurrencyId;

	$queryQuery='';    
	$queryQuery=GetPageRecord('*',_QUERY_MASTER_,'id='.clean($paymentRequestData['queryid']).''); 
	$queryData=mysqli_fetch_array($queryQuery); 


	$queryId = $queryData['id'];
	$companyName = showClientTypeUserName($queryData['clientType'],$queryData['companyId']);
	?>
	<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
			<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />Mail Sent Successfully</div>
			<table border="0" align="center" cellpadding="0" cellspacing="0">
			   <tbody>
			   <tr>
					 <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
				  </tr>
			   </tbody>
			</table>
		</div>
		<div id="sendmailfrm">
			<h1 style="text-align:left;">Update Payment  </h1>
			<div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<form action="loadSave_DmcPayment.php" method="post" enctype="multipart/form-data" name="loadSave_DmcPayment" target="actoinfrm"  id="loadSave_DmcPayment">
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Agent/Client Name<span class="redmind"></span></div>
					<input type="text" class="gridfield" value="<?php echo strip($companyName); ?>"  maxlength="20"  displayname="Agent Name"/>
				</label>
			</div>
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Payment Type <span class="redmind"></span></div>
					<select id="paymentType" name="paymentType" class="gridfield" autocomplete="off" >
					<option value="1" <?php if($scheduleData['paymentType'] == 1){ ?> selected="selected" <?php } ?>>On Credit</option>
					<option value="0" <?php if($scheduleData['paymentType'] == 0){ ?> selected="selected" <?php } ?>>Full Payment</option>
					<option value="3" <?php if($scheduleData['paymentType'] == 3){ ?> selected="selected" <?php } ?>>Direct&nbsp;Payment</option>
					<option value="2" <?php if($scheduleData['paymentType'] == 2){ ?> selected="selected" <?php } ?>selected>Advanced Payment</option>
					</select>
				</label>
			</div>
			
			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Payment&nbsp;Amount&nbsp;(In&nbsp;<?php echo $currencyName; ?>)<span class="redmind"></span></div>

					<input onKeyUp="numericFilter(this);" name="amount" type="text" class="gridfield validate" id="amount" value="<?php echo getChangeCurrencyValue_New($baseCurrencyId,$quotationId,$scheduleData['amount']); //round($scheduleData['amount']); ?>"  maxlength="20"  displayname="Payment Amount" disabled  />
				</label>
			</div>

			<div class="griddiv" id="boxpaymentdiv">
				<label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Payment Through <span class="redmind"></span></div>
					<select id="paymentBy" name="paymentBy" class="gridfield" displayname="Payment By" autocomplete="off">
					<?php
						$select = '';
						$where = '';
						$rs = '';
						$select = '*';
						$where = ' deletestatus=0 and status=1 order by id asc';
						$rs = GetPageRecord($select, 'paymentTypeMaster', $where);
						while ($resListing = mysqli_fetch_array($rs)) {
						?>
						<option value="<?php echo strip($resListing['id']); ?>" <?php if ($editresult['paymentBy'] == $resListing['id']) { ?> selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>


					<?php } ?>
					</select>
				</label>
			</div>

			<div class="griddiv"><label>
			<div class="gridlable">Bank Name<span class="redmind"></span> </div>
				<input type="text" name="bankName" id="bankName" class="gridfield validate" displayname="Bank Name">
			</label>
			</div>

			<div class="griddiv"><label>
			<div class="gridlable" style="width:50%;">Transaction Id/Cheque Number</div>
				<input type="text" name="transactionId" id="transactionId" class="gridfield" displayname="Transaction Id or Cheque Number">
			</label>
			</div>

			<div class="griddiv"><label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Description</div>
				<textarea name="details" rows="3" class="gridfield" id="details" displayname="Email Subject" field_min_length="6"></textarea>
				</label>
			</div>
			<input name="action" type="hidden"  value="agentUpdatePayment" />
			<input type="hidden"  name="scheduleId"  id="scheduleId" value="<?php echo $scheduleData['id']; ?>" />
	  	</form>
		</div>
			<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
			<tr><td>
			<input name="addnewuserbtn" type="button" class="bluembutton submitbtn loadpaymentreq" id="addnewuserbtn" value=" Save" onclick="formValidation('loadSave_DmcPayment','submitbtn','0');" /></td>
			<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
			</tr>
			</table>
		</div>
		</div>
	</div>
	
<?php 
} 
?>
<?php if($_REQUEST['action']=='serviceSchedulePayment' && $_REQUEST['supplierStatusId']!='' ){ ?>
<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
		<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
		Mail Sent Successfully</div>
		<table border="0" align="center" cellpadding="0" cellspacing="0">
		   <tbody>
		   <tr>
				 <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
			  </tr>
		   </tbody>
		</table>
	</div>
	<div id="sendmailfrm">
		<div id="loadSupplierPaymentSchedule"  style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >Loading...</div>
		<script>
		function loadSupplierPaymentSchedule(){
			$('#loadSupplierPaymentSchedule').load('loadSupplierPaymentSchedule.php?supplierStatusId=<?php echo $_REQUEST['supplierStatusId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>');
		}
		loadSupplierPaymentSchedule();
		</script>
	</div>
</div>
<?php } ?>
<?php if($_REQUEST['action']=='dmcSchedulePayment' && $_REQUEST['quotationId']!='' ){ ?>
<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
		<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
		Mail Sent Successfully</div>
		<table border="0" align="center" cellpadding="0" cellspacing="0">
		   <tbody>
		   <tr>
				 <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
			  </tr>
		   </tbody>
		</table>
	</div>
	<div id="sendmailfrm">
		<div id="loadDmcPaymentSchedule"  style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >Loading...</div>
		<script>
		function loadDmcPaymentSchedule(){
			$('#loadDmcPaymentSchedule').load('loadDmcPaymentSchedule.php?quotationId=<?php echo $_REQUEST['quotationId']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>');
		}
		loadDmcPaymentSchedule();
		</script>
	</div>
</div>
<?php } ?>
<?php if($_REQUEST['action']=='serviceUploadDocument' && $_REQUEST['supplierStatusId']!=''  && $_REQUEST['quotationId']!=''){ ?>
<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
   <tbody>
   <tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody>
</table>
</div>
	<div id="sendmailfrm">
		<h1 style="text-align:left;">Upload Document</h1>
		<div id="contentbox" class="addeditpagebox" style="  padding:12px 0px 0px; overflow:auto; text-align:left; margin-bottom:0px; " >
		<form action="loadSave_SupplierPayment.php" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
		<div class="griddiv" id="boxpaymentdiv">
			<label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Document&nbsp;Title<span class="redmind"></span></div>
				<input name="docTitle" type="text" class="gridfield validate" id="docTitle"  maxlength="20"  displayname="Document&nbsp;Title" autocomplete="off"   />
			</label>
		</div>
		<div class="griddiv" id="boxpaymentdiv">
			<label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Document&nbsp;Type<span class="redmind"></span></div>
				<select id="docType" name="docType" class="gridfield" displayname="Document Type" autocomplete="off">
					<option value="1">Proforma Invoice</option>
					<option value="2">Tax Invoice</option>
				</select>
			</label>
		</div>
		<div class="griddiv"><label>
			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Attachment </div>
			<input name="documentFile" type="file" id="documentFile" style="width:100%;" />
			</label>
		</div>
		<input name="action" type="hidden"  value="serviceUploadDocument" />
		<input name="quotationId" type="hidden" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>" />
		<input name="supplierStatusId" type="hidden" id="supplierStatusId" value="<?php echo $_REQUEST['supplierStatusId']; ?>" />
	</form>
	</div>
		<div id="buttonsbox"  style="text-align:center;">
		<table border="0" align="right" cellpadding="0" cellspacing="0">
		<tr>
		<td>
		<input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		</tr>
		</table>
	</div>
	</div>
</div>
<?php } ?>
<?php if($_GET['action']=='sendTransfervoucheremail'){
?>
<div class="contentclass">
<div id="sendmailaction" style="display:none;">
<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
Mail Sent Successfully</div>
<table border="0" align="center" cellpadding="0" cellspacing="0">
      <tbody><tr>
         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
      </tr>
   </tbody></table>
</div>
<div id="sendmailfrm">
<h1 style="text-align:left;">Send Voucher </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="mailusers" id="showmultiemails">
<?php
$voucherid=$_GET['vid'];
$select1='*';
$where1='id="'.$voucherid.'"';
$rs1=GetPageRecord($select1,'finalQuotetransfer',$where1);
$voucherids=mysqli_fetch_array($rs1);
$select1='*';
$where1='id="'.$voucherids['queryId'].'"';
$rs1=GetPageRecord($select1,_QUERY_MASTER_,$where1);
$editresultQuery=mysqli_fetch_array($rs1);
$select='';
$where='';
$rs='';
$select='email';
$where='id="'.$editresultQuery['assignTo'].'"';
$rs=GetPageRecord($select,_USER_MASTER_,$where);
$resultpageassignemail=mysqli_fetch_array($rs);
$select='';
$where='';
$rs='';
$select='*';
$where='id=1';
$rs=GetPageRecord($select,_QUERY_MAILS_SECTION_MASTER_,$where);
$resultpageemail=mysqli_fetch_array($rs);
?>
		   <div class="mailusersbox"><strong>Client: </strong><?php if($editresultQuery['companyId']!=''){ if($editresultQuery['clientType']==1){ echo getPrimaryEmail($editresultQuery['companyId'],'corporate'); } if($editresultQuery['clientType']==2){ echo getPrimaryEmail($editresultQuery['companyId'],'contacts'); } } ?></div>
		   <div class="mailusersbox"><strong>Sales Executive: </strong><?php echo $resultpageassignemail['email']; ?></div>
		   <div class="mailusersbox"><strong>Group: </strong><?php echo $resultpageemail['queryemail']; ?></div>
	    </div>
<div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Add More Email   </div>
	<input name="emailsender" type="text" class="gridfield" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Subject <span class="redmind"></span></div>
	<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="Booking No. <?php echo makeInvoiceId($_GET['voucherid']); ?>" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
	</label>
 </div>
 <div class="griddiv"><label>
 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
	<div class="gridlable">Description  </div>
	<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
	</label>
 </div><input name="sendTransfervoucheremail" type="hidden" id="sendTransfervoucheremail" value="1" /><input name="sendemailvoucherid" type="hidden" id="sendemailvoucherid" value="<?php echo $_GET['voucherid']; ?>" /><input name="vid" type="hidden" id="vid" value="<?php echo $_GET['vid']; ?>" />
 <input name="voucherType" type="hidden" id="voucherType" value="<?php echo $_GET['voucherType']; ?>" />
 <input name="transferQuotationId" type="hidden" id="transferQuotationId" value="<?php echo $_GET['transferQuotationId']; ?>" />
 </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
	<?php } ?>
<?php
if($_GET['action']=='createwelcomelettervoucher' && $_GET['queryId']!=''){
?>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
<div class="contentclass"><span style="float:right;"><input name="Cancel" type="button" style="background-color: #cccccc !important; border-radius: 3px; padding: 4px; margin: 2px;cursor:pointer;  " id="Cancel" value="Close" onclick="alertspopupopenClose();" /> </span>
<h1 style="text-align:left;">Welcome&nbsp;Letter&nbsp;Voucher</h1>
  <div id="loadcreateitinerary"  style="padding:0px; overflow:auto; text-align:left; margin-bottom:0px;" >Loading...</div>
  <script>
  $('#loadcreateitinerary').load('loadwelcomevoucher.php?queryId=<?php echo $_GET['queryId'];?>');
  </script>
  <div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
  </tr>
</table></div>
</div>
</form>
	<?php }

if($_GET['action']=='letterTypeMaster' && $_GET['queryId']!=''  && $_GET['letterType']!=''){
?>
  <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
 <!-- <div onclick="openPreferLan();" class="gridcheck">You want to change the Preferred Language</div> -->
  <!-- <div class="preferLan" style="display: none;">
  <div class="gridLan">
<div><label>Preferred&nbsp;Language</label>
<select id="languageType" name="languageType" autocomplete="off" style="height:30px;width: 100%;padding-left: 10px;"> -->
 <?php 
// $select=''; 
// $where=''; 
// $rs='';  
// $select='*';    
// $where='status=1 and deletestatus=0 order by id asc';  
// $rs=GetPageRecord($select,'tbl_languagemaster',$where); 
// while($resListing=mysqli_fetch_array($rs)){  
?>
<!-- <option value="<?php echo $resListing['id']; ?>"><?php echo $resListing['name']; ?></option> -->
<?php //} ?>
<!-- </select>
</div>
</div>
<div class="contentclass"><span style="float:right;"><input name="Cancel" type="button" style="background-color: #cccccc !important; border-radius: 3px; padding: 4px; margin: 2px; cursor:pointer; " id="Cancel" value="Close" onclick="alertspopupopenClose();" /> </span>
<div style="display: flex;padding: 10px 20px;">
<div onclick="openLanEditor();" class="saveeditor">Save</div>
<div onclick="closePreferLan();" class="closeeditor">Cancel</div>
</div> -->
</div>
<input type="hidden" name="letterType" value="<?php echo $_GET['letterType'] ?>">
 <input type="hidden" name="queryId" value="<?php echo encode($_GET['queryId']); ?>">	
 <input type="hidden" name="action" value="languagelettereditor">	
<?php 
$rs1=GetPageRecord('letterName','letterMaster','1 and status=1 and letterType="'.$_GET['letterType'].'"');
$editresult=mysqli_fetch_array($rs1);
?>	
<h1 style="text-align:left; margin:10px;"><?php echo $editresult['letterName'] ?></h1> 
 <!-- <div id="lanEditor" style="display: none;"></div> -->
<div id="loadletter" style="padding:0px; overflow:auto; text-align:left; margin-bottom:0px;" >Loading...</div>
  <script>
    <?php  

    if($_GET['letterType']=='agentwelcomeLetter'){ ?>
	 $('#loadletter').load('<?php echo $fullurl; ?>loadwelcomevoucher.php?queryId=<?php echo $_GET['queryId']; ?>');
    <?php }elseif($_GET['letterType']=='plainwelcomeLetter'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>loadplainwelcomevoucher.php?queryId=<?php echo $_GET['queryId']; ?>'); 
	<?php }elseif($_GET['letterType']=='agentfeedbackForm22222'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>generateAgentfeedback.php?queryId=<?php echo $_GET['queryId']; ?>'); 
	// new added agentfeedbackForm started code
	<?php }elseif($_GET['letterType']=='agentfeedbackForm'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>online_feedback_form.php?queryId=<?php echo $_GET['queryId']; ?>');
	// new added agentfeedbackForm started code
	<?php }elseif($_GET['letterType']=='sendfeedbackform'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>sendfeedbackmail.php?queryId=<?php echo $_GET['queryId']; ?>'); 
    <?php }elseif($_GET['letterType']=='plainfeedbackForm33'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>generatefeedbackform.php?queryId=<?php echo $_GET['queryId']; ?>');
	// new added plainfeedbackForm started code
	<?php }elseif($_GET['letterType']=='plainfeedbackForm'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>online_feedback_form.php?queryId=<?php echo $_GET['queryId']; ?>&plainfeedbackfrom=1');
	// new added plainfeedbackForm ended code
    <?php }elseif($_GET['letterType']=='contactList'){ ?>
	$('#loadletter').load('<?php echo $fullurl; ?>generatecontactList.php?queryId=<?php echo $_GET['queryId']; ?>');
    <?php }?>
	

	
	
	
	
</script>
  <div style="overflow:hidden;">
  <table border="0" align="right" cellpadding="5" cellspacing="0"  >
  <tr>
    <td >
   <input name="savenewlan" type="submit" class="saveeditor" id="savenewlan" style="border-radius:5px;width: 70px;padding:10px;display: none;" value="Save" />
     <input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="alertspopupopenClose();" />
 </td>
  </tr>
</table></div>
<!-- </div> -->
</form>
	<?php 
}

if($_GET['action']=='addTourExtension' && $_REQUEST['queryId']!='' && $_REQUEST['quotationId']!=''){
	$dateAdded=time();
  $namevalue ='addedBy="'.$_SESSION['userid'].'",deletestatus=1,isTourEx=1,gstType=1,dateAdded="'.$dateAdded.'",currencyId="'.$baseCurrencyId.'",queryId="'.decode($_REQUEST['queryId']).'"';
	$newQuotationId= addlistinggetlastid(_QUOTATION_MASTER_,$namevalue);

	$queryData = GetPageRecord('*',_QUERY_MASTER_,'1 and id="'.decode($_REQUEST['queryId']).'"');
	$queryDataq = mysqli_fetch_array($queryData);

	$quotationData = GetPageRecord('*',_QUOTATION_MASTER_,'1 and queryId="'.decode($_REQUEST['queryId']).'" order by id asc limit 1');
	$quotationDataq = mysqli_fetch_array($quotationData);

	$fromDateCheck = strtotime("-1 month", strtotime($queryDataq['fromDate']));
	$fromDateFinal = date("d-m-Y", $fromDateCheck);

	$toDateCheck = strtotime("+1 month", strtotime($queryDataq['fromDate']));
	$toDateFinal = date("d-m-Y", $toDateCheck);
		
	?>
<script src="js/zebra_datepicker.js"></script>
<script type="text/javascript"  src="plugins/select2/select2.min.js"></script>
 <div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left;">Make Tour Extension</h1>
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
	<table width="100%" border="0" cellspacing="0" cellpadding="3" style="border: 1px solid #e7e7e8; padding: 10px; background-color: #fcfcfc; margin-bottom: 20px;">
	  <tr>
	    <td >
	    	<div class="griddiv">
		    	<label>
						<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
						<div class="gridlable">Extension&nbsp;Type<span class="redmind"></span></div>
						<select id="extensionType" name="extensionType" class="gridfield validate" autocomplete="off" onchange="changeTourDate();">
							<!-- <option>Select Tour Type</option> -->
							<option value="2">Post Tour</option>
							<option value="1">Pre Tour</option>
						</select>
					</label>
				</div>
			</td>
			 
	    <td colspan="3">
	    	<div class="griddiv">
		    	<label>
				 		<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
						<div class="gridlable" style="width: 100%;">Quotation&nbsp;Title<span class="redmind"></span></div>
						<input name="quotationSubject" type="text" class="gridfield validate"  id="quotationSubject" value="<?php echo $quotationDataq['quotationSubject'] ?>" displayname="Quotation Title" />
					</label>
			 </div>
			</td>
	  </tr>
	</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
	  <tr>
	    <td width="200px">
	    	<div class="griddiv">
	    		<label>
			 			<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
						<div class="gridlable">Quotation&nbsp;Type<span class="redmind"></span></div>
						<select id="quotationType" name="quotationType" class="gridfield validate" displayname="Quotation Type" autocomplete="off" onchange="selecthotelfun();">
							<option value="1">Single Hotel Category</option>
							<option value="2">Multiple Hotel Category</option>
						</select>
					</label>
			 	</div>
			</td>
	    <td colspan="2">
	    	<div class="griddiv" id="showhot" style=" display:none;">
	    		<label>
						<div class="gridlable">Hotel&nbsp;Category</div> 
						<select class="selectpicker select2" name="hotCategory[]" multiple data-actions-box="true">
								<?php 
								$rsname1=GetPageRecord('*','hotelCategoryMaster',' deletestatus=0 and status=1 order by hotelCategory asc');
								while($hotelCatData1=mysqli_fetch_array($rsname1)){
								?>
								<option value="<?php echo $hotelCatData1['id'];?>"><?php echo $hotelCatData1['hotelCategory'];?> Star</option>
								<?php } ?> 
						</select>
					</label>
				</div>
			</td> 
	  </tr>
	</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
	 	<tr>
			<td>
				<div class="griddiv">
					<label>
						<div class="gridlable">Adult <span class="redmind"></span></div>
						<input name="adult" type="number" class="gridfield validate totalpax" id="adult" value="" maxlength="200"  displayname="Adult"  autocomplete="off" />
					</label>
				</div>
			</td>

			<td>
				<div class="griddiv">
					<label>
						<div class="gridlable">Child </div>
						<input name="child" type="number" class="gridfield totalpax" id="child"   value="" maxlength="200"  displayname="Child"  autocomplete="off" />
					</label>
				</div>
			</td>

			<td>
				<div class="griddiv">
					<label>
						<div class="gridlable">Infant</div>
						<input name="infant" type="number" class="gridfield totalpax" id="infant"  autocomplete="off" />
						<input name="totalPax" type="hidden" class="gridfield " id="totalPax"  autocomplete="off" />
					</label>
				</div>
			</td>
		</tr>
	</table> 
	<?php 
	$roomrs = GetPageRecord('*','roomMaster','roomName="quadroom"');
	$roomQuad = mysqli_fetch_assoc($roomrs);

	$roomrs1 = GetPageRecord('*','roomMaster','roomName="sixbedroom"');
	$roomSix = mysqli_fetch_assoc($roomrs1);

	$roomrs2 = GetPageRecord('*','roomMaster','roomName="eightbedroom"');
	$roomEight = mysqli_fetch_assoc($roomrs2);

	$roomrs3 = GetPageRecord('*','roomMaster','roomName="tenbedroom"');
	$roomTen = mysqli_fetch_assoc($roomrs3);

	$roomrs4 = GetPageRecord('*','roomMaster','roomName="teenbed"');
	$roomTeen = mysqli_fetch_assoc($roomrs4);

	?>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
	 	<tr>
	    <td width="16%"><div class="griddiv"><label>
			<div class="gridlable">SGLRoom<span class="redmind"></span></div>
			<input name="sglRoom" type="number" class="gridfield " id="sglRoom" value="" maxlength="3"  displayname="SGLRoom"  autocomplete="off" />
			</label>
			</div></td>
			<td width="16%"><div class="griddiv"><label>
			<div class="gridlable">DBLRoom</div>
			<input name="dblRoom" type="number" class="gridfield" id="dblRoom"   value="" maxlength="3"  displayname="DBLRoom"  autocomplete="off" />
			</label>
			</div></td>
			<td width="16%"><div class="griddiv"><label>
			<div class="gridlable">TPLRoom</div>
			<input name="tplRoom" type="number" class="gridfield " id="tplRoom"   value="" maxlength="3" displayname="TPLRoom" autocomplete="off" />
			</label>
			</div></td>
			<td width="16%"><div class="griddiv"><label>
			<div class="gridlable">TWINRoom</div>
			<input name="twinRoom" type="number" class="gridfield " id="twinRoom"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>

			<td width="16%"><div class="griddiv"><label>
			<div class="gridlable">EBed(C)</div>
			<input name="noofchildwithbed" type="number" class="gridfield " id="noofchildwithbed"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>
			<td width="16%"><div class="griddiv"><label>
			<div class="gridlable">ENBed(C)</div>
			<input name="noofchildwithoutbed" type="number" class="gridfield " id="noofchildwithoutbed"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>
		</tr>
		<tr>
		  <td><div class="griddiv"><label>
			  <div class="gridlable">EBed(A)</div>
			  <input name="extraNoofBed" type="number" class="gridfield " id="extraNoofBed"   value="" maxlength="3" displayname="Extra Bed Adult" autocomplete="off" />
			</label>
			</div></td>
			<?php if($roomQuad['status']==1){ ?> 
			<td><div class="griddiv"><label>
			<div class="gridlable">Quad</div>
			<input name="noofQuadRoom" type="number" class="gridfield " id="noofQuadRoom"   value="" maxlength="3" displayname="Quad" autocomplete="off" />
			</label>
			</div></td>
			<?php } if($roomSix['status']==1){ ?>
			<td><div class="griddiv"><label>
			<div class="gridlable">SixBed</div>
			<input name="noofSixBRoom" type="number" class="gridfield " id="noofSixBRoom"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>
			<?php } if($roomEight['status']==1){ ?>
			<td><div class="griddiv"><label>
			<div class="gridlable">EightBed</div>
			<input name="noofEightBRoom" type="number" class="gridfield " id="noofEightBRoom"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>
			<?php } if($roomTen['status']==1){ ?>
			<td><div class="griddiv"><label>
			<div class="gridlable">TenBed</div>
			<input name="noofTenBRoom" type="number" class="gridfield " id="noofTenBRoom"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>
			<?php } if($roomTeen['status']==1){ ?>
			<td><div class="griddiv"><label>
			<div class="gridlable">TeenRoom</div>
			<input name="noofTeenRoom" type="number" class="gridfield " id="noofTeenRoom"   value="" maxlength="3" displayname="TWINRoom" autocomplete="off" />
			</label>
			</div></td>
			<?php } ?>
		</tr>
	</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
	  <tr>
	    <td>
	    	<div class="griddiv">
					<label>
						<div class="gridlable" >From&nbsp;Date </div>
						<input name="fromDate" type="text" id="fromDate2" class="gridfield calfieldicon validate"  displayname="From Date"   autocomplete="off" value="" style="width:100%;"/>
					</label>
				</div>
			</td>

	    <td>
	    	<div class="griddiv">
					<label>
						<div class="gridlable" >To&nbsp;Date </div>
						<input name="toDate" type="text" id="toDate2" class="gridfield calfieldicon validate"  displayname="To Date"   autocomplete="off" value="" style="width:100%;"/>
					</label>
				</div>
			</td>
			<td width="100px">
				<div class="griddiv">
					<label>
						<div class="gridlable">Total&nbsp;Nights <span class="redmind"></span></div>
						<input name="totalNights" type="text" class="gridfield" id="totalNights" readonly="" value="" maxlength="200"  displayname="Total Nights"  autocomplete="off" /> 
					</label>
				</div>
			</td>
			<td >
				<div class="griddiv">
					<label>
						<div class="gridlable">&nbsp;</div> 
						<a href="#" onclick="adddestinationsQuo();" class="fa fa-plus" style="margin-top: 5px; padding: 10px; border-radius: 0px; background-color: #006699; color: #ffffff !important; width: fit-content; border-radius: 3px; ">&nbsp;&nbsp;Add</a>
					</label>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="4">
				<div id="loaddestSubQuo" style="margin-bottom: 20px;"></div>	
			</td>
		</tr> 
	</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
		<tr>
			<td> 	
				<div class="griddiv">
					<label>
						<div class="gridlable">Lead&nbsp;Pax&nbsp;Name</div>
						<input name="leadPaxName" type="text" class="gridfield" id="leadPaxName" autocomplete="off" placeholder="Lead Pax Name" />
					</label>
				</div>
			</td>
			<td width="50%"> 
				<div class="griddiv">
					<label>
						<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
						<div class="gridlable" style=" width: 100%;">Suggested Packages</div>
						<select id="packageId" name="packageId" class="gridfield " displayname="Suggested Packages" autocomplete="off" >
							<option value="0">None</option>
							<?php 
							$rs="";
							$rs=GetPageRecord('*','quotationMaster',' quotationType=1 and isPackage=1 and queryType=4 order by id asc');
							while($suggPackagList=mysqli_fetch_array($rs)){
							?>
							<option value="<?php echo $suggPackagList['id'];?>"><?php echo $suggPackagList['quotationSubject'];?></option>
							<?php } ?>
						</select>
					</label>
				</div>
				
			</td>
			<td align="right" width="130px">
				<a href="#" id="loadPackage" onclick="loadsuggestedpackage();" style="margin-top: 5px; padding: 10px; border-radius: 0px; background-color: #006699; color: #ffffff !important; width: fit-content; border-radius: 3px;"><i id="spinnerI" class="" ></i> &nbsp;Load&nbsp;Package</a>
			</td> 
		</tr>
		
	</table>

	<script type="text/javascript">
		function adddestinationsQuo(){
			var fromDate = encodeURI($('#fromDate2').val());
			var toDate = encodeURI($('#toDate2').val());
			var extensionType = encodeURI($('#extensionType').val());
			var dates = fromDate;
			var dates1 = dates.split("-");
			var newDate = dates1[1]+"/"+dates1[0]+"/"+dates1[2];
			var fromDateTimestamp = new Date(newDate).getTime();
			var todates = toDate;
			var todates1 = todates.split("-");
			var tonewDate = todates1[1]+"/"+todates1[0]+"/"+todates1[2];
			var toDateTimestamp = new Date(tonewDate).getTime();
			var isEditable = <?php echo "1"; ?>;
			var dayscount = Math.round((toDateTimestamp-fromDateTimestamp)/(1000*60*60*24)+1);
			$('#loaddestSubQuo').load('generateTourDays.php?action=generateTourDays&quotationId=<?php echo $newQuotationId; ?>&fromDate='+fromDate+'&toDate='+toDate+'&extensionType='+extensionType+'&sbq=1&queryId=<?php echo $_REQUEST['queryId']; ?>&nights='+dayscount+'&isEditable='+isEditable);
		}
		// function loaddestinationsQuo(){
		// $('#loaddestSubQuo').load('loaddatedistination.php?id=<?php echo $newQueryId; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
		// }
		// loaddestinationsQuo();
	  $(document).ready(function() {
	  	$('.select2').select2();
	  });
		function deletedestination(did){
			$('#loaddestSubQuo').load('loaddatedistination.php?id=<?php echo $newQueryId; ?>&did='+did+'&action=regenerateDestination');
		}

		function selecthotelfun(){
		 	var qt = $('#quotationType :selected').val();
			if(qt==2){
				$('#showhot').show();
			}else{
				$('#showhot').hide();
			}
		}
		$(document).on("change", ".totalpax", function() {
	    var sum = 0;
	    $(".totalpax").each(function(){
	        sum += +$(this).val();
	    });
	    $("#totalPax").val(sum);
		}); 

	
		function loadsuggestedpackage(){

			var quotationType=$('#quotationType').val();

			if(quotationType == 2){ 
				var hotCategory=$('#hotCategory').val();
			}else{
				var hotCategory = 0;
			}
			$('#packageId').load('loadsuggestedpackage.php?tourextension=1&quotationId=<?php echo $newQuotationId; ?>&quotationType='+quotationType+'&hotCategory='+hotCategory);

			// add class spin and remove child 
			const fa = document.getElementById('spinnerI');
			fa.classList.add('fa','fa-spinner','fa-pulse','fa-fw');

			setInterval(function(){
				const element = document.getElementById('loadPackage');
				element.removeAttribute("onclick");
				fa.removeAttribute("class");
			}, 5000);
		}
		// loadsuggestedpackage(); 
	 
		function changeTourDate(){
			var extensionType = encodeURI($('#extensionType').val());
			if(extensionType == 1){
				$('#fromDate2').val('');
				$('#toDate2').val('');
				$('#totalNights').val('');	
				var validTo = "<?php echo date("d-m-Y", strtotime($queryDataq['fromDate'])); ?>";
				var validFrom = "<?php echo $fromDateFinal;  ?>";

				$('#fromDate2').Zebra_DatePicker({
					direction: [validFrom,validTo],
					format: 'd-m-Y',
				  pair: $('#toDate2')
				});


				$('#toDate2').Zebra_DatePicker({
					direction: [validFrom,validTo],
					format: 'd-m-Y',
					onSelect: function (date) {
						var temptddate = date.split("-").reverse().join("-");
						var todate = new Date(temptddate).getTime();
						var fd = $('#fromDate2').val();
						var tempfddate = fd.split("-").reverse().join("-");
						var fromdate = new Date(tempfddate).getTime();
						var nightscount = Math.round((todate-fromdate)/(1000*60*60*24));
						$('#totalNights').val(nightscount);
					}
				}); 
			}	
			
			if(extensionType == 2){
				$('#toDate2').val('');
				$('#fromDate2').val('');
				$('#totalNights').val('');
				var validFrom = "<?php echo date("d-m-Y", strtotime($queryDataq['toDate'])) ?>";
				var validTo = "<?php echo $toDateFinal;  ?>";

				$('#fromDate2').Zebra_DatePicker({
					direction: [validFrom,validTo],
					format: 'd-m-Y',
				}); 

				$('#toDate2').Zebra_DatePicker({
					direction: [validFrom,validTo],
					format: 'd-m-Y',
					onSelect: function (date) {
						var temptddate = date.split("-").reverse().join("-");
						var todate = new Date(temptddate).getTime();
						var fd = $('#fromDate2').val();
						var tempfddate = fd.split("-").reverse().join("-");
						var fromdate = new Date(tempfddate).getTime();
						var nightscount = Math.round((todate-fromdate)/(1000*60*60*24));
						$('#totalNights').val(nightscount);
					}
				});	
			}
		}
		changeTourDate();
	</script> 
	<!-- <input name="itinerary" type="hidden" id="itinerary" class="validate"  displayname="Destination" value="" /> -->
	<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
	<input name="isTourEx" type="hidden" id="isTourEx" value="1" />
	<input name="quotationId" type="hidden" id="quotationId" value="<?php echo encode($newQuotationId); ?>" />
	<input name="action" type="hidden" id="action" value="addTourExtension" />
</form>
</div>
<div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
	  <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		<td style="padding-right:20px;"><a href="<?php echo $fullurl; ?>showpage.crm?module=query&view=yes&id=<?php echo $_REQUEST['queryId']; ?>&tourextension=1"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" /></a></td>
	  </tr>
	</table>
</div>
</div>
</div>
<style>
#alertnotificationsmainbox .select2-search__field {
    padding: 6px !important; }
.select2-container {
    width: 100% !important;	 }
	#alertnotificationsmainbox .select2-container .select2-search--inline {
    display:none;
}
.select2-container--open{
z-index:9999999
}
.select2-container .select2-selection--single {
height: 35px;
}
.addeditpagebox .griddiv .gridlable {
    display: block;
}
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<?php } ?>


<?php 
if($_GET['action']=='sendmailtoclient'){ ?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
	.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper { width:100% !important; }
</style>
<div class="contentclass">
 <script>
 var repotBody = $('#repotBody').val();
  $('#repotBodymail').val(repotBody);
 </script>
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #22a928 !important;">Send Mail</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <table width="100%" border="0" cellpadding="5" cellspacing="0" id="<?php echo ($editresult['id']); ?>" style="background-color: #eff2f2; margin-bottom:10px; border: 1px solid #57a0a4; border-radius: 3px;">
     <tr>
       <td width="100%"><div class="griddiv">
        <div class="gridlable">Email Id</div>
        <input name="emailid" id="emailid"  type="text" class="gridfield" value="" style="width: 305px;" />
      </div></td>
       </tr>
   </table>
	<textarea name="repotBodymail" id="repotBodymail" style="display:none;"></textarea>
    <input name="action" id="action" type="hidden" value="mailsendtoclient" />
	<input name="fromDate" id="fromDate" type="hidden" value="<?php echo $_GET['fromDate']; ?>" />
	<input name="toDate" id="toDate" type="hidden" value="<?php echo $_GET['toDate']; ?>" />
	<input name="assignto" id="assignto" type="hidden" value="<?php echo $_GET['assignto']; ?>" />
    </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Save    "  onclick="formValidation('addflight','saveflight','0'); myFunction()" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<script>
function myFunction() {
  alert("Please Fill Email ID!");
}
</script>
<style>
.newtowrobox .griddiv { width:unset !important; }
</style>
	<?php } ?>
<?php if($_GET['action']=='sendmailtoclientguide'){
 ?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
	.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper { width:100% !important; }
</style>
<div class="contentclass">
 <script>
 var repotBody = $('#repotBody').val();
  $('#repotBodymail').val(repotBody);
 </script>
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #22a928 !important;">Send Mail</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addflight" target="actoinfrm"  id="addflight">
   <table width="100%" border="0" cellpadding="5" cellspacing="0" id="<?php echo ($editresult['id']); ?>" style="background-color: #eff2f2; margin-bottom:10px; border: 1px solid #57a0a4; border-radius: 3px;">
     <tr>
       <td width="100%"><div class="griddiv">
        <div class="gridlable">Email Id</div>
        <input name="emailid" id="emailid"  type="text" class="gridfield" value="" style="width: 305px;" />
      </div></td>
       </tr>
   </table>
	<textarea name="repotBodymail" id="repotBodymail" style="display:none;"></textarea>
    <input name="action" id="action" type="hidden" value="mailsendtoclientguide" />
	<input name="fromDate" id="fromDate" type="hidden" value="<?php echo $_GET['fromDate']; ?>" />
	<input name="toDate" id="toDate" type="hidden" value="<?php echo $_GET['toDate']; ?>" />
	<input name="assignto" id="assignto" type="hidden" value="<?php echo $_GET['assignto']; ?>" />
    </form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0" >
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="    Send    "  onclick="formValidation('addflight','saveflight','0'); myFunction()" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div>
<script>
function myFunction() {
  alert("Please Fill Email ID!");
}
</script>
<style>
.newtowrobox .griddiv { width:unset !important; }
</style>

 <!-- ============================Add tour manager=start======================== -->
<?php } 
if($_GET['action']=='tourdetails' && $_GET['queryId']!=''){
?>
<div class="contentclass"> 
<div id="sendmailfrm"> 
<h1 style="text-align:left;">Tour Manager</h1> 
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="addTourManager"> 
   
<div class=""><label>  
	<select id="tourManagerId" name="tourManagerId" class="gridfield validate" displayname="Tour Manager" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" > 
 <option value="">Select</option>  
  <?php  
		$select='id,name,serviceType';    
		$where=' status="1" and deletestatus=0 and serviceType=2  order by name asc '; 
		$rs=GetPageRecord($select,_GUIDE_MASTER_,$where); 
		while($restype=mysqli_fetch_array($rs)){  
		?>
      <option value="<?php echo $restype['id'] ?>" <?php if($restype['id']==$_REQUEST['tourManager']){ ?>selected="selected"<?php } ?>><?php echo strip($restype['name']); ?></option>
      <?php } ?> 
</select>  
	</label>
 </div>
 <!-- <input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" /> -->
 <input name="module" type="hidden" id="module" value="<?php echo $_GET['sectiontype']; ?>" />
 <input name="action" type="hidden" id="action" value="tourdetails" /> 
  <input name="editId" id="editId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />			
</form>
  </div>
</div>
  <div id="buttonsbox"  style="text-align:center;margin-bottom:20px;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Save    " onclick="formValidation('addTourManager','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div></div> 

  <!-- <div class="contentclass">
<h1 style="text-align:left;"><?php // if($_REQUEST['id']!=''){ echo 'Edit'; } else { echo 'Add'; } ?>  </h1>
  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="masters_frmaction.php" method="post" enctype="multipart/form-data" name="addmasters" target="actoinfrm" id="addmasters">
 <div class="griddiv"><label>
	<div class="gridlable">Name<span class="redmind"></span></div>
	<input name="name" type="text" class="gridfield validate" id="name" displayname="Name" value="<?php echo $name; ?>" maxlength="100" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Contact No.<span class="redmind"></span></div>
	<input name="sortname" type="text" class="gridfield validate" id="sortname" displayname="Name" value="<?php echo $sortname; ?>" maxlength="100" />
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">WattsApp no.<span class="redmind"></span></div>
	<input name="sortname" type="text" class="gridfield validate" id="sortname" displayname="Name" value="<?php echo $sortname; ?>" maxlength="100" />
	</label>
	</div>
		<div class="griddiv"><label>
	<div class="gridlable">Email .<span class="redmind"></span></div>
	<input name="sortname" type="text" class="gridfield validate" id="sortname" displayname="Name" value="<?php echo $sortname; ?>" maxlength="100" />
	</label>
	</div>
 <input name="editId" type="hidden" id="editId" value="<?php //echo $id; ?>" />
 <input name="module" type="hidden" id="module" value="<?php //echo $_GET['sectiontype']; ?>" />
 <input name="action" type="hidden" id="action" value="tourdetails" />
</form>
  </div>
  <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addmasters','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();"/></td>
      </tr>
   </table>
</div></div> -->

<!-- ===============================add tour manager=end======================= -->
<?php }
if($_REQUEST['action']=='hotelvoucher' && $_REQUEST['queryId']!='' && $_REQUEST['quotationId']!='' && $_REQUEST['serviceId']!=''){
?>
<div class="contentclass">
<h1 style="text-align:left;">Hotel&nbsp;Voucher</h1>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
     <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
 <table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td align="left" valign="top" style="display:noned;">
	<table width="100%" border="0" cellpadding="5" cellspacing="0" style="font-size:12px;">
      <tr>
	    <td><input type="file" name="voucherimage" /></td>
 	  </tr>
</table>
	</td>
    </tr>
  <tr>
    <td align="left" valign="top">
	 	<input name="quotationid" type="hidden" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>" />
		<input name="action" type="hidden" id="action" value="hotelvoucher" />
		<input name="queryid" type="hidden" id="queryid" value="<?php echo $_REQUEST['queryId']; ?>" />
		<input name="serviceid" type="hidden" id="serviceid" value="<?php echo $_REQUEST['serviceId']; ?>" />
	  </td>
  </tr>
</table>
  	</div>
  </form>
  	<div id="buttonsbox"  style="text-align:center;">
 	<table border="0" align="left" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
	</div>
</div>
<?php }
if($_REQUEST['action']=='flightvoucher' && $_REQUEST['queryId']!='' && $_REQUEST['quotationId']!=''){
?>
<div class="contentclass">
<h1 style="text-align:left;">Flight&nbsp;Voucher</h1>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addeditfrmbankinfo" target="actoinfrm" id="addeditfrmbankinfo">
     <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
 <table width="100%" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td align="left" valign="top" style="display:noned;">
	<table width="100%" border="0" cellpadding="5" cellspacing="0" style="font-size:12px;">
      <tr>
	    <td><input type="file" name="voucherimage" /></td>
 	  </tr>
</table>
	</td>
    </tr>
  <tr>
    <td align="left" valign="top">
	 	<input name="quotationid" type="hidden" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>" />
		<input name="status" type="hidden" id="status" value="<?php echo $_REQUEST['status']; ?>" />
		<input name="action" type="hidden" id="action" value="flightvoucher" />
		<input name="queryid" type="hidden" id="queryid" value="<?php echo $_REQUEST['queryId']; ?>" />
	  </td>
  </tr>
</table>
  	</div>
  </form>
  	<div id="buttonsbox"  style="text-align:center;">
 	<table border="0" align="left" cellpadding="0" cellspacing="0">
      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addeditfrmbankinfo','submitbtn','0');" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
	</div>
</div>
<?php }
?>

<?php 
if($_GET['action']=='finalquote' && $_GET['queryId']!=''){
	$select='*';
	$where='id='.decode($_GET['queryId']).'';
	$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
	$resultpage=mysqli_fetch_array($rs);
	$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"  ');
	$resultpageQuotation=mysqli_fetch_array($rsp);
	?>
	<style>
	.maindiv{
	margin: 0px 0px 60px 0px;
	position: relative;
	left: 17%;
		}
	.btndiv{
	width: 20%;
	float: left;
	border: 1px solid #ddd;
	padding: 10px;
	margin: auto;
	cursor: pointer;
	}
	.activediv{
	background-color: #22ae74;
	color: #ffffff;
	}
	</style>
	<div class="contentclass">
		<h1 style="text-align:left; position:relative;"> <?php if($_REQUEST['status'] == 1){ ?>Supplier&nbsp;Confirmation<?php } else{ ?> Final Confirmation  <?php }  ?></h1>
		<div class="maindiv">
		
			<div class="btndiv activediv" id="unaservice" onclick="loadquotationfun(3);$('#unaservice').addClass('activediv');$('#day').removeClass('activediv');$('#group').removeClass('activediv');">Supplier Selection</div>	
			
			<div class="btndiv" id="group" onclick="loadquotationfun(2);$('#group').addClass('activediv');$('#day').removeClass('activediv');$('#unaservice').removeClass('activediv');">Reservation Request</div>

			<?php if($resultpageQuotation['calculationType']<>3){ ?>
		  <div class="btndiv " id="day" onclick="loadquotationfun(1);$('#group').removeClass('activediv');$('#unaservice').removeClass('activediv');$('#day').addClass('activediv');">Final Price</div>
			<?php } ?>
		
			<script>
				function loadquotationfun(id){
					$('#finalquote').html('<div style="text-align:center; margin-top:125px;">Loading...</div>');
					if(id==1){
						$('#finalquote').load('load_finalquote.php?<?php if($_REQUEST['status'] == 1){ ?>status=1&<?php } ?>queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
					}
					if(id==2){
						$('#finalquote').load('load_groupWisefinalquote.php?<?php if($_REQUEST['status'] == 1){ ?>status=1&<?php } ?>queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
					}
					if(id==3){
						$('#finalquote').load('unassiged_assigned_services.php?<?php if($_REQUEST['status'] == 1){ ?>status=1&<?php } ?>queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
					}
				}
				<?php if($_REQUEST['o']==3){ ?>
				loadquotationfun(3);
				$('#group').addClass('activediv');
				$('#day').removeClass('activediv');
				 <?php }else{ ?>
				loadquotationfun(3);
				<?php } ?>
				</script>
		</div>
		<div style="text-align:left;" id="finalquote"></div>
	</div>
	<?php 
}

if($_REQUEST['action']=='chooseSupplimentServices' && $_REQUEST['queryId']!='' && $_REQUEST['quotationId']!=''){
	
	if($_REQUEST['quotationType'] == 2){
		$finalcategory = $_REQUEST['finalcategory'];
		$quotationType = $_REQUEST['quotationType'];
		$finalcategoryQuery = " and categoryId = ".$_REQUEST['finalcategory'];
	}else{
		$finalcategory = 0;
		$quotationType = 1;
		$finalQuery = $finalcategoryQuery = $roomSuppCateQuery = "";
	}
	
	// markupType
	
	$queryId=$_REQUEST['queryId'];
	$countQuot='';
	$select2='*';
	$where2='id='.$_REQUEST['quotationId'].'';
	$rs2=GetPageRecord($select2,_QUOTATION_MASTER_,$where2);
	$countQuot=mysqli_num_rows($rs2);
	if($countQuot>0){

		$maintable=mysqli_fetch_array($rs2);

		//update main quotation that its final mark  
		$update = updatelisting(_QUOTATION_MASTER_,'status=0,finalcategory=0,isPaymentRequest=0','queryId="'.$maintable['queryId'].'"'); 
		
		//isPaymentRequest 
		$namevalue ='clientType="'.$maintable['clientType'].'",queryId="'.$maintable['queryId'].'",companyId="'.$maintable['companyId'].'",quotationSubject="'.$maintable['quotationSubject'].'",travelDate="'.$maintable['travelDate'].'",queryDate="'.$maintable['queryDate'].'",fromDate="'.$maintable['fromDate'].'",toDate="'.$maintable['toDate'].'",officeBranch="'.$maintable['officeBranch'].'",destinationId="'.$maintable['destinationId'].'",adult="'.$maintable['adult'].'",child="'.$maintable['child'].'",night="'.$maintable['night'].'",sglRoom="'.$maintable['sglRoom'].'",dblRoom="'.$maintable['dblRoom'].'",tplRoom="'.$maintable['tplRoom'].'",twinRoom="'.$maintable['twinRoom'].'",childwithNoofBed="'.$maintable['childwithNoofBed'].'",childwithoutNoofBed="'.$maintable['childwithoutNoofBed'].'",extraNoofBed="'.$maintable['extraNoofBed'].'",sixNoofBedRoom="'.$maintable['sixNoofBedRoom'].'",eightNoofBedRoom="'.$maintable['eightNoofBedRoom'].'",tenNoofBedRoom="'.$maintable['tenNoofBedRoom'].'",quadNoofRoom="'.$maintable['quadNoofRoom'].'",teenNoofRoom="'.$maintable['teenNoofRoom'].'",isSupp_TRR="'.$maintable['isSupp_TRR'].'",infant="'.$maintable['infant'].'",voucherDate="'.$maintable['voucherDate'].'",voucherNumber="'.$maintable['voucherNumber'].'",voucherReferanceNumber="'.$maintable['voucherReferanceNumber'].'",totalpax="'.$maintable['totalpax'].'",departureDestinationId="'.$maintable['departureDestinationId'].'",guest1="'.$maintable['guest1'].'",categoryId="'.$maintable['categoryId'].'",modifyBy="'.$_SESSION['userid'].'",markup="'.$maintable['markup'].'",addedBy="'.$_SESSION['userid'].'",dateAdded="'.time().'",modifyDate="'.$maintable['modifyDate'].'",deletestatus="'.$maintable['deletestatus'].'",quotationId="'.$maintable['quotationId'].'",starRating="'.$maintable['starRating'].'",status="'.$maintable['status'].'",viewQuotation="'.$maintable['viewQuotation'].'",totalAmount="'.$maintable['totalAmount'].'",totalquotCostWithMarkup="'.$maintable['totalquotCostWithMarkup'].'",markupType="'.$maintable['markupType'].'",serviceTax="'.$maintable['serviceTax'].'",tcs="'.$maintable['tcs'].'",finalQuotationType="'.$maintable['finalQuotationType'].'",currencyId="'.$maintable['currencyId'].'",queryType="'.$maintable['queryType'].'",cost2person="'.$maintable['cost2person'].'",image="'.$maintable['image'].'",flightCostType="'.$maintable['flightCostType'].'",quotationType="'.$maintable['quotationType'].'",hotCategory="'.$finalcategory.'",otherLocation="'.$maintable['otherLocation'].'",otherLocationCost="'.$maintable['otherLocationCost'].'",isOtherLocation="'.$maintable['isOtherLocation'].'",inclusion="'.addslashes($maintable['inclusion']).'",exclusion="'.addslashes($maintable['exclusion']).'",isInc_exc="'.$maintable['isInc_exc'].'",quotationNo="'.$maintable['quotationNo'].'",generateNo="'.$maintable['generateNo'].'",isRegenerated="'.$maintable['isRegenerated'].'",finalcategory="'.$maintable['finalcategory'].'",dayroe="'.$maintable['dayroe'].'",isSer_Mark="'.$maintable['isSer_Mark'].'",lostStatus="'.$maintable['lostStatus'].'",isAddExp="'.$maintable['isAddExp'].'",overviewText="'.addslashes($maintable['overviewText']).'",highlightsText="'.addslashes($maintable['highlightsText']).'",tncText="'.addslashes($maintable['tncText']).'",specialText="'.addslashes($maintable['specialText']).'",proposalType="'.$maintable['proposalType'].'",isTransport="'.$maintable['isTransport'].'",isUni_Mark="'.$maintable['isUni_Mark'].'",isPaymentRequest=0,departureDate="'.$maintable['departureDate'].'",saveQuotaiton="'.$maintable['saveQuotaiton'].'",subName="'.$maintable['subName'].'",issueDate="'.$maintable['issueDate'].'",asOnDate="'.$maintable['asOnDate'].'",discount="'.$maintable['discount'].'",discountType="'.$maintable['discountType'].'",costType="'.$maintable['costType'].'",languageId="'.$maintable['languageId'].'",deletestatusDuplicate="1",onlyTFS="'.$maintable['onlyTFS'].'",visaRequired="'.$maintable['visaRequired'].'",insuranceRequired="'.$maintable['insuranceRequired'].'",passportRequired="'.$maintable['passportRequired'].'",visaCostType="'.$maintable['visaCostType'].'",passportCostType="'.$maintable['passportCostType'].'",insuranceCostType="'.$maintable['insuranceCostType'].'",flightRequired="'.$maintable['flightRequired'].'",dayWise="'.$maintable['dayWise'].'",calculationType="'.$maintable['calculationType'].'",slabAndRoomType="'.$maintable['slabAndRoomType'].'",gstType="'.$maintable['gstType'].'",packageSupplier="'.$maintable['packageSupplier'].'",travelType="'.$maintable['travelType'].'",transferRequired="'.$maintable['transferRequired'].'",trainRequired="'.$maintable['trainRequired'].'"';

		$add = addlistinggetlastid(_QUOTATION_MASTER_,$namevalue);
		$quotationId=$add;
		 
		$b='';
		$totalPaxSlab="";
		$b=GetPageRecord('*','totalPaxSlab',' quotationId="'.$maintable['id'].'" and status=1 order by fromRange asc');
		$totalPaxSlab = mysqli_num_rows($b);
		if($totalPaxSlab == 1){
			while($slabData=mysqli_fetch_array($b)){
				
				$addHotel = '';  
				$modevalue = 'quotationId="'.$quotationId.'", fromRange="'.$slabData['fromRange'].'", toRange="'.$slabData['toRange'].'", localEscort="'.$slabData['localEscort'].'", foreignEscort="'.$slabData['foreignEscort'].'", dividingFactor="'.$slabData['dividingFactor'].'", status=1, dateAdded="'.$slabData['dateAdded'].'",modifyBy="'.$slabData['modifyBy'].'",dividingFactorC="'.$slabData['dividingFactorC'].'", DF_SGL="'.$slabData['DF_SGL'].'", DF_DBL="'.$slabData['DF_DBL'].'", DF_TWN="'.$slabData['DF_TWN'].'", DF_TPL="'.$slabData['DF_TPL'].'", DF_QUAD="'.$slabData['DF_QUAD'].'", DF_SIX="'.$slabData['DF_SIX'].'", DF_EIGHT="'.$slabData['DF_EIGHT'].'", DF_TEN="'.$slabData['DF_TEN'].'", DF_ABED="'.$slabData['DF_ABED'].'", DF_CBED="'.$slabData['DF_CBED'].'",adult="'.$slabData['adult'].'",child="'.$slabData['child'].'",infant="'.$slabData['infant'].'",sglRoom="'.$slabData['sglRoom'].'",dblRoom="'.$slabData['dblRoom'].'",twinRoom="'.$slabData['twinRoom'].'",tplRoom="'.$slabData['tplRoom'].'",quadNoofRoom="'.$slabData['quadNoofRoom'].'",sixNoofBedRoom="'.$slabData['sixNoofBedRoom'].'",eightNoofBedRoom="'.$slabData['eightNoofBedRoom'].'",tenNoofBedRoom="'.$slabData['tenNoofBedRoom'].'",teenNoofRoom="'.$slabData['teenNoofRoom'].'",extraNoofBed="'.$slabData['extraNoofBed'].'",childwithNoofBed="'.$slabData['childwithNoofBed'].'",childwithoutNoofBed="'.$slabData['childwithoutNoofBed'].'"';
				$slabId = addlistinggetlastid('totalPaxSlab',$modevalue);
				
				$esQ="";
				$esQ=GetPageRecord('*','quotationFOCRates',' slabId="'.$slabData['id'].'" and quotationId="'.$slabData['quotationId'].'"');
				if(mysqli_num_rows($esQ) > 0 && ( $slabData['localEscort'] > 0 || $slabData['foreignEscort'] > 0)){
					$isEscort = 1; // True for having any escort
					while($escortData=mysqli_fetch_array($esQ)){
						$focRatesQuery = '';  
						$focRatesQuery ='quotationId="'.$quotationId.'",slabId="'.$slabId.'",sglNORoom="'.$escortData['sglNORoom'].'",dblNORoom="'.$escortData['dblNORoom'].'",tplNORoom="'.$escortData['tplNORoom'].'",focType="'.$escortData['focType'].'",hotelCost="'.$escortData['hotelCost'].'",guideCost="'.$escortData['guideCost'].'",activityCost="'.$escortData['activityCost'].'",entranceCost="'.$escortData['entranceCost'].'",transferCost="'.$escortData['transferCost'].'",ferryCost="'.$escortData['ferryCost'].'",trainCost="'.$escortData['trainCost'].'",flightCost="'.$escortData['flightCost'].'",restaurantCost="'.$escortData['restaurantCost'].'",otherCost="'.$escortData['otherCost'].'",hotelCalType="'.$escortData['hotelCalType'].'",guideCalType="'.$escortData['guideCalType'].'",activityCalType="'.$escortData['activityCalType'].'",entranceCalType="'.$escortData['entranceCalType'].'",ferryCalType="'.$escortData['ferryCalType'].'",transferCalType="'.$escortData['transferCalType'].'",trainCalType="'.$escortData['trainCalType'].'",flightCalType="'.$escortData['flightCalType'].'",restaurantCalType="'.$escortData['restaurantCalType'].'",otherCalType="'.$escortData['otherCalType'].'"';
						$focRateId = addlistinggetlastid('quotationFOCRates',$focRatesQuery);
					} 
				} 
			}

			$rs=GetPageRecord('*','newQuotationDays',' queryId="'.$maintable['queryId'].'" and quotationId="'.$maintable['id'].'"  and addstatus=0  order by id asc');
			while($QueryDaysData=mysqli_fetch_array($rs)){

				$adddays='';
				$namevalue =' queryId="'.$QueryDaysData['queryId'].'",cityId="'.$QueryDaysData['cityId'].'",title="'.$QueryDaysData['title'].'",description="'.$QueryDaysData['description'].'",quotationId="'.$add.'",srdate="'.$QueryDaysData['srdate'].'"';
				$adddays = addlistinggetlastid('newQuotationDays',$namevalue);
				
				$b=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' quotationId="'.$maintable['id'].'"'.$finalcategoryQuery.' and dayId="'.$QueryDaysData['id'].'" and supplierId in ( select serviceId from quotationItinerary where serviceType="hotel" order by serviceId asc ) and (isGuestType=1 or isLocalEscort=1 or isForeignEscort=1) and isRoomSupplement=0 and isHotelSupplement=0 order by id asc');
				while($HotelRes=mysqli_fetch_array($b)){

					// normal and escort
					$namevalue ='';
					$addHotel ='';
					$namevalue ='hotelName="'.$HotelRes['hotelName'].'",fromDate="'.$HotelRes['fromDate'].'",toDate="'.$HotelRes['toDate'].'",checkin="'.$HotelRes['checkin'].'",checkout="'.$HotelRes['checkout'].'",queryId="'.$HotelRes['queryId'].'",quotationId="'.$add.'",dayId="'.$adddays.'",destinationId="'.$HotelRes['destinationId'].'",categoryId="'.$HotelRes['categoryId'].'",roomTariffId="'.$HotelRes['roomTariffId'].'",currencyId="'.$HotelRes['currencyId'].'",currencyValue="'.$HotelRes['currencyValue'].'",supplierId="'.$HotelRes['supplierId'].'",supplierMasterId="'.$HotelRes['supplierMasterId'].'",mealPlan="'.$HotelRes['mealPlan'].'",night="'.$HotelRes['night'].'",status="'.$HotelRes['status'].'",address="'.$HotelRes['address'].'",roomType="'.$HotelRes['roomType'].'",tariffType="'.$HotelRes['tariffType'].'",quotTotalNight="'.$HotelRes['quotTotalNight'].'",hotelQuotatoinType="'.$HotelRes['hotelQuotatoinType'].'",singleoccupancy="'.$HotelRes['singleoccupancy'].'",doubleoccupancy="'.$HotelRes['doubleoccupancy'].'",tripleoccupancy="'.$HotelRes['tripleoccupancy'].'",quadoccupancy="'.$HotelRes['quadoccupancy'].'",twinoccupancy="'.$HotelRes['twinoccupancy'].'",childwithbed="'.$HotelRes['childwithbed'].'",childwithoutbed="'.$HotelRes['childwithoutbed'].'",lunch="'.$HotelRes['lunch'].'",dinner="'.$HotelRes['dinner'].'",extraadult="'.$HotelRes['extraadult'].'",taxType="'.$HotelRes['taxType'].'",markupType="'.$HotelRes['markupType'].'",sglMarkup="'.$HotelRes['sglMarkup'].'",dblMarkup="'.$HotelRes['dblMarkup'].'",twinMarkup="'.$HotelRes['twinMarkup'].'",tplMarkup="'.$HotelRes['tplMarkup'].'",cwbMarkup="'.$HotelRes['cwbMarkup'].'",quadMarkup="'.$HotelRes['quadMarkup'].'",sixMarkup="'.$HotelRes['sixMarkup'].'",eightMarkup="'.$HotelRes['eightMarkup'].'",tenMarkup="'.$HotelRes['tenMarkup'].'",teenMarkup="'.$HotelRes['teenMarkup'].'",cnbMarkup="'.$HotelRes['cnbMarkup'].'",exMarkup="'.$HotelRes['exMarkup'].'",mealMarkup="'.$HotelRes['mealMarkup'].'",paymentMode="'.$HotelRes['paymentMode'].'",agentCode="'.$HotelRes['agentCode'].'",fileNo="'.$HotelRes['fileNo'].'",confirmation="'.$HotelRes['confirmation'].'",arrivalBy="'.$HotelRes['arrivalBy'].'",departureBy="'.$HotelRes['departureBy'].'",specialRequest="'.$HotelRes['specialRequest'].'",remark="'.$HotelRes['remark'].'",tourManager="'.$HotelRes['tourManager'].'",harrivalon="'.$HotelRes['harrivalon'].'",hfrom="'.$HotelRes['hfrom'].'",hbyfrom="'.$HotelRes['hbyfrom'].'",hatfrom="'.$HotelRes['hatfrom'].'",hdepartureon="'.$HotelRes['hdepartureon'].'",hto="'.$HotelRes['hto'].'",hbyto="'.$HotelRes['hbyto'].'",hatto="'.$HotelRes['hatto'].'",supplementCostAdded="'.$HotelRes['supplementCostAdded'].'",isHotelSupplement="'.$HotelRes['isHotelSupplement'].'",isRoomSupplement="'.$HotelRes['isRoomSupplement'].'",hotelQuoteId="'.$HotelRes['hotelQuoteId'].'",rand_color="'.$HotelRes['rand_color'].'",escortHotelStatus="'.$HotelRes['escortHotelStatus'].'",breakfast="'.$HotelRes['breakfast'].'",extraBed="'.$HotelRes['extraBed'].'",roomGST="'.$HotelRes['roomGST'].'",mealGST="'.$HotelRes['mealGST'].'",TAC="'.$HotelRes['TAC'].'",complimentaryLunch="'.$HotelRes['complimentaryLunch'].'",complimentaryDinner="'.$HotelRes['complimentaryDinner'].'",complimentaryBreakfast="'.$HotelRes['complimentaryBreakfast'].'",isChildBreakfast="'.$HotelRes['isChildBreakfast'].'",isChildDinner="'.$HotelRes['isChildDinner'].'",isChildLunch="'.$HotelRes['isChildLunch'].'",startDayDate="'.$HotelRes['startDayDate'].'",endDayDate="'.$HotelRes['endDayDate'].'",singleNoofRoom="'.$HotelRes['singleNoofRoom'].'",doubleNoofRoom="'.$HotelRes['doubleNoofRoom'].'",twinNoofRoom="'.$HotelRes['twinNoofRoom'].'",tripleNoofRoom="'.$HotelRes['tripleNoofRoom'].'",childwithNoofBed="'.$HotelRes['childwithNoofBed'].'",childwithoutNoofBed="'.$HotelRes['childwithoutNoofBed'].'",extraNoofBed="'.$HotelRes['extraNoofBed'].'",isGuestType="'.$HotelRes['isGuestType'].'",isLocalEscort="'.$HotelRes['isLocalEscort'].'",isForeignEscort="'.$HotelRes['isForeignEscort'].'",isEarlyCheckin="'.$HotelRes['isEarlyCheckin'].'",sixNoofBedRoom="'.$HotelRes['sixNoofBedRoom'].'",eightNoofBedRoom="'.$HotelRes['eightNoofBedRoom'].'",tenNoofBedRoom="'.$HotelRes['tenNoofBedRoom'].'",quadNoofRoom="'.$HotelRes['quadNoofRoom'].'",teenNoofRoom="'.$HotelRes['teenNoofRoom'].'",sixBedRoom="'.$HotelRes['sixBedRoom'].'",eightBedRoom="'.$HotelRes['eightBedRoom'].'",tenBedRoom="'.$HotelRes['tenBedRoom'].'",quadRoom="'.$HotelRes['quadRoom'].'",teenRoom="'.$HotelRes['teenRoom'].'",childBreakfast="'.$HotelRes['childBreakfast'].'",childLunch="'.$HotelRes['childLunch'].'",childDinner="'.$HotelRes['childDinner'].'",isSelectedFinal=1';
					$addHotel = addlistinggetlastid(_QUOTATION_HOTEL_MASTER_,$namevalue); 

					$check_h=GetPageRecord('*','quotationItinerary',' queryId="'.$QueryDaysData['queryId'].'" and dayId="'.$adddays.'" and quotationId="'.$add.'" and serviceId="'.$HotelRes['supplierId'].'"');
					if(mysqli_num_rows($check_h)==0){
						$namevalue ='';
						$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$HotelRes['supplierId'].'",quotationId="'.$add.'",serviceType="hotel",startDate="'.$HotelRes['fromDate'].'",endDate="'.$HotelRes['fromDate'].'"';
						addlistinggetlastid('quotationItinerary',$namevalue);
					}

					// supplement
					$hotelSuppQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and hotelQuoteId="'.$HotelRes['id'].'" and (isRoomSupplement=1 or isHotelSupplement=1) order by id asc');
					while($hotelSuppD=mysqli_fetch_array($hotelSuppQuery)){
						$namevalue ='';
						$namevalue ='hotelName="'.$hotelSuppD['hotelName'].'",fromDate="'.$hotelSuppD['fromDate'].'",toDate="'.$hotelSuppD['toDate'].'",checkin="'.$hotelSuppD['checkin'].'",checkout="'.$hotelSuppD['checkout'].'",queryId="'.$hotelSuppD['queryId'].'",quotationId="'.$add.'",dayId="'.$adddays.'",destinationId="'.$hotelSuppD['destinationId'].'",categoryId="'.$hotelSuppD['categoryId'].'",roomTariffId="'.$hotelSuppD['roomTariffId'].'",currencyId="'.$hotelSuppD['currencyId'].'",currencyValue="'.$hotelSuppD['currencyValue'].'",supplierId="'.$hotelSuppD['supplierId'].'",supplierMasterId="'.$hotelSuppD['supplierMasterId'].'",mealPlan="'.$hotelSuppD['mealPlan'].'",night="'.$hotelSuppD['night'].'",status="'.$hotelSuppD['status'].'",address="'.$hotelSuppD['address'].'",roomprice="'.$hotelSuppD['roomprice'].'",noofrooms="'.$hotelSuppD['noofrooms'].'",roomType="'.$hotelSuppD['roomType'].'",tariffType="'.$hotelSuppD['tariffType'].'",quotTotalNight="'.$hotelSuppD['quotTotalNight'].'",hotelQuotatoinType="'.$hotelSuppD['hotelQuotatoinType'].'",singleoccupancy="'.$hotelSuppD['singleoccupancy'].'",doubleoccupancy="'.$hotelSuppD['doubleoccupancy'].'",twinoccupancy="'.$hotelSuppD['twinoccupancy'].'",tripleoccupancy="'.$hotelSuppD['tripleoccupancy'].'",quadoccupancy="'.$hotelSuppD['quadoccupancy'].'",childwithbed="'.$hotelSuppD['childwithbed'].'",childwithoutbed="'.$hotelSuppD['childwithoutbed'].'",lunch="'.$hotelSuppD['lunch'].'",dinner="'.$hotelSuppD['dinner'].'",extraadult="'.$hotelSuppD['extraadult'].'",paymentMode="'.$hotelSuppD['paymentMode'].'",agentCode="'.$hotelSuppD['agentCode'].'",fileNo="'.$hotelSuppD['fileNo'].'",confirmation="'.$hotelSuppD['confirmation'].'",arrivalBy="'.$hotelSuppD['arrivalBy'].'",departureBy="'.$hotelSuppD['departureBy'].'",specialRequest="'.$hotelSuppD['specialRequest'].'", taxType="'.$hotelSuppD['taxType'].'",markupType="'.$hotelSuppD['markupType'].'",sglMarkup="'.$hotelSuppD['sglMarkup'].'",dblMarkup="'.$hotelSuppD['dblMarkup'].'",twinMarkup="'.$hotelSuppD['twinMarkup'].'",tplMarkup="'.$hotelSuppD['tplMarkup'].'",cwbMarkup="'.$hotelSuppD['cwbMarkup'].'",quadMarkup="'.$hotelSuppD['quadMarkup'].'",sixMarkup="'.$hotelSuppD['sixMarkup'].'",eightMarkup="'.$hotelSuppD['eightMarkup'].'",tenMarkup="'.$hotelSuppD['tenMarkup'].'",teenMarkup="'.$hotelSuppD['teenMarkup'].'",cnbMarkup="'.$hotelSuppD['cnbMarkup'].'",exMarkup="'.$hotelSuppD['exMarkup'].'",mealMarkup="'.$hotelSuppD['mealMarkup'].'",remark="'.$hotelSuppD['remark'].'",tourManager="'.$hotelSuppD['tourManager'].'",supplementCostAdded="'.$hotelSuppD['supplementCostAdded'].'",isHotelSupplement="'.$hotelSuppD['isHotelSupplement'].'",isRoomSupplement="'.$hotelSuppD['isRoomSupplement'].'",rand_color="'.$hotelSuppD['rand_color'].'",hotelQuoteId="'.$addHotel.'",breakfast="'.$hotelSuppD['breakfast'].'",extraBed="'.$hotelSuppD['extraBed'].'",roomGST="'.$hotelSuppD['roomGST'].'",taxType="'.$hotelSuppD['taxType'].'",mealGST="'.$hotelSuppD['mealGST'].'",TAC="'.$hotelSuppD['TAC'].'",complimentaryLunch="'.$hotelSuppD['complimentaryLunch'].'",complimentaryDinner="'.$hotelSuppD['complimentaryDinner'].'",complimentaryBreakfast="'.$hotelSuppD['complimentaryBreakfast'].'",startDayDate="'.$hotelSuppD['startDayDate'].'",endDayDate="'.$hotelSuppD['endDayDate'].'",singleNoofRoom="'.$hotelSuppD['singleNoofRoom'].'",doubleNoofRoom="'.$hotelSuppD['doubleNoofRoom'].'",twinNoofRoom="'.$hotelSuppD['twinNoofRoom'].'",tripleNoofRoom="'.$hotelSuppD['tripleNoofRoom'].'",extraNoofBed="'.$hotelSuppD['extraNoofBed'].'",childwithNoofBed="'.$hotelSuppD['childwithNoofBed'].'",childwithoutNoofBed="'.$hotelSuppD['childwithoutNoofBed'].'",isGuestType="'.$hotelSuppD['isGuestType'].'",isLocalEscort="'.$hotelSuppD['isLocalEscort'].'",isForeignEscort="'.$hotelSuppD['isForeignEscort'].'",isEarlyCheckin="'.$hotelSuppD['isEarlyCheckin'].'",sixBedRoom="'.$hotelSuppD['sixBedRoom'].'",eightBedRoom="'.$hotelSuppD['eightBedRoom'].'",tenBedRoom="'.$hotelSuppD['tenBedRoom'].'",quadRoom="'.$hotelSuppD['quadRoom'].'",teenRoom="'.$hotelSuppD['teenRoom'].'",childBreakfast="'.$hotelSuppD['childBreakfast'].'",childDinner="'.$hotelSuppD['childDinner'].'",childLunch="'.$hotelSuppD['childLunch'].'",sixNoofBedRoom="'.$hotelSuppD['sixNoofBedRoom'].'",eightNoofBedRoom="'.$hotelSuppD['eightNoofBedRoom'].'",tenNoofBedRoom="'.$hotelSuppD['tenNoofBedRoom'].'",quadNoofRoom="'.$hotelSuppD['quadNoofRoom'].'",teenNoofRoom="'.$hotelSuppD['teenNoofRoom'].'",isChildBreakfast="'.$hotelSuppD['isChildBreakfast'].'",isChildLunch="'.$hotelSuppD['isChildLunch'].'",isChildDinner="'.$hotelSuppD['isChildDinner'].'"'; //hotelQuoteId
						$addSuppId = addlistinggetlastid(_QUOTATION_HOTEL_MASTER_,$namevalue);

						$check_h=GetPageRecord('*','quotationItinerary',' queryId="'.$QueryDaysData['queryId'].'" and dayId="'.$adddays.'" and quotationId="'.$add.'" and serviceId="'.$hotelSuppD['supplierId'].'"');
						if(mysqli_num_rows($check_h)==0 && $hotelSuppD['isHotelSupplement'] == 1){
							$namevalue ='';
							$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$hotelSuppD['supplierId'].'",quotationId="'.$add.'",serviceType="hotel",startDate="'.$hotelSuppD['fromDate'].'",endDate="'.$hotelSuppD['fromDate'].'"';
							addlistinggetlastid('quotationItinerary',$namevalue);
						}

					}

					
					$qhaQuery=GetPageRecord('*','quotationHotelAdditionalMaster','hotelQuotId="'.$HotelRes['id'].'"  and quotationId="'.$QueryDaysData['quotationId'].'" order by id asc');
					while($qhAData=mysqli_fetch_array($qhaQuery)){

						$namevalue ='quotationId="'.$add.'",dayId="'.$adddays.'",hotelId="'.$qhAData['hotelId'].'",additionalCost="'.$qhAData['additionalCost'].'",name="'.$qhAData['name'].'",hotelQuotId="'.$addHotel.'",additionalId="'.$qhAData['additionalId'].'",costType="'.$qhAData['costType'].'",queryId="'.$qhAData['queryId'].'",destinationId="'.$qhAData['destinationId'].'",fromDate="'.$qhAData['fromDate'].'",toDate="'.$qhAData['toDate'].'",currencyId="'.$qhAData['currencyId'].'",currencyValue="'.$qhAData['currencyValue'].'",rateId="'.$qhAData['rateId'].'"';
						addlistinggetlastid('quotationHotelAdditionalMaster',$namevalue);
					}
				}
				
				$b=''; 
				$b=GetPageRecord('*',_QUOTATION_TRANSFER_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="transfer" or serviceType="transportation" order by serviceId asc) order by id asc');
				if(mysqli_num_rows($b)>0){ 
					while($transferRes=mysqli_fetch_array($b)){
						
						$bb2='';
						$bb2=GetPageRecord('id','totalPaxSlab',' quotationId="'.$quotationId.'" and status=1');
						$paxSlabData2=mysqli_fetch_array($bb2);
						$totalPaxId = $paxSlabData2['id']; 
						$addHotel = '';

						$transfernamevalue ='fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",queryId="'.$maintable['queryId'].'",quotationId="'.$add.'",destinationId="'.$transferRes['destinationId'].'",transferNameId="'.$transferRes['transferNameId'].'",supplierId="'.$transferRes['supplierId'].'",vehicleId="'.$transferRes['vehicleId'].'",vehicleModelId="'.$transferRes['vehicleModelId'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",transferToId="'.$transferRes['transferToId'].'",transferFromId="'.$transferRes['transferFromId'].'",transferType="'.$transferRes['transferType'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",detail="'.$transferRes['detail'].'",vehicleCost="'.$transferRes['vehicleCost'].'",transferQuotatoinType="'.$transferRes['transferQuotatoinType'].'",dmcId="'.$transferRes['dmcId'].'",pickupFrom="'.$transferRes['pickupFrom'].'",pickupTime="'.$transferRes['pickupTime'].'",duration="'.$transferRes['duration'].'",vehicleMaxPax="'.$transferRes['vehicleMaxPax'].'",adMarkup="'.$transferRes['adMarkup'].'",chMarkup="'.$transferRes['chMarkup'].'",vehMarkup="'.$transferRes['vehMarkup'].'",remark="'.$transferRes['remark'].'",confirmation="'.$transferRes['confirmation'].'",tourManager="'.$transferRes['tourManager'].'",driverId="'.$transferRes['driverId'].'",vehicleType="'.$transferRes['vehicleType'].'",parkingFee="'.$transferRes['parkingFee'].'",representativeEntryFee="'.$transferRes['representativeEntryFee'].'",assistance="'.$transferRes['assistance'].'",guideAllowance="'.$transferRes['guideAllowance'].'",interStateAndToll="'.$transferRes['interStateAndToll'].'",miscellaneous="'.$transferRes['miscellaneous'].'",tariffId="'.$transferRes['tariffId'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",transferName="'.$transferRes['transferName'].'",noOfDays="'.$transferRes['noOfDays'].'",dayId="'.$adddays.'",serviceType="'.$transferRes['serviceType'].'",costType="'.$transferRes['costType'].'",noOfVehicles="'.$transferRes['noOfVehicles'].'",totalPax="'.$totalPaxId.'",isGuestType="'.$transferRes['isGuestType'].'"';

						$addHotel = addlistinggetlastid(_QUOTATION_TRANSFER_MASTER_,$transfernamevalue);
						 
						$c1=GetPageRecord('*','quotationTransferTimelineDetails','transferQuoteId="'.$transferRes['id'].'" ');
						if(mysqli_num_rows($c1)>0){
							$transferTimelineData=mysqli_fetch_array($c1);

								$namevalue ='quotationId="'.$add.'",dayId="'.$adddays.'",supplierId="'.$transferTimelineData['supplierId'].'",transferQuoteId="'.$addHotel.'",arrivalFrom="'.$transferTimelineData['arrivalFrom'].'",trainName="'.$transferTimelineData['trainName'].'",trainNumber="'.$transferTimelineData['trainNumber'].'",flightName="'.$transferTimelineData['flightName'].'",flightNumber="'.$transferTimelineData['flightNumber'].'",vehicleName="'.$transferTimelineData['vehicleName'].'",airportName="'.$transferTimelineData['airportName'].'",pickupAddress="'.$transferTimelineData['pickupAddress'].'",dropAddress="'.$transferTimelineData['dropAddress'].'",VehicleModel="'.$transferTimelineData['VehicleModel'].'",arrivalTime="'.$transferTimelineData['arrivalTime'].'",dropTime="'.$transferTimelineData['dropTime'].'",mode="'.$transferTimelineData['mode'].'",pickupTime="'.$transferTimelineData['pickupTime'].'"';
			          
			          $hotelSupHot = addlistinggetlastid('quotationTransferTimelineDetails',$namevalue);
						}

						$namevalue ='';
						$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="'.$transferRes['serviceType'].'",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
						addlistinggetlastid('quotationItinerary',$namevalue);
					}
				}

				 
				$b=GetPageRecord('*','quotationGuideMaster',' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="guide" order by serviceId asc) and isGuestType=1 order by id asc');
				while($transferRes=mysqli_fetch_array($b)){

					$bb2='';
					$bb2=GetPageRecord('id','totalPaxSlab',' quotationId="'.$add.'" and status=1');
					$paxSlabData2=mysqli_fetch_array($bb2);
					$totalPaxId = $paxSlabData2['id']; 
					
					$addHotel =''; 
					$transfernamevalue ='guideId="'.$transferRes['guideId'].'",slabId="'.$totalPaxId.'",price="'.$transferRes['price'].'",guideName="'.$transferRes['guideName'].'",queryId="'.$maintable['queryId'].'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",quotationId="'.$add.'",srn="'.$transferRes['srn'].'",destinationId="'.$transferRes['destinationId'].'",rules="'.$transferRes['rules'].'",category="'.$transferRes['category'].'",subcategory="'.$transferRes['subcategory'].'",totalDays="'.$transferRes['totalDays'].'",perDaycost="'.$transferRes['perDaycost'].'",serviceType="'.$transferRes['serviceType'].'",tariffId="'.$transferRes['tariffId'].'",supplierId="'.$transferRes['supplierId'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",guideQuoteId="'.$transferRes['guideQuoteId'].'",isGuestType="'.$transferRes['isGuestType'].'",isSupplement="'.$transferRes['isSupplement'].'",isSelectedFinal=1,paxRange="'.$transferRes['paxRange'].'",dayType="'.$transferRes['dayType'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",dayId="'.$adddays.'"';

					$addHotel = addlistinggetlastid('quotationGuideMaster',$transfernamevalue);

					$bSupp=GetPageRecord('*','quotationGuideMaster',' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'"  and guideQuoteId="'.$transferRes['id'].'" and isSupplement=1 order by id asc');
					while($transferSuppRes=mysqli_fetch_array($bSupp)){
						$suppGuidevalue ='guideId="'.$transferSuppRes['guideId'].'",slabId="'.$totalPaxId.'",price="'.$transferSuppRes['price'].'",guideName="'.$transferSuppRes['guideName'].'",queryId="'.$maintable['queryId'].'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",supplierId="'.$transferSuppRes['supplierId'].'",tariffId="'.$transferSuppRes['tariffId'].'",quotationId="'.$add.'",srn="'.$transferSuppRes['srn'].'",destinationId="'.$transferSuppRes['destinationId'].'",rules="'.$transferSuppRes['rules'].'",category="'.$transferSuppRes['category'].'",subcategory="'.$transferSuppRes['subcategory'].'",totalDays="'.$transferSuppRes['totalDays'].'",perDaycost="'.$transferSuppRes['perDaycost'].'",serviceType="'.$transferSuppRes['serviceType'].'",currencyId="'.$transferSuppRes['currencyId'].'",currencyValue="'.$transferSuppRes['currencyValue'].'",guideQuoteId="'.$addHotel.'",isGuestType="'.$transferSuppRes['isGuestType'].'",isSupplement="'.$transferSuppRes['isSupplement'].'",isSelectedFinal="'.$transferSuppRes['isSelectedFinal'].'",paxRange="'.$transferSuppRes['paxRange'].'",dayType="'.$transferSuppRes['dayType'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",dayId="'.$adddays.'"';
			
						$addSuppHotel = addlistinggetlastid('quotationGuideMaster',$suppGuidevalue);
					}

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="guide",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				} 

				$b=GetPageRecord('*',_QUOTATION_OTHER_ACTIVITY_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="activity" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){

					$addHotel = '';
					$transfernamevalue ='otherActivityName="'.$transferRes['otherActivityName'].'",transferType="'.$transferRes['transferType'].'",dateotherActivity="'.$transferRes['dateotherActivity'].'",queryId="'.$transferRes['queryId'].'",quotationId="'.$add.'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",groupCost="'.$transferRes['groupCost'].'",otherActivityCity="'.$transferRes['otherActivityCity'].'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",activityCost="'.$transferRes['activityCost'].'",maxpax="'.$transferRes['maxpax'].'",perPaxCost="'.$transferRes['perPaxCost'].'",tariffId="'.$transferRes['tariffId'].'",supplierId="'.$transferRes['supplierId'].'",quotationOtherActivitymaster="'.$transferRes['quotationOtherActivitymaster'].'",currencyId="'.$transferRes['currencyId'].'",vehicleId="'.$transferRes['vehicleId'].'",vehicleCost="'.$transferRes['vehicleCost'].'",noOfVehicles="'.$transferRes['noOfVehicles'].'",repCost="'.$transferRes['repCost'].'",ticketAdultCost="'.$transferRes['ticketAdultCost'].'",ticketchildCost="'.$transferRes['ticketchildCost'].'",ticketinfantCost="'.$transferRes['ticketinfantCost'].'",currencyValue="'.$transferRes['currencyValue'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",dayId="'.$adddays.'"';
					$addHotel = addlistinggetlastid(_QUOTATION_OTHER_ACTIVITY_MASTER_,$transfernamevalue);
						
					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="activity",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);
						
					$c1="";
					$c1=GetPageRecord('*','quotationActivityTimelineDetails',' hotelQuoteId="'.$transferRes['id'].'"');  
					if(mysqli_num_rows($c1)>0){
						$transferTimelineData=mysqli_fetch_array($c1); 
						 $namevalue ='quotationId="'.$add.'",dayId="'.$adddays.'",hotelQuoteId="'.$addHotel.'",supplierId="'.$transferTimelineData['supplierId'].'",startTime="'.$transferTimelineData['startTime'].'",endTime="'.$transferTimelineData['endTime'].'"';
						 $entraceTimeId = addlistinggetlastid('quotationActivityTimelineDetails',$namevalue);
						
					}

				}
				$b=GetPageRecord('*','quotationEnrouteMaster',' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="enroute" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){
					$addHotel ='';

					$transfernamevalue ='enrouteId="'.$transferRes['enrouteId'].'",queryId="'.$transferRes['queryId'].'",quotationId="'.$add.'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",destinationId="'.$transferRes['destinationId'].'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",dayId="'.$adddays.'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'"';
					$addHotel = addlistinggetlastid('quotationEnrouteMaster',$transfernamevalue);

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="enroute",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				}

				$b=''; 
				$b=GetPageRecord('*',_QUOTATION_FERRY_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="ferry" order by serviceId asc) order by id asc');
				if(mysqli_num_rows($b)>0){ 
					while($ferryData=mysqli_fetch_array($b)){
						
						$feryyQId = '';
						$ferrynamevalue ='pickupTime="'.$ferryData['pickupTime'].'",dropTime="'.$ferryData['dropTime'].'",fromDate="'.$ferryData['fromDate'].'",toDate="'.$ferryData['toDate'].'",queryId="'.$maintable['queryId'].'",quotationId="'.$add.'",destinationId="'.$ferryData['destinationId'].'",serviceid="'.$ferryData['serviceid'].'",ferryNameId="'.$ferryData['ferryNameId'].'",supplierId="'.$ferryData['supplierId'].'",ferryClass="'.$ferryData['ferryClass'].'",currencyId="'.$ferryData['currencyId'].'",currencyValue="'.$ferryData['currencyValue'].'",adultCost="'.$ferryData['adultCost'].'",childCost="'.$ferryData['childCost'].'",infantCost="'.$ferryData['infantCost'].'",ferryCost="'.$ferryData['ferryCost'].'",remark="'.$ferryData['remark'].'",processingfee="'.$ferryData['processingfee'].'",miscCost="'.$ferryData['miscCost'].'",rateId="'.$ferryData['rateId'].'",markupType="'.$ferryData['markupType'].'",markupCost="'.$ferryData['markupCost'].'",taxType="'.$ferryData['taxType'].'",gstTax="'.$ferryData['gstTax'].'",dayId="'.$adddays.'"';
						$feryyQId = addlistinggetlastid(_QUOTATION_FERRY_MASTER_,$ferrynamevalue);
						 
						$namevalue ='';
						$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$feryyQId.'",quotationId="'.$add.'",serviceType="ferry",startDate="'.$ferryData['fromDate'].'",endDate="'.$ferryData['fromDate'].'"';
						addlistinggetlastid('quotationItinerary',$namevalue);
					}
				}

				$b=GetPageRecord('*','quotationEntranceMaster','quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="entrance" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){

					$addHotel = '';
					// transferType
					$transfernamevalue ='entranceNameId="'.$transferRes['entranceNameId'].'",quotationId="'.$add.'",destinationId="'.$transferRes['destinationId'].'",dmcId="'.$transferRes['dmcId'].'",vehicleId="'.$transferRes['vehicleId'].'",repCost="'.$transferRes['repCost'].'",supplierId="'.$transferRes['supplierId'].'",transferType="'.$transferRes['transferType'].'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",ticketAdultCost="'.$transferRes['ticketAdultCost'].'",ticketchildCost="'.$transferRes['ticketchildCost'].'",ticketinfantCost="'.$transferRes['ticketinfantCost'].'",entranceType="'.$transferRes['entranceType'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",detail="'.$transferRes['detail'].'",vehicleCost="'.$transferRes['vehicleCost'].'",noOfVehicles="'.$transferRes['noOfVehicles'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",entranceQuotatoinType="'.$transferRes['entranceQuotatoinType'].'",pickupTime="'.$transferRes['pickupTime'].'",pickupFrom="'.$transferRes['pickupFrom'].'",duration="'.$transferRes['duration'].'",vehicleMaxPax="'.$transferRes['vehicleMaxPax'].'",adMarkup="'.$transferRes['adMarkup'].'",chMarkup="'.$transferRes['chMarkup'].'",remark="'.$transferRes['remark'].'",confirmation="'.$transferRes['confirmation'].'",tourManager="'.$transferRes['tourManager'].'",guideCost="'.$transferRes['guideCost'].'",queryId="'.$maintable['queryId'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",dayId="'.$adddays.'"';
					$addHotel = addlistinggetlastid('quotationEntranceMaster',$transfernamevalue);

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="entrance",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);
					
					$c1="";
					$c1=GetPageRecord('*','quotationEntranceTimelineDetails','  hotelQuoteId="'.$transferRes['id'].'"');  
					if(mysqli_num_rows($c1)>0){
						$transferTimelineData=mysqli_fetch_array($c1);

						 $namevalue ='quotationId="'.$add.'",dayId="'.$adddays.'",hotelQuoteId="'.$addHotel.'",supplierId="'.$transferTimelineData['supplierId'].'",startTime="'.$transferTimelineData['startTime'].'",endTime="'.$transferTimelineData['endTime'].'",pickupTime="'.$transferTimelineData['pickupTime'].'",dropTime="'.$transferTimelineData['dropTime'].'",pickupAddress="'.$transferTimelineData['pickupAddress'].'",dropAddress="'.$transferTimelineData['dropAddress'].'"';
						 $entraceTimeId = addlistinggetlastid('quotationEntranceTimelineDetails',$namevalue);
					}
					
				}
 
				$b=GetPageRecord('*',_QUOTATION_INBOUND_MEAL_PLAN_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="mealplan" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){
					$addHotel = '';
					$transfernamevalue ='mealPlanName="'.$transferRes['mealPlanName'].'",mealPlanNameId="'.$transferRes['mealPlanNameId'].'",quotationId="'.$add.'",dateMealPlan="'.$transferRes['dateMealPlan'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",groupCost="'.$transferRes['groupCost'].'",mealPlanCity="'.$transferRes['mealPlanCity'].'",mealType="'.$transferRes['mealType'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",destinationId="'.$transferRes['destinationId'].'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",queryId="'.$maintable['queryId'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",dayId="'.$adddays.'"';
					$addHotel = addlistinggetlastid(_QUOTATION_INBOUND_MEAL_PLAN_MASTER_,$transfernamevalue);

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="mealplan",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				} 

				$b=GetPageRecord('*',_QUOTATION_FLIGHT_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="flight" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){
					$addHotel = '';
					$transfernamevalue ='fromDate="'.$transferRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$transferRes['toDate'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",flightId="'.$transferRes['flightId'].'",arrivalTo="'.$transferRes['arrivalTo'].'",departureFrom="'.$transferRes['departureFrom'].'",departureDate="'.$transferRes['departureDate'].'",arrivalDate="'.$transferRes['arrivalDate'].'",departureTime="'.$transferRes['departureTime'].'",arrivalTime="'.$transferRes['arrivalTime'].'",destinationId="'.$transferRes['destinationId'].'",flightNumber="'.$transferRes['flightNumber'].'",flightClass="'.$transferRes['flightClass'].'",queryId="'.$maintable['queryId'].'",dayId="'.$adddays.'",isGuestType="'.$transferRes['isGuestType'].'",isLocalEscort="'.$transferRes['isLocalEscort'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",adult="'.$transferRes['adult'].'",child="'.$transferRes['child'].'",infant="'.$transferRes['infant'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",isForeignEscort="'.$transferRes['isForeignEscort'].'"';
					$addHotel = addlistinggetlastid(_QUOTATION_FLIGHT_MASTER_,$transfernamevalue);
					
					$c1 ='';
					$c1=GetPageRecord('*','flightTimeLineMaster',' flightQuoteId="'.$transferRes['id'].'" and quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'"');
					if(mysqli_num_rows($c1)>0){
					$timeData = mysqli_fetch_assoc($c1);
						$timeValue = 'quotationId="'.$add.'",flightQuoteId="'.$addHotel.'",dayId="'.$adddays.'",flightId="'.$timeData['flightId'].'",departureDate="'.$timeData['departureDate'].'",departureTime="'.$timeData['departureTime'].'",arrivalDate="'.$timeData['arrivalDate'].'",arrivalTime="'.$timeData['arrivalTime'].'",status="'.$timeData['status'].'",deletestatus="'.$timeData['deletestatus'].'",remark="'.$timeData['remark'].'",via="'.$timeData['via'].'",queryId="'.$maintable['queryId'].'"';
						$addTime = addlistinggetlastid('flightTimeLineMaster',$timeValue);
					}

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="flight",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				}

				$b=GetPageRecord('*',_QUOTATION_TRAINS_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="train" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){
					$addHotel = '';
					$transfernamevalue ='fromDate="'.$transferRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$transferRes['toDate'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",trainId="'.$transferRes['trainId'].'",arrivalTo="'.$transferRes['arrivalTo'].'",departureFrom="'.$transferRes['departureFrom'].'",departureDate="'.$transferRes['departureDate'].'",arrivalDate="'.$transferRes['arrivalDate'].'",departureTime="'.$transferRes['departureTime'].'",arrivalTime="'.$transferRes['arrivalTime'].'",journeyType="'.$transferRes['journeyType'].'",destinationId="'.$transferRes['destinationId'].'",trainNumber="'.$transferRes['trainNumber'].'",trainClass="'.$transferRes['trainClass'].'",queryId="'.$maintable['queryId'].'",dayId="'.$adddays.'",isGuestType="'.$transferRes['isGuestType'].'",isLocalEscort="'.$transferRes['isLocalEscort'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",isForeignEscort="'.$transferRes['isForeignEscort'].'"';
					$addHotel = addlistinggetlastid(_QUOTATION_TRAINS_MASTER_,$transfernamevalue);

					$c1 ='';
					$c1=GetPageRecord('*','trainTimeLineMaster',' trainQuoteId="'.$transferRes['id'].'" and quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'"');
					if(mysqli_num_rows($c1)>0){
					$timeData = mysqli_fetch_assoc($c1);
						$timeValue = 'quotationId="'.$add.'",trainQuoteId="'.$addHotel.'",dayId="'.$adddays.'",trainId="'.$timeData['trainId'].'",departureDate="'.$timeData['departureDate'].'",departureTime="'.$timeData['departureTime'].'",arrivalDate="'.$timeData['arrivalDate'].'",arrivalTime="'.$timeData['arrivalTime'].'",status="'.$timeData['status'].'",deletestatus="'.$timeData['deletestatus'].'",remark="'.$timeData['remark'].'",queryId="'.$maintable['queryId'].'"';
						$addTime = addlistinggetlastid('trainTimeLineMaster',$timeValue);
					}

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="train",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				}


				$b='';
				$b=GetPageRecord('*',_QUOTATION_EXTRA_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="additional" order by serviceId asc) order by id asc');
				if(mysqli_num_rows($b)>0){

					while($transferRes=mysqli_fetch_array($b)){
						$addHotel = '';
						$transfernamevalue ='name="'.$transferRes['name'].'",dateExtra="'.$transferRes['dateExtra'].'",queryId="'.$maintable['queryId'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",groupCost="'.$transferRes['groupCost'].'",destinationId="'.$transferRes['destinationId'].'",quotationId="'.$add.'",fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",additionalId="'.$transferRes['additionalId'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",costType="'.$transferRes['costType'].'",dayId="'.$adddays.'"';

						$addHotel = addlistinggetlastid(_QUOTATION_EXTRA_MASTER_,$transfernamevalue);


						$namevalue ='';
						$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="additional",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
						addlistinggetlastid('quotationItinerary',$namevalue);

					}
				}

				$quotationMode=GetPageRecord('*','quotationModeMaster','quotationId="'.$maintable['id'].'" and queryId="'.$QueryDaysData['queryId'].'" order by id asc');
				while($quotationModeData=mysqli_fetch_array($quotationMode)){

					$namevalue ='quotationId="'.$add.'",dayId="'.$adddays.'",name="'.$quotationModeData['name'].'",queryId="'.$QueryDaysData['queryId'].'" ';
					addlistinggetlastid('quotationModeMaster',$namevalue);
				}


			}
			// New quotation days loop end
			// For Multiple services Quotation
			if($maintable['queryType']==13){
				$b=GetPageRecord('*',_QUOTATION_FLIGHT_MASTER_,' quotationId="'.$maintable['id'].'" and id in (select serviceId from quotationItinerary where serviceType="flight" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){
					$addHotel = '';
					$transfernamevalue ='fromDate="'.$transferRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$transferRes['toDate'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",flightId="'.$transferRes['flightId'].'",arrivalTo="'.$transferRes['arrivalTo'].'",departureFrom="'.$transferRes['departureFrom'].'",departureDate="'.$transferRes['departureDate'].'",arrivalDate="'.$transferRes['arrivalDate'].'",departureTime="'.$transferRes['departureTime'].'",arrivalTime="'.$transferRes['arrivalTime'].'",destinationId="'.$transferRes['destinationId'].'",flightNumber="'.$transferRes['flightNumber'].'",flightClass="'.$transferRes['flightClass'].'",queryId="'.$maintable['queryId'].'",dayId="'.$adddays.'",isGuestType="'.$transferRes['isGuestType'].'",isLocalEscort="'.$transferRes['isLocalEscort'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",adult="'.$transferRes['adult'].'",child="'.$transferRes['child'].'",infant="'.$transferRes['infant'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",isForeignEscort="'.$transferRes['isForeignEscort'].'"';
					$addHotel = addlistinggetlastid(_QUOTATION_FLIGHT_MASTER_,$transfernamevalue);
					
					$c1 ='';
					$c1=GetPageRecord('*','flightTimeLineMaster',' flightQuoteId="'.$transferRes['id'].'" and quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'"');
					if(mysqli_num_rows($c1)>0){
					$timeData = mysqli_fetch_assoc($c1);
						$timeValue = 'quotationId="'.$add.'",flightQuoteId="'.$addHotel.'",dayId="'.$adddays.'",flightId="'.$timeData['flightId'].'",departureDate="'.$timeData['departureDate'].'",departureTime="'.$timeData['departureTime'].'",arrivalDate="'.$timeData['arrivalDate'].'",arrivalTime="'.$timeData['arrivalTime'].'",status="'.$timeData['status'].'",deletestatus="'.$timeData['deletestatus'].'",remark="'.$timeData['remark'].'",via="'.$timeData['via'].'",queryId="'.$maintable['queryId'].'"';
						$addTime = addlistinggetlastid('flightTimeLineMaster',$timeValue);
					}

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$maintable['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="flight",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				}

				$b=GetPageRecord('*',_QUOTATION_TRAINS_MASTER_,' quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'" and id in (select serviceId from quotationItinerary where serviceType="train" order by serviceId asc) order by id asc');
				while($transferRes=mysqli_fetch_array($b)){
					$addHotel = '';
					$transfernamevalue ='fromDate="'.$transferRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$transferRes['toDate'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",trainId="'.$transferRes['trainId'].'",arrivalTo="'.$transferRes['arrivalTo'].'",departureFrom="'.$transferRes['departureFrom'].'",departureDate="'.$transferRes['departureDate'].'",arrivalDate="'.$transferRes['arrivalDate'].'",departureTime="'.$transferRes['departureTime'].'",arrivalTime="'.$transferRes['arrivalTime'].'",journeyType="'.$transferRes['journeyType'].'",destinationId="'.$transferRes['destinationId'].'",trainNumber="'.$transferRes['trainNumber'].'",trainClass="'.$transferRes['trainClass'].'",queryId="'.$maintable['queryId'].'",dayId="'.$adddays.'",isGuestType="'.$transferRes['isGuestType'].'",isLocalEscort="'.$transferRes['isLocalEscort'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",isForeignEscort="'.$transferRes['isForeignEscort'].'"';
					$addHotel = addlistinggetlastid(_QUOTATION_TRAINS_MASTER_,$transfernamevalue);

					$c1 ='';
					$c1=GetPageRecord('*','trainTimeLineMaster',' trainQuoteId="'.$transferRes['id'].'" and quotationId="'.$maintable['id'].'" and dayId="'.$QueryDaysData['id'].'"');
					if(mysqli_num_rows($c1)>0){
					$timeData = mysqli_fetch_assoc($c1);
						$timeValue = 'quotationId="'.$add.'",trainQuoteId="'.$addHotel.'",dayId="'.$adddays.'",trainId="'.$timeData['trainId'].'",departureDate="'.$timeData['departureDate'].'",departureTime="'.$timeData['departureTime'].'",arrivalDate="'.$timeData['arrivalDate'].'",arrivalTime="'.$timeData['arrivalTime'].'",status="'.$timeData['status'].'",deletestatus="'.$timeData['deletestatus'].'",remark="'.$timeData['remark'].'",queryId="'.$maintable['queryId'].'"';
						$addTime = addlistinggetlastid('trainTimeLineMaster',$timeValue);
					}

					$namevalue ='';
					$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$maintable['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="train",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
					addlistinggetlastid('quotationItinerary',$namevalue);

				}


				// Transfer service Copy
				$b=''; 
				$b=GetPageRecord('*',_QUOTATION_TRANSFER_MASTER_,' quotationId="'.$maintable['id'].'" and id in (select serviceId from quotationItinerary where serviceType="transfer" order by serviceId asc) order by id asc');
				if(mysqli_num_rows($b)>0){ 
					while($transferRes=mysqli_fetch_array($b)){
						
						$bb2='';
						$bb2=GetPageRecord('id','totalPaxSlab',' quotationId="'.$quotationId.'" and status=1');
						$paxSlabData2=mysqli_fetch_array($bb2);
						$totalPaxId = $paxSlabData2['id']; 
						$addHotel = '';

						$transfernamevalue ='fromDate="'.$transferRes['fromDate'].'",toDate="'.$transferRes['toDate'].'",queryId="'.$maintable['queryId'].'",quotationId="'.$add.'",destinationId="'.$transferRes['destinationId'].'",transferNameId="'.$transferRes['transferNameId'].'",supplierId="'.$transferRes['supplierId'].'",vehicleId="'.$transferRes['vehicleId'].'",vehicleModelId="'.$transferRes['vehicleModelId'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",transferToId="'.$transferRes['transferToId'].'",transferFromId="'.$transferRes['transferFromId'].'",transferType="'.$transferRes['transferType'].'",adultCost="'.$transferRes['adultCost'].'",childCost="'.$transferRes['childCost'].'",infantCost="'.$transferRes['infantCost'].'",detail="'.$transferRes['detail'].'",vehicleCost="'.$transferRes['vehicleCost'].'",transferQuotatoinType="'.$transferRes['transferQuotatoinType'].'",dmcId="'.$transferRes['dmcId'].'",pickupFrom="'.$transferRes['pickupFrom'].'",pickupTime="'.$transferRes['pickupTime'].'",duration="'.$transferRes['duration'].'",vehicleMaxPax="'.$transferRes['vehicleMaxPax'].'",adMarkup="'.$transferRes['adMarkup'].'",chMarkup="'.$transferRes['chMarkup'].'",vehMarkup="'.$transferRes['vehMarkup'].'",remark="'.$transferRes['remark'].'",confirmation="'.$transferRes['confirmation'].'",tourManager="'.$transferRes['tourManager'].'",driverId="'.$transferRes['driverId'].'",vehicleType="'.$transferRes['vehicleType'].'",parkingFee="'.$transferRes['parkingFee'].'",representativeEntryFee="'.$transferRes['representativeEntryFee'].'",assistance="'.$transferRes['assistance'].'",guideAllowance="'.$transferRes['guideAllowance'].'",interStateAndToll="'.$transferRes['interStateAndToll'].'",miscellaneous="'.$transferRes['miscellaneous'].'",tariffId="'.$transferRes['tariffId'].'",markupType="'.$transferRes['markupType'].'",markupCost="'.$transferRes['markupCost'].'",taxType="'.$transferRes['taxType'].'",gstTax="'.$transferRes['gstTax'].'",transferName="'.$transferRes['transferName'].'",noOfDays="'.$transferRes['noOfDays'].'",dayId="'.$adddays.'",serviceType="'.$transferRes['serviceType'].'",costType="'.$transferRes['costType'].'",noOfVehicles="'.$transferRes['noOfVehicles'].'",totalPax="'.$totalPaxId.'",isGuestType="'.$transferRes['isGuestType'].'"';

						$addHotel = addlistinggetlastid(_QUOTATION_TRANSFER_MASTER_,$transfernamevalue);
						 
						$c1=GetPageRecord('*','quotationTransferTimelineDetails','transferQuoteId="'.$transferRes['id'].'" ');
						if(mysqli_num_rows($c1)>0){
							$transferTimelineData=mysqli_fetch_array($c1);

								$namevalue ='quotationId="'.$add.'",dayId="'.$adddays.'",supplierId="'.$transferTimelineData['supplierId'].'",transferQuoteId="'.$addHotel.'",arrivalFrom="'.$transferTimelineData['arrivalFrom'].'",trainName="'.$transferTimelineData['trainName'].'",trainNumber="'.$transferTimelineData['trainNumber'].'",flightName="'.$transferTimelineData['flightName'].'",flightNumber="'.$transferTimelineData['flightNumber'].'",vehicleName="'.$transferTimelineData['vehicleName'].'",airportName="'.$transferTimelineData['airportName'].'",pickupAddress="'.$transferTimelineData['pickupAddress'].'",dropAddress="'.$transferTimelineData['dropAddress'].'",VehicleModel="'.$transferTimelineData['VehicleModel'].'",arrivalTime="'.$transferTimelineData['arrivalTime'].'",dropTime="'.$transferTimelineData['dropTime'].'",mode="'.$transferTimelineData['mode'].'",pickupTime="'.$transferTimelineData['pickupTime'].'"';
			          
			          $hotelSupHot = addlistinggetlastid('quotationTransferTimelineDetails',$namevalue);
						}

						$namevalue ='';
						$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$maintable['queryId'].'",serviceId="'.$addHotel.'",quotationId="'.$add.'",serviceType="'.$transferRes['serviceType'].'",startDate="'.$transferRes['fromDate'].'",endDate="'.$transferRes['fromDate'].'"';
						addlistinggetlastid('quotationItinerary',$namevalue);
					}
				}
			}
			
			$b=GetPageRecord('*',_QUOTATION_VISA_MASTER_,' quotationId="'.$maintable['id'].'" and id in (select serviceId from quotationItinerary where serviceType="visa" order by serviceId asc) order by id asc');
			while($visaRes=mysqli_fetch_array($b)){
				$addVisa = '';
				$visanamevalue ='fromDate="'.$visaRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$visaRes['toDate'].'",adultCost="'.$visaRes['adultCost'].'",childCost="'.$visaRes['childCost'].'",serviceid="'.$visaRes['serviceid'].'",name="'.$visaRes['name'].'",rateId="'.$visaRes['rateId'].'",visaTypeId="'.$visaRes['visaTypeId'].'",supplierId="'.$visaRes['supplierId'].'",startDate="'.$visaRes['startDate'].'",currencyId="'.$visaRes['currencyId'].'",currencyValue="'.$visaRes['currencyValue'].'",gstTax="'.$visaRes['gstTax'].'",infantCost="'.$visaRes['infantCost'].'",adultPax="'.$visaRes['adultPax'].'",childPax="'.$visaRes['childPax'].'",infantPax="'.$visaRes['infantPax'].'",queryId="'.$maintable['queryId'].'",markupType="'.$visaRes['markupType'].'",processingFee="'.$visaRes['processingFee'].'",vfsCharges="'.$visaRes['vfsCharges'].'",embassyFee="'.$visaRes['embassyFee'].'",status="'.$visaRes['status'].'",deletestatus="'.$visaRes['deletestatus'].'",addedBy="'.$visaRes['addedBy'].'",dateAdded="'.$visaRes['dateAdded'].'",modifyBy="'.$visaRes['modifyBy'].'",modifyDate="'.$visaRes['modifyDate'].'",visaDate="'.$visaRes['visaDate'].'",visaCountryId="'.$visaRes['visaCountryId'].'",visaValidity="'.$visaRes['visaValidity'].'",entryType="'.$visaRes['entryType'].'"';
				$addVisa = addlistinggetlastid(_QUOTATION_VISA_MASTER_,$visanamevalue);
				
				$namevalue ='';
				$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addVisa.'",quotationId="'.$add.'",serviceType="visa",startDate="'.$visaRes['fromDate'].'",endDate="'.$visaRes['toDate'].'"';
				addlistinggetlastid('quotationItinerary',$namevalue);

			}

			$b=GetPageRecord('*',_QUOTATION_PASSPORT_MASTER_,' quotationId="'.$maintable['id'].'" and id in (select serviceId from quotationItinerary where serviceType="passport" order by serviceId asc) order by id asc');
			while($passportRes=mysqli_fetch_array($b)){
				$addPass = '';
				$passnamevalue ='fromDate="'.$passportRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$passportRes['toDate'].'",adultCost="'.$passportRes['adultCost'].'",childCost="'.$passportRes['childCost'].'",serviceid="'.$passportRes['serviceid'].'",name="'.$passportRes['name'].'",rateId="'.$passportRes['rateId'].'",passportTypeId="'.$passportRes['passportTypeId'].'",supplierId="'.$passportRes['supplierId'].'",startDate="'.$passportRes['startDate'].'",currencyId="'.$passportRes['currencyId'].'",currencyValue="'.$passportRes['currencyValue'].'",gstTax="'.$passportRes['gstTax'].'",infantCost="'.$passportRes['infantCost'].'",adultPax="'.$passportRes['adultPax'].'",childPax="'.$passportRes['childPax'].'",infantPax="'.$passportRes['infantPax'].'",queryId="'.$maintable['queryId'].'",markupType="'.$passportRes['markupType'].'",processingFee="'.$passportRes['processingFee'].'",status="'.$passportRes['status'].'",deletestatus="'.$passportRes['deletestatus'].'",addedBy="'.$passportRes['addedBy'].'",dateAdded="'.$passportRes['dateAdded'].'",modifyBy="'.$passportRes['modifyBy'].'",modifyDate="'.$passportRes['modifyDate'].'"';
				$addPass = addlistinggetlastid(_QUOTATION_PASSPORT_MASTER_,$passnamevalue);
				
				$namevalue ='';
				$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addPass.'",quotationId="'.$add.'",serviceType="passport",startDate="'.$passportRes['fromDate'].'",endDate="'.$passportRes['toDate'].'"';
				addlistinggetlastid('quotationItinerary',$namevalue);

			}

			$b=GetPageRecord('*',_QUOTATION_INSURANCE_MASTER_,' quotationId="'.$maintable['id'].'" and id in (select serviceId from quotationItinerary where serviceType="insurance" order by serviceId asc) order by id asc');
			while($insuranceRes=mysqli_fetch_array($b)){
				$addInsurance = '';
				$insurancenamevalue ='fromDate="'.$insuranceRes['fromDate'].'",quotationId="'.$add.'",toDate="'.$insuranceRes['toDate'].'",adultCost="'.$insuranceRes['adultCost'].'",childCost="'.$insuranceRes['childCost'].'",serviceid="'.$insuranceRes['serviceid'].'",name="'.$insuranceRes['name'].'",rateId="'.$insuranceRes['rateId'].'",insuranceTypeId="'.$insuranceRes['insuranceTypeId'].'",supplierId="'.$insuranceRes['supplierId'].'",startDate="'.$insuranceRes['startDate'].'",currencyId="'.$insuranceRes['currencyId'].'",currencyValue="'.$insuranceRes['currencyValue'].'",gstTax="'.$insuranceRes['gstTax'].'",infantCost="'.$insuranceRes['infantCost'].'",adultPax="'.$insuranceRes['adultPax'].'",childPax="'.$insuranceRes['childPax'].'",infantPax="'.$insuranceRes['infantPax'].'",queryId="'.$maintable['queryId'].'",markupType="'.$insuranceRes['markupType'].'",processingFee="'.$insuranceRes['processingFee'].'",status="'.$insuranceRes['status'].'",deletestatus="'.$insuranceRes['deletestatus'].'",addedBy="'.$insuranceRes['addedBy'].'",dateAdded="'.$insuranceRes['dateAdded'].'",modifyBy="'.$insuranceRes['modifyBy'].'",modifyDate="'.$insuranceRes['modifyDate'].'",insuranceStartDate="'.$insuranceRes['insuranceStartDate'].'",insuranceEndDate="'.$insuranceRes['insuranceEndDate'].'",countryId="'.$insuranceRes['countryId'].'"';
				$addInsurance = addlistinggetlastid(_QUOTATION_INSURANCE_MASTER_,$insurancenamevalue);
				
				$namevalue ='';
				$namevalue ='srn="'.$adddays.'",dayId="'.$adddays.'",queryId="'.$QueryDaysData['queryId'].'",serviceId="'.$addInsurance.'",quotationId="'.$add.'",serviceType="insurance",startDate="'.$insuranceRes['fromDate'].'",endDate="'.$insuranceRes['toDate'].'"';
				addlistinggetlastid('quotationItinerary',$namevalue);

			}

			$b='';
			$b=GetPageRecord('*','quotationServiceMarkup',' quotationId="'.$maintable['id'].'" order by id asc');
			if(mysqli_num_rows($b)>0){
				$transferRes=mysqli_fetch_array($b);
				$addHotel = '';
				$modevalue = 'markupCost="'.$transferRes['markupCost'].'", curren="'.$transferRes['curren'].'", quotationId="'.$add.'", hotel="'.$transferRes['hotel'].'", package="'.$transferRes['package'].'", guide="'.$transferRes['guide'].'", activity="'.$transferRes['activity'].'", entrance="'.$transferRes['entrance'].'", transfer="'.$transferRes['transfer'].'",ferry="'.$transferRes['ferry'].'", train="'.$transferRes['train'].'", flight="'.$transferRes['flight'].'", restaurant="'.$transferRes['restaurant'].'",visa="'.$transferRes['visa'].'",passport="'.$transferRes['passport'].'",insurance="'.$transferRes['insurance'].'",other="'.$transferRes['other'].'",packageMarkupType="'.$transferRes['packageMarkupType'].'",hotelMarkupType="'.$transferRes['hotelMarkupType'].'",guideMarkupType="'.$transferRes['guideMarkupType'].'",activityMarkupType="'.$transferRes['activityMarkupType'].'",entranceMarkupType="'.$transferRes['entranceMarkupType'].'",transferMarkupType="'.$transferRes['transferMarkupType'].'",ferryMarkupType="'.$transferRes['ferryMarkupType'].'",trainMarkupType="'.$transferRes['trainMarkupType'].'",flightMarkupType="'.$transferRes['flightMarkupType'].'",restaurantMarkupType="'.$transferRes['restaurantMarkupType'].'",visaMarkupType="'.$transferRes['visaMarkupType'].'",passportMarkupType="'.$transferRes['passportMarkupType'].'",insuranceMarkupType="'.$transferRes['insuranceMarkupType'].'",otherMarkupType="'.$transferRes['otherMarkupType'].'",status="'.$transferRes['status'].'"';
				$markup = addlistinggetlastid('quotationServiceMarkup',$modevalue);
			}

			$getPackageRateQuery="";
			$getPackageRateQuery=GetPageRecord('*','packageWiseRateMaster',' quotationId="'.$maintable['id'].'"');
			if(mysqli_num_rows($getPackageRateQuery) > 0){
			    $transferRes=mysqli_fetch_array($getPackageRateQuery); 

				$addHotel = '';
				$modevalue = 'queryId="'.$QueryDaysData['queryId'].'",quotationId="'.$add.'",singleCost="'.$transferRes['singleCost'].'",doubleCost="'.$transferRes['doubleCost'].'",tripleCost="'.$transferRes['tripleCost'].'",twinCost="'.$transferRes['twinCost'].'",quadCost="'.$transferRes['quadCost'].'",sixBedCost="'.$transferRes['sixBedCost'].'",eightBedCost="'.$transferRes['eightBedCost'].'",tenBedCost="'.$transferRes['tenBedCost'].'",teenBedCost="'.$transferRes['teenBedCost'].'",extraBedACost="'.$transferRes['extraBedACost'].'",childwithbedCost="'.$transferRes['childwithbedCost'].'",childwithoutbedCost="'.$transferRes['childwithoutbedCost'].'",guideA="'.$transferRes['guideA'].'",activityA="'.$transferRes['activityA'].'",entranceA="'.$transferRes['entranceA'].'",enrouteA="'.$transferRes['enrouteA'].'",transferA="'.$transferRes['transferA'].'",trainA="'.$transferRes['trainA'].'",flightA="'.$transferRes['flightA'].'",restaurantA="'.$transferRes['restaurantA'].'",otherA="'.$transferRes['otherA'].'",guideC="'.$transferRes['guideC'].'",activityC="'.$transferRes['activityC'].'",entranceC="'.$transferRes['entranceC'].'",enrouteC="'.$transferRes['enrouteC'].'",transferC="'.$transferRes['transferC'].'",trainC="'.$transferRes['trainC'].'",flightC="'.$transferRes['flightC'].'",restaurantC="'.$transferRes['restaurantC'].'",otherC="'.$transferRes['otherC'].'",supplierId="'.$transferRes['supplierId'].'",currencyId="'.$transferRes['currencyId'].'",currencyValue="'.$transferRes['currencyValue'].'",singleBasis="'.$transferRes['singleBasis'].'",doubleBasis="'.$transferRes['doubleBasis'].'",tripleBasis="'.$transferRes['tripleBasis'].'",twinBasis="'.$transferRes['twinBasis'].'",quadBasis="'.$transferRes['quadBasis'].'",sixBedBasis="'.$transferRes['sixBedBasis'].'",eightBedBasis="'.$transferRes['eightBedBasis'].'",tenBedBasis="'.$transferRes['tenBedBasis'].'",teenBedBasis="'.$transferRes['teenBedBasis'].'",extraBedABasis="'.$transferRes['extraBedABasis'].'",childwithbedBasis="'.$transferRes['childwithbedBasis'].'",childwithoutbedBasis="'.$transferRes['childwithoutbedBasis'].'",infantBedBasis="'.$transferRes['infantBedBasis'].'"';
				$addHotel = addlistinggetlastid('packageWiseRateMaster',$modevalue);
			} 

			$c12=GetPageRecord('*','quotationAdditionalMaster',' quotationId="'.$maintable['id'].'" order by id asc');
			if( mysqli_num_rows($c12) > 0){
			 	updatelisting(_QUOTATION_MASTER_,' isAddExp="1"','id="'.$add.'"'); 
			 	while($transferRes=mysqli_fetch_array($c12)){

					$namevalue ='additionalId="'.$transferRes['additionalId'].'",adultCost="'.round($transferRes['adultCost']).'",childCost="'.round($transferRes['childCost']).'",infantCost="'.round($transferRes['infantCost']).'",quotationId="'.$add.'",entranceId="'.$transferRes['entranceId'].'",serviceType="'.($transferRes['serviceType']).'",destinationId="'.($transferRes['destinationId']).'"';
					addlistinggetlastid('quotationAdditionalMaster',$namevalue);

				}
			} 
			$slabErr = '';
		}elseif($totalPaxSlab>1){
			$slabErr = "Select only one slab";
		}else{
			$slabErr = "Choose the slab range which you want to final.";
		}
	}

//DATA IS COMPELETLY MOVED TO NEW QUOTATION.
?>
<div class="contentclass">
	<?php  
	//get the immediateOccupancy date and status
	$rs2='';
	$rs2=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"');
 	if(mysqli_num_rows($rs2)>0){
		$quotationData=mysqli_fetch_array($rs2);
		$rs2='';
		$rs2=GetPageRecord('*',_QUERY_MASTER_,'id="'.$quotationData['queryId'].'"');
		$queryData=mysqli_fetch_array($rs2);
		
		if($queryData['earlyCheckin'] == 1){ 
			$earlyArrivalDate = date("Y-m-d", strtotime("-1 days", strtotime($quotationData['fromDate'])));  
			$iqnorImmeQuery = ' and startDate!="'.$earlyArrivalDate.'" ';
			$iqnorHotelImmeQuery= ' and fromDate!="'.$earlyArrivalDate.'" ';
		}
	}

	$delHOtid='';
	$delHOtSupid=''; 

	$queryDaysQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationId.'"  and addstatus=0  and ( id in ( select dayId from quotationHotelMaster where 1 '.$finalcategoryQuery.' and ( isHotelSupplement=1 or  isRoomSupplement=1 ) )  or id in ( select dayId from quotationGuideMaster where 1 and isSupplement=1 ) )order by id asc');
	
	$suppRoomQuery=$checkSuppHQuery="";
	$suppRoomQuery=GetPageRecord('*','quotationHotelMaster','quotationId="'.$quotationId.'" and isRoomSupplement=1 ');
	$checkSuppHQuery=GetPageRecord('*','quotationHotelMaster','quotationId="'.$quotationId.'" and isHotelSupplement=1 ');
	$checkSuppGQuery=GetPageRecord('*','quotationGuideMaster','quotationId="'.$quotationId.'" and isSupplement=1 ');

	?>
	<h1 style="text-align:left;">Make Final / Select Supplement<?php if($slabErr!=''){ echo ' - <span style="color:red;">'.$slabErr.'</span>'; } ?></h1>
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="supplementSelectionForm" target="actoinfrm"  id="supplementSelectionForm">
     <div id="contentbox" class="addeditpagebox" style="  padding:0px; overflow:auto; text-align:left; margin-bottom:0px; " >
		<table width="100%" border="0" cellspacing="0" cellpadding="3">
		<?php 
		if(mysqli_num_rows($checkSuppHQuery) > 0 || mysqli_num_rows($suppRoomQuery) > 0 || mysqli_num_rows($checkSuppGQuery) > 0){
 		$NORate=1;
		while($QueryDaysData=mysqli_fetch_array($queryDaysQuery)){
			// get the right day Number
			$n=1;$dayno=0;
			$rsday=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationId.'"  and addstatus=0  order by id asc');
			while($getDay=mysqli_fetch_array($rsday)){
				if($getDay['id']==$QueryDaysData['id']){ $dayno=$n; }
				$n++;
			}
 			
			// Hotel listing 
			$normalQuery=GetPageRecord('*','quotationHotelMaster',' quotationId="'.$quotationId.'" '.$finalcategoryQuery.'  '.$iqnorHotelImmeQuery.' and dayId="'.$QueryDaysData['id'].'" and ( isGuestType=1 or isLocalEscort=1 or isForeignEscort=1 ) and isHotelSupplement=0 and isRoomSupplement=0 order by id asc');
			while($normalSuppD=mysqli_fetch_array($normalQuery)){

				$checksuppHRQuery="";  
				$checksuppHRQuery=GetPageRecord('*','quotationHotelMaster',' quotationId="'.$quotationId.'" '.$finalcategoryQuery.'  '.$iqnorHotelImmeQuery.' and dayId="'.$QueryDaysData['id'].'" and ( hotelQuoteId="'.$normalSuppD['id'].'" or id="'.$normalSuppD['id'].'") and ( isHotelSupplement=1 or isRoomSupplement=1 ) order by id asc');
				if(mysqli_num_rows($checksuppHRQuery)>0){

					if($NORate == 1){ ?>
					<tr>
					<td height="30" bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Day</strong></td>
					<td height="30" bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Service&nbsp;Type</strong></td>
					<td height="30" bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Select&nbsp;Hotel</strong></td>
					<?php if($normalSuppD['singleNoofRoom']>0){ ?>
					<td bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Single</strong></td>
					<?php } if($normalSuppD['doubleNoofRoom']>0){ ?>
					<td bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Double</strong></td>
					<?php } ?>
					<td bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Action</strong></td>
					</tr>
					<?php } ?>
				  <tr>
						<td height="25" style="border-bottom: 1px solid #e4e4e4;"><strong>Day <?php echo $dayno; ?></strong><!--(<?php echo date('d-m-Y', strtotime($normalSuppD['fromDate'])); ?>)--></td>
						<td height="25" style="border-bottom: 1px solid #e4e4e4;">

							<?php if($normalSuppD['isGuestType']==1){ $isSelectedType = 'isGuestType'; echo 'Guest Hotel'; }
							elseif($normalSuppD['isLocalEscort']==1){ $isSelectedType = 'isLocalEscort'; echo 'Local Escort Hotel'; }
							elseif($normalSuppD['isForeignEscort']==1){ $isSelectedType = 'isForeignEscort'; echo 'Foreign Escort Hotel'; }
							else{ echo '--'; } ?>
						</td>
						<td height="25" style="border-bottom: 1px solid #e4e4e4;">
						<div style=" display:none;" id="saveCost"></div>
						<input type="hidden" name="isSelectedType<?php echo $normalSuppD['id']; ?>" id="isSelectedType<?php echo $normalSuppD['id']; ?>" value="<?php echo $isSelectedType; ?>">
						<select id="selectedHotelId<?php echo $normalSuppD['id']; ?>" name="selectedHotelId<?php echo $normalSuppD['id']; ?>" class="gridfield" autocomplete="off" style="width:200px; padding:6px; border-radius: 3px;" onchange="getSelectedHotelRate('<?php echo $normalSuppD['id']; ?>');">
							<?php
							$hotelAllQuery="";  
							$hotelAllQuery=GetPageRecord('*','quotationHotelMaster',' quotationId="'.$quotationId.'" '.$finalcategoryQuery.'  '.$iqnorHotelImmeQuery.' and dayId="'.$QueryDaysData['id'].'" and ( hotelQuoteId="'.$normalSuppD['id'].'" or id="'.$normalSuppD['id'].'" ) and ( isGuestType=1 or isLocalEscort=1 or isForeignEscort=1 or isHotelSupplement=1 or isRoomSupplement=1 ) order by id asc');
							while($normalSuppHRD=mysqli_fetch_array($hotelAllQuery)){
							
								$rshotel="";
								$rshotel=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,'id="'.$normalSuppHRD['supplierId'].'"');
								$hotelemail=mysqli_fetch_array($rshotel);
							
								$rs12="";
								$rs12=GetPageRecord('*',_ROOM_TYPE_MASTER_,'id='.$normalSuppHRD['roomType'].'');
								$editresult2=mysqli_fetch_array($rs12);

								$rs121="";
								$rs121=GetPageRecord('*',_MEAL_PLAN_MASTER_,'id='.$normalSuppHRD['mealPlan'].'');
								$editresult21=mysqli_fetch_array($rs121);
								?>
								<option value="<?php echo $normalSuppHRD['id']; ?>"><?php echo $hotelemail['hotelName']; ?> - <?php echo $editresult2['name']; ?> - <?php echo $editresult21['name']; ?></option>
								<?php 
							} 
							?>
						</select>
						</td>
						<?php if($normalSuppD['singleNoofRoom']>0){ ?>
				    <td style="border-bottom: 1px solid #e4e4e4;"><div id="loadSingleRoomCost<?php echo $normalSuppD['id']; ?>">0</div></td>
						<?php } if($normalSuppD['doubleNoofRoom']>0){ ?>
				    <td style="border-bottom: 1px solid #e4e4e4;"><div id="loadDoubleRoomCost<?php echo $normalSuppD['id']; ?>">0</div></td>
						<?php } ?>
				    <td style="border-bottom: 1px solid #e4e4e4;"><div id="saveRate<?php echo $normalSuppD['id']; ?>" style="padding:5px 8px; background:#357eaa; color:#FFFFFF; border-radius:3px; width:fit-content; cursor:pointer;" onclick="selectHotelRate('<?php echo $normalSuppD['id']; ?>','<?php echo encode($finalcategoryQuery); ?>');">Select</div>
						<script type="text/javascript">
							jQuery(document).ready(function(){
								getSelectedHotelRate('<?php echo $normalSuppD['id']; ?>');
							});
						</script>
				    </td>
			  	</tr>
			 		<?php
			 		$NORate++;
		  	}
		 	}
		 	
		 	// guide listing 
			$normalGuideQuery=GetPageRecord('*','quotationGuideMaster',' quotationId="'.$quotationId.'" and dayId="'.$QueryDaysData['id'].'" and isGuestType=1 and isSupplement=0 order by id asc');
			while($normalGuideSuppD=mysqli_fetch_array($normalGuideQuery)){

				$checksuppHRQuery="";  
				$checksuppHRQuery=GetPageRecord('*','quotationGuideMaster',' quotationId="'.$quotationId.'" and dayId="'.$QueryDaysData['id'].'" and guideQuoteId="'.$normalGuideSuppD['id'].'" and isSupplement=1 order by id asc');
				if(mysqli_num_rows($checksuppHRQuery)>0){

					if($NORate == 1){ ?>
					<tr>
					<td height="30" bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Day</strong></td>
					<td height="30" bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Service&nbsp;Type</strong></td>
					<td height="30" bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Select&nbsp;Guide</strong></td> 
					<td bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Service&nbsp;Cost</strong></td> 
					<td bgcolor="#357EAA" style="border-bottom: 1px solid #e4e4e4; color:#FFFFFF;"><strong>Action</strong></td>
					</tr>
					<?php } ?>
				  	<tr>
						<td height="25" style="border-bottom: 1px solid #e4e4e4;"><strong>Day <?php echo $dayno; ?></strong></td>
						<td height="25" style="border-bottom: 1px solid #e4e4e4;">Guide</td>
						<td height="25" style="border-bottom: 1px solid #e4e4e4;">
						<div style=" display:none;" id="saveCostGuide"></div>
						<select id="selectedGuideId<?php echo $normalGuideSuppD['id']; ?>" name="selectedGuideId<?php echo $normalGuideSuppD['id']; ?>" class="gridfield" autocomplete="off" style="width:200px; padding:6px; border-radius: 3px;" onchange="getSelectedGuideRate('<?php echo $normalGuideSuppD['id']; ?>');">
							<?php
							$guideAllQuery="";   
							$guideAllQuery=GetPageRecord('*','quotationGuideMaster',' quotationId="'.$quotationId.'" and dayId="'.$QueryDaysData['id'].'" and ( guideQuoteId="'.$normalGuideSuppD['id'].'" or id="'.$normalGuideSuppD['id'].'" ) and ( isGuestType=1 or isSupplement=1 ) order by id asc');
							while($normalSuppHRD=mysqli_fetch_array($guideAllQuery)){

								$rsGuide="";
								$rsGuide=GetPageRecord('*',_GUIDE_SUB_CAT_MASTER_,'id="'.$normalSuppHRD['guideId'].'"');
								$GuideData5=mysqli_fetch_array($rsGuide);
								
								if(trim($normalSuppHRD['dayType']) == 'fullday'){
									$dayType = "Full Day";
								}else{
									$dayType = "Half Day";
								}	
								?>
								<option value="<?php echo $normalSuppHRD['id']; ?>"><?php echo strip($GuideData5['name']); ?> | <?php echo $dayType; ?></option>
								<?php 
							} 
							?>
						</select>
						</td> 
				    	<td style="border-bottom: 1px solid #e4e4e4;"><div id="loadGuideCost<?php echo $normalGuideSuppD['id']; ?>">0</div></td>
					 
				    	<td style="border-bottom: 1px solid #e4e4e4;"><div id="saveRateGuide<?php echo $normalGuideSuppD['id']; ?>" style="padding:5px 8px; background:#357eaa; color:#FFFFFF; border-radius:3px; width:fit-content; cursor:pointer;" onclick="selectGuideRate('<?php echo $normalGuideSuppD['id']; ?>');">Select</div>
						<script type="text/javascript">
							jQuery(document).ready(function(){
								getSelectedGuideRate('<?php echo $normalGuideSuppD['id']; ?>');
							});
						</script>
				    </td>
			  		</tr>
					<?php
					$NORate++;
				}
			}



		} 
		?>
		<script>
				function getSelectedHotelRate(hotelQuoteId){
					var selectedHotelId = encodeURI($('#selectedHotelId'+hotelQuoteId).val());
					$('#saveCost').load('loadGetSupplimentHotelRate.php?action=getSelectedHotelRate&selectedHotelId='+selectedHotelId+'&hotelQuoteId='+hotelQuoteId);
					$('#saveRate'+hotelQuoteId).css('background', '##357eaa');
					$('#saveRate'+hotelQuoteId).text('Select');
				}
				function selectHotelRate(hotelQuoteId,finalcategoryQuery){
					var selectedHotelId = encodeURI($('#selectedHotelId'+hotelQuoteId).val());
					var isSelectedType = encodeURI($('#isSelectedType'+hotelQuoteId).val());
					$('#saveCost').load('loadGetSupplimentHotelRate.php?action=updateSelectedHotel&hotelQuoteId='+hotelQuoteId+'&&selectedHotelId='+selectedHotelId+'&finalcategoryQuery='+encodeURI(finalcategoryQuery)+'&isSelectedType='+isSelectedType);
					$('#saveRate'+hotelQuoteId).css('background', '#4caf50');
					$('#saveRate'+hotelQuoteId).text('Selected');
				}
			</script>

			<script>
				function getSelectedGuideRate(guideQuoteId){
					var selectedGuideId = encodeURI($('#selectedGuideId'+guideQuoteId).val());
					$('#saveCostGuide').load('loadGetSupplimentHotelRate.php?action=getSelectedGuideRate&selectedGuideId='+selectedGuideId+'&guideQuoteId='+guideQuoteId);
					$('#saveRateGuide'+guideQuoteId).css('background', '##357eaa');
					$('#saveRateGuide'+guideQuoteId).text('Select');
				}
				function selectGuideRate(guideQuoteId){
					var selectedGuideId = encodeURI($('#selectedGuideId'+guideQuoteId).val());
					$('#saveCostGuide').load('loadGetSupplimentHotelRate.php?action=updateSelectedGuide&guideQuoteId='+guideQuoteId+'&selectedGuideId='+selectedGuideId);
					$('#saveRateGuide'+guideQuoteId).css('background', '#4caf50');
					$('#saveRateGuide'+guideQuoteId).text('Selected');
				}
			</script>
		 	<tr>
				<td>&nbsp;</td>
		 	</tr>
	 	<?php 
	 	}  

		$c12=GetPageRecord('*','quotationAdditionalMaster',' quotationId="'.$quotationId.'" group by serviceType order by id asc');
		if( mysqli_num_rows($c12) > 0){ ?>
		<tr>
		<td colspan="2"><strong style="color:#2879a8;">Additional Experience - Suppliment </strong></td>
	 		<td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
	  <tr>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	    <td>&nbsp;</td>
	    <td>&nbsp;</td>
	    <td>&nbsp;</td>
	  </tr>
	
	  <tr>
		<td colspan="6">
			<table width="90%" border="1" cellpadding="3" cellspacing="0" style="margin-left: 6px;" >
				<tr>
				 <td width="99" align="left"><strong>Service&nbsp;Type </strong></td>
				<td width="179" align="left"><strong>Name</strong></td>
				<td width="139" align="center"><strong>Destination</strong></td>
				<td width="139" align="center"><strong>Per Pax Cost</strong></td> 
				<td width="139" align="center">&nbsp;</td>
				<td width="139" align="center"><strong>Select Day </strong></td>
				</tr>
				<?php
				while($additionalIdData=mysqli_fetch_array($c12)){
					if($additionalIdData['serviceType']=='Activity'){

					$rsAct=GetPageRecord('*','quotationAdditionalMaster',' quotationId="'.$quotationId.'" and serviceType="'.$additionalIdData['serviceType'].'" order by id desc');
					while($activityData=mysqli_fetch_array($rsAct)){
					$c121=GetPageRecord('*','packageBuilderotherActivityMaster',' id in (select otherActivityNameId from dmcotherActivityRate where id="'.$activityData['additionalId'].'") order by id asc');
					$activityDataName=mysqli_fetch_array($c121);
					?>
					<tr id="addnl<?php echo $activityData['id'];?>">
					 <td width="99" align="left"><?php echo $activityData['serviceType'];?></td>
					<td width="179" align="left"><?php echo ucwords($activityDataName['otherActivityName']);?></td>
					<td width="139" align="center"><?php echo getDestination($activityData['destinationId']); ?></td>
					<td width="139" align="center"><?php echo $activityData['adultCost'];?></td> 
					<td width="139" align="center"><select id="selectactivity<?php echo $activityData['id']; ?>" class="gridfield" autocomplete="off" style="width:90px; padding:6px; border-radius: 3px;" onchange="selectactivityfun<?php echo $activityData['id']; ?>();">
								<option value="0">No</option>
								<option value="1">Yes</option>
								</select><script>
								function selectactivityfun<?php echo $activityData['id']; ?>(){
								var selectact = $('#selectactivity<?php echo $activityData['id']; ?>').val();
								if(selectact==1){
								$('#additionalId<?php echo $activityData['id']; ?>').show();
								}else{ $('#additionalId<?php echo $activityData['id']; ?>').hide();  }
								}
								</script></td>
					<td width="139" align="center"><select id="additionalId<?php echo $activityData['id']; ?>" name="additionalId<?php echo $activityData['id']; ?>" class="gridfield" autocomplete="off" style="width:90px; padding:6px; border-radius: 3px; display:none;">
								<option value="0">Select</option>
								<?php 
									$day=1;
									$Q2=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationId.'"  and addstatus=0  order by id asc');
									while($supData2=mysqli_fetch_array($Q2)){

									$dayDate = $supData2['srdate'];

									if($supData2['cityId']==$activityData['destinationId']){
									 ?>

									<option value="<?php echo $supData2['id']; ?>,<?php echo date('d-m-Y', strtotime($dayDate)); ?>,<?php echo $supData2['cityId']; ?>,Activity">Day <?php echo $day; ?></option>

									<?php } $day++; }  ?>

									</select></td>
				</tr>
				<?php
				}
				}


				if($additionalIdData['serviceType']=='Guide'){

				$rsAct=GetPageRecord('*','quotationAdditionalMaster',' quotationId="'.$quotationId.'" and serviceType="'.$additionalIdData['serviceType'].'" order by id desc');
				while($guideData=mysqli_fetch_array($rsAct)){
				$c121=GetPageRecord('*',_GUIDE_SUB_CAT_MASTER_,' id in (select serviceid from dmcGuidePorterRate where id="'.$guideData['additionalId'].'") order by id asc');
				$guideDataName=mysqli_fetch_array($c121);
				?>
				<tr id="addnl<?php echo $guideData['id'];?>">
				 <td width="99" align="left"><?php echo $guideData['serviceType'];?></td>
				<td width="179" align="left"><?php echo ucwords($guideDataName['name']);?> </td>
				<td width="139" align="center"><?php echo getDestination($guideData['destinationId']); ?></td>
				<td width="139" align="center"><?php echo $guideData['adultCost'];?></td> 
				<td width="139" align="center"><select id="selectactivity<?php echo $guideData['id']; ?>" class="gridfield" autocomplete="off" style="width:90px; padding:6px; border-radius: 3px;" onchange="selectactivityfun<?php echo $guideData['id']; ?>();">
								<option value="0">No</option>
								<option value="1">Yes</option>
								</select><script>
								function selectactivityfun<?php echo $guideData['id']; ?>(){
								var selectact = $('#selectactivity<?php echo $guideData['id']; ?>').val();
								if(selectact==1){
								$('#additionalId<?php echo $guideData['id']; ?>').show();
								}else{ $('#additionalId<?php echo $guideData['id']; ?>').hide();  }
								}
								</script></td>
				<td width="139" align="center"><select id="additionalId<?php echo $guideData['id']; ?>" name="additionalId<?php echo $guideData['id']; ?>" class="gridfield" autocomplete="off" style="width:90px; padding:6px; border-radius: 3px; display:none;">
								<option value="0">Select</option>
								<?php
			 
									$day=1;
									$Q2=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationId.'"  and addstatus=0  order by id asc');
									while($supData2=mysqli_fetch_array($Q2)){

									$dayDate = $supData2['srdate'];

									if($supData2['cityId']==$guideData['destinationId']){
								 ?>
								<option value="<?php echo $supData2['id']; ?>,<?php echo date('d-m-Y', strtotime($dayDate)); ?>,<?php echo $supData2['cityId']; ?>,Guide">Day <?php echo $day; ?></option>
								<?php } $day++; }  ?>
							</select></td>
				</tr>
				<?php
				}
				}

				if($additionalIdData['serviceType']=='Entrance'){
				$rsAct=GetPageRecord('*','quotationAdditionalMaster',' quotationId="'.$quotationId.'" and serviceType="'.$additionalIdData['serviceType'].'" order by id desc');
				while($entranceData=mysqli_fetch_array($rsAct)){

					if($entranceData['additionalId'] != 0){
	$c121=GetPageRecord('entranceName',_PACKAGE_BUILDER_ENTRANCE_MASTER_,' id in (select entranceNameId from '._DMC_ENTRANCE_RATE_MASTER_.' where id="'.$entranceData['additionalId'].'") order by id asc'); 
	$entranceDataName=mysqli_fetch_array($c121);
}else{
$c121=GetPageRecord('entranceName',_PACKAGE_BUILDER_ENTRANCE_MASTER_,' id="'.$entranceData['entranceId'].'"'); 
$entranceDataName=mysqli_fetch_array($c121);	
}

				?>
				<tr id="addnl<?php echo $entranceData['id'];?>">
				 <td width="99" align="left"><?php echo $entranceData['serviceType'];?></td>
				<td width="179" align="left"><?php echo ucwords($entranceDataName['entranceName']);?></td>
				<td width="139" align="center"><?php echo getDestination($entranceData['destinationId']); ?></td>
				<td width="139" align="center"><?php echo $entranceData['adultCost'];?></td> 
				<td width="139" align="center"><select id="selectactivity<?php echo $entranceData['id']; ?>" class="gridfield" autocomplete="off" style="width:90px; padding:6px; border-radius: 3px;" onchange="selectactivityfun<?php echo $entranceData['id']; ?>();">
								<option value="0">No</option>
								<option value="1">Yes</option>
								</select><script>
								function selectactivityfun<?php echo $entranceData['id']; ?>(){
								var selectact = $('#selectactivity<?php echo $entranceData['id']; ?>').val();
								if(selectact==1){
								$('#additionalId<?php echo $entranceData['id']; ?>').show();
								}else{ $('#additionalId<?php echo $entranceData['id']; ?>').hide();  }
								}
								</script></td>
				<td width="139" align="center"><select id="additionalId<?php echo $entranceData['id']; ?>" name="additionalId<?php echo $entranceData['id']; ?>" class="gridfield" autocomplete="off" style="width:90px; padding:6px; border-radius: 3px; display:none;">
								<option value="0">Select</option>
								<?php 
									$day=1;
									$Q2=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationId.'"  and addstatus=0  order by id asc');
									while($supData2=mysqli_fetch_array($Q2)){

									$dayDate = $supData2['srdate'];

									if($supData2['cityId']==$entranceData['destinationId']){
								 ?>
								<option value="<?php echo $supData2['id']; ?>,<?php echo date('d-m-Y', strtotime($dayDate)); ?>,<?php echo $supData2['cityId']; ?>,Entrance">Day <?php echo $day; ?></option>
								<?php } $day++; }  ?>
							</select>				</td>
				</tr>
				<?php
				}
				}

				}
				?>
			</table> 
		</td> 
	</tr>
	<?php 
	}

		if( mysqli_num_rows($c12) == 0 && mysqli_num_rows($queryDaysQuery) == 0){ 
		?>	
	  	<tr>
			<td colspan="6" align="left">--No Supplement Services--</td> 
	  	</tr>
	  	<tr>
			<td colspan="6">&nbsp;</td> 
		</tr>
		<?php } ?>
	</table>

  	</div>

  <input name="old_quotationId" type="hidden" id="old_quotationId" value="<?php echo trim($maintable['id']); ?>" />
	<input name="quotationId" type="hidden" id="quotationId" value="<?php echo $quotationId; ?>" />
	<input name="queryId" type="hidden" id="queryid" value="<?php echo $_REQUEST['queryId']; ?>" />
	<input name="quotationType" type="hidden" id="quotationType" value="<?php echo $quotationType; ?>" />
	<input name="finalcategory" type="hidden" id="finalcategory" value="<?php echo $finalcategory; ?>" /> 
	<input name="action" type="hidden" id="action" value="chooseSupplimentServices" />
   	<div id="buttonsbox" style="text-align:center;">
 	<table border="0" align="left" cellpadding="0" cellspacing="0">
      <tr><td  >
      	<?php if($slabErr==''){ ?>
      		<!-- Are you sure you want make the query final and update the changes.? You would not be able to change anything after this action. -->
      		<!-- Are you sure you want to finalize the query and update the changes? After this action you will not be able to change anything.
				 -->
      	<input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value=" Save & Make Final " onclick="if(confirm('Are you sure you want to finalize the query and update the changes? After this action you will not be able to change anything.')) formValidation('supplementSelectionForm','submitbtn','0'); " />
      	<?php } ?>
      </td>
        <td style="padding-right:20px;"><a href="showpage.crm?module=query&view=yes&deletestatusDuplicate=1&quotationId=<?php echo $quotationId; ?>&id=<?php echo encode($_REQUEST['queryId']); ?>"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" /></a></td>
      </tr>
   </table>
	</div>
	 </form>
</div>
<?php } 
?> 
<?php if($_GET['action']=='addeGuideAllocation' && $_GET['id']!='' && $_GET['serviceType']!=''){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div  class="contentclass">
<div id="sendmailfrm">
	<h1 style="text-align:left; background-color: #57a0a4!important;">Select Guide</h1>
  	<div id="contentbox" class="addeditpagebox newtowrobox" style="padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile">
   <input name="guideQuoteId" id="guideQuoteId" type="hidden" value="<?php echo $_GET['id']; ?>" />
   <input name="fromDate" id="fromDate" type="hidden" value="<?php echo $_GET['fromDate']; ?>" />
   <input name="toDate" id="toDate" type="hidden" value="<?php echo $_GET['toDate']; ?>" />
   <input name="queryId" id="queryId" type="hidden" value="<?php echo $_GET['queryId']; ?>" />
   <input name="quotationId" id="quotationId" type="hidden" value="<?php echo $_GET['quotationId']; ?>" />
    <input name="action" id="action" type="hidden" value="quotationAllocateGuide" />
	<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
	   <tr>
		  <td width="30%">
			 <select id="guideId" name="guideId" class="gridfield" displayname="Guide" autocomplete="off" style="padding: 8px;width: 249px;" onchange="guideAllocationDetails()">
				<option value="">Select Guide</option>
			<?php
			$selvehd='*';
			$wherevehd='1 order by id desc';
			$rsvehd=GetPageRecord($selvehd,_GUIDE_MASTER_,$wherevehd);
				while ($guidenamed=mysqli_fetch_array($rsvehd)) {?>
				 <option value="<?php echo $guidenamed['id']; ?>" <?php if($guidenamed['id']==$_REQUEST['guideId']){ ?>selected="selected"<?php  } ?>><?php echo $guidenamed['name']; ?></option>
			 <?php } ?>
			</select>
		  </td>
		  <td width="60%"  ><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Select" onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td>
	<style type="text/css">
	.addBtn {
		background-color: #cccccc5c!important;
		padding: 8px;
		color: bloack;
		border: 1px solid #8080806b;
	}
	</style>
		   <td width="10%"><div style="font-size:12px; padding:0px;position:relative;width: 84px;">
		<div class="addBtn" onclick="alertspopupopen('action=addPrivateGuide&id=<?php echo $_REQUEST['id']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&toDate=<?php echo $_REQUEST['toDate']; ?>&guideId=<?php echo $_REQUEST['guideId']; ?>&serviceType=guide','400px');" style=" right: 14px; top: 8px; ">+&nbsp;Add New</div>
		</div></td>
	   </tr>   
	</table>
</form>
	</div>
	<div id="guideDetail" style="margin-top: 15px;"></div>
</div>
</div>
<script>
	function guideAllocationDetails(){
	  var guideId = $('#guideId').val();
	  var queryId = $('#queryId').val();
	  var fromDate = $('#fromDate').val();
	  var toDate = $('#toDate').val();
	  var quotationId = $('#quotationId').val();
	  $("#guideDetail").load("guideDetails.php?guideId="+guideId+"&queryId="+queryId+"&fromDate="+fromDate+"&toDate="+toDate+"&quotationId="+quotationId);
	}
	guideAllocationDetails();
	</script>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } ?>	
<?php if($_GET['action']=='addPrivateGuide' && $_GET['id']!='' && $_GET['serviceType']!=''){
?>
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #57a0a4!important">Add Guide</h1>
  	<div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveguide" target="actoinfrm"  id="saveguide">
	 <input type="hidden" name="guideQuoteId" id="guideQuoteId" value="<?php echo $_REQUEST['id']; ?>">	
	 <input type="hidden" name="fromDate" id="fromDate" value="<?php echo $_REQUEST['fromDate']; ?>">	
	 <input type="hidden" name="toDate" id="toDate" value="<?php echo $_REQUEST['toDate']; ?>">	
	 <input type="hidden" name="queryId" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>">
	 <input type="hidden" name="quotationId" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>">
	 <input type="hidden" name="serviceType" id="serviceType" value="<?php echo $_REQUEST['serviceType']; ?>">
	 <input type="hidden" name="action" id="action" value="addnewGuide">	
	<div class="griddiv"><label>
	<div class="gridlable">Guide Name<span class="redmind"></span></div>
	<input name="name" type="text" class="gridfield" id="name" value="" displayname="Guide Name" maxlength="100">
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Mobile No.</div>
	<input name="mobileNo" type="text" class="gridfield" id="mobileNo" value="" displayname="Mobile No." maxlength="100">
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">WhatsApp No.</div>
	<input name="whatsAppNo" type="text" class="gridfield" id="whatsAppNo" value="" displayname="WhatsApp No." maxlength="100">
	</label>
	</div>
	<div class="griddiv"><label>
	<div class="gridlable">Email Address</div>
	<input name="emailAddress" type="text" class="gridfield" id="emailAddress" value="" displayname="Email Address" maxlength="100">
	</label>
	</div>
	</form>
	</div>
</div>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Save" onclick="formValidation('saveguide','submitbtn','0');" style=" background-color: #57a0a4 !important;" /></td>
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Back To Vehicle" onclick="alertspopupopen('action=addeGuideAllocation&id=<?php echo $_REQUEST['id']; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>&fromDate=<?php echo $_REQUEST['fromDate']; ?>&toDate=<?php echo $_REQUEST['toDate']; ?>&guideId=<?php echo $_REQUEST['guideId']; ?>&serviceType=guide','800px');" /></td>
      </tr>
   </table>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } 
if($_GET['action']=='addtodolistaction' && $_GET['id']!=''){
if($_GET['id']!=''){
  $id=decode($_REQUEST['id']);
  $resultListsq=GetPageRecord('*','toDoTimeLine','1 and id="'.$id.'"');
  $resultLists=mysqli_fetch_array($resultListsq);
}
?> 
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #2bb0dd!important;">Select Status</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile"> 
    <input name="action" id="action" type="hidden" value="addtodolistaction" />
	 <input name="editId" id="editId" type="hidden" value="<?php echo $_GET['id']; ?>" />
<table width="99%"  border="0" cellpadding="0" cellspacing="0" class=" gridtable">
   <tr>
   	  <td width="30%">
   	  	 <select id="todoStatus" name="todoStatus" class="validate gridfield" displayname="Status" autocomplete="off" style="padding: 8px;width: 249px;" onchange="loadtodostatus();">
	     <option value="">Select</option>
	     <option value="1">Completed</option>
		  <option value="2">Extended</option>
        </select>
   	  </td>
<style type="text/css">
.addBtn {
    background-color: #cccccc5c!important;
    padding: 8px;
    color: bloack;
    border: 1px solid #8080806b;
}
</style> 
   </tr>   
   <tr id="extededblock" style="display:none;">
   <td>
     <div style="width:27%; display:inline-block;margin-right:20px;">
	 <input type="date" class="gridfield" id="toDoDate" name="toDoDate" style="text-align: left; width: 100%; padding: 5px !important; border-radius: 2px;" value="<?php echo $resultLists['toDoDate']; ?>">
	 </div>  
	 <div style="width:27%; display:inline-block;">
		<select name="toDotime" id="toDotime" class="gridfield" style="text-align: left; width: 100%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
	<?php 
	 $start=strtotime('00:00'); 
	 $end=strtotime('23:59'); 
	for ($i=$start;$i<=$end;$i = $i + 15*60){ ?>
	<option value="<?php echo date('g:i A',$i); ?>" <?php if(date('g:i A',strtotime($resultLists['toDotime']))==date('g:i A',$i)){ ?> selected="selected" <?php } ?>><?php echo date('g:i A',$i); ?></option>
	<?php } ?>
		</select>
	 </div> 
   </td>
   </tr> 
</table> 
</div>
</div> 
<script> 
function loadtodostatus(){
 var todoStatus = $('#todoStatus').val();
  if(todoStatus==1){
  $('#extededblock').hide();
 }
  if(todoStatus==2){
  $('#extededblock').show();
 }
} 
	</script>
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save" onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td> 
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php }	
if($_GET['action']=='addtodoforquotation' && $_GET['queryId']!=''){
$type=$_REQUEST['type'];
?> 
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{    width: 12% !important;
    display: inline-block;
    margin: 8px;}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #2bb0dd!important;">Select Task</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile"> 
	<input name="action" id="action" type="hidden" value="addtodoforquotation" />
	<input name="type-todo" id="type-todo" type="hidden" value="<?php echo $_REQUEST['type']; ?>" />
	<input name="queryId-todo" id="queryId-todo" type="hidden" value="<?php echo $_REQUEST['queryId']; ?>" />
<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
    <tr>
   <td>
     <div style="width: 100%; float: left; margin-bottom: 10px; overflow: hidden; margin-right: 2%;">
	 <label>Task Title</label> 
<?php 
if($type==1){
$hotelid=decode($_REQUEST['hotelid']);
$d=GetPageRecord('hotelName,hotelCity,hotelCategoryId',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$hotelid.'"');   
$hotelData=mysqli_fetch_array($d);
 
	$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,' id='.$hotelData['hotelCategoryId'].'');   
	$hcD=mysqli_fetch_array($rr2);
 
?>	 
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($hotelData['hotelName']);?> ( <?php echo $hcity = strip($hotelData['hotelCity']);  ?> ) | <?php echo trim($hcD['hotelCategory']); ?> Star"> 
<?php } ?> 
<?php 
if($type==2){
$transferid=decode($_REQUEST['transferid']);
$transferQuotationId=decode($_REQUEST['transferQuotationId']);
$c=GetPageRecord('destinationId',_QUOTATION_TRANSFER_MASTER_,' id="'.$transferQuotationId.'"  order by fromDate asc'); 
$transferQuotData=mysqli_fetch_array($c);
$d=GetPageRecord('transferName','packageBuilderTransportMaster',' id="'.$transferid.'"');   
$transferData=mysqli_fetch_array($d);
?>	 
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($transferData['transferName']); ?> ( <?php echo $hcity = getDestination($transferQuotData['destinationId']);  ?> )">
<?php } ?>
<?php 
if($type==3){
$entranceNameId=decode($_REQUEST['entranceNameId']); 
$d=GetPageRecord('entranceName,entranceCity',_PACKAGE_BUILDER_ENTRANCE_MASTER_,' id="'.$entranceNameId.'"');   
$entranceData=mysqli_fetch_array($d);  
?>	 
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($entranceData['entranceName']);  ?> ( <?php echo $hcity = strip($entranceData['entranceCity']);  ?> )">
<?php } ?>
<?php 
if($type==4){
$activityId=decode($_REQUEST['activityId']); 
$d12=GetPageRecord('otherActivityName,otherActivityCity','packageBuilderotherActivityMaster',' id="'.$activityId.'"');
$activityData=mysqli_fetch_array($d12);
?>	  
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($activityData['otherActivityName']);  ?> ( <?php echo $hcity = strip($activityData['otherActivityCity']);  ?> )">
<?php } ?> 
<?php 
if($type==5){ 
$trainId=decode($_REQUEST['trainId']); 
$trainQuotationId=decode($_REQUEST['trainQuotationId']); 
$quotationId=decode($_REQUEST['quotationId']);  
$e=GetPageRecord('destinationId',_QUOTATION_TRAINS_MASTER_,'id="'.$trainQuotationId.'" and quotationId="'.$quotationId.'" order by id desc'); 
$trainQuotData=mysqli_fetch_array($e);
$d23=GetPageRecord('trainName',_PACKAGE_BUILDER_TRAINS_MASTER_,'id="'.$trainId.'"');   
$trainData=mysqli_fetch_array($d23); 
?>	 
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($trainData['trainName']);  ?> ( <?php echo getDestination($trainQuotData['destinationId']);  ?> )">
<?php } ?> 
<?php 
if($type==6){ 
$flightId=decode($_REQUEST['flightId']);
$destinationId=decode($_REQUEST['destinationId']);  
$d=GetPageRecord('flightName',_PACKAGE_BUILDER_FLIGHT_MASTER_,'id="'.$flightId.'"');   
$flightData=mysqli_fetch_array($d); 
$Ecity = getDestination($destinationId); 
?>	  
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($flightData['flightName']);  ?> ( <?php echo $Ecity;  ?> )">
<?php } ?> 
<?php 
if($type==7){ 
$guideId=decode($_REQUEST['guideId']);
$destinationId=decode($_REQUEST['destinationId']);  
$d=GetPageRecord('name',_GUIDE_SUB_CAT_MASTER_,'id="'.$guideId.'"');   
$guideData=mysqli_fetch_array($d); 
$Ecity = getDestination($destinationId); 
?>	  
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($guideData['name']);  ?> ( <?php echo $Ecity;  ?> )">
<?php } ?> 
<?php 
if($type==8){ 
$mealplanQuotationId=decode($_REQUEST['mealplanQuotationId']);
$quotationId=decode($_REQUEST['quotationId']);  
$b=GetPageRecord('mealPlanName,destinationId',_QUOTATION_INBOUND_MEAL_PLAN_MASTER_,'id="'.$mealplanQuotationId.'" and quotationId="'.$quotationId.'" order by fromDate asc');    
$mealQuotData=mysqli_fetch_array($b); 
?>	  
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($mealQuotData['mealPlanName']); ?> ( <?php echo $hcity = getDestination($mealQuotData['destinationId']);  ?> )">
<?php } ?> 
<?php 
if($type==9){ 
$additionalId=decode($_REQUEST['additionalId']);
$destinationId=decode($_REQUEST['destinationId']); 
$d=GetPageRecord('name','extraQuotation',' id="'.$additionalId.'"');   
$additionalData=mysqli_fetch_array($d);
$Ecity = getDestination($destinationId);  
?>	  
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($additionalData['name']);  ?> ( <?php echo $Ecity;  ?> )">
<?php } ?> 
<?php 
if($type==10){ 
$enrouteId=decode($_REQUEST['enrouteId']);
$destinationId=decode($_REQUEST['destinationId']);  
$d=GetPageRecord('enrouteName',_PACKAGE_BUILDER_ENROUTE_MASTER_,' id="'.$enrouteId.'"');   
$enrouteData=mysqli_fetch_array($d); 
$Ecity = getDestination($destinationId);
?>	  
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle-todo" name="taskTitle-todo" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value="<?php echo strip($enrouteData['enrouteName']);  ?> ( <?php echo $Ecity;  ?> )">
<?php } ?> 
	 </div> 
     <div style="width: 32%; float: left; margin-bottom: 10px; overflow: hidden; margin-right: 2%;">
	 <label>Task Date</label>
	 <input type="date" class="validate gridfield" displayname="Task Date" id="actionDate-todo" name="actionDate-todo" style="text-align: left; width: 94% !important; padding: 5px !important; border-radius: 2px;" value="<?php echo date('Y-m-d'); ?>">
	 </div>  
	 <div style="width: 31%; float: left; margin-bottom: 10px; overflow: hidden; margin-right: 2%;">
	 <label>Task Time</label>
		<select name="actionTime-todo" id="actionTime-todo" class="validate gridfield" displayname="Task Time" style="text-align: left; width: 99%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
	<?php 
	 $start=strtotime('00:00'); 
	 $end=strtotime('23:59'); 
	for ($i=$start;$i<=$end;$i = $i + 15*60){ ?>
	<option value="<?php echo date('g:i A',$i); ?>" <?php if(date('g:i A',$i)=="10:00 AM"){ ?> selected="selected" <?php } ?>><?php echo date('g:i A',$i); ?></option>
	<?php } ?>
		</select>
	 </div> 
	 <div style="width: 31%; float: left; margin-bottom: 10px; overflow: hidden; margin-right: 2%;">
	 <label>Assign To</label>
		<select name="assignTo-todo" id="assignTo-todo" class="validate gridfield" displayname="Assign To" style="text-align: left; width: 99%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
<?php  
$assignDataq=GetPageRecord('id,firstName,lastName','userMaster','1 and status=1 and deletestatus=0 order by firstName');   
while($assignData=mysqli_fetch_array($assignDataq)){ ?>
<option value="<?php echo $assignData['id']; ?>"><?php echo $assignData['firstName'].' '.$assignData['lastName']; ?></option>
<?php } ?>
		</select>
	 </div> 
	 <div style="width: 100%; float: left; margin-bottom: 10px; overflow: hidden; margin-right: 2%;">
	 <label>Remarks</label>
	 <input type="text" class="gridfield" id="remark-todo" name="remark-todo" style="text-align: left; width: 95%; padding: 5px !important; border-radius: 2px;">
	 </div>
   </td>
   </tr> 
</table> 
</div>
</div>  
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save" onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td> 
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php }	 
if($_GET['action']=='finalquotetodo' && $_GET['queryId']!=''){
$select='*';
$where='id='.decode($_GET['queryId']).'';
$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
$resultpage=mysqli_fetch_array($rs); 
$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"  ');
$resultpageQuotation=mysqli_fetch_array($rsp);
?>
<style>
.maindiv{
margin: 0px 0px 60px 0px;
position: relative;
left: 17%;
} 
.btndiv{
width: 20%;
float: left;
border: 1px solid #ddd;
padding: 10px;
margin: auto;
cursor: pointer;
}
.activediv{
background-color: #22ae74;
color: #ffffff;
}

</style>
<div class="contentclass">
<h1 style="text-align:left; position:relative;">To Do Setting</h1>
	 	<script> 
		$('#finalquote').html('<div style="text-align:center; margin-top:125px;">Loading...</div>');
        $('#finalquote').load('unassiged_assigned_services-todo.php?queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
	  </script>
<div style="text-align:left;" id="finalquote"></div>
</div>
<?php }
// addsupplierquote 
if($_GET['action']=='assignafterconfirmation' && $_GET['queryId']!=''){ 
	$rsQuery='';
	$rsQuery=GetPageRecord('*',_QUERY_MASTER_,'id='.decode($_GET['queryId']).'');
	$queryData=mysqli_fetch_array($rsQuery);
	?> 
	<div class="contentclass"> 
		<div id="sendmailfrm"> 
			<h1 style="text-align:left;">Assign User</h1> 
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd"> 
				<input name="action" id="action" type="hidden" value="assignafterconfirmation" /> 
				<input name="editId" id="editId" type="hidden" value="<?php echo $_GET['queryId']; ?>" /> 
				<input type="hidden" name="assignTo" id="assignTo" value="<?php echo $_GET['assignTo']; ?>">
				<div class="griddiv">
					<label> 
						<div class="gridlable" style="text-align:left;">Assign To</div> 
						<select id="confirmedAssignTo" name="confirmedAssignTo" class="gridfield validate" displayname="Assign To" autocomplete="off" style="padding:10px; width:100%; box-sizing:border-box; border:1px #CCC solid; margin-top:10px;" > 
						<option value="">Select</option>  
						<?php  
						$select='*';    
						$where='superParentId='.$loginusersuperParentId.' and status="1" and deletestatus=0 and userType=1 or (userType=2) order by firstName asc'; 
						$rs=GetPageRecord($select,_USER_MASTER_,$where); 
						while($restype=mysqli_fetch_array($rs)){  
						?>
						<option value="<?php echo strip($restype['id']); ?>" <?php if($restype['id']==$_GET['assignTo']){ ?>selected="selected"<?php } ?>><?php echo strip($restype['firstName']).' '.strip($restype['lastName']); ?></option>
						<?php } ?> 
						</select>  
					</label>
				</div>	
				<!-- <br> -->
				<div class="griddiv" style="display:none;">
					<label>  
						<?php 
						$description='Dear {Assignee},<br> #'.makeQueryId($queryData['id']).' is assigned to you for further action.';
						?>
							<textarea name="details" rows="5" id="details" class="gridfield" style="width:100%; height:150px;"><?php echo $description; ?></textarea> 
					</label>
				</div>
				<br>
				<div class="griddiv">
					<label>
						<div class="gridlable" style="text-align:left;" >Add more emails</div>
						<input type="text" class="gridfield" name="ccmails" id="ccmails" placeholder="test@example.com,test@example.com" style="width: 96% !important; margin: 0px !important; padding: 8px 10px !important; box-shadow: inset 0 0 2px #ccc !important; border: 1px solid #ccc !important;"/>
					</label>
				</div> 

			</form>
		</div>
	</div>
	<div id="buttonsbox"  style="text-align:center;margin: 10px 0;">
		<table border="0" align="right" cellpadding="0" cellspacing="0">
		<tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="   Save    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		</tr>
		</table>
	</div>
	<?php 
} ?>

<?php 
if($_REQUEST['action']=='deleteServiceVoucher'){ 
//echo $_REQUEST['queryId'].'rrrrrrrr'.$_REQUEST['serviceId'].'jjjjjjj'.$_REQUEST['quotationId'];
?>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="cancleVoucher" target="actoinfrm"  id="cancleVoucher">
<input type="hidden" name="action" value="cancleServicevoucher" />
<input type="hidden" name="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
<input type="hidden" name="serviceId" value="<?php echo $_REQUEST['serviceId']; ?>" />
<input type="hidden" name="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>" />
<div class="delbg"><img src="images/Remove-64.png" /></div>
<div class="contentclass">
<h1 style="padding:15px 11px !important;"> Are you sure you want to Cancel Voucher ? </h1> 
<div id="buttonsbox">
<table border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td><input name="Yes" type="button" class="redmbutton2 submitbtn" id="addnewuserbtn" value="Yes" onclick="formValidation('cancleVoucher','submitbtn','0');" /></td>
<td style="padding-right:20px;"><input name="No" type="button" class="whitembutton" id="no" value="No" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div>
</form>
<?php } ?>
<?php if($_REQUEST['action']=='cancelfinalquotVouchers' && $_REQUEST['queryId'] != ''){ 
?>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="cancleV" target="actoinfrm"  id="cancleV">
<div class="contentclass">
<h1 style="padding:15px 11px !important;"> Do you want to cancel voucher also ? </h1> 
<div id="buttonsbox">
<table border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>
<a class="submitbtn bluembutton" href="frmaction.php?action=cancelSupplierVoucherList&queryId=<?php echo encode($_REQUEST['queryId']); ?>&noteDetails=<?php echo $_REQUEST['noteDetails'] ?>">Yes</a>
</td>
<td style="padding-right:20px;"><input name="No" type="button" class="whitembutton" id="no" value="No" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div>
</form>
<?php } ?>

<?php if($_REQUEST['action']=='cancelfinalquotInvoice' && $_REQUEST['queryId'] != ''){ 
?>
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="cancleV" target="actoinfrm"  id="cancleV">
<div class="contentclass">
<h1 style="padding:15px 11px !important;"> Do you want to cancel Invoice ? </h1> 
<div id="buttonsbox">
<table border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>
<a class="submitbtn bluembutton" href="frmaction.php?action=cancelfinalquotInvoice&queryId=<?php echo $_REQUEST['queryId']; ?>">Yes</a>
</td>
<td style="padding-right:20px;"><input name="No" type="button" class="whitembutton" id="no" value="No" onclick="alertspopupopenClose();" /></td>
</tr>
</table>
</div>
</div>
</form>
<?php } ?>

<?php if($_REQUEST['action']=='cancleSupplierVoucherList' && $_REQUEST['queryId']!=''){
$select='*';
$where='id='.$_REQUEST['queryId'].'';
$rs=GetPageRecord($select,_QUERY_MASTER_,$where);
$resultpage=mysqli_fetch_array($rs);
$rsp=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"');
$resultpageQuotation=mysqli_fetch_array($rsp);
?>
<style>
.maindiv{
margin: 0px 0px 60px 0px;
position: relative;
left: 27%;
	}
.btndiv{
width: 20%;
float: left;
border: 1px solid #ddd;
padding: 10px;
margin: auto;
cursor: pointer;
}
.activediv{
background-color: #22ae74;
color: #ffffff;
}
</style>
<div class="contentclass">
<h1 style="text-align:left; position:relative;"> <?php if($_REQUEST['status'] == 1){ ?>Vouchers&nbsp;Cancellation<?php } else{ ?> Final Confirmation  <?php }  ?></h1>
	<div class="maindiv">
	<div class="btndiv activediv" id="unaservice" onclick="loadquotationfun(3);$('#unaservice').addClass('activediv');$('#day').removeClass('activediv');$('#group').removeClass('activediv');">Supplier Voucher</div>	
	<div class="btndiv" id="group" onclick="loadquotationfun(2);$('#group').addClass('activediv');$('#day').removeClass('activediv');$('#unaservice').removeClass('activediv');"> Client Voucher</div>
		<script>
		function loadquotationfun(id){
		$('#finalquote').html('<div style="text-align:center; margin-top:125px;">Loading...</div>');
			if(id==2){
				$('#finalquote').load('load_clientServicevoucher.php?<?php if($_REQUEST['status'] == 1){ ?>status=1&<?php } ?>queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
			}
			if(id==3){
				$('#finalquote').load('loadSupplierServicevoucher.php?<?php if($_REQUEST['status'] == 1){ ?>status=1&<?php } ?>queryId=<?php echo $resultpage['id']; ?>&quotationId=<?php echo $_REQUEST['quotationId']; ?>');
			}
		}
		<?php if($_REQUEST['o']==3){ ?>
		loadquotationfun(3);
		$('#group').addClass('activediv');
		$('#day').removeClass('activediv');
		 <?php }else{ ?>
		//loadquotationfun(3);
		<?php } ?>
		</script>
	</div>
<div style="text-align:left;" id="finalquote"></div>
</div>
<?php } ?>

<?php 

if($_GET['action']=='addQuery_Type'){ ?>
<div class="contentclass"> 
	<div id="sendmailfrm">
		<h1 style="text-align:left;">Module&nbsp;Type</h1>
		<div id="contentbox" class="addeditpagebox" style="padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="makeQuotation" target="actoinfrm"  id="makeQuotation">
				 
				<div class="griddiv">
					<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
					<div class="gridlable">Module&nbsp;Type<span class="redmind"></span></div>
					<select id="moduleTypeName" name="moduleTypeName" class="gridfield validate" displayname="Module Type" autocomplete="off" onchange="selectModuleType();"> 
						<option value="0">Select </option>
						<option value="query">Query Module</option>
						<option value="series">Series Module</option>
					</select> 
				</div>
				<script type="text/javascript" > 
					function selectModuleType(){
						// :selected
						var moduleType = $('#moduleTypeName :selected').val();
						//alert(moduleType);
						if(moduleType !=0 ){ 
							setupbox('showpage.crm?module='+moduleType+'&add=yes');
						}else{
							alert('Please select module');
						}
					}
				</script> 
			</form>
		</div>
		<div id="buttonsbox" style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
				<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="selectModuleType()" /></td>
				<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
				</tr>
			</table>
		</div>
	</div>
</div>
<?php }

if($_GET['action']=='addSubSeries' && $_REQUEST['queryId']!='' && $_REQUEST['quotationId']!=''){
	$select='*';
	$where='queryId='.decode($_REQUEST['queryId']).' and quotationId="'.$_REQUEST['quotationId'].'"';
	$rs=GetPageRecord($select,'newQuotationDays',$where);
	$countDays=mysqli_num_rows($rs);

	$quotationData=GetPageRecord($select,_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'" and isSeries=1');
	$quotationDataq=mysqli_fetch_array($quotationData);
	$quotationCount = mysqli_num_rows($quotationData);

	$queryData=GetPageRecord('seriesCode,night',_QUERY_MASTER_,'id="'.decode($_REQUEST['queryId']).'"');
	$queryDataq=mysqli_fetch_array($queryData);
	?>

<script src="js/zebra_datepicker.js"></script>
 <div class="contentclass">
<h1 style="text-align:left;">
<?php if($quotationCount > 0){ echo makeQuotationId($quotationDataq['id']); } else { echo 'Make Sub Series'; } ?></h1>
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellspacing="0" cellpadding="3" style="border: 1px solid #e7e7e8; padding: 10px; background-color: #fcfcfc; margin-bottom: 20px;">
  <tr>
    <td><div class="griddiv">
	<label>
	<div class="gridlable">Sub Series Name</div>
	<input name="subName" type="text" class="gridfield" id="subName" displayname="Sub Series" value="<?php if($quotationCount > 0){ echo $quotationDataq['subName']; } else { echo $queryDataq['seriesCode'];  } ?>" />

	</label>
	</div></td>
</tr>
  <tr>
    <td><div class="griddiv">
	<label>
	<div class="gridlable">Sub Series Code</div>
	<input name="subSeriesCode" type="text" class="gridfield" id="subSeriesCode" displayname="Sub Series Code" value="<?php if($quotationCount > 0){ echo $quotationDataq['subSeriesCode']; } ?>" />

	</label>
	</div></td>
</tr>
<tr>
    <td>
    	<table width="100%">
    		<tr>
    			<td>
    				<div class="griddiv">
<label>
<div class="gridlable" >Issue&nbsp;Date </div>
<input name="issueDate" type="text" id="issueDate" class="gridfield calfieldicon"  displayname="Issue Date"   autocomplete="off" value="<?php if($quotationCount > 0){ echo date('d-m-Y',strtotime($quotationDataq['issueDate'])); } else { echo date('d-m-Y'); } ?>" style="width:100%;"/>
</label>
</div></td>
    <td><div class="griddiv">
<label>
<div class="gridlable" >Total&nbsp;Days </div>
<input name="totalDays" type="text" id="totalDays" class="gridfield"  displayname="Total Days"   autocomplete="off" value="<?php echo $countDays; ?>" style="width:100%;" readonly="readonly" />
</label>
</div></td>
</tr>
</table>
</td>
    </tr>
    <tr>
    <td><div class="griddiv">
<label>
<div class="gridlable" >Start&nbsp;Date</div>
<input name="fromDate" type="text" id="fromDate" class="gridfield calfieldicon"  displayname="Valid From" autocomplete="off" value="<?php if($quotationCount > 0){ echo date('d-m-Y',strtotime($quotationDataq['fromDate'])); } else { } ?>" style="width:100%;"/>
</label>

</div></td>
    </tr>
    <tr>
    <td><div class="griddiv">
<label>
<div class="gridlable" >End&nbsp;Date</div>
<input name="toDate" type="text" id="toDate" class="gridfield calfieldicon"  displayname="Valid To"   autocomplete="off" value="<?php if($quotationCount > 0){ echo date('d-m-Y',strtotime($quotationDataq['toDate'])); } else { } ?>" style="width:100%;"/ readonly="readonly">
</label>
</div>
</td>
  </tr>
</table>
<script type="text/javascript">
	$('#fromDate').Zebra_DatePicker({
	  direction: 1,
	  format: 'd-m-Y',
		onSelect: function (date) {
			var tempdate = date.split("-").reverse().join("-");
			var todate = new Date(tempdate);

			var totalDays = <?php echo $queryDataq['night']; ?>;
			todate.setDate(todate.getDate() + Number(totalDays));
			var tempDD = todate.getDate();

			if(tempDD < 10){ var DD = '0'+tempDD; } else { var DD = tempDD; }

			var tempMM = todate.getMonth()+Number('1');
			if(tempMM < 10){ var MM = '0'+tempMM; } else { var MM = tempMM; }

			var YYYY = todate.getFullYear();
			$('#toDate').val(DD+'-'+MM+'-'+YYYY);
		}
  });

$('#issueDate').Zebra_DatePicker({
  format: 'd-m-Y',
});	
</script>
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
<input name="quotationId" type="hidden" id="quotationId" value="<?php echo encode($_REQUEST['quotationId']); ?>" />
<div id="buttonsbox"  style="text-align:center;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
  <tr><td>
  <?php if($quotationCount > 0){ ?> 
  	<input name="updatesubseries" type="button" class="bluembutton submitbtn" id="updatesubseries" value="Update" />
  <?php } else { ?>
  	<input name="subseries" type="button" class="bluembutton submitbtn" id="subseries" value="    Save    " />
  <?php } ?>
  </td>
	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
  </tr>
</table>
</div>
<div id="saveSubSeries"></div>
<script>
$(document).ready(function (){
	   $('#subseries').click(function(){
	   var subName = encodeURI($('#subName').val());
	   var subSeriesCode = encodeURI($('#subSeriesCode').val());
	   var issueDate = encodeURI($('#issueDate').val().split("-").reverse().join("-"));
	   var validFrom = encodeURI($('#fromDate').val().split("-").reverse().join("-"));
	   var validTo = encodeURI($('#toDate').val().split("-").reverse().join("-"));
	   var quotationId = encodeURI($('#quotationId').val());
	   var queryId = encodeURI($('#queryId').val());
	   if(subName == '' || issueDate == '' ||  validFrom == '' || validTo == '' ){
	   	alert('Fill All the fields');
	   }
	   else{
	$('#saveSubSeries').load('subSeriesAction.php?action=addSubSeries&queryId='+queryId+'&quotationId='+quotationId+'&subName='+subName+'&subSeriesCode='+subSeriesCode+'&issueDate='+issueDate+'&validFrom='+validFrom+'&validTo='+validTo);
	   }
	   })

	  $('#updatesubseries').click(function(){
	   var subName = encodeURI($('#subName').val());
	   var subSeriesCode = encodeURI($('#subSeriesCode').val());
	   var issueDate = encodeURI($('#issueDate').val().split("-").reverse().join("-"));
	   var validFrom = encodeURI($('#fromDate').val().split("-").reverse().join("-"));
	   var validTo = encodeURI($('#toDate').val().split("-").reverse().join("-"));
	   var quotationId = encodeURI($('#quotationId').val());
	   var queryId = encodeURI($('#queryId').val());
	   if(subName == '' || issueDate == '' ||  validFrom == '' || validTo == '' ){
	   	alert('Fill All the fields');
	   }
	   else{
	$('#saveSubSeries').load('subSeriesAction.php?action=updateSubSeries&queryId='+queryId+'&quotationId='+quotationId+'&subName='+subName+'&subSeriesCode='+subSeriesCode+'&issueDate='+issueDate+'&validFrom='+validFrom+'&validTo='+validTo);
	   }
	   })  
	}) 	
</script>
</div>
</div>
<style>
	.addeditpagebox .griddiv .gridlable {
    display: block;
}
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<?php } ?>

<?php if($_GET['action']=='hotelAvailability' && $_GET['queryId']!='') { ?>
 <div style="text-align:left;background-color:#ffffff;color: #233a49;margin-bottom: 12px;text-transform:uppercase;font-weight:600;letter-spacing:1px;font-size:13px;font-weight:500;padding:10px;border-bottom: 2px solid #233a49;">Check Availability</div>
    
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<?php
$queryId = decode($_GET['queryId']);

$dd=GetPageRecord('supplierId,supplierMasterId,quotationId,HotelSupplierStatus',_QUOTATION_HOTEL_MASTER_,'quotationId in (SELECT id from quotationMaster where queryId="'.$queryId.'" and isSeries=1 and isActive=0) group by supplierId');   
if(mysqli_num_rows($dd) > 0){
while($hotelQuotData=mysqli_fetch_array($dd)){	

$rr=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelQuotData['quotationId'].'"');   
$QuotDataq=mysqli_fetch_array($rr);

$supplierDataq=GetPageRecord('id',_SUPPLIERS_MASTER_,'id="'.$hotelQuotData['supplierMasterId'].'"'); 
	$supplierData=mysqli_fetch_array($supplierDataq);

$ddd=GetPageRecord('id,hotelName,hotelAddress,hotelCategoryId',_PACKAGE_BUILDER_HOTEL_MASTER_,'id="'.$hotelQuotData['supplierId'].'"');   
$hotelData=mysqli_fetch_array($ddd);

$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'id="'.$hotelData['hotelCategoryId'].'"');   
$hcD=mysqli_fetch_array($rr2);
 ?>
<tr>
<td colspan="10" style="color: white;background: #233a49;border: 0.15em solid #233a49;padding: 7px;font-size: 14px;border-radius: 2px;"><div style="display: grid;grid-template-columns: 3fr 0.7fr 0.4fr;">
<div style=" display: flex;align-items: center;line-height: 20px;"><?php echo $hotelData['hotelName'].' | '.$hcD['hotelCategory'].' Star | '.$hotelData['hotelAddress']; ?></div>
<div>
<select name="resRequest" id="resRequest<?php echo $hotelData['id']; ?>" style="height: 30px;border-radius: 2px;padding-left: 5px;" onchange="saverequest<?php echo $hotelData['id']; ?>();">
<option value="1" <?php if($hotelQuotData['HotelSupplierStatus'] == 1){ echo 'selected'; } ?>>Pending</option>
<option value="2" <?php if($hotelQuotData['HotelSupplierStatus'] == 2){ echo 'selected'; } ?>>Sent</option>
<option value="3" <?php if($hotelQuotData['HotelSupplierStatus'] == 3){ echo 'selected'; } ?>>Requested</option>
<option value="4" <?php if($hotelQuotData['HotelSupplierStatus'] == 4){ echo 'selected'; } ?>>Confirm</option>
<option value="5" <?php if($hotelQuotData['HotelSupplierStatus'] == 5){ echo 'selected'; } ?>>Rejected</option>
<option value="6" <?php if($hotelQuotData['HotelSupplierStatus'] == 6){ echo 'selected'; } ?>>Waitlist</option>
</select>
<script>
function saverequest<?php echo $hotelData['id']; ?>(){
var hotelId = <?php echo $hotelData['id']; ?>;
var queryId = <?php echo $QuotDataq['queryId']; ?>;
var status = $('#resRequest<?php echo $hotelData['id']; ?>').val();
$('#saveHotelRequest').load('subSeriesAction.php?action=saveHotelRequest&queryId='+queryId+'&hotelId='+hotelId+'&status='+status);
} 	
</script>	
</div>
<div><a id="sendSuppConfirmation<?php echo $hotelData['id']; ?>" style="background-color: #1b81ca; color: #FFFFFF !important; width: fit-content; cursor: pointer; padding: 6px 10px; border-radius: 2PX; box-sizing: border-box; float:right; margin-left: 3px;" href="showpage.crm?module=query&view=yes&supplier=1&supplierId=<?php echo encode($supplierData['id']); ?>&quotationId=<?php echo encode($QuotDataq['id']); ?>&id=<?php echo encode($queryId); ?>&availability=1" target="_blank">SEND</a> </div></div>
</td>	
</tr>
<tr>
<td colspan="10"></td>	
</tr>
<tr class="maintd">
<td>Destination</td>
<td>From</td>
<td>To</td>
<td>Nights</td>
<td>SGL</td>
<td>DBL</td>
<td>TPL</td>
<td>TWIN</td>
<td>Room&nbsp;Type</td>
<td style="border-right: 1px solid black">Meal&nbsp;Plan</td>
 </tr>
<?php
$rr=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,'quotationId in (SELECT id from quotationMaster where queryId="'.$queryId.'" and isSeries=1 and isActive=0) and supplierId="'.$hotelQuotData['supplierId'].'" order by fromDate asc');   
while($hotelDataq=mysqli_fetch_array($rr)){

	$d=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelDataq['quotationId'].'"');   
    $QuotData=mysqli_fetch_array($d);

	$roomTypeDataq=GetPageRecord('*',_ROOM_TYPE_MASTER_,'id='.$hotelDataq['roomType'].''); 
	$roomTypeData=mysqli_fetch_array($roomTypeDataq);

	$destinationDataq=GetPageRecord('*',_DESTINATION_MASTER_,'id='.$hotelDataq['destinationId'].''); 
	$destinationData=mysqli_fetch_array($destinationDataq);

$paxSlabDataq=GetPageRecord('*','totalPaxSlab','quotationId='.$hotelDataq['quotationId'].' and localEscort!=0 order by toRange desc limit 1'); 
    $paxSlabData=mysqli_fetch_array($paxSlabDataq);

	$mealPlanDataq=GetPageRecord('*',_MEAL_PLAN_MASTER_,'id='.$hotelDataq['mealPlan'].''); 
	$mealPlanData=mysqli_fetch_array($mealPlanDataq);
 ?>
<tr class="secondtd">
<td><?php echo $destinationData['name']; ?></td>
<td><?php echo date('d-m-Y',strtotime($hotelDataq['fromDate'])); ?></td>
<td><?php echo date('d-m-Y',strtotime("+1 day",strtotime($hotelDataq['fromDate']))); ?></td>
<td>1</td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo $paxSlabData['localEscort']; } else{ echo $QuotData['sglRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['dblRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['tplRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['twinRoom']; } ?></td>
<td><?php echo $roomTypeData['name']; ?></td>
<td style="border-right: 1px solid black"><?php echo $mealPlanData['name']; ?></td>	
</tr>
<?php } ?>
<tr>
<td colspan="10">&nbsp;</td>	
</tr>
<?php } } else { ?>
<tr>
<td style="text-align: center;height: 25px;background: #233a49d9;color: white;">No Hotel Found</td>	
</tr>	
<?php } ?>
</table>
</div>
<div id="saveHotelRequest"></div>
<style type="text/css">
.maintd td{
font-weight: 600;	
border:1px solid black;
padding: 5px;
border-right: none;
}	
.secondtd td{
border:1px solid black;
padding: 5px;
border-right: none;
border-top: none;	
}
</style>
<div style="text-align:center;margin: 10px">
<table border="0" align="right" cellpadding="0" cellspacing="0">
  <tr>
<!--   	<td style="padding-right:10px;"><input name="hotelsave" type="button" class="bluembutton submitbtn" id="hotelsave" value="Save" />
</td> -->
  	<!-- <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td> -->
  	<td style="padding-right:20px;"><input name="Cancel" type="button" class="bluembutton" id="Cancel" value="Save" onclick="location.href='<?php echo $fullurl; ?>showpage.crm?module=query&view=yes&id=<?php echo $_REQUEST['queryId']; ?>'"/></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
</table>
</div>
<?php }  ?>

<?php if($_GET['action']=='queryHotelAvailability' && $_GET['quotationId']!='' && $_GET['queryId']!='') { 

$quotationId = decode($_GET['quotationId']);

?>
 <div style="text-align:left;background-color:#ffffff;color: #233a49;margin-bottom: 12px;text-transform:uppercase;font-weight:600;letter-spacing:1px;font-size:13px;font-weight:500;padding:10px;border-bottom: 2px solid #233a49;">Check Availability</div>
    
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<?php

$queryId = decode($_GET['queryId']);

$dd=GetPageRecord('supplierId,supplierMasterId,quotationId,HotelSupplierStatus',_QUOTATION_HOTEL_MASTER_,'quotationId="'.$quotationId.'" group by supplierId');   
if(mysqli_num_rows($dd) > 0){
while($hotelQuotData=mysqli_fetch_array($dd)){	

$rr=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelQuotData['quotationId'].'"');   
$QuotDataq=mysqli_fetch_array($rr);

$supplierDataq=GetPageRecord('id',_SUPPLIERS_MASTER_,'id="'.$hotelQuotData['supplierMasterId'].'"'); 
	$supplierData=mysqli_fetch_array($supplierDataq);

$ddd=GetPageRecord('id,hotelName,hotelAddress,hotelCategoryId',_PACKAGE_BUILDER_HOTEL_MASTER_,'id="'.$hotelQuotData['supplierId'].'"');   
$hotelData=mysqli_fetch_array($ddd);

$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'id="'.$hotelData['hotelCategoryId'].'"');   
$hcD=mysqli_fetch_array($rr2);
 ?>
<tr>
<td colspan="18" style="color: white;background: #233a49;border: 0.15em solid #233a49;padding: 7px;font-size: 14px;border-radius: 2px;"><div style="display: grid;grid-template-columns: 3fr 0.7fr 0.4fr;">
<div style=" display: flex;align-items: center;line-height: 20px;width:722px;"><?php echo $hotelData['hotelName'].' | '.$hcD['hotelCategory'].' Star | '.$hotelData['hotelAddress']; ?></div>

<!-- <div style="display:none;">

<select name="resRequest" id="resRequest<?php echo $hotelData['id']; ?>" style="height: 30px;border-radius: 2px;padding-left: 5px;" onchange="saverequest<?php echo $hotelData['id']; ?>();">
<option value="1" <?php if($hotelQuotData['HotelSupplierStatus'] == 1){ echo 'selected'; } ?>>Pending</option>
<option value="2" <?php if($hotelQuotData['HotelSupplierStatus'] == 2){ echo 'selected'; } ?>>Sent</option>
<option value="3" <?php if($hotelQuotData['HotelSupplierStatus'] == 3){ echo 'selected'; } ?>>Requested</option>
<option value="4" <?php if($hotelQuotData['HotelSupplierStatus'] == 4){ echo 'selected'; } ?>>Confirm</option>
<option value="5" <?php if($hotelQuotData['HotelSupplierStatus'] == 5){ echo 'selected'; } ?>>Rejected</option>
<option value="6" <?php if($hotelQuotData['HotelSupplierStatus'] == 6){ echo 'selected'; } ?>>Waitlist</option>
</select>
<script>
function saverequest<?php echo $hotelData['id']; ?>(){
var hotelId = <?php echo $hotelData['id']; ?>;
var queryId = <?php echo $QuotDataq['queryId']; ?>;
var status = $('#resRequest<?php echo $hotelData['id']; ?>').val();
$('#saveHotelRequest').load('subSeriesAction.php?action=saveHotelRequest&queryId='+queryId+'&hotelId='+hotelId+'&status='+status);
} 	
</script>	
</div> -->
<div><a id="sendSuppConfirmation<?php echo $hotelData['id']; ?>" style="background-color: #1b81ca; color: #FFFFFF !important; width: fit-content; cursor: pointer; padding: 6px 10px; border-radius: 2PX; box-sizing: border-box; float:right; margin-left: 3px;" href="showpage.crm?module=query&view=yes&supplier=1&supplierId=<?php echo encode($supplierData['id']); ?>&quotationId=<?php echo encode($QuotDataq['id']); ?>&id=<?php echo encode($queryId); ?>&queryAvailability=1" target="_blank">SEND</a> </div></div>
</td>	
</tr>
<tr>
<td colspan="16"></td>	
</tr>
<tr class="maintd">
<td>Destination</td>
<td style="min-width: 70px;">From</td>
<td style="min-width: 70px;">To</td>
<td>Nights</td>
<td>SGL</td>
<td>DBL</td>
<td>TPL</td>
<td>TWIN</td>
<td>EBed(A)</td>
<?php if($QuotDataq['quadNoofRoom']>0){ ?>
<td>Quad</td>
<?php } if($QuotDataq['teenNoofRoom']>0){ ?>
<td>Teen</td>
<?php } ?>
<td>CWBed</td>
<td>CNBed</td>
<?php if($QuotDataq['sixNoofBedRoom']>0){ ?>
<td>Six&nbsp;BR</td>
<?php } if($QuotDataq['eightNoofBedRoom']>0){ ?>
<td>Eight&nbsp;BR</td>
<?php } if($QuotDataq['tenNoofBedRoom']>0){ ?>
<td>Ten&nbsp;BR</td>
<?php } ?>
<td>Room&nbsp;Type</td>
<td style="border-right: 1px solid black">Meal&nbsp;Plan</td>
 </tr>
<?php
$rr=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,'quotationId="'.$quotationId.'" and supplierId="'.$hotelQuotData['supplierId'].'" order by fromDate asc');   
while($hotelDataq=mysqli_fetch_array($rr)){

	$d=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelDataq['quotationId'].'"');   
    $QuotData=mysqli_fetch_array($d);

	$roomTypeDataq=GetPageRecord('*',_ROOM_TYPE_MASTER_,'id='.$hotelDataq['roomType'].''); 
	$roomTypeData=mysqli_fetch_array($roomTypeDataq);

	$destinationDataq=GetPageRecord('*',_DESTINATION_MASTER_,'id='.$hotelDataq['destinationId'].''); 
	$destinationData=mysqli_fetch_array($destinationDataq);

$paxSlabDataq=GetPageRecord('*','totalPaxSlab','quotationId='.$hotelDataq['quotationId'].' and localEscort!=0 order by toRange desc limit 1'); 
    $paxSlabData=mysqli_fetch_array($paxSlabDataq);

	$mealPlanDataq=GetPageRecord('*',_MEAL_PLAN_MASTER_,'id='.$hotelDataq['mealPlan'].''); 
	$mealPlanData=mysqli_fetch_array($mealPlanDataq);
 ?>
<tr class="secondtd">
<td><?php echo $destinationData['name'] ?></td>
<td><?php echo date('d-m-Y',strtotime($hotelDataq['fromDate'])); ?></td>
<td><?php echo date('d-m-Y',strtotime("+1 day",strtotime($hotelDataq['fromDate']))); ?></td>
<td>1</td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo $paxSlabData['localEscort']; } else{ echo $QuotData['sglRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['dblRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['tplRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['twinRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['extraNoofBed']; } ?></td>
<?php  if($QuotData['quadNoofRoom']>0){ ?><td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['quadNoofRoom']; } ?></td><?php }  if($QuotData['teenNoofRoom']>0){ ?>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['teenNoofRoom']; } ?></td> <?php } ?>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['childwithNoofBed']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['childwithoutNoofBed']; } ?></td>
<?php if($QuotData['sixNoofBedRoom']>0){ ?>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['sixNoofBedRoom']; } ?></td>
<?php } if($QuotData['eightNoofBedRoom']>0){ ?>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['eightNoofBedRoom']; } ?></td>
<?php } if($QuotData['tenNoofBedRoom']>0){ ?>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['tenNoofBedRoom']; } ?></td>
<?php } ?>
<td><?php echo $roomTypeData['name']; ?></td>
<td style="border-right: 1px solid black"><?php echo $mealPlanData['name']; ?></td>	
</tr>
<?php } ?>
<tr>
<td colspan="11">&nbsp;</td>	
</tr>
<?php } } else{ ?>
<tr>
<td style="text-align: center;height: 25px;background: #233a49d9;color: white;">No Hotel Found</td>	
</tr>	
<?php } ?>
</table>
</div>
<div id="saveHotelRequest"></div>
<style type="text/css">
.maintd td{
font-weight: 600;	
border:1px solid black;
padding: 5px;
border-right: none;
}	
.secondtd td{
border:1px solid black;
padding: 5px;
border-right: none;
border-top: none;	
}
</style>
<div style="text-align:center;margin: 10px;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
  <tr>
  	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
</table>
</div>
<?php }
if($_GET['action']=='addFixDeparture' && $_REQUEST['queryId']!='' && $_REQUEST['quotationId']!=''){
$select='*';
$where='queryId='.decode($_REQUEST['queryId']).' and quotationId="'.$_REQUEST['quotationId'].'"';
$rs=GetPageRecord($select,'newQuotationDays',$where);
$countDays=mysqli_num_rows($rs);

$quotationData=GetPageRecord($select,_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'" and isFD=1');
$quotationDataq=mysqli_fetch_array($quotationData);
$quotationCount = mysqli_num_rows($quotationData);

$queryData=GetPageRecord('FDCode,night',_QUERY_MASTER_,'id="'.decode($_REQUEST['queryId']).'"');
$queryDataq=mysqli_fetch_array($queryData);
?>

<script src="js/zebra_datepicker.js"></script>
 <div class="contentclass">
<h1 style="text-align:left;">
<?php if($quotationCount > 0){ echo makeQuotationId($quotationDataq['id']); } else { echo 'Make Fix Departure'; } ?></h1>
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellspacing="0" cellpadding="3" style="border: 1px solid #e7e7e8; padding: 10px; background-color: #fcfcfc; margin-bottom: 20px;">
  <tr>
    <td><div class="griddiv">
	<label>
	<div class="gridlable">Fix&nbsp;Departure&nbsp;Id</div>
	<input name="subName" type="text" class="gridfield" id="subName" displayname="Fix Departure" value="<?php if($quotationCount > 0){ echo $quotationDataq['subName']; } else { echo $queryDataq['FDCode'];  } ?>" />

	</label>
	</div></td>
</tr>
<tr>
    <td>
    	<table width="100%">
    		<tr>
    			<td>
    				<div class="griddiv">
<label>
<div class="gridlable" >Issue&nbsp;Date</div>
<input name="issueDate" type="text" id="issueDate" class="gridfield calfieldicon"  displayname="Issue Date"   autocomplete="off" value="<?php if($quotationCount > 0){ echo date('d-m-Y',strtotime($quotationDataq['issueDate'])); } else { echo date('d-m-Y'); } ?>" style="width:100%;"/>
</label>
</div></td>
    <td><div class="griddiv">
<label>
<div class="gridlable" >Total&nbsp;Days </div>
<input name="totalDays" type="text" id="totalDays" class="gridfield"  displayname="Total Days"   autocomplete="off" value="<?php echo $countDays; ?>" style="width:100%;" readonly="readonly" />
</label>
</div></td>
</tr>
</table>
</td>
    </tr>
    <tr>
    <td><div class="griddiv">
<label>
<div class="gridlable" >Start&nbsp;Date</div>
<input name="fromDate" type="text" id="fromDate" class="gridfield calfieldicon"  displayname="Valid From" autocomplete="off" value="<?php if($quotationCount > 0){ echo date('d-m-Y',strtotime($quotationDataq['fromDate'])); } else { } ?>" style="width:100%;"/>
</label>

</div></td>
    </tr>
    <tr>
    <td><div class="griddiv">
<label>
<div class="gridlable" >End&nbsp;Date</div>
<input name="toDate" type="text" id="toDate" class="gridfield calfieldicon"  displayname="Valid To"   autocomplete="off" value="<?php if($quotationCount > 0){ echo date('d-m-Y',strtotime($quotationDataq['toDate'])); } else { } ?>" style="width:100%;"/ readonly="readonly">
</label>
</div>
</td>
  </tr>
</table>
<script type="text/javascript">
$('#fromDate').Zebra_DatePicker({
   direction: 1,
  format: 'd-m-Y',
onSelect: function (date) {
var tempdate = date.split("-").reverse().join("-");
var todate = new Date(tempdate);

var totalDays = <?php echo $queryDataq['night']; ?>;
todate.setDate(todate.getDate() + Number(totalDays));
var tempDD = todate.getDate();

if(tempDD < 10){ var DD = '0'+tempDD; } else { var DD = tempDD; }

var tempMM = todate.getMonth()+Number('1');
if(tempMM < 10){ var MM = '0'+tempMM; } else { var MM = tempMM; }

var YYYY = todate.getFullYear();
$('#toDate').val(DD+'-'+MM+'-'+YYYY);
}
  });

$('#issueDate').Zebra_DatePicker({
  format: 'd-m-Y',
});	
</script>
<input name="queryId" type="hidden" id="queryId" value="<?php echo $_REQUEST['queryId']; ?>" />
<input name="quotationId" type="hidden" id="quotationId" value="<?php echo encode($_REQUEST['quotationId']); ?>" />
<div id="buttonsbox"  style="text-align:center;">
<table border="0" align="right" cellpadding="0" cellspacing="0">
  <tr><td>
  <?php if($quotationCount > 0){ ?> 
  	<input name="updatefixdeparture" type="button" class="bluembutton submitbtn" id="updatefixdeparture" value="Update" />
  <?php } else { ?>
  	<input name="fixdeparture" type="button" class="bluembutton submitbtn" id="fixdepartureBtn" value="    Save    " />
  <?php } ?>
  </td>
	<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
  </tr>
</table>
</div>
<div id="saveFixDeparture"></div>
<script>
$(document).ready(function (){
	   $('#fixdepartureBtn').click(function(){
		   var subName = encodeURI($('#subName').val());
		   var issueDate = encodeURI($('#issueDate').val().split("-").reverse().join("-"));
		   var validFrom = encodeURI($('#fromDate').val().split("-").reverse().join("-"));
		   var validTo = encodeURI($('#toDate').val().split("-").reverse().join("-"));
		   var quotationId = encodeURI($('#quotationId').val());
		   var queryId = encodeURI($('#queryId').val());
		   if(subName == '' || issueDate == '' ||  validFrom == '' || validTo == '' ){
				alert('Fill All the fields');
		   }
		   else{
				$('#saveFixDeparture').load('fixDepartureAction.php?action=addFixDeparture&queryId='+queryId+'&quotationId='+quotationId+'&subName='+subName+'&issueDate='+issueDate+'&validFrom='+validFrom+'&validTo='+validTo);
		   }
	   })

	  $('#updatefixdeparture').click(function(){
		   var subName = encodeURI($('#subName').val());
		   var issueDate = encodeURI($('#issueDate').val().split("-").reverse().join("-"));
		   var validFrom = encodeURI($('#fromDate').val().split("-").reverse().join("-"));
		   var validTo = encodeURI($('#toDate').val().split("-").reverse().join("-"));
		   var quotationId = encodeURI($('#quotationId').val());
		   var queryId = encodeURI($('#queryId').val());
		   if(subName == '' || issueDate == '' ||  validFrom == '' || validTo == '' ){
			alert('Fill All the fields');
		   }
		   else{
				$('#saveFixDeparture').load('fixDepartureAction.php?action=updateFixDeparture&queryId='+queryId+'&quotationId='+quotationId+'&subName='+subName+'&issueDate='+issueDate+'&validFrom='+validFrom+'&validTo='+validTo);
		   }
	   })  
	}) 	
</script>
</div>
</div>
<style>
	.addeditpagebox .griddiv .gridlable {
    display: block;
}
.addeditpagebox .griddiv .Zebra_DatePicker_Icon_Wrapper {
    width: 100% !important;
}
</style>
<?php }

 if($_GET['action']=='fixDepHotelAvailability' && $_GET['queryId']!='') { ?>
 <div style="text-align:left;background-color:#ffffff;color: #233a49;margin-bottom: 12px;text-transform:uppercase;font-weight:600;letter-spacing:1px;font-size:13px;font-weight:500;padding:10px;border-bottom: 2px solid #233a49;">Check Availability</div>
    
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<?php
$queryId = decode($_GET['queryId']);

$dd=GetPageRecord('supplierId,supplierMasterId,quotationId,HotelSupplierStatus',_QUOTATION_HOTEL_MASTER_,'quotationId in (SELECT id from quotationMaster where queryId="'.$queryId.'" and isFD=1 and isActive=0) group by supplierId');   
if(mysqli_num_rows($dd) > 0){
while($hotelQuotData=mysqli_fetch_array($dd)){	

$rr=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelQuotData['quotationId'].'"');   
$QuotDataq=mysqli_fetch_array($rr);

$supplierDataq=GetPageRecord('id',_SUPPLIERS_MASTER_,'id="'.$hotelQuotData['supplierMasterId'].'"'); 
	$supplierData=mysqli_fetch_array($supplierDataq);

$ddd=GetPageRecord('id,hotelName,hotelAddress,hotelCategoryId',_PACKAGE_BUILDER_HOTEL_MASTER_,'id="'.$hotelQuotData['supplierId'].'"');   
$hotelData=mysqli_fetch_array($ddd);

$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'id="'.$hotelData['hotelCategoryId'].'"');   
$hcD=mysqli_fetch_array($rr2);
 ?>
<tr>
<td colspan="10" style="color: white;background: #233a49;border: 0.15em solid #233a49;padding: 7px;font-size: 14px;border-radius: 2px;"><div style="display: grid;grid-template-columns: 3fr 0.7fr 0.4fr;">
<div style=" display: flex;align-items: center;line-height: 20px;"><?php echo $hotelData['hotelName'].' | '.$hcD['hotelCategory'].' Star | '.$hotelData['hotelAddress']; ?></div>
<div>
<select name="resRequest" id="resRequest<?php echo $hotelData['id']; ?>" style="height: 30px;border-radius: 2px;padding-left: 5px;" onchange="saverequest<?php echo $hotelData['id']; ?>();">
<option value="1" <?php if($hotelQuotData['HotelSupplierStatus'] == 1){ echo 'selected'; } ?>>Pending</option>
<option value="2" <?php if($hotelQuotData['HotelSupplierStatus'] == 2){ echo 'selected'; } ?>>Sent</option>
<option value="3" <?php if($hotelQuotData['HotelSupplierStatus'] == 3){ echo 'selected'; } ?>>Requested</option>
<option value="4" <?php if($hotelQuotData['HotelSupplierStatus'] == 4){ echo 'selected'; } ?>>Confirm</option>
<option value="5" <?php if($hotelQuotData['HotelSupplierStatus'] == 5){ echo 'selected'; } ?>>Rejected</option>
<option value="6" <?php if($hotelQuotData['HotelSupplierStatus'] == 6){ echo 'selected'; } ?>>Waitlist</option>
</select>
<script>
function saverequest<?php echo $hotelData['id']; ?>(){
var hotelId = <?php echo $hotelData['id']; ?>;
var queryId = <?php echo $QuotDataq['queryId']; ?>;
var status = $('#resRequest<?php echo $hotelData['id']; ?>').val();
$('#saveHotelRequest').load('fixDepartureAction.php?action=saveHotelRequest&queryId='+queryId+'&hotelId='+hotelId+'&status='+status);
} 	
</script>	
</div>
<div><a id="sendSuppConfirmation<?php echo $hotelData['id']; ?>" style="background-color: #1b81ca; color: #FFFFFF !important; width: fit-content; cursor: pointer; padding: 6px 10px; border-radius: 2PX; box-sizing: border-box; float:right; margin-left: 3px;" href="showpage.crm?module=query&view=yes&supplier=1&supplierId=<?php echo encode($supplierData['id']); ?>&quotationId=<?php echo encode($QuotDataq['id']); ?>&id=<?php echo encode($queryId); ?>&availability=1" target="_blank">SEND</a> </div></div>
</td>	
</tr>
<tr>
<td colspan="10"></td>	
</tr>
<tr class="maintd">
<td>Destination</td>
<td>From</td>
<td>To</td>
<td>Nights</td>
<td>SGL</td>
<td>DBL</td>
<td>TPL</td>
<td>TWIN</td>
<td>EBed(C)</td>
<td>Room&nbsp;Type</td>
<td style="border-right: 1px solid black">Meal&nbsp;Plan</td>
 </tr>
<?php
$rr=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,'quotationId in (SELECT id from quotationMaster where queryId="'.$queryId.'" and isFD=1 and isActive=0) and supplierId="'.$hotelQuotData['supplierId'].'" order by fromDate asc');   
while($hotelDataq=mysqli_fetch_array($rr)){

	$d=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelDataq['quotationId'].'"');   
    $QuotData=mysqli_fetch_array($d);

	$roomTypeDataq=GetPageRecord('*',_ROOM_TYPE_MASTER_,'id='.$hotelDataq['roomType'].''); 
	$roomTypeData=mysqli_fetch_array($roomTypeDataq);

	$destinationDataq=GetPageRecord('*',_DESTINATION_MASTER_,'id='.$hotelDataq['destinationId'].''); 
	$destinationData=mysqli_fetch_array($destinationDataq);

$paxSlabDataq=GetPageRecord('*','totalPaxSlab','quotationId='.$hotelDataq['quotationId'].' and localEscort!=0 order by toRange desc limit 1'); 
    $paxSlabData=mysqli_fetch_array($paxSlabDataq);

	$mealPlanDataq=GetPageRecord('*',_MEAL_PLAN_MASTER_,'id='.$hotelDataq['mealPlan'].''); 
	$mealPlanData=mysqli_fetch_array($mealPlanDataq);
 ?>
<tr class="secondtd">
<td><?php echo $destinationData['name']; ?></td>
<td><?php echo date('d-m-Y',strtotime($hotelDataq['fromDate'])); ?></td>
<td><?php echo date('d-m-Y',strtotime("+1 day",strtotime($hotelDataq['fromDate']))); ?></td>
<td>1</td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo $paxSlabData['localEscort']; } else{ echo $QuotData['sglRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['dblRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['tplRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['twinRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['childwithNoofBed']; } ?></td>
<td><?php echo $roomTypeData['name']; ?></td>
<td style="border-right: 1px solid black"><?php echo $mealPlanData['name']; ?></td>	
</tr>
<?php } ?>
<tr>
<td colspan="10">&nbsp;</td>	
</tr>
<?php } } else { ?>
<tr>
<td style="text-align: center;height: 25px;background: #233a49d9;color: white;">No Hotel Found</td>	
</tr>	
<?php } ?>
</table>
</div>
<div id="saveHotelRequest"></div>
<style type="text/css">
.maintd td{
font-weight: 600;	
border:1px solid black;
padding: 5px;
border-right: none;
}	
.secondtd td{
border:1px solid black;
padding: 5px;
border-right: none;
border-top: none;	
}
</style>
<div style="text-align:center;margin: 10px">
<table border="0" align="right" cellpadding="0" cellspacing="0">
  <tr>
<!--   	<td style="padding-right:10px;"><input name="hotelsave" type="button" class="bluembutton submitbtn" id="hotelsave" value="Save" />
</td> -->
  	<!-- <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td> -->
  	<td style="padding-right:20px;"><input name="Cancel" type="button" class="bluembutton" id="Cancel" value="Save" onclick="location.href='<?php echo $fullurl; ?>showpage.crm?module=query&view=yes&id=<?php echo $_REQUEST['queryId']; ?>'"/></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
</table>
</div>
<?php } 

if($_GET['action']=='packageHotelAvailability' && $_GET['queryId']!='') { ?>
 <div style="text-align:left;background-color:#ffffff;color: #233a49;margin-bottom: 12px;text-transform:uppercase;font-weight:600;letter-spacing:1px;font-size:13px;font-weight:500;padding:10px;border-bottom: 2px solid #233a49;">Check Availability</div>
    
<div id="contentbox" class="addeditpagebox" style="padding: 0px 20px; overflow:auto; text-align:left; margin-bottom:0px; " >
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<?php
$queryId = decode($_GET['queryId']);

$dd=GetPageRecord('supplierId,supplierMasterId,quotationId,HotelSupplierStatus',_QUOTATION_HOTEL_MASTER_,'quotationId in (SELECT id from quotationMaster where queryId="'.$queryId.'" and isPackage=1 and isActive=0) group by supplierId');   
if(mysqli_num_rows($dd) > 0){
while($hotelQuotData=mysqli_fetch_array($dd)){	

$rr=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelQuotData['quotationId'].'"');   
$QuotDataq=mysqli_fetch_array($rr);

$supplierDataq=GetPageRecord('id',_SUPPLIERS_MASTER_,'id="'.$hotelQuotData['supplierMasterId'].'"'); 
	$supplierData=mysqli_fetch_array($supplierDataq);

$ddd=GetPageRecord('id,hotelName,hotelAddress,hotelCategoryId',_PACKAGE_BUILDER_HOTEL_MASTER_,'id="'.$hotelQuotData['supplierId'].'"');   
$hotelData=mysqli_fetch_array($ddd);

$rr2=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'id="'.$hotelData['hotelCategoryId'].'"');   
$hcD=mysqli_fetch_array($rr2);
 ?>
<tr>
<td colspan="10" style="color: white;background: #233a49;border: 0.15em solid #233a49;padding: 7px;font-size: 14px;border-radius: 2px;"><div style="display: grid;grid-template-columns: 3fr 0.7fr 0.4fr;">
<div style=" display: flex;align-items: center;line-height: 20px;"><?php echo $hotelData['hotelName'].' | '.$hcD['hotelCategory'].' Star | '.$hotelData['hotelAddress']; ?></div>
<div>
<select name="resRequest" id="resRequest<?php echo $hotelData['id']; ?>" style="height: 30px;border-radius: 2px;padding-left: 5px;" onchange="saverequest<?php echo $hotelData['id']; ?>();">
<option value="1" <?php if($hotelQuotData['HotelSupplierStatus'] == 1){ echo 'selected'; } ?>>Pending</option>
<option value="2" <?php if($hotelQuotData['HotelSupplierStatus'] == 2){ echo 'selected'; } ?>>Sent</option>
<option value="3" <?php if($hotelQuotData['HotelSupplierStatus'] == 3){ echo 'selected'; } ?>>Requested</option>
<option value="4" <?php if($hotelQuotData['HotelSupplierStatus'] == 4){ echo 'selected'; } ?>>Confirm</option>
<option value="5" <?php if($hotelQuotData['HotelSupplierStatus'] == 5){ echo 'selected'; } ?>>Rejected</option>
<option value="6" <?php if($hotelQuotData['HotelSupplierStatus'] == 6){ echo 'selected'; } ?>>Waitlist</option>
</select>
<script>
function saverequest<?php echo $hotelData['id']; ?>(){
var hotelId = <?php echo $hotelData['id']; ?>;
var queryId = <?php echo $QuotDataq['queryId']; ?>;
var status = $('#resRequest<?php echo $hotelData['id']; ?>').val();
$('#saveHotelRequest').load('frmaction.php?action=savePackageHotelRequest&queryId='+queryId+'&hotelId='+hotelId+'&status='+status);
} 	
</script>	
</div>
<div><a id="sendSuppConfirmation<?php echo $hotelData['id']; ?>" style="background-color: #1b81ca; color: #FFFFFF !important; width: fit-content; cursor: pointer; padding: 6px 10px; border-radius: 2PX; box-sizing: border-box; float:right; margin-left: 3px;" href="showpage.crm?module=query&view=yes&supplier=1&supplierId=<?php echo encode($supplierData['id']); ?>&quotationId=<?php echo encode($QuotDataq['id']); ?>&id=<?php echo encode($queryId); ?>&availability=1" target="_blank">SEND</a> </div></div>
</td>	
</tr>
<tr>
<td colspan="10"></td>	
</tr>
<tr class="maintd">
<td>Destination</td>
<td>From</td>
<td>To</td>
<td>Nights</td>
<td>SGL</td>
<td>DBL</td>
<td>TPL</td>
<td>TWIN</td>
<td>EBed(C)</td>

><td>Room&nbsp;Type</td>
<td style="border-right: 1px solid black">Meal&nbsp;Plan</td>
 </tr>
<?php
$rr=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,'quotationId in (SELECT id from quotationMaster where queryId="'.$queryId.'" and isPackage=1 and isActive=0) and supplierId="'.$hotelQuotData['supplierId'].'" order by fromDate asc');   
while($hotelDataq=mysqli_fetch_array($rr)){

	$d=GetPageRecord('*',_QUOTATION_MASTER_,'id="'.$hotelDataq['quotationId'].'"');   
    $QuotData=mysqli_fetch_array($d);

	$roomTypeDataq=GetPageRecord('*',_ROOM_TYPE_MASTER_,'id='.$hotelDataq['roomType'].''); 
	$roomTypeData=mysqli_fetch_array($roomTypeDataq);

	$destinationDataq=GetPageRecord('*',_DESTINATION_MASTER_,'id='.$hotelDataq['destinationId'].''); 
	$destinationData=mysqli_fetch_array($destinationDataq);

$paxSlabDataq=GetPageRecord('*','totalPaxSlab','quotationId='.$hotelDataq['quotationId'].' and localEscort!=0 order by toRange desc limit 1'); 
    $paxSlabData=mysqli_fetch_array($paxSlabDataq);

	$mealPlanDataq=GetPageRecord('*',_MEAL_PLAN_MASTER_,'id='.$hotelDataq['mealPlan'].''); 
	$mealPlanData=mysqli_fetch_array($mealPlanDataq);
 ?>
<tr class="secondtd">
<td><?php echo $destinationData['name']; ?></td>
<td><?php echo date('d-m-Y',strtotime($hotelDataq['fromDate'])); ?></td>
<td><?php echo date('d-m-Y',strtotime("+1 day",strtotime($hotelDataq['fromDate']))); ?></td>
<td>1</td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo $paxSlabData['localEscort']; } else{ echo $QuotData['sglRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['dblRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['tplRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['twinRoom']; } ?></td>
<td><?php if($hotelDataq['escortHotelStatus'] == 1){ echo '_'; } else{ echo $QuotData['childwithNoofBed']; } ?></td>
<td><?php echo $roomTypeData['name']; ?></td>
<td style="border-right: 1px solid black"><?php echo $mealPlanData['name']; ?></td>	
</tr>
<?php } ?>
<tr>
<td colspan="10">&nbsp;</td>	
</tr>
<?php } } else { ?>
<tr>
<td style="text-align: center;height: 25px;background: #233a49d9;color: white;">No Hotel Found</td>	
</tr>	
<?php } ?>
</table>
</div>
<div id="saveHotelRequest"></div>
<style type="text/css">
.maintd td{
font-weight: 600;	
border:1px solid black;
padding: 5px;
border-right: none;
}	
.secondtd td{
border:1px solid black;
padding: 5px;
border-right: none;
border-top: none;	
}
</style>
<div style="text-align:center;margin: 10px">
<table border="0" align="right" cellpadding="0" cellspacing="0">
  <tr>
<!--   	<td style="padding-right:10px;"><input name="hotelsave" type="button" class="bluembutton submitbtn" id="hotelsave" value="Save" />
</td> -->
  	<!-- <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td> -->
  	<td style="padding-right:20px;"><input name="Cancel" type="button" class="bluembutton" id="Cancel" value="Save" onclick="location.href='<?php echo $fullurl; ?>showpage.crm?module=query&view=yes&id=<?php echo $_REQUEST['queryId']; ?>'"/></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
</table>
</div>
<?php } 

if($_REQUEST['action']=='leadAssignTask' && $_REQUEST['id']!=''){

$editId=decode($_REQUEST['id']);

?> 
<style>
.addeditpagebox .griddiv .gridlable {
    width: 100%;
}
.newtowrobox .griddiv{
    width: 12% !important;
    display: inline-block;
    margin: 8px;
  }
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #2bb0dd!important;">Select Task</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<input name="action" id="action" type="hidden" value="leadAssignTask" />
	<input name="editId" id="editId" type="hidden" value="<?php echo $_REQUEST['id']; ?>" />
<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
    <tr>
   <td>
   	<div style="display: grid;grid-template-columns: 2fr 1fr;float: left;overflow: hidden;width: 100%;">
     <div style="margin-bottom: 10px; margin-right: 2%;">
	 <label>Task Title</label>
<input type="text" class="validate gridfield" displayname="Task Title" id="taskTitle" name="taskTitle" style="text-align: left; width: 95%; padding: 7px 5px !important; border-radius: 2px;" value=""> 
	 </div> 
	<div style="margin-bottom: 10px;margin-right: 2%;">
	 <label>Assign To</label>
		<select name="assignTo" id="assignTo" class="validate gridfield" displayname="Assign To" style="text-align: left; width: 99%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
<option value="">Select</option>
<?php  
$assignDataq=GetPageRecord('id,firstName,lastName','userMaster','1 and status=1 and deletestatus=0 order by firstName');   
while($assignData=mysqli_fetch_array($assignDataq)){ ?>
<option value="<?php echo $assignData['id']; ?>"><?php echo $assignData['firstName'].' '.$assignData['lastName']; ?></option>
<?php } ?>
		</select>
	 </div>
	 </div> 
	 <div style="display: grid;grid-template-columns: 1fr 1fr 1fr;float: left;overflow: hidden;width: 100%;">
     <div style="float: left; margin-bottom: 10px;margin-right: 2%;">
	 <label>Task Date</label>
	 <input type="date" class="validate gridfield" displayname="Task Date" id="actionDate" name="actionDate" style="text-align: left; width: 94% !important; padding: 5px !important; border-radius: 2px;" value="<?php echo date('Y-m-d'); ?>">
	 </div>  
	 <div style="margin-bottom: 10px;margin-right: 2%;">
	 <label>Task Time</label>
		<select name="actionTime" id="actionTime" class="validate gridfield" displayname="Task Time" style="text-align: left; width: 99%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
	<?php 
	 $start=strtotime('00:00'); 
	 $end=strtotime('23:59'); 
	for ($i=$start;$i<=$end;$i = $i + 15*60){ ?>
	<option value="<?php echo date('H:i',$i); ?>" <?php if(date('H:i',$i)=="10:00"){ ?> selected="selected" <?php } ?>><?php echo date('g:i A',$i); ?></option>
	<?php } ?>
		</select>
	 </div>
	  <div style="margin-bottom: 10px;margin-right: 2%;">
	 <label>Reminder</label>
	 <select name="reminderTime" class="validate gridfield" id="reminderTime" style="text-align: left; width: 99%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
   <option value="0" >No Reminder</option>  
   <option value="15" >Before 15 Min.</option>  
   <option value="30" >Before 30 Min.</option>  
   <option value="45" >Before 45 Min.</option>  
   <option value="60" >Before 1 Hour</option>  
   <option value="120" >Before 2 Hour</option>   
      </select>
	 </div>  
	 
	 </div> 
	 <div style="width: 100%; float: left; margin-bottom: 10px; overflow: hidden; margin-right: 2%;">
	 <label>Notes</label>
	 <input type="text" class="gridfield" id="notes" name="notes" style="text-align: left; width: 98%; padding: 5px !important; border-radius: 2px;">
	 </div>
   </td>
   </tr> 
</table> 
</div>
</div>  
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td><div class="bluembutton" onclick="saveMeetingTask();">Save</div>
      	</td> 
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
      
   	<script>
function saveMeetingTask(){
var title = encodeURI($('#taskTitle').val());
var assignTo = encodeURI($('#assignTo').val());
var actionDate = encodeURI($('#actionDate').val());
var actionTime = encodeURI($('#actionTime').val());
var notes = encodeURI($('#notes').val());
var reminderTime = encodeURI($('#reminderTime').val()); 
$('#savedata').load('frmaction.php?action=saveLeadTask&editId=<?php echo $_REQUEST['id'] ?>'+'&title='+title+'&assignTo='+assignTo+'&actionDate='+actionDate+'&actionTime='+actionTime+'&reminderTime='+reminderTime+'&notes='+notes);
		   
}	
</script>
 
   </table>
   <div style="display:none" id="savedata"></div>
</div>
</div>
<style>
.newtowrobox .griddiv {
    width: 100% !important;
}
</style>
	<?php } 
if($_REQUEST['action']=='addtodosaleaction' && $_REQUEST['id']!=''){

if($_REQUEST['id']!=''){
$id=decode($_REQUEST['id']);

 if($_REQUEST['type'] == 'lead'){
  
  $resultListsq=GetPageRecord('fromDate,starttime','leadManageMaster','1 and id="'.$id.'"');
  $resultLists=mysqli_fetch_array($resultListsq);
}
 if($_REQUEST['type'] == 'activity'){

  $resultListsq=GetPageRecord('fromDate,starttime','activityMaster','1 and id="'.$id.'"');
  $resultLists=mysqli_fetch_array($resultListsq);
 }
 if($_REQUEST['type'] == 'call'){

  $resultListsq=GetPageRecord('fromDate,starttime',_CALLS_MASTER_,'1 and id="'.$id.'"');
  $resultLists=mysqli_fetch_array($resultListsq);
 }
 if($_REQUEST['type'] == 'task'){

  $resultListsq=GetPageRecord('fromDate,starttime',_TASKS_MASTER_,'1 and id="'.$id.'"');
  $resultLists=mysqli_fetch_array($resultListsq);
 }
 if($_REQUEST['type'] == 'meeting'){
 	$resultListsq=GetPageRecord('fromDate,starttime',_MEETINGS_MASTER_,'1 and id="'.$id.'"');
  $resultLists=mysqli_fetch_array($resultListsq);
}

}
?> 
<style>
.addeditpagebox .griddiv .gridlable {
width: 100%;
}
.newtowrobox .griddiv{  
width: 12% !important;
display: inline-block;
margin: 8px;
}
.addBtn {
background-color: #cccccc5c!important;
padding: 8px;
color: bloack;
border: 1px solid #8080806b;
	}
.newtowrobox .griddiv {
width: 100% !important;
}
</style>
<div class="contentclass">
<div id="sendmailfrm">
<h1 style="text-align:left; background-color: #2bb0dd!important;">Select Status</h1>
  <div id="contentbox" class="addeditpagebox newtowrobox" style="padding:16px; text-align:left; margin-bottom:0px; " >
<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="saveVehile" target="actoinfrm"  id="saveVehile"> 
    <input name="action" id="action" type="hidden" value="addtodosaleaction" />
	 <input name="editId" id="editId" type="hidden" value="<?php echo $_REQUEST['id']; ?>" />
	 <input name="type" id="type" type="hidden" value="<?php echo $_REQUEST['type']; ?>" />
<table width="99%"  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
   <tr>
   	  <td width="30%">
   	  	 <select id="todoStatus" name="todoStatus" class="validate gridfield" displayname="Status" autocomplete="off" style="padding: 8px;width: 249px;" onchange="loadtodostatus();">
			  <!-- <select id="status" name="status" class="gridfield" autocomplete="off"   >  -->
			<?php
			$select='';
			$where='';
			$rs=''; 
			$select='*';  
			$where='id!="" order by id';
			$rs=GetPageRecord($select,_CALLS_STATUS_MASTER_,$where);
			while($rest=mysqli_fetch_array($rs)){ 
			?>
			<option value="<?php echo $rest['id']; ?>" <?php if($statusedit==$rest['id']){ ?>selected="selected"<?php } ?>><?php echo $rest['name']; ?></option> 
			<?php } ?>
			</select>
   	  </td>
   </tr>   
   <tr id="extededblock" style="display:none;">
   <td>
     <div style="width:10%; display:inline-block;margin-right: 16px;">
	 <input type="date" class="gridfield" id="toDoDate" name="toDoDate" style="text-align: left; width: 100%; padding: 5px !important; border-radius: 2px;" value="<?php echo $resultLists['fromDate']; ?>">
	 </div>  
	 <div style="width:10%; display:inline-block;">
		<select name="toDotime" id="toDotime" class="gridfield" style="text-align: left; width: 100%; padding: 7px !important; border-radius: 2px; box-shadow: none;">
	<?php 
	 $start=strtotime('00:00'); 
	 $end=strtotime('23:59'); 
	for ($i=$start;$i<=$end;$i = $i + 15*60){ ?>
	<option value="<?php echo date('g:i A',$i); ?>" <?php if(date('g:i A',strtotime($resultLists['starttime']))==date('g:i A',$i)){ ?> selected="selected" <?php } ?>><?php echo date('g:i A',$i); ?></option>
	<?php } ?>
		</select>
	 </div> 
   </td>
   </tr> 
</table> 
</div>
</div> 
 <div id="buttonsbox"  style="text-align:center;">
 <table border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      	<td><input name="addnewuserbtn" type="button" class="bluembutton saveflight" id="addnewuserbtn" value="Save" onclick="formValidation('saveVehile','saveflight','0');" style=" background-color: #57a0a4 !important;" /></td> 
        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="alertspopupopenClose();" /></td>
      </tr>
   </table>
</div>
</div>
<script> 
function loadtodostatus(){
 var todoStatus = $('#todoStatus').val();
  if(todoStatus==5){
  $('#extededblock').show();
 }else{
	$('#extededblock').hide();
 }
} 
	</script>
	<?php 
} 
?>

<?php 
// New document-master
if($_GET['action']=='addDocumentFolder'){
	$id=decode($_GET['id']);
	if($id!=''){
		$select='';
		$where='';
		$rs='';
		$select='name';
		$where='id='.$id.'';
		$rs=GetPageRecord($select,_DOCUMENT_FOLDER_MASTER_,$where);
		$editFolderD=mysqli_fetch_array($rs);
	}
	?>
	<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
			<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
			Mail Sent Successfully</div>
			<table border="0" align="center" cellpadding="0" cellspacing="0">
	      <tbody><tr>
	         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
	      </tr>
	   		</tbody>
		 	</table>
		</div>
		<div id="sendmailfrm">
			<h1 style="text-align:left;">Create Folder  </h1>
			<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
				<div class="griddiv"><label>
				<div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
				<div class="gridlable">Folder Name  <span class="redmind"></span></div>
				<input name="folderName" type="text" class="gridfield validate" id="folderName" value="<?php echo $editFolderD['name']; ?>" maxlength="40"  displayname="Folder Name" autocomplete="off"  />
				</label>
				</div>
				<input name="action" type="hidden" id="action" value="addDocumentFolder" />
				<input name="editId" type="hidden" id="editId" value="<?php echo $_GET['id']; ?>" />
				<input name="folderId" type="hidden" id="folderId" value="<?php echo $_REQUEST['folderId']; ?>" />
			</form>
			</div>
			<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
			<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Create    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
			<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
			</tr>
			</table>
			</div>
		</div>
	</div>
	<?php 
} 
if($_GET['action']=='addFolderFiles' && $_GET['folderId']!='' ){
		 $folderId=($_GET['folderId']);
		?>
		<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
		<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
		Mail Sent Successfully</div>
		<table border="0" align="center" cellpadding="0" cellspacing="0">
		      <tbody><tr>
		         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
		      </tr>
		   </tbody></table>
		</div>
		<div id="sendmailfrm">
		<h1 style="text-align:left;">Upload File</h1>
		  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
				<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
					<div class="griddiv">
						<label>
							<div class="gridlable">File Title  <span class="redmind"></span></div>
							<input name="fileName" type="text" class="gridfield validate" id="fileName" value="" maxlength="40"  displayname="File Title" autocomplete="off"  />
						</label>
					</div>
					<div class="griddiv">
						<label>
							<div class="gridlable">File&nbsp;Type<span class="redmind"></span></div>
								<select id="fileType" name="fileType" class="gridfield" autocomplete="off" onchange="fileTypeChange(this.value);" >
									<option value="IMG">IMAGE</option>
									<option value="OTHER">OTHER</option>
								</select>
						</label>
						<script type="text/javascript">
							function fileTypeChange(fileTypeVal){
								// var fileType = fileTypeVal;
								// alert(fileTypeVal);
								if(fileTypeVal=='IMG'){
									$('#fileSizeBox').show();
								}else{
									$('#fileSizeBox').hide();
								}
							}
							fileTypeChange('IMG');
						</script>
					</div>
					<div class="griddiv" id="fileSizeBox" style="display:none;">
						<label>
							<div class="gridlable">IMG&nbsp;File&nbsp;Size<span class="redmind"></span></div>
								<select id="fileSize" name="fileSize" class="gridfield" autocomplete="off" >
									<option value="380x246">380x246</option>
									<option value="1080x300">1080x300</option>
									<option value="1300x700">1300x700</option>
									<option value="790x100">(Header & Footer)790x100</option>
									<option value="800x300">(Banner)800x300</option>
									<option value="750x500">(Banner)750x500</option>
								</select>
						</label>
					</div> 
					<div class="griddiv">
						<label>
							<div class="gridlable">Select File<span class="redmind"></span></div>
							<input name="uploadFolderfile" type="file" id="uploadFolderfile" style=" margin-top:3px; width:100%;" />
						</label>
					</div>
					<input name="action" type="hidden" id="action" value="addFolderFiles" /> 
					<input name="folderId" type="hidden" id="folderId" value="<?php echo $folderId; ?>" />
				</form>
		  </div>
		  <div id="buttonsbox"  style="text-align:center;">
		 <table border="0" align="right" cellpadding="0" cellspacing="0">
		      <tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Upload" onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		      </tr>
		   </table>
		</div>
		</div></div>
	<?php 
} 

if($_GET['action']=='openDocumentfile' && $_GET['id']!='' && $_GET['folderId']!=''){
	$id=decode($_GET['id']);
	$nod=1;
	$select='*';
	$where=' id='.$id.' order by id asc';
	$rs=GetPageRecord($select,_DOCUMENT_FILES_MASTER_,$where);
	while($folderlist=mysqli_fetch_array($rs)){
		$name=$folderlist['name'];
		$uploadFile=$folderlist['uploadFile'];
		$fileType=$folderlist['fileType'];
		$fileicon=getFileIcon($folderlist['fileType']);
	}
	?>
	<div class="contentclass">
	<div id="sendmailaction" style="display:none;">
	<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
	Mail Sent Successfully</div>
	<table border="0" align="center" cellpadding="0" cellspacing="0">
	      <tbody><tr>
	         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
	      </tr>
	   </tbody></table>
	</div>
	<div id="sendmailfrm">
	  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
	<div class="documentfiledisply"><img src="<?php echo getFileIcon($fileType); ?>" alt="<?php echo showdatetime($folderlist['dateAdded'],$loginusertimeFormat);?>" width="54"    title="<?php echo showdatetime($folderlist['dateAdded'],$loginusertimeFormat);?>"/>
	<div style="margin-top:6px; font-size:15px;"><?php echo $name; ?></div>
	</div>
	<div class="documentoptionsfile">
	  <a href="<?php echo $uploadFile; ?>" target="_blank">Download File</a>
	  <a onclick="alertspopupopen('action=sendDocumentfile&id=<?php echo $id; ?>&folderId=<?php echo $_GET['folderId']; ?>','600px','auto');">Send File</a>
	  </div>
	  </div>
	  <div id="buttonsbox"  style="text-align:center;">
	 <table border="0" align="right" cellpadding="0" cellspacing="0">
	      <tr><td  > </td>
	        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
	      </tr>
	   </table>
	</div>
	</div></div>
	<?php 
} 
if($_GET['action']=='deleteDocumentFolder' && $_GET['id']!=''){	?>
	<div class="contentclass">
		<div id="sendmailfrm">
			<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="documentForm" target="actoinfrm"  id="documentForm">
				<div class="griddiv"><label>
				<div class="gridlable" style="width:100%;text-align: center;font-weight: 500;font-size: 17px;">Are you sure You want to delete this folder ?</div>
				</label>
				</div>
				<input name="action" type="hidden" id="action" value="deleteDocumentFolder" />
				<input name="editId" type="hidden" id="editId" value="<?php echo $_GET['id']; ?>" />
			</form>
			</div>
			<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value=" Yes, Delete  " onclick="formValidation('documentForm','submitbtn','0');" /></td>
			<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
			</tr>
			</table>
			</div>
		</div>
	</div>
	<?php 
} 
if($_GET['action']=='deleteDocumentFile' && $_GET['id']!=''){	?>
	<div class="contentclass">
		<div id="sendmailfrm">
			<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="documentForm" target="actoinfrm"  id="documentForm">
				<div class="griddiv"><label>
				<div class="gridlable" style="width:100%;text-align: center;font-weight: 500;font-size: 17px;">Are you sure You want to delete this file ?</div>
				</label>
				</div>
				<input name="action" type="hidden" id="action" value="deleteDocumentFile" />
				<input name="editId" type="hidden" id="editId" value="<?php echo $_GET['id']; ?>" />
			</form>
			</div>
			<div id="buttonsbox"  style="text-align:center;">
			<table border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value=" Yes, Delete  " onclick="formValidation('documentForm','submitbtn','0');" /></td>
			<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
			</tr>
			</table>
			</div>
		</div>
	</div>
	<?php 
} 
if($_GET['action']=='sendDocumentfile' && $_GET['id']!='' && $_GET['folderId']!=''){
	$id=($_GET['id']);
	$folderId=decode($_GET['folderId']);
	$nod=1;
	$select='*';
	$where='folderId='.$folderId.' and id='.$id.' order by id asc';
	$rs=GetPageRecord($select,_DOCUMENT_FILES_MASTER_,$where);
	while($folderlist=mysqli_fetch_array($rs)){
		$name=$folderlist['name'];
		$uploadFile=$folderlist['uploadFile'];
		$fileType=$folderlist['fileType'];
		$fileicon=getFileIcon($folderlist['fileType']);
	}
	?>
		<div class="contentclass">
		<div id="sendmailaction" style="display:none;">
		<div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
		Mail Sent Successfully</div>
		<table border="0" align="center" cellpadding="0" cellspacing="0">
		      <tbody><tr>
		         <td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
		      </tr>
		   </tbody></table>
		</div>
		<div id="sendmailfrm">
		<h1 style="text-align:left;">Send File </h1>
		  <div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
		<div class="documentfiledisply"><img src="<?php echo getFileIcon($fileType); ?>" alt="<?php echo showdatetime($folderlist['dateAdded'],$loginusertimeFormat);?>" width="54"    title="<?php echo showdatetime($folderlist['dateAdded'],$loginusertimeFormat);?>"/>
		<div style="margin-top:6px; font-size:15px;"><?php echo $name; ?></div>
		</div>
		<div style="text-align:center; padding:20px; text-align:center; color:#009900; font-size:15px; display:none;" id="sentfilemsg">File Sent Successfully.<br ><br ><table border="0" align="center" cellpadding="0" cellspacing="0">
		      <tr><td  > </td>
		        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Close" onclick="masters_alertspopupopenClose();" /></td>
		      </tr>
		   </table></div>
		<div id="sendfilefrm">
		<div class="griddiv"><label>
		 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Email <span class="redmind"></span></div>
			<input name="emailsender" type="text" class="gridfield validate" id="emailsender" maxlength="200"  displayname="Email" autocomplete="off"  />
			</label>
		 </div>
		 <div class="griddiv"><label>
		 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Subject <span class="redmind"></span></div>
			<input name="emailsubject" type="text" class="gridfield validate" id="emailsubject"   value="" maxlength="200"  displayname="Email Subject"  autocomplete="off" />
			</label>
		 </div>
		 <div class="griddiv"><label>
		 <div style="color:#CC0000; margin:10px 0px; display:none; text-align:left;" id="addpaymentreqesmsg"></div>
			<div class="gridlable">Description  </div>
			<textarea name="emaildescription" rows="8" class="gridfield" id="emaildescription" displayname="Email Subject" field_min_length="6"></textarea>
			</label>
		 </div></div>
		 <input name="action" type="hidden" id="action" value="sendDocumentfile" />
		 <input name="sendfilename" type="hidden" id="sendfilename" value="<?php echo $name; ?>" />
		 <input name="uploadFile" type="hidden" id="uploadFile" value="<?php echo $uploadFile; ?>" />
		 <input name="fileicon" type="hidden" id="fileicon" value="<?php echo $fileicon; ?>" />
		 </form>
		  </div>
		  <div id="buttonsbox"  style="text-align:center;">
		 <table border="0" align="right" cellpadding="0" cellspacing="0">
		      <tr><td  ><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Send    " onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		        <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		      </tr>
		   </table>
		</div>
		</div></div>
	<?php 
} 
// end document-master


if($_GET['action']=='addFilesToMaster' && $_GET['parentId']!='' && $_GET['galleryType']!=''){
	$folderId=($_GET['folderId']);
   ?>
   <div class="contentclass">
   <div id="sendmailaction" style="display:none;">
   <div style="margin-bottom:25px; text-align:center; color:#009900; font-size:15px;"><img src="images/mailsendseccicon.png" /><br />
   Mail Sent Successfully</div>
   <table border="0" align="center" cellpadding="0" cellspacing="0">
		 <tbody><tr>
			<td><input name="Cancel" type="button" class="whitembutton" id="Close" value="Close" onclick="alertspopupopenClose();$('#sendtestmailresult').hide();"></td>
		 </tr>
	  </tbody></table>
   </div>
   <div id="sendmailfrm">
   <h1 style="text-align:left;">Upload File</h1>
	 <div id="contentbox" class="addeditpagebox" style="padding:16px; overflow:auto; text-align:left; margin-bottom:0px; " >
		   <form action="frm_action.crm" method="post" enctype="multipart/form-data" name="getpaymentadd" target="actoinfrm"  id="getpaymentadd">
			   <div class="griddiv">
				   <label>
					   <div class="gridlable">File Title  <span class="redmind"></span></div>
					   <input name="desktopFileName" type="text" class="gridfield validate" id="desktopFileName" value="" maxlength="40"  displayname="File Title" autocomplete="off"  />
				   </label>
			   </div>
			   <div class="griddiv">
				   <label>
					   <div class="gridlable">File&nbsp;Type<span class="redmind"></span></div>
						   <select id="fileType" name="fileType" class="gridfield" autocomplete="off" onchange="fileTypeChange(this.value);" >
							   <option value="IMG">IMAGE</option>
							   <option value="OTHER">OTHER</option>
						   </select>
				   </label>
				   <script type="text/javascript">
					   function fileTypeChange(fileTypeVal){
						   // var fileType = fileTypeVal;
						   // alert(fileTypeVal);
						   if(fileTypeVal=='IMG'){
							   $('#fileSizeBox').show();
						   }else{
							   $('#fileSizeBox').hide();
						   }
					   }
					   fileTypeChange('IMG');
				   </script>
			   </div>
			   <div class="griddiv" id="fileSizeBox" style="display:none;">
				   <label>
					   <div class="gridlable">IMG&nbsp;File&nbsp;Size<span class="redmind"></span></div>
						   <select id="fileSize" name="fileSize" class="gridfield" autocomplete="off" >
							   <option value="380x246">380x246</option>
							   <option value="1080x300">1080x300</option>
							   <option value="1300x700">1300x700</option>
							   <option value="790x100">(Header & Footer)790x100</option>
							   <option value="800x300">(Banner)800x300</option>
							   <option value="750x500">(Banner)750x500</option>
						   </select>
				   </label>
			   </div> 
			   <div class="griddiv">
				   <label>
					   <div class="gridlable">Select File<span class="redmind"></span></div>
					   <input name="uploadDesktopfile" type="file" id="uploadDesktopfile" style=" margin-top:3px; width:99%;" />
				   </label>
			   </div>
			   <input name="action" type="hidden" id="action" value="addFilesToMaster" /> 
			   <input name="parentId" type="hidden" id="parentId" value="<?php echo $_GET['parentId']; ?>" />
			   <input name="galleryType" type="hidden" id="galleryType" value="<?php echo $_REQUEST['galleryType']; ?>" />
		   </form>
	 </div>
	 <div id="buttonsbox"  style="text-align:center;">
	<table border="0" align="right" cellpadding="0" cellspacing="0">
		 <tr><td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Upload" onclick="formValidation('getpaymentadd','submitbtn','0');" /></td>
		   <td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="masters_alertspopupopenClose();" /></td>
		 </tr>
	  </table>
   </div>
   </div></div>
<?php 
} 
?>



