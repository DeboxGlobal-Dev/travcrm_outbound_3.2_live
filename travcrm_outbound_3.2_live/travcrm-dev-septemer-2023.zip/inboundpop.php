<?php
include "inc.php";
ini_set('post_max_size', '10M');
ini_set('upload_max_filesize', '10M');
//actions for delete code or popup
 
if($_REQUEST['action'] == 'deleteQuotationHotel'){

	$serviceIdArr = explode('_', $_REQUEST['serviceId']);
	$serviceId = $serviceIdArr['0'];
	$hotelId = $serviceIdArr['1'];
	$quotationId = $_REQUEST['quotationId'];


	$quotQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' id="'.$serviceId.'" and quotationId="'.$quotationId.'"');
	if(mysqli_num_rows($quotQuery) > 0){
		$qHotelData=mysqli_fetch_array($quotQuery);
		
		// Hotel Supplement
		// need to delete all the hotel supplement regarding the requested deleteId
		$quotHSuppQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' hotelQuoteId="'.$serviceId.'" and dayId="'.$qHotelData['dayId'].'" and isHotelSupplement=1 and quotationId="'.$quotationId.'"');
		if(mysqli_num_rows($quotHSuppQuery)>0){
			while($qHSuppData=mysqli_fetch_array($quotHSuppQuery)){ 

				$checkHSuppQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' dayId="'.$qHSuppData['dayId'].'" and supplierId="'.$qHSuppData['supplierId'].'" and quotationId="'.$quotationId.'"');
				if(mysqli_num_rows($checkHSuppQuery) == 1){
					$qHSuppData=mysqli_fetch_array($checkHSuppQuery); 
					// need to delete this entry because this entry having only one dependent rate
					deleteRecord('quotationItinerary',' serviceType="hotel" and quotationId="'.$quotationId.'" and serviceId="'.$qHSuppData['supplierId'].'"  and dayId="'.$qHSuppData['dayId'].'" ');
				}
				deleteRecord(_QUOTATION_HOTEL_MASTER_,'id="'.$qHSuppData['id'].'" and isHotelSupplement=1'); 
			}
		}
		// Room Supplement
		// need to delete all the Room supplement regarding the requested deleteId
		$quotRSuppQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' hotelQuoteId="'.$serviceId.'" and dayId="'.$qHotelData['dayId'].'" and isRoomSupplement=1 and quotationId="'.$quotationId.'"');
		if(mysqli_num_rows($quotRSuppQuery)>0){
			while($qRSuppData=mysqli_fetch_array($quotRSuppQuery)){ 

				$checkRSuppQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' dayId="'.$qRSuppData['dayId'].'" and supplierId="'.$qRSuppData['supplierId'].'" and quotationId="'.$quotationId.'"');
				if(mysqli_num_rows($checkRSuppQuery) == 1){
					$qRSuppData=mysqli_fetch_array($checkRSuppQuery); 
					// need to delete this entry because this entry having only one dependent rate
					deleteRecord('quotationItinerary',' serviceType="hotel" and quotationId="'.$quotationId.'" and serviceId="'.$qRSuppData['supplierId'].'"  and dayId="'.$qRSuppData['dayId'].'" ');
				}
				deleteRecord(_QUOTATION_HOTEL_MASTER_,'id="'.$qRSuppData['id'].'" and isRoomSupplement=1'); 
			}
		}

		// Normal Supplement
		// need to delete this the Normal Rate
		$checkRSuppQuery=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' dayId="'.$qHotelData['dayId'].'" and supplierId="'.$qHotelData['supplierId'].'" and quotationId="'.$quotationId.'"');
		if(mysqli_num_rows($checkRSuppQuery) == 1){
			$qRSuppData=mysqli_fetch_array($checkRSuppQuery); 
			// need to delete this entry because this entry having only one dependent rate
			deleteRecord('quotationItinerary',' serviceType="hotel" and quotationId="'.$quotationId.'" and serviceId="'.$qRSuppData['supplierId'].'"  and dayId="'.$qRSuppData['dayId'].'" ');
		}
		deleteRecord(_QUOTATION_HOTEL_MASTER_,' quotationId="'.$quotationId.'" and id="'.$serviceId.'"');
		?>
		<script>
			warningalert('Hotel Deleted!');
			loadquotationmainfile();
		</script>
		<?php
	}
}
if($_REQUEST['action'] == 'deleteQuotationFerry'){
 	deleteRecord('quotationFerryMaster','id="'.$_REQUEST['serviceId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
	?>	
	<script>
		warningalert('Room Supplement Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteQuotationRoomSupplement'){
	deleteRecord('quotationRoomSupplimentMaster','id="'.$_REQUEST['serviceId'].'"');
   ?>
   <script>
	   warningalert('Room Supplement Deleted!');
	   loadquotationmainfile();
   </script>
   <?php
}


if($_REQUEST['action'] == 'deleteQuotationHotelAdditional'){
	deleteRecord('quotationHotelAdditionalMaster','id="'.$_REQUEST['serviceId'].'"');
   ?>
   <script>
	   warningalert('Hotel Additional Deleted!');
	   loadquotationmainfile();
   </script>
   <?php
} 

if($_REQUEST['action'] == 'deleteQuotationTransfer'){

	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="transfer" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_TRANSFER_MASTER_,' id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
	warningalert('Transfer Deleted..!');
	loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteQuotationTransport'){

	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="transportation" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_TRANSFER_MASTER_,' id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
	warningalert('Transportation Deleted..!');
	loadquotationmainfile();
	</script>
	<?php
}


if($_REQUEST['action'] == 'deleteQuotationSightseeing'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="sightseeing" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_SIGHTSEEING_MASTER_,' id = '.$_REQUEST['serviceId'].'');
	?>
	<script>
	warningalert('Transportation Deleted..!');
	loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteActivityQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="activity" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_OTHER_ACTIVITY_MASTER_,' id = '.$_REQUEST['serviceId'].'');
	?>
	<script>
	warningalert('Sightseeing Deleted..!');
	loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteGuideQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="guide" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_GUIDE_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Tour Escort Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteEntranceQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="entrance" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_ENTRANCE_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Monument Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteEnrouteQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="enroute" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_ENROUTE_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Enroute Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteMealPlanQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="mealplan" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_INBOUND_MEAL_PLAN_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Restaurant Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteAdditionalQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="additional" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_EXTRA_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Additional Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteItineraryQuotation'){
	
	$namevalue='title="",description=""';
	
	updatelisting('newQuotationDays',$namevalue,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Itinerary Information Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteTrainQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="train" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_TRAINS_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Train Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteFlightQuotation'){
	deleteRecord('quotationItinerary','serviceId = "'.$_REQUEST['serviceId'].'" and serviceType="flight" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord(_QUOTATION_FLIGHT_MASTER_,'id = "'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Flight Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}


if($_REQUEST['action'] == 'deleteServiceMarkup' && $_REQUEST['serviceMarkId']!=''){
 	deleteRecord('quotationServiceMarkup','id = "'.$_REQUEST['serviceMarkId'].'"');
	?>
	<script>
		warningalert('Markup Deleted!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'editSupplimentService' && $_REQUEST['deleteid']!=''){
	$namevalue ='adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'"';
	$updatelist = updatelisting('quotationAdditionalMaster',$namevalue,'id="'.decode($_REQUEST['deleteid']).'"');
	?>
	<script>
	parent.$('#inboundpopbg').hide();
	parent.$('#pageloader').hide();
	parent.$('#pageloading').hide();
	parent.loadAddtionalDatafun();
	// parent.location.reload();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteAdditionalExperience' && $_REQUEST['additionalId']!='' && $_REQUEST['quotationId']!='' ){
 	deleteRecord('quotationAdditionalMaster','id = "'.$_REQUEST['additionalId'].'"');
	deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['additionalId'].'" and serviceType="additional" and quotationId="'.$_REQUEST['quotationId'].'"');
	?>
	<script>
		warningalert('Additional Deleted!');
		loadquotationmainfile();
		// location.reload();
	</script>
	<?php
}

if($_REQUEST['action'] == 'deleteTransport' && $_REQUEST['transportId']!='' && $_REQUEST['quotationId']!='' ){
 	deleteRecord('quotationTransferMaster','id = "'.$_REQUEST['transportId'].'"');
	//echo 'serviceId="'.$_REQUEST['transportId'].'" and serviceType="transportation" and quotationId="'.$_REQUEST['quotationId'].'"';
	deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['transportId'].'" and serviceType="transportation" and quotationId="'.$_REQUEST['quotationId'].'"');
	?>
	<script>
		warningalert('Transportation Deleted!');
		//loadquotationmainfile();
		
	</script>
	<?php
}


// if($_REQUEST['action'] == 'deleteAdditionalExperience' && $_REQUEST['additionalId']!='' && $_REQUEST['quotationId']!='' ){
//  	deleteRecord('quotationAdditionalMaster','id = "'.$_REQUEST['additionalId'].'"');
// 	deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['additionalId'].'" and serviceType="additional" and quotationId="'.$_REQUEST['quotationId'].'"');
// 	?>
	<script>
		
// 		warningalert('Additional Deleted!');
// 	//	loadquotationmainfile();
// 	</script>
	<?php
// }



//end actions for delete code or popup

// save actions

if($_REQUEST['action'] == 'saveQuotationHotel' && $_REQUEST['serviceId']!=''){
	$namevalue ='mealPlan="'.$_REQUEST['mealPlan'].'",roomType="'.$_REQUEST['roomType'].'",childwithbed="'.$_REQUEST['childwithbed'].'",childwithoutbed="'.$_REQUEST['childwithoutbed'].'",singleoccupancy="'.$_REQUEST['singleoccupancy'].'",doubleoccupancy="'.$_REQUEST['doubleoccupancy'].'",twinoccupancy="'.$_REQUEST['doubleoccupancy'].'",tripleoccupancy="'.($_REQUEST['doubleoccupancy']+$_REQUEST['extraBed']).'",breakfast="'.$_REQUEST['breakfast'].'",lunch="'.$_REQUEST['lunch'].'",dinner="'.$_REQUEST['dinner'].'",extraBed="'.$_REQUEST['extraBed'].'",sixBedRoom="'.$_REQUEST['sixBedRoomCost'].'",eightBedRoom="'.$_REQUEST['eightBedRoomCost'].'",tenBedRoom="'.$_REQUEST['tenBedRoomCost'].'",quadRoom="'.$_REQUEST['quadRoomCost'].'",teenRoom="'.$_REQUEST['teenRoomCost'].'",childDinner="'.$_REQUEST['childdinnerc'].'",childLunch="'.$_REQUEST['childlunchc'].'",childBreakfast="'.$_REQUEST['childbreakfastc'].'"';
	$updatelist = updatelisting(_QUOTATION_HOTEL_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Hotel Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveQuotationRoomSupplement' && $_REQUEST['serviceId']!=''){
	$namevalue ='mealPlan="'.$_REQUEST['mealPlan'].'",roomType="'.$_REQUEST['roomType'].'",childwithbed="'.$_REQUEST['childwithbed'].'",childwithoutbed="'.$_REQUEST['childwithoutbed'].'",singleoccupancy="'.$_REQUEST['singleoccupancy'].'",doubleoccupancy="'.$_REQUEST['doubleoccupancy'].'",twinoccupancy="'.$_REQUEST['doubleoccupancy'].'",breakfast="'.$_REQUEST['breakfast'].'",lunch="'.$_REQUEST['lunch'].'",dinner="'.$_REQUEST['dinner'].'",tripleoccupancy="'.($_REQUEST['doubleoccupancy']+$_REQUEST['extraBed']).'",extraBed="'.$_REQUEST['extraBed'].'",teenRoom="'.$_REQUEST['suppTeenRoomCost'].'",quadRoom="'.$_REQUEST['suppQuadRoomCost'].'",sixBedRoom="'.$_REQUEST['suppSixRoomCost'].'",eightBedRoom="'.$_REQUEST['suppEightRoomCost'].'",tenBedRoom="'.$_REQUEST['suppTenRoomCost'].'",childLunch="'.$_REQUEST['suppLunchCost'].'",childDinner="'.$_REQUEST['suppdinnerCost'].'",childBreakfast="'.$_REQUEST['suppBRCost'].'"';

	$updatelist = updatelisting('quotationRoomSupplimentMaster',$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Hotel Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveQuotationTransfer' && $_REQUEST['serviceId']!=''){

	$vehicleCost= $adultCost= $childCost= $infantCost= 0;
	if($_REQUEST['transferType']==2){
		$vehicleCost= $_REQUEST['vehicleCost'];
		$noOfVehicles= $_REQUEST['noOfVehicles'];
	}else{
		$adultCost= $_REQUEST['adultCost'];
		$childCost= $_REQUEST['childCost'];
		$infantCost= $_REQUEST['infantCost'];
	}
	//noOfVehicles
	$namevalue ='transferName="'.$_REQUEST['transferNameId'].'",vehicleCost="'.$vehicleCost.'",noOfVehicles="'.$noOfVehicles.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",infantCost="'.$infantCost.'",totalPax="'.$_REQUEST['paxSlab'].'",vehicleModelId="'.$_REQUEST['vehicleModelId'].'"';
	$updatelist = updatelisting(_QUOTATION_TRANSFER_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
	warningalert('Transport Updated!');
	loadquotationmainfile();
	</script>
	<?php
} 


if($_REQUEST['action'] == 'saveQuotationTransport' && $_REQUEST['serviceId']!=''){
	$namevalue ='transferName="'.$_REQUEST['transferNameId'].'",vehicleCost="'.$_REQUEST['vehicleCost'].'",totalPax="'.$_REQUEST['paxSlab'].'",vehicleModelId="'.$_REQUEST['vehicleModelId'].'",noOfVehicles="'.$_REQUEST['noOfVehicles'].'",vehicleType="'.$_REQUEST['vehicleType'].'"';
	$updatelist = updatelisting(_QUOTATION_TRANSFER_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
	warningalert('Transport Updated!');
	loadquotationmainfile();
	</script>
	<?php
} 

if($_REQUEST['action'] == 'saveQuotationFerry' && $_REQUEST['serviceId']!=''){
	
	$namevalue ='ferryNameId="'.$_REQUEST['ferryNameId'].'",adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'",processingfee="'.$_REQUEST['processingfee'].'",miscCost="'.$_REQUEST['miscCost'].'",ferryClass="'.$_REQUEST['ferryClass'].'"';
	$updatelist = updatelisting(_QUOTATION_FERRY_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
	warningalert('Ferry Updated!');
	loadquotationmainfile();
	</script>
	<?php
} 



if($_REQUEST['action'] == 'saveActivityQuotation' && $_REQUEST['serviceId']!=''){
	$namevalue ='ticketAdultCost="'.$_REQUEST['ticketAdultCost'].'",ticketchildCost="'.$_REQUEST['ticketchildCost'].'",ticketinfantCost="'.$_REQUEST['ticketinfantCost'].'",adultCost="'.$_REQUEST['adultTransferCost'].'",childCost="'.$_REQUEST['childTransferCost'].'",infantCost="'.$_REQUEST['infantTransferCost'].'",vehicleId="'.$_REQUEST['vehicleId'].'",vehicleCost="'.$_REQUEST['vehicleCost'].'",repCost="'.$_REQUEST['repCost'].'"';

	$updatelist = updatelisting(_QUOTATION_OTHER_ACTIVITY_MASTER_,$namevalue,'id="'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Monument Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveEnrouteQuotation' && $_REQUEST['serviceId']!=''){
	$namevalue ='adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'"';
	$updatelist = updatelisting(_QUOTATION_ENROUTE_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
	warningalert('Enroute Updated!');
	loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveGuideQuotation' && $_REQUEST['serviceId']!=''){
	$namevalue ='perDaycost="'.$_REQUEST['perDaycost'].'",price="'.$_REQUEST['price'].'",slabId="'.$_REQUEST['slabId'].'"';
	$updatelist = updatelisting(_QUOTATION_GUIDE_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Tour Escort Updated!');
		loadquotationmainfile();
	</script>
	<?php
}


if($_REQUEST['action'] == 'saveItineraryQuotation' && $_REQUEST['serviceId']!=''){
	

	$namevalue ='title="'.trim($_REQUEST['subjectTitle']).'",description="'.trim($_REQUEST['description']).'"';
	$updatelist = updatelisting('newQuotationDays',$namevalue,'id="'.$_REQUEST['serviceId'].'"');
	?>
	<script>
		warningalert('Itinerary Infomation Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveEntranceQuotation' && $_REQUEST['serviceId']!=''){
	$namevalue ='ticketAdultCost="'.$_REQUEST['ticketAdultCost'].'",ticketchildCost="'.$_REQUEST['ticketchildCost'].'",ticketinfantCost="'.$_REQUEST['ticketinfantCost'].'",adultCost="'.$_REQUEST['adultTransferCost'].'",childCost="'.$_REQUEST['childTransferCost'].'",infantCost="'.$_REQUEST['infantTransferCost'].'",vehicleId="'.$_REQUEST['vehicleId'].'",vehicleCost="'.$_REQUEST['vehicleCost'].'",repCost="'.$_REQUEST['repCost'].'"';
	$updatelist = updatelisting(_QUOTATION_ENTRANCE_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Monument Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveMealPlanQuotation' && $_REQUEST['serviceId']!=''){
	$namevalue ='adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'"';
	$updatelist = updatelisting(_QUOTATION_INBOUND_MEAL_PLAN_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Restaurant Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveAdditionalQuotation' && $_REQUEST['serviceId']!=''){
	$namevalue ='adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'",groupCost="'.$_REQUEST['groupCost'].'"';
	$updatelist = updatelisting(_QUOTATION_EXTRA_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Additional Updated!');
		loadquotationmainfile();
	</script>
	<?php
}
if($_REQUEST['action'] == 'saveTrainQuotation' && $_REQUEST['serviceId']!=''){

if(!empty($_REQUEST['arrivalTime'])){
		$arrivalTime=date('H:i:s', strtotime($_REQUEST['arrivalTime']));
	}else{
		$arrivalTime = '';
	}
	if(!empty($_REQUEST['departureTime'])){
		$departureTime= date('H:i:s', strtotime($_REQUEST['departureTime']));
	}else{
		$departureTime = '';
	}

	$namevalue ='trainClass="'.$_REQUEST['trainClass'].'",trainNumber="'.$_REQUEST['trainNumber'].'",departureFrom="'.$_REQUEST['departureFrom'].'",arrivalTo="'.$_REQUEST['arrivalTo'].'",adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'",departureTime="'.$departureTime.'",arrivalTime="'.$arrivalTime.'"';
	$updatelist = updatelisting(_QUOTATION_TRAINS_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Train Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'saveFlightQuotation' && $_REQUEST['serviceId']!=''){

	if(!empty($_REQUEST['arrivalTime'])){
		$arrivalTime=date('H:i:s', strtotime($_REQUEST['arrivalTime']));
	}else{
		$arrivalTime = '';
	}
	if(!empty($_REQUEST['departureTime'])){
		$departureTime= date('H:i:s', strtotime($_REQUEST['departureTime']));
	}else{
		$departureTime = '';
	}

	$namevalue ='flightClass="'.$_REQUEST['flightClass'].'",flightNumber="'.$_REQUEST['flightNumber'].'",departureFrom="'.$_REQUEST['departureFrom'].'",arrivalTo="'.$_REQUEST['arrivalTo'].'",adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'",departureTime="'.$departureTime.'",arrivalTime="'.$arrivalTime.'"';
	$updatelist = updatelisting(_QUOTATION_FLIGHT_MASTER_,$namevalue,'id="'.($_REQUEST['serviceId']).'"');
	?>
	<script>
		warningalert('Flight Updated!');
		loadquotationmainfile();
	</script>
	<?php
}

//end of the save actions

//action for adding code or popup
if($_REQUEST['action'] == 'addServiceHotel' && $_REQUEST['dayId']!=''){ 
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	$lastDayQuery=GetPageRecord('*','newQuotationDays','  quotationId="'.$dayData['quotationId'].'" and addstatus=0  order by id desc limit 1');
	$lastDayData = mysqli_fetch_array($lastDayQuery);
	$lastDayId = $lastDayData['id'];

	
	 //for day serial
	$day1 = 1;
	$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
	while($dayData1 = mysqli_fetch_array($dayQuery1)){
		if(strip($dayData1['id']) == $_REQUEST['dayId']){ break; }
		$day1++;
	}

	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);
	
	//Query data
	$queQuery="";
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);
	$queryType = $queryData['queryType'];
	$paxType = $queryData['paxType'];
	$earlyCheckin = $queryData['earlyCheckin'];
	$moduleType = $queryData['moduleType'];

	$focQLE=GetPageRecord('*','quotationFOCRates','1 and quotationId="'.$quotationData['id'].'" and focType="LE" ');
	$focQFE=GetPageRecord('*','quotationFOCRates','1 and quotationId="'.$quotationData['id'].'" and focType="FE" ');



 	?>
 	<div class="inboundheader" >
 		<!-- style="background-color: #ffffff;color: #233a49;" -->
 		<?php if(isset($_REQUEST['hotelQuoteId']) && $_REQUEST['stype'] == 'hotelSupplement'){
 			$headingName = 'Hotel Supplement';
 			$selectionType = 'isHotelSupplement';
 		}elseif(isset($_REQUEST['hotelQuoteId']) && $_REQUEST['stype'] == 'roomSupplement'){
 			$headingName = 'Room Supplement';
 			$selectionType = 'isRoomSupplement';
 		}else{
 			$headingName = 'Normal Hotel';
 			$selectionType = 'isGuestType';
 		} 
 		if($queryData['dayWise']==1){ $headingName = $headingName."&nbsp;|&nbsp;".date('D j M Y', strtotime($dayData['srdate'])); } 
 		?>&nbsp;<?php echo $headingName; ?>&nbsp;&nbsp;|&nbsp;&nbsp;Pax&nbsp;Type:&nbsp;<?php echo ($paxType == 1)?'GIT':'FIT'; ?>
 		<i class="fa fa-times" aria-hidden="true" style="position: absolute;top: 5px; right: 10px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;
 		
 		<input type="hidden" id="stype" name="stype" value="<?php echo $_REQUEST['stype']; ?>">
 		<input type="hidden" id="hotelQuoteId" name="hotelQuoteId" value="<?php echo $_REQUEST['hotelQuoteId']; ?>">
 		<input type="radio" id="isHotelSupplement" <?php echo ($selectionType=='isHotelSupplement')?'checked':'';?>>
 		<input type="radio" id="isRoomSupplement" <?php echo ($selectionType=='isRoomSupplement')?'checked':'';?>>
 		<?php if($selectionType == 'isGuestType'){ ?>
 		<table border="0" cellpadding="0" cellspacing="0"> 
 			<tr style="background-color: #233a49;color: white;"> 
 				<td>
 					<?php 
					$QueryDaysQuery=GetPageRecord('srdate','newQuotationDays',' quotationId="'.$quotationData['id'].'" and addstatus=0 and deletestatus=0  order by srdate asc limit 1');
			        $QueryDaysData=mysqli_fetch_array($QueryDaysQuery);
					$dayDate = date('Y-m-d', strtotime($QueryDaysData['srdate']));
					$earlyArrivalDate = date("Y-m-d", strtotime("-1 days", strtotime($dayDate)));
					$b1q2="";
					$b1q2=GetPageRecord('*','quotationItinerary',' quotationId="'.$quotationData['id'].'" and queryId="'.$quotationData['queryId'].'" and startDate="'.$earlyArrivalDate.'" and serviceId in ( select id from quotationHotelMaster where isHotelSupplement=0 ) and serviceType="hotel" ');

					if( mysqli_num_rows($b1q2) < 1  && $_REQUEST['day'] == 1 && $earlyCheckin == 1){  ?>
						<input type="checkbox" name="earlyCheckin" id="earlyCheckin" style="display:inline-block;">&nbsp;Guest Immediate Hotel
					<?php } ?>	
				</td> 
				<?php if(mysqli_num_rows($focQFE) > 0 || mysqli_num_rows($focQLE) > 0 ){ ?> 
 				<td>
 					<input type="checkbox" name="isGuestType" id="isGuestType" style="display:inline-block;"  <?php echo ($selectionType=='isGuestType')?'checked':'';?>>&nbsp;Guest Hotel
 				</td>
 				<?php }else{ ?> 
 				<input type="checkbox" id="isGuestType" checked>
 				<?php } ?>
 				<td>
 					<?php if(mysqli_num_rows($focQFE) > 0 ){ ?>
 						<input type="checkbox" checked="checked" name="isForeignEscort" id="isForeignEscort" style="display:inline-block;" >&nbsp;Foreign Escort
 					<?php } ?>
 				</td>
 				<td>
 					<?php if(mysqli_num_rows($focQLE) > 0){ ?>
 						<input type="checkbox" checked="checked" name="isLocalEscort" id="isLocalEscort" style="display:inline-block;" >&nbsp;Local Escort
 					<?php } ?>
 				</td>
 			</tr>
 		</table>
 		<?php } ?>

	</div>	
	 
	<div style="padding:10px;" id="hotelBox">
		<?php if($selectionType!='isRoomSupplement'){ ?>
		<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px;">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
		 		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
		  			<tbody>
						<tr style="background-color:transparent !important;">
						<td width="100" align="left"><div class="griddiv" style="position:static;">
						<label> <div>Select&nbsp;Destination</div>
							<select id="destWise" name="destWise" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%;">
							<option value="1">Selected Destination</option>
							<option value="2">All Destinations</option>
							</select>
						</label>
						<script>
							  function getdestWise(){
								if($('#destWise').val()==2){
									$('#destinationId').load('loadAllDestinations.php');
								}

								if($('#destWise').val()==1){
									$('#destinationId').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
								}

							  }
							  </script>
							  <style>
								.select2-selection--single {
									display: inline-block !important;
									outline: 0px;
									padding-bottom: 0px;
									width: 100%;
									background-color: #FFFFFF !important;
									font-size: 14px;
									border: 1px #e0e0e0 solid !important;
									box-sizing: border-box !important;
									height: auto !important;
									padding: 2px;
									margin-top: 4px;
									border-radius: 2px !important;
								}
								.select2-container--default .select2-selection--single .select2-selection__arrow {
								top: 9px !important;
								}
							  </style>
						</div></td>
						  <td width="100" align="left"><div class="griddiv" style="position:static;">
								<label>
								<div>Destination</div>
								<select id="destinationId" name="destinationId" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" style="width: 100%; ">
								<?php
									$day=1;
									$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and  cityId="'.$dayData['cityId'].'"  group by cityId order by id asc');
									while($QueryDaysData=mysqli_fetch_array($a)){
								?>
								<option value="<?php echo stripslashes(trim($QueryDaysData['cityId'])); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
								<?php
								$day++;
								} ?>
								</select>
								</label>
								<script src="plugins/select2/select2.full.min.js"></script>
								<script>
								$(document).ready(function() {
								$('.select2').select2();
								});
								</script>
								 <style>
								.select2-container--open{
								z-index: 9999999999 !important;
								width: 100%;
								}

								.select2-container {
									box-sizing: border-box;
									display: inline-block;
									margin: 0;
									position: relative;
									vertical-align: middle;
									width: 100% !important;
								}
								  </style>
								</div></td>
							<?php if($queryData['seasonType'] == 3 && $queryData['seasonType'] != 0){ ?>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Season&nbsp;Type</div>
								<select id="seasonType" name="seasonType" class="gridfield validate" displayname="Season&nbsp;Type" autocomplete="off" >
								<option value="<?php echo $queryData['seasonType']; ?>" ><?php if($queryData['seasonType'] == 2){ ?>Winter<?php } elseif($queryData['seasonType'] == 1){ ?>Summer <?php } else { ?>Both<?php } ?></option>
								</select>
								</label>
								</div>							
							</td>
							<?php } ?>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Star Rating</div>
								<select id="categoryId" name="categoryId" class="gridfield validate" displayname="Hotel Category" autocomplete="off"   >
								<?php if($quotationData['quotationType']==1 || $quotationData['quotationType']==0){ ?>	
								<option value="">All</option>
								<?php
								$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'  deletestatus=0 and status=1  order by hotelCategory asc');
								while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){
								?>
								<option value="<?php echo strip($hotelCategoryData['id']); ?>"  <?php if($hotelCategoryData['id']==$queryData['hotelAccommodation']){ ?>  selected="selected" <?php } ?>><?php echo strip($hotelCategoryData['hotelCategory']).' Star'; ?></option>
								<?php }}?>

								<?php 
								if($quotationData['quotationType']==2){
									$hotelCategory = explode(',', $quotationData['hotCategory']);
									foreach ($hotelCategory as $hotelcat) {
									
 										$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,' deletestatus=0 and status=1 and id="'.$hotelcat.'" '); 
 										while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){ ?>
										<option value="<?php echo strip($hotelCategoryData['id']); ?>" <?php if($hotelCategoryData['id']==$queryData['hotelAccommodation']){ ?>  selected="selected" <?php } ?>><?php echo strip($hotelCategoryData['hotelCategory']).' Star'; ?></option>
										<?php 
										} 
									}
								} ?>
								</select>
								</label>
								</div>							
							</td>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Hotel Type </div>
								<select id="hotelTypeId" name="hotelTypeId" class="gridfield" displayname="Hotel Type" autocomplete="off"   >
								<option value="">All</option>
								<?php
								$hotelTypeQuery=GetPageRecord('*','hotelTypeMaster',' 1 and deletestatus=0 and status=1 order by name asc ');
								while($hotelTypeData=mysqli_fetch_array($hotelTypeQuery)){
								?>
								<option value="<?php echo strip($hotelTypeData['id']); ?>" <?php if($queryData['hotelTypeId']==$hotelTypeData['id']){ echo "selected"; } ?> ><?php echo strip($hotelTypeData['name']); ?></option>
								<?php } ?>
								</select>
								</label>
								</div>							
							</td>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Room Type </div>
								<select id="roomTypeId" name="roomTypeId" class="gridfield " displayname="Room Type" autocomplete="off"   >
								<option value="">All</option>
								<?php
								$roomTypeQuery=GetPageRecord('*',_ROOM_TYPE_MASTER_,' deletestatus=0 and status=1 order by id asc');
								while($roomTypeData=mysqli_fetch_array($roomTypeQuery)){
								?>
								<option value="<?php echo strip($roomTypeData['id']); ?>" ><?php echo strip($roomTypeData['name']); ?></option>
								<?php } ?>
								</select>
								</label>
								</div>							</td> 
							<td width="100" align="left" >
								<div class="griddiv" style="position:static;"><label>
								<div>From</div>
								<select id="startDay" name="startDay" class="gridfield validate" displayname="Start Day" autocomplete="off"   >
								<?php
								$day=$day1;
								$starDayQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and id >= "'.$dayData['id'].'"  order by srdate asc');
								while($startDaysData=mysqli_fetch_array($starDayQuery)){
									if(($cityId==$startDaysData['cityId'] && $startDaysData['id']!=$lastDayId) || $lastDayId==$dayData['id']){
									?>
									<option value="<?php echo strip($startDaysData['id']); ?>"  <?php if(strip($startDaysData['id']) == $_REQUEST['dayId']){ ?>  selected="selected" <?php } ?> >Night <?php echo $day; ?> - <?php echo getDestination($startDaysData['cityId']);?></option>
									<?php
									} else{
										break;
									}
									$day++;

								} ?>
								</select>
								</label>
						  </div>
						  </td>
						  <td width="100" align="left" >
							  	<div class="griddiv" style="position:static;">
							  	<label>
									<div>To</div>
									<select id="endDay" name="endDay" class="gridfield validate" displayname="End Day" autocomplete="off"   >
									<?php
									$day=$day1;
									$endDayQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0   and id >= "'.$dayData['id'].'" order by srdate asc');
									while($endDaysData=mysqli_fetch_array($endDayQuery)){
										if(($cityId==$endDaysData['cityId'] && $endDaysData['id']!=$lastDayId) || $lastDayId==$dayData['id']){
										?>
										<option value="<?php echo strip($endDaysData['id']); ?>"  <?php ///if(strip($endDaysData['id']) == $_REQUEST['dayId']){ ?>  selected="selected" <?php //} ?> >Night <?php echo $day; ?> - <?php echo getDestination($endDaysData['cityId']);?></option>
										<?php
										} else{
											break;
										}
 										$day++;
									}
									?>
								</select>
								</label>
						  </div>
						  </td> 
							<td width="100" align="left">
								<div class="griddiv" style="position:static;"><label>
								<div style="width:100%;">Hotel Name</div>
								<input name="hotelName" type="text" class="gridfield " id="hotelName" placeholder="Search Hotel "  displayname="Hotel Name" value="<?php echo urldecode($_REQUEST['hotelname']); ?>" />
								</label>
						  </div>							</td> 
							<td width="100" align="left">
									<div class="griddiv" style="position:static;"><label>
									<div>Meal&nbsp;Type </div>
									<select id="mealPlan" name="mealPlan" class="gridfield validate" displayname="Restaurant" autocomplete="off"   >
									<option value="0">All</option>
									<?php
									$mealPlanQuery =GetPageRecord('name,id',_MEAL_PLAN_MASTER_,'name!="" and deletestatus=0 and status=1 order by id asc');
									while($mealPlanData=mysqli_fetch_array($mealPlanQuery)){
									?>
									<option value="<?php echo strip($mealPlanData['id']); ?>" <?php if($queryData['mealPlanId']==$mealPlanData['id']){ ?> selected="selected" <?php } ?>><?php echo strip($mealPlanData['name']); ?></option>
									<?php } ?>
									</select>
									</label>
									</div>
							</td>
						  
						  
						  <td width="100" align="left" style="<?php //if($moduleType==2 || $moduleType==3 ){ ?>display:none;<?php //} ?>">
						
						  <div class="griddiv" >
							<label> <div>Pax&nbsp;Type</div>
							<select id="tourType" name="tourType" class="gridfield" autocomplete="off" style="width: 100%;">
							<?php if($paxType==1){ ?><option value="2">GIT</option><?php }
							else{ ?><option value="1">FIT</option><?php } ?>
							</select>
							</label> 
								</div>
							</td>
						 
							<td width="100" align="left" valign="middle">
						 	<input type="button" name="Submit" value="   Search   " class="bluembutton"    onclick="loadsearchhotelfunction();">
						 	<input type="hidden" name="quotationId"  id="quotationId" value="<?php echo $quotationData['id']; ?>">
						 	<input type="hidden" name="queryId"  id="queryId" value="<?php echo $quotationData['queryId']; ?>">
						 	<input type="hidden" name="dayId"  id="dayId" value="<?php echo $_REQUEST['dayId']; ?>"> 
							</td>
					  	</tr> 
					</tbody>
			  </table>
			</form>
		</div>
		<?php } ?>
		<div style="background-color:#feffbc;display:none;" id="loadhotelsavehotel" ></div>
	  	<div style="background-color:#f7f7f7;" id="loadhotelsearch" >&nbsp;</div>
		<script type="text/javascript">
			function addhoteltoquotations(cityId,roomTariffId,tblNum,supplementId){
				var isHotelSupplement = ($('#isHotelSupplement').prop('checked'))? 1 : 0;
				var isRoomSupplement = ($('#isRoomSupplement').prop('checked'))? 1 : 0;
				var isGuestType = ($('#isGuestType').prop('checked'))? 1 : 0;

		 		var stype = encodeURI($('#stype').val());
		 		var hotelQuoteId = encodeURI($('#hotelQuoteId').val());
				
				var isLocalEscort  =  $('#isLocalEscort').prop('checked') ? 1 : 0;
				var isForeignEscort=$('#isForeignEscort').prop('checked') ? 1 : 0; 
				var earlyCheckin   =   $('#earlyCheckin').prop('checked') ? 1 : 0; 
		 		
				var quotationId = $('#quotationId').val();
		 		var startDay = encodeURI($('#startDay').val());
				var endDay = encodeURI($('#endDay').val());
				
				if(isGuestType>0 || isLocalEscort>0 || isForeignEscort>0 || isRoomSupplement>0 ||  isHotelSupplement>0 || earlyCheckin>0){
	 				$('#loadhotelsavehotel').load('loadsavehotel.php?add=yes&quotationId='+quotationId+'&cityId='+cityId+'&startDayId='+startDay+'&isGuestType='+isGuestType+'&isLocalEscort='+isLocalEscort+'&isForeignEscort='+isForeignEscort+'&isHotelSupplement='+isHotelSupplement+'&isRoomSupplement='+isRoomSupplement+'&earlyCheckin='+earlyCheckin+'&endDayId='+endDay+'&roomTariffId='+roomTariffId+'&tblNum='+tblNum+'&stype='+stype+'&hotelQuoteId='+hotelQuoteId+'&supplementId='+supplementId);
				}else{
					alert('Please choose hotel Type.');
					
				}
			}

			function addhoteltoquotations_package(cityId,serviceId){
				var isHotelSupplement = ($('#isHotelSupplement').prop('checked'))? 1 : 0;
				var isRoomSupplement = ($('#isRoomSupplement').prop('checked'))? 1 : 0;
				var isGuestType = ($('#isGuestType').prop('checked'))? 1 : 0;

		 		var stype = encodeURI($('#stype').val());
		 		var hotelQuoteId = encodeURI($('#hotelQuoteId').val());
				
				var isLocalEscort  =  $('#isLocalEscort').prop('checked') ? 1 : 0;
				var isForeignEscort=$('#isForeignEscort').prop('checked') ? 1 : 0; 
				var earlyCheckin   =   $('#earlyCheckin').prop('checked') ? 1 : 0; 
		 		
				var quotationId = $('#quotationId').val();
		 		var startDay = encodeURI($('#startDay').val());
				var endDay = encodeURI($('#endDay').val());
				
				if(isGuestType>0 || isLocalEscort>0 || isForeignEscort>0 || isRoomSupplement>0 ||  isHotelSupplement>0 || earlyCheckin>0){
	 				$('#loadhotelsavehotel').load('loadsavehotel.php?add=yes&quotationId='+quotationId+'&cityId='+cityId+'&startDayId='+startDay+'&isGuestType='+isGuestType+'&isLocalEscort='+isLocalEscort+'&isForeignEscort='+isForeignEscort+'&isHotelSupplement='+isHotelSupplement+'&isRoomSupplement='+isRoomSupplement+'&earlyCheckin='+earlyCheckin+'&endDayId='+endDay+'&stype='+stype+'&hotelQuoteId='+hotelQuoteId+'&serviceId='+serviceId);
				}else{
					alert('Please choose hotel Type.');
					
				}
			}

			function loadsearchhotelfunction(added){
				var categoryId = encodeURI($('#categoryId').val());
				var roomTypeId = encodeURI($('#roomTypeId').val());
				var hotelTypeId = encodeURI($('#hotelTypeId').val());
				var mealPlan = encodeURI($('#mealPlan').val());
				var startDayId = encodeURI($('#startDay').val());
				var endDayId = encodeURI($('#endDay').val());
				var hotelName = encodeURI($('#hotelName').val());

				var stype = encodeURI($('#stype').val());
				var hotelQuoteId = encodeURI($('#hotelQuoteId').val());
				
				var isHotelSupplement = ($('#isHotelSupplement').prop('checked'))? 1 : 0;
				var isRoomSupplement = ($('#isRoomSupplement').prop('checked'))? 1 : 0;
				var isGuestType = ($('#isGuestType').prop('checked'))? 1 : 0;
				
				var isLocalEscort  =  $('#isLocalEscort').prop('checked') ? 1 : 0;
				var isForeignEscort=$('#isForeignEscort').prop('checked') ? 1 : 0; 
				var earlyCheckin   =   $('#earlyCheckin').prop('checked') ? 1 : 0; 

 				var cityId = $('#destinationId').val();
				var destWise = $('#destWise').val();
				var quotationId = $('#quotationId').val();
				var queryId = $('#queryId').val();
				var dayId = $('#dayId').val(); 
				var tourType = $('#tourType').val();
				$('#loadhotelsearch').load('loadhotelsearch.php?categoryId='+categoryId+'&cityId='+cityId+'&isGuestType='+isGuestType+'&isLocalEscort='+isLocalEscort+'&isForeignEscort='+isForeignEscort+'&roomTypeId='+roomTypeId+'&hotelTypeId='+hotelTypeId+'&startDayId='+startDayId+'&endDayId='+endDayId+'&Hotel='+hotelName+'&mealPlan='+mealPlan+'&destWise='+destWise+'&quotationId='+quotationId+'&queryId='+queryId+'&dayId='+dayId+'&tourType='+tourType+'&isHotelSupplement='+isHotelSupplement+'&isRoomSupplement='+isRoomSupplement+'&earlyCheckin='+earlyCheckin+'&stype='+stype+'&hotelQuoteId='+hotelQuoteId);
			}
			<?php if($_REQUEST['hotelname']!='' || (isset($_REQUEST['hotelQuoteId']) && $_REQUEST['stype'] == 'roomSupplement')){ ?>
			loadsearchhotelfunction('');
			<?php } ?>
		</script>
	</div>

	<?php
} 

if($_REQUEST['action'] == 'addhoteldetails' && $_REQUEST['hotelId'] != ''){

	// hotel data
	$d=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$_REQUEST['hotelId'].'"');
	$hotelData=mysqli_fetch_array($d);


	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Hotel T&C </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<table width="100%" border="1" cellpadding="8" cellspacing="0" bordercolor="#CCCCCC" class="hotelds " style="font-size: 15px;">
		  <tr>
       <td><strong style="text-decoration: underline;">Hotel Information</strong><br><br><?php echo $hotelData['hoteldetail']; ?></td> 
     </tr>
     <tr>
       <td><strong style="text-decoration: underline;">Policy</strong><br><br><?php echo $hotelData['policy']; ?></td>
     </tr>
     <tr>
	 <td><strong style="text-decoration: underline;">T&C</strong><br><br><a target="_blank" href="packageimages/<?php echo $hotelData['hotelImage']; ?>"><?php echo $hotelData['hotelImage']; ?></a>
		<br><br>
	   <p><?php echo $hotelData['termAndCondition']; ?></p>
		</td>
     </tr>
	  </table>
	
	
	</div>

<?php
}

// add room type information in quatation
if($_REQUEST['action'] == 'addroomdetails' && $_REQUEST['roomId'] != ''){

	// hotel data
	$d=GetPageRecord('*','roomTypeMaster',' id="'.$_REQUEST['roomId'].'"');
	$roomData=mysqli_fetch_array($d);


	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">ROOM INFO. </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
	
		<table width="100%" border="1" cellpadding="8" cellspacing="0" bordercolor="#CCCCCC" class="hotelds " style="font-size: 15px;">
			<tr>
				<th>Room Type Name</th>
				<th>Size</th>
				<th>Maximum Occupancy</th>
				<th>Bedding</th>
			</tr>
			<tr style="background: #f4f0f0;">
				<td><?php echo $roomData['name']; ?></td>
				<td><?php echo $roomData['size']; ?></td>
				<td><?php echo $roomData['maxoccupancy']; ?></td>
				<td><?php echo $roomData['bedding']; ?></td>
			</tr>

	  </table>
	</div>

<?php
}

 
if($_REQUEST['action'] == 'addServiceEarlyHotel' && $_REQUEST['dayId']!=''){


	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];
	//for day serial
	$day1 = 1;
	$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
	while($dayData1 = mysqli_fetch_array($dayQuery1)){
	if(strip($dayData1['id']) == $_REQUEST['dayId']){ break ; }
	$day1++;
	}
	//echo $day1;
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);
 
	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);
	$tourType = $queryData['queryType'];

	?>

 	<div style="display: grid;background-color: #ffffff;color: #233a49;" class="inboundheader"> Select&nbsp;Hotel for Immediate Occupancy <?php if($queryData['dayWise']==1){ echo "&nbsp;|&nbsp;".date('D j M Y', strtotime($dayData['srdate'])); } ?> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px;">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
		 		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
		  			<tbody>
						<tr style="background-color:transparent !important;">
						  <td width="100" align="left"><div class="griddiv" style="position:static;">
						<label> <div>Selected&nbsp;Destination</div>
							<select id="destWise" name="destWise" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" >
							<option value="1">Selected Destination</option>
							<option value="2">All Destinations</option>
							</select>
						</label>
						<script>
							  function getdestWise(){
								if($('#destWise').val()==2){
									$('#destinationId').load('loadAllDestinations.php');
								}

								if($('#destWise').val()==1){
									$('#destinationId').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
								}

							  }
							  </script>
						</div></td>
						  <td width="100" align="left"><div class="griddiv" style="position:static;">
								<label>
								<div>Destination</div>
								<select id="destinationId" name="destinationId" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;">
								<?php
									$day=1;
									echo ' quotationId="'.$quotationData['id'].'"  and addstatus=0  and  cityId="'.$dayData['cityId'].'"  group by cityId order by id asc';
									$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and  cityId="'.$dayData['cityId'].'"  group by cityId order by id asc');
									while($QueryDaysData=mysqli_fetch_array($a)){
								?>
								<option value="<?php echo stripslashes(trim($QueryDaysData['cityId'])); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
								<?php
								$day++;
								} ?>
								</select>
								</label>
								<script src="plugins/select2/select2.full.min.js"></script>
								<script>
								$(document).ready(function() {
								$('.select2').select2();
								});
								</script>
								<style>
									.select2-selection--single {
										display: inline-block !important;
										outline: 0px;
										padding-bottom: 0px;
										width: 100%;
										background-color: #FFFFFF !important;
										font-size: 14px;
										border: 1px #e0e0e0 solid !important;
										box-sizing: border-box !important;
										height: auto !important;
										padding: 2px;
										margin-top: 4px;
										border-radius: 2px !important;
									}
									.select2-container--default .select2-selection--single .select2-selection__arrow {
										top: 9px !important;
									} 
									.select2-container--open{
										z-index: 9999999999 !important;
										width: 100%;
									} 
									.select2-container {
										box-sizing: border-box;
										display: inline-block;
										margin: 0;
										position: relative;
										vertical-align: middle;
										width: 100% !important;
									}
								  </style>
								</div></td>
							<?php if($queryData['queryType'] == 3 && $queryData['seasonType'] != 0){ ?>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Season&nbsp;Type</div>
								<select id="seasonType" name="seasonType" class="gridfield validate" displayname="Season&nbsp;Type" autocomplete="off" >
								<option value="<?php echo $queryData['seasonType']; ?>" ><?php if($queryData['seasonType'] == 2){ ?>Winter<?php } elseif($queryData['seasonType'] == 1){ ?>Summer <?php } else { ?>Both<?php } ?></option>
								</select>
								</label>
								</div>							</td>
							<?php } ?>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Star Rating </div>
								<select id="categoryId" name="categoryId" class="gridfield validate" displayname="Hotel Category" autocomplete="off"   >
								<?php if($quotationData['quotationType']==1){ ?>	
								<option value="">All</option>
								<?php
								$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'  deletestatus=0 and status=1 order by hotelCategory asc');
								while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){
								?>
								<option value="<?php echo strip($hotelCategoryData['id']); ?>" <?php if($hotelCategoryData['id']==$queryData['hotelAccommodation']){ ?>  selected="selected" <?php } ?>><?php echo strip($hotelCategoryData['hotelCategory']).' Star'; ?></option>
								<?php } }?>

								<?php 
								if($quotationData['quotationType']==2){
									$hotelCategory = explode(',', $quotationData['hotCategory']);
									foreach ($hotelCategory as $hotelcat) {
 										$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'deletestatus=0 and status=1 and id="'.$hotelcat.'" ');
										while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){ ?>
										<option value="<?php echo strip($hotelCategoryData['id']); ?>" <?php if($hotelCategoryData['id']==$queryData['hotelAccommodation']){ ?>  selected="selected" <?php } ?>><?php echo strip($hotelCategoryData['hotelCategory']).' Star'; ?></option>
									<?php } } } ?>
								</select>
								</label>
								</div>							
							</td>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Hotel Type </div>
								<select id="hotelTypeId" name="hotelTypeId" class="gridfield" displayname="Hotel Type" autocomplete="off"   >
								<option value="">All</option>
								<?php
								$hotelTypeQuery=GetPageRecord('*','hotelTypeMaster',' 1 and deletestatus=0 and status=1 order by name asc ');
								while($hotelTypeData=mysqli_fetch_array($hotelTypeQuery)){
								?>
								<option value="<?php echo strip($hotelTypeData['id']); ?>" ><?php echo strip($hotelTypeData['name']); ?></option>
								<?php } ?>
								</select>
								</label>
								</div>							
							</td>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;">
								<label>
								<div>Room Type </div>
								<select id="roomType" name="roomType" class="gridfield validate" displayname="Room Type" autocomplete="off"   >
								<option value="">All</option>
								<?php
								$roomTypeQuery=GetPageRecord('*',_ROOM_TYPE_MASTER_,' deletestatus=0 and status=1 order by id asc');
								while($roomTypeData=mysqli_fetch_array($roomTypeQuery)){
								?>
								<option value="<?php echo strip($roomTypeData['id']); ?>" ><?php echo strip($roomTypeData['name']); ?></option>
								<?php } ?>
								</select>
								</label>
								</div>							</td>
							<td width="100" align="left">
								<div class="griddiv" style="position:static;"><label>
								<div>Meal&nbsp;Type</div>
								<select id="mealPlan" name="mealPlan" class="gridfield validate" displayname="Restaurant" autocomplete="off"   >
								<option value="0">All</option>
								<?php
								$mealPlanQuery =GetPageRecord('name,id',_MEAL_PLAN_MASTER_,'1 and deletestatus=0');
								while($mealPlanData=mysqli_fetch_array($mealPlanQuery)){
								?>
								<option value="<?php echo strip($mealPlanData['id']); ?>" <?php if($queryData['mealPlanId']==$mealPlanData['id']){ ?> selected="selected" <?php } ?>><?php echo strip($mealPlanData['name']); ?></option>
								<?php } ?>
								</select>
								</label>
								</div>
						  </td> 
						  <td width="100" align="left"><div class="griddiv" style="position:static;">
							<label> <div>Pax&nbsp;Type</div>
							<select id="tourType" name="tourType" class="gridfield" autocomplete="off" style="width: 100%;">
							<?php if($tourType==2){ ?><option value="1">FIT</option><?php } ?>
							<?php if($tourType==1){ ?><option value="2">GIT</option><?php } ?>
							</select>
							</label> 
							</div>
						</td>
						
						  <td width="100" align="left" >
								<div class="griddiv" style="position:static;">
							  	<label>
								<div>Check&nbsp;In&nbsp;</div>
								<input id="checkIn" name="checkIn" type="text" class="gridfield validate timepicker2"  data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"/>
 								</label>
								</div>
							</td>

							<td width="100" align="left">
								<div class="griddiv" style="position:static;"><label>
								<div style="width:100%;">Hotel Name</div>
								<input name="hotelName" type="text" class="gridfield" id="hotelName" placeholder="Search Hotel "  displayname="Hotel Name" value="<?php echo urldecode($_REQUEST['hotelname']); ?>" />
								</label>
						  </div>							</td>
							<td width="100" align="left" valign="middle">
						  <input type="button" name="Submit" value="   Search   " class="bluembutton"    onclick="loadsearchhotelfunction();">
						  </td>
					  </tr>
					</tbody>
			  </table>
			</form>
		</div>
		<div style="background-color:#feffbc;display:none;" id="loadhotelsavehotel" ></div>
	  	<div style="background-color:#f7f7f7;" id="loadhotelsearch" >&nbsp;</div>
		<script type="text/javascript" src="js/jquery.timepicker.js"></script> 
		<script type="text/javascript"> 
			$(document).ready(function(){
				$('.timepicker2').timepicker();	
			});   
			function addhoteltoquotations(cityId,roomTariffId,tblNum,supplementId){
 				var startDay = encodeURI(<?php echo $_REQUEST['dayId']; ?>);
				var endDay = encodeURI(<?php echo $_REQUEST['dayId']; ?>);
 				$('#loadhotelsavehotel').load('loadsavehotel.php?add=yes&earlyCheckin=1&cityId='+cityId+'&startDayId='+startDay+'&endDayId='+endDay+'&roomTariffId='+roomTariffId+'&tblNum='+tblNum+'&supplementId='+supplementId);
			}
			function loadsearchhotelfunction(added){
				var categoryId = encodeURI($('#categoryId').val());
				var roomType = encodeURI($('#roomType').val());
				var hotelTypeId = encodeURI($('#hotelTypeId').val());
				var mealPlan = encodeURI($('#mealPlan').val());
				var startDayId = encodeURI(<?php echo $_REQUEST['dayId']; ?>);
				var endDayId = encodeURI(<?php echo $_REQUEST['dayId']; ?>);
				var hotelName = encodeURI($('#hotelName').val());
 				var destinationId = $('#destinationId').val();
				var destWise = $('#destWise').val();
				var tourType = $('#tourType').val();
				
				$('#loadhotelsearch').load('loadhotelsearch.php?categoryId='+categoryId+'&earlyCheckin=1&hotelTypeId='+hotelTypeId+'&roomType='+roomType+'&startDayId='+startDayId+'&endDayId='+endDayId+'&Hotel='+hotelName+'&mealPlan='+mealPlan+'&destWise='+destWise+'&tourType='+tourType);
			 
			}

			<?php if($_REQUEST['hotelname']!=''){ ?>
			loadsearchhotelfunction('');
			<?php } ?>
		</script>
	</div>

	<?php
}

if($_REQUEST['action'] == 'addQuotationHotelSupplement' && $_REQUEST['dayId']!=''){

		$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
		$dayData = mysqli_fetch_array($dayQuery);
		$cityId = $dayData['cityId'];
		//for day serial
		$day1 = 1;
		$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
		while($dayData1 = mysqli_fetch_array($dayQuery1)){
			if(strip($dayData1['id']) == $_REQUEST['dayId']){ break ; }
			$day1++;
		}
		//echo $day1;
		//quotation data
		$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
		$quotationData=mysqli_fetch_array($quotQuery);
		 
		//Query data
		$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
		$queryData=mysqli_fetch_array($queQuery);

	?>

	 	<div class="inboundheader" >Select&nbsp;Supplement&nbsp;Hotel&nbsp;|&nbsp;<?php if($queryData['dayWise']==1){ echo date('D j M Y', strtotime($dayData['srdate'])); }?> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i></div>
		<div style="padding:10px;" id="hotelBox">
			<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px;">
				<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
			 		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
			  			<tbody>
							<tr style="background-color:transparent !important;">
							  <td width="100" align="left"><div class="griddiv" style="position:static;">
							<label> <div>Selected&nbsp;Destination</div>
								<select id="destWise" name="destWise" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" >
								<option value="1">Selected Destination</option>
								<option value="2">All Destinations</option>
								</select>
							</label>
							<script>
						  function getdestWise(){
							if($('#destWise').val()==2){
								$('#destinationId').load('loadAllDestinations.php');
							}

							if($('#destWise').val()==1){
								$('#destinationId').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
							}

						  }
						  </script>
				    </div></td>
							  <td width="100" align="left"><div class="griddiv" style="position:static;">
									<label>
									<div>Destination</div>
									<select id="destinationId" name="destinationId" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;">
									<?php
										$day=1;
										$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and  cityId="'.$dayData['cityId'].'"  group by cityId order by id asc');
										while($QueryDaysData=mysqli_fetch_array($a)){
									?>
									<option value="<?php echo stripslashes(trim($QueryDaysData['cityId'])); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
									<?php
									$day++;
									} ?>
									</select>
									</label>
									<script src="plugins/select2/select2.full.min.js"></script>
									<script>
									$(document).ready(function() {
									$('.select2').select2();
									});
									</script>
									 <style>
									.select2-container--open{
									z-index: 9999999999 !important;
									width: 100%;
									}

									.select2-container {
									    box-sizing: border-box;
									    display: inline-block;
									    margin: 0;
									    position: relative;
									    vertical-align: middle;
									    width: 100% !important;
									}
									  </style>
									</div></td>
								<?php if($queryData['queryType'] == 3 && $queryData['seasonType'] != 0){ ?>
								<td width="100" align="left">
									<div class="griddiv" style="position:static;">
									<label>
									<div>Season&nbsp;Type</div>
									<select id="seasonType" name="seasonType" class="gridfield validate" displayname="Season&nbsp;Type" autocomplete="off" >
									<option value="<?php echo $queryData['seasonType']; ?>" ><?php if($queryData['seasonType'] == 2){ ?>Winter<?php } elseif($queryData['seasonType'] == 1){ ?>Summer <?php } else { ?>Both<?php } ?></option>
									</select>
									</label>
									</div>							</td>
								<?php } ?>
								<td width="100" align="left">
									<div class="griddiv" style="position:static;">
									<label>
									<div>Star Rating </div>
									<select id="categoryId" name="categoryId" class="gridfield validate" displayname="Hotel Category" autocomplete="off"   >
									<?php if($quotationData['quotationType']==1){ ?>	
									<option value="">All</option>
									<?php
									$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'  deletestatus=0 and status=1  order by hotelCategory asc');
									while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){
									?>
									<option value="<?php echo strip($hotelCategoryData['id']); ?>" <?php if($hotelCategoryData['id']==$queryData['hotelAccommodation']){ ?>  selected="selected" <?php } ?>><?php echo strip($hotelCategoryData['hotelCategory']).' Star'; ?></option>
									<?php }}?>

									<?php if($quotationData['quotationType']==2){
										$hotelCategory = explode(',', $quotationData['hotCategory']);
										foreach ($hotelCategory as $hotelcat) {
	 										$hotelCatQuery=GetPageRecord('*',_HOTEL_CATEGORY_MASTER_,'deletestatus=0 and status=1 and id="'.$hotelcat.'"  ');
											while($hotelCategoryData=mysqli_fetch_array($hotelCatQuery)){ ?>
											<option value="<?php echo strip($hotelCategoryData['id']); ?>" <?php if($hotelCategoryData['id']==$queryData['hotelAccommodation']){ ?>  selected="selected" <?php } ?>><?php echo strip($hotelCategoryData['hotelCategory']).' Star'; ?></option>
										<?php } }} ?>
									</select>
									</label>
									</div>							
								</td>
								<td width="100" align="left">
									<div class="griddiv" style="position:static;">
									<label>
									<div>Hotel Type </div>
									<select id="hotelTypeId" name="hotelTypeId" class="gridfield" displayname="Hotel Type" autocomplete="off"   >
									<option value="">All</option>
									<?php
									$hotelTypeQuery=GetPageRecord('*','hotelTypeMaster',' 1 and deletestatus=0 and status=1 order by name asc ');
									while($hotelTypeData=mysqli_fetch_array($hotelTypeQuery)){
									?>
									<option value="<?php echo strip($hotelTypeData['id']); ?>" ><?php echo strip($hotelTypeData['name']); ?></option>
									<?php } ?>
									</select>
									</label>
									</div>							
								</td>
								<td width="100" align="left">
									<div class="griddiv" style="position:static;">
									<label>
									<div>Room Type </div>
									<select id="roomType" name="roomType" class="gridfield validate" displayname="Room Type" autocomplete="off"   >
									<option value="">All</option>
									<?php
									$roomTypeQuery=GetPageRecord('*',_ROOM_TYPE_MASTER_,' deletestatus=0 and status=1 order by id asc');
									while($roomTypeData=mysqli_fetch_array($roomTypeQuery)){
									?>
									<option value="<?php echo strip($roomTypeData['id']); ?>" ><?php echo strip($roomTypeData['name']); ?></option>
									<?php } ?>
									</select>
									</label>
									</div>							
								</td>
								<td width="100" align="left">
									<div class="griddiv" style="position:static;"><label>
									<div>Meal&nbsp;Type </div>
									<select id="mealPlan" name="mealPlan" class="gridfield validate" displayname="Restaurant" autocomplete="off"   >
									<option value="0">All</option>
									<?php
									$mealPlanQuery =GetPageRecord('name,id',_MEAL_PLAN_MASTER_,'1 and deletestatus=0');
									while($mealPlanData=mysqli_fetch_array($mealPlanQuery)){
									?>
									<option value="<?php echo strip($mealPlanData['id']); ?>" <?php if($queryData['mealPlanId']==$mealPlanData['id']){ ?> selected="selected" <?php } ?>><?php echo strip($mealPlanData['name']); ?></option>
									<?php } ?>
									</select>
									</label>
									</div>
									</td>
								<td width="100" align="left" >
									<div class="griddiv" style="position:static;"><label>
									<div>From</div>
									<select id="startDay" name="startDay" class="gridfield validate" displayname="Start Day" autocomplete="off"   >
									<?php
									$day=$day1;
									$starDayQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0 and id >= "'.$dayData['id'].'"  order by srdate asc');
									while($QueryDaysData=mysqli_fetch_array($starDayQuery)){
										if($cityId==$QueryDaysData['cityId']){
										?>
										<option value="<?php echo strip($QueryDaysData['id']); ?>"  <?php if(strip($QueryDaysData['id']) == $_REQUEST['dayId']){ ?>  selected="selected" <?php } ?> >Night <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
										<?php
										} else{
											break;
										}
										$day++;

									} ?>
									</select>
									</label>
							  </div>
							  </td>
							  <td width="100" align="left" >
								  	<div class="griddiv" style="position:static;">
								  	<label>
										<div>To</div>
										<select id="endDay" name="endDay" class="gridfield validate" displayname="End Day" autocomplete="off"   >
										<?php
										$day=$day1;
										$starDayQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0   and id >= "'.$dayData['id'].'" order by srdate asc');
										while($QueryDaysData=mysqli_fetch_array($starDayQuery)){
											if($cityId==$QueryDaysData['cityId']){
											?>
											<option value="<?php echo strip($QueryDaysData['id']); ?>"  <?php ///if(strip($QueryDaysData['id']) == $_REQUEST['dayId']){ ?>  selected="selected" <?php //} ?> >Night <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
											<?php
											} else{
												break;
											}
	 										$day++;
										}
										?>
									</select>
									</label>
							  </div>
							  </td>

								<td width="100" align="left">
									<div class="griddiv" style="position:static;"><label>
									<div style="width:100%;">Hotel Name</div>
									<input name="hotelName" type="text" class="gridfield " id="hotelName" placeholder="Search Hotel "  displayname="Hotel Name" value="<?php echo urldecode($_REQUEST['hotelname']); ?>" />
									</label>
							  </div>
							  </td>
							<td width="100" align="left" valign="middle">
							<input name="hotelQuoteId" type="hidden" id="hotelQuoteId" value="<?php echo  $_REQUEST['hotelQuoteId']; ?>">
							<input type="button" name="Submit" value="   Search   " class="bluembutton"    onclick="loadsearchhotelfunction();">							</td>
						  </tr>
						</tbody>
				  </table>
				</form>
			</div>

			<div style="background-color:#feffbc;display:none;" id="loadhotelsavehotel" ></div>
		  	<div style="background-color:#f7f7f7;" id="loadhotelsearch" >&nbsp;</div>
			<script type="text/javascript">
				function addSupplementhotel(cityId,roomTariffId,tblNum,supplementId){
	 				var startDay = encodeURI($('#startDay').val());
					var endDay = encodeURI($('#endDay').val());
	 				$('#loadhotelsavehotel').load('loadsaveSupplimenthotel.php?add=yes&cityId='+cityId+'&startDayId='+startDay+'&endDayId='+endDay+'&roomTariffId='+roomTariffId+'&tblNum='+tblNum+'&supplementId='+supplementId);
				}
				function loadsearchhotelfunction(added){
					var categoryId = encodeURI($('#categoryId').val());
					var roomType = encodeURI($('#roomType').val());
					var hotelTypeId = encodeURI($('#hotelTypeId').val());
					var mealPlan = encodeURI($('#mealPlan').val());
					var startDayId = encodeURI($('#startDay').val());
					var endDayId = encodeURI($('#endDay').val());
					var hotelName = encodeURI($('#hotelName').val());
	 				var destinationId = $('#destinationId').val();
					var destWise = $('#destWise').val();

					$('#loadhotelsearch').load('loadsupplimenthotelsearch.php?categoryId='+categoryId+'&roomType='+roomType+'&hotelTypeId='+hotelTypeId+'&startDayId='+startDayId+'&endDayId='+endDayId+'&Hotel='+hotelName+'&mealPlan='+mealPlan+'&destWise='+destWise);
				}

				<?php if($_REQUEST['hotelname']!=''){ ?>
				loadsearchhotelfunction('');
				<?php } ?>
			</script>

		</div>

		<?php
	}

if($_REQUEST['action'] == 'addRoomSupplement' && $_REQUEST['dayId'] != '' && $_REQUEST['hotelQuoteId'] != ''){

	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' id="'.$_REQUEST['hotelQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);
	// hotel data
	$d=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$hotelQuotData['supplierId'].'"');
	$hotelData=mysqli_fetch_array($d);


	?>
	<div class="inboundheader">
		<span id="hotelcounding">Add Room Supplement </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #ffffff; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<table width="100%" border="1" cellpadding="8" cellspacing="0" bordercolor="#CCCCCC" class="hotelds " style="font-size: 15px;color: #589fa6;">
		<thead>
		<tr>
		<td  > <strong>Hotel&nbsp;Name:&nbsp;</strong><?php echo strip($hotelData['hotelName']);  ?></td>

		<td  ><strong>Category:&nbsp;</strong><?php
			$rs231=GetPageRecord('*','hotelCategoryMaster','id="'.$hotelData['hotelCategoryId'].'"');
			$hotelCatNam=mysqli_fetch_array($rs231);
			echo $hotelCatNam['hotelCategory'].'Star'; ?></td>

		<td ><strong>City:&nbsp;</strong><?php echo strip($hotelData['hotelCity']);  ?></td>

		<td  align="right"><span class="editbtnselect" onclick="addnewRates('<?php echo $hotelData['id']; ?>','0');" style=" padding: 6px 23px !important; background-color:#589fa6;"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;Add&nbsp;Price</span>

		</td>
		</tr>
		</thead>
	  </table>
		<div style="background-color:#feffbc;display:none;" id="loadhotelsavehotel2" ></div>
	  	<div style="background-color:#f7f7f7;" id="loadhotelsearch2" >&nbsp;</div>
		<script type="text/javascript">
			// function addSupplementRoom(quotationId,roomTariffId,tblNum,supplementId){
			// 	//confirm('Click "OK" to Add');
			// 	$('#loadhotelsavehotel2').load('loadsave_Suppliment.php?action=add_RoomSupplement&dayId=<?php echo $_REQUEST['dayId']; ?>&hotelQuoteId=<?php echo $_REQUEST['hotelQuoteId']; ?>&quotationId='+quotationId+'&roomTariffId='+roomTariffId+'&tblNum='+tblNum+'&supplementId='+supplementId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
			// }
			function addhoteltoquotations(cityId,roomTariffId,tblNum,supplementId){
				if(roomTariffId>0){
	 				$('#loadhotelsavehotel').load('loadsavehotel.php?add=yes&action=saveRoomSupplement&cityId='+cityId+'&hotelQuoteId=<?php echo $_REQUEST['hotelQuoteId']; ?>&roomTariffId='+roomTariffId+'&tblNum='+tblNum+'&supplementId='+supplementId);
					selectthis(roomTariffId)
				}else{
					alert('Please select a valid rate.');
					
				}
			}

			function loadSearchSupplementRoom(hotelQuoteId){
				$('#loadhotelsearch2').load('loadhotelsearch.php?action=searchRoomSupplement&hotelQuoteId='+hotelQuoteId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
			}
			loadSearchSupplementRoom('<?php echo $_REQUEST['hotelQuoteId']; ?>');

			function selectthisH(ele){
				$(ele).html('Selected');
				$(ele).removeAttr('onclick');
				$(ele).css('background-color','#d88319');
			}
		</script>
	</div>

<?php
}

if($_REQUEST['action'] == 'selectAdultChildMeal' && $_REQUEST['dayId'] != '' && $_REQUEST['hotelQuoteId'] != '' && $_REQUEST['roomTariffId']!=''){

	$quotationId = $_REQUEST['quotationId'];
	$hotelQuoteId = $_REQUEST['hotelQuoteId'];

	$rs1=GetPageRecord('*',_QUOTATION_MASTER_,' id="'.$quotationId.'" order by id desc');
	$quotationData = mysqli_fetch_assoc($rs1);

	$rs2=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' quotationId="'.$quotationId.'" and id="'.$hotelQuoteId.'" order by id desc');
	$hotelQuotData = mysqli_fetch_assoc($rs2);

	?>
	<div class="mealClass"><h4 style="display: inline-block;">Select Meal</h4><span class="closeBTN" onclick="closeinbound();"><i class="fa fa-times"></i></span></div>
	<div class="mainDiv">
		<div style="padding-bottom: 15px;">
		<div class="lunchdinner addBtnMeal"  ><input type="checkbox" id="lunch" style="display: block;" value="1" <?php if($hotelQuotData['complimentaryLunch']==1){ ?> checked="checked" <?php } ?> />Adult Lunch</div>

		<div class="lunchdinner addBtnMeal" ><input type="checkbox" id="dinner" style="display: block;" value="1" <?php if($hotelQuotData['complimentaryDinner']==1){ ?> checked="checked" <?php } ?> />Adult Dinner</div>

		<div class="lunchdinner addBtnMeal"  ><input type="checkbox" id="breakfastA" style="display: block;" value="1" <?php if($hotelQuotData['complimentaryBreakfast']==1){ ?> checked="checked" <?php } ?> />Adult Breakfast</div>
		</div>
		<div>
		<div class="lunchdinner addBtnMeal"  ><input type="checkbox" id="childLunch" style="display: block;" value="1" <?php if($hotelQuotData['isChildLunch']==1){ ?> checked="checked" <?php } ?> />Child Lunch</div>

		<div class="lunchdinner addBtnMeal"  ><input type="checkbox" id="childDinner" style="display: block;" value="1" <?php if($hotelQuotData['isChildDinner']==1){ ?> checked="checked" <?php } ?> />Child Dinner</div>

		<div class="lunchdinner addBtnMeal"  ><input type="checkbox" id="childBreakfast" style="display: block;" value="1" <?php if($hotelQuotData['isChildBreakfast']==1){ ?> checked="checked" <?php } ?> />Child Breakfast</div>
		</div>
		<div id="savelunchdinner" style="display:none;"></div>
	<script>
	$("#lunch").click(function(){
		if($(this).is(":checked")) {
			var lunch = 1;
		}else{
			var lunch = 0;
		}
		$('#savelunchdinner').load('frmaction.php?action=savelunchHotel&quotationId=<?php echo ($quotationData['id']); ?>&supplierId=<?php echo ($hotelQuotData['supplierId']); ?>&lunch='+lunch+'&lunchquoteId=<?php echo ($hotelQuotData['id']); ?>');
	});

	$("#dinner").click(function(){
		if($(this).is(":checked")) {
			var dinner = 1;
		}else{
			var dinner = 0;
		}
		$('#savelunchdinner').load('frmaction.php?action=savedinnerHotel&quotationId=<?php echo ($quotationData['id']); ?>&supplierId=<?php echo ($hotelQuotData['supplierId']); ?>&dinner='+dinner+'&dinnerquoteId=<?php echo ($hotelQuotData['id']); ?>');
	});

	// BreakFast
	$("#breakfastA").click(function(){
		if($(this).is(":checked")) {
			var breakfast = 1;
		}else{
			var breakfast = 0;
		}
		
		$('#savelunchdinner').load('frmaction.php?action=saveBreakfastHotel&quotationId=<?php echo ($quotationData['id']); ?>&supplierId=<?php echo ($hotelQuotData['supplierId']); ?>&breakfast='+breakfast+'&breakfastquotId=<?php echo ($hotelQuotData['id']); ?>');
	});

	$("#childLunch").click(function(){
		if($(this).is(":checked")) {
			var childLunch = 1;
		}else{
			var childLunch = 0;
		}
		$('#savelunchdinner').load('frmaction.php?action=saveChildLunchHotel&quotationId=<?php echo ($quotationData['id']); ?>&supplierId=<?php echo ($hotelQuotData['supplierId']); ?>&childlunch='+childLunch+'&childLunchquotId=<?php echo ($hotelQuotData['id']); ?>');
	});

	$("#childDinner").click(function(){
		if($(this).is(":checked")) {
			var childDinner = 1;
		}else{
			var childDinner = 0;
		}
		$('#savelunchdinner').load('frmaction.php?action=saveChildDinnerHotel&quotationId=<?php echo ($quotationData['id']); ?>&supplierId=<?php echo ($hotelQuotData['supplierId']); ?>&childdinner='+childDinner+'&childDinnerquotId=<?php echo ($hotelQuotData['id']); ?>');
	});

	$("#childBreakfast").click(function(){
		if($(this).is(":checked")) {
			var childBreakfast = 1;
		}else{
			var childBreakfast = 0;
		}
		$('#savelunchdinner').load('frmaction.php?action=saveChildBreakfastHotel&quotationId=<?php echo ($quotationData['id']); ?>&supplierId=<?php echo ($hotelQuotData['supplierId']); ?>&childbreakfast='+childBreakfast+'&childBreakfastquotId=<?php echo ($hotelQuotData['id']); ?>');
	});

	</script>
	
		<div id="savelunchdinner" style="display:none;"></div>
	</div>
	<style>
		.mealClass{
		background-color: #233a49 !important;
    	color: #fff;
    	padding: 10px;
    	font-size: 16px;
		border-radius: 3px;
		}
		.closeBTN{
			float: right;
    	font-weight: 600;
    	cursor: pointer;
    	width: 18px;
    	text-align: center;
		}
		.addBtnMeal{
			width: fit-content !important;
			padding: 8px 12px !important;
			background-color: #e7e7e7;
			box-shadow: -2px 3px 4px -3px black;
		}
		.mainDiv{
			margin-top: 20px;
    		margin-bottom: 20px;
		}
	</style>
<?php
}
 
if($_REQUEST['action'] == 'addHotelAdditionalService' && $_REQUEST['dayId'] != '' && $_REQUEST['hotelQuoteId'] != '' && $_REQUEST['roomTariffId']!=''){
	// Hotel Additional Start From Hotel 
	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' id="'.$_REQUEST['hotelQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);
	// hotel data
	$d=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$hotelQuotData['supplierId'].'"');
	$hotelData=mysqli_fetch_array($d);
	?>
	<div class="inboundheader">
		<span id="hotelcounding">Add Hotel Additional </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #ffffff; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
	  	<table>
	  	<thead>
	  		<!--  and isQuoteRate=0 -->
		<tr>
		<th>
			<div class="griddiv" style="margin-left: 20px;"><label>
			<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">Hotel Additional</div>
			<select name="additionalRateId" id="additionalRateId" onchange="getHotelAdditionalCost();" class="gridfield"  >
				<option value="">Select Hotel Additional</option>
				<?php 
				$hadditionaln = GetPageRecord('*','dmcAdditionalHotelRate','rateId="'.$_REQUEST['roomTariffId'].'" and isQuoteRate=0');
				if(mysqli_num_rows($hadditionaln)>0){

					$isRateId = 1;
					while($addhoname = mysqli_fetch_assoc($hadditionaln)){
						$hnameres = GetPageRecord('*','additionalHotelMaster','id="'.$addhoname['additionalName'].'" and status=1 and deletestatus=0');
						$gerahname = mysqli_fetch_assoc($hnameres );
						?>
						<option value="<?php echo $addhoname['id']; ?>"> <?php echo $gerahname['name']; ?> </option>
						<?php
					}

				}else{

					$isRateId = 0;
					$rs='';  
					$hotelAdditionalArray = explode(',',rtrim($hotelData['hotelAdditional'],','));
					foreach($hotelAdditionalArray as $roomArray){
						$rs=GetPageRecord('*','additionalHotelMaster','id="'.$roomArray.'"'); 
						if(mysqli_num_rows($rs)>0){
							$additinalres=mysqli_fetch_array($rs);	
							?>
							<option value="<?php echo strip($additinalres['id']); ?>" ><?php echo strip($additinalres['name']); ?></option>
							<?php 
						} 
					} 
				}
				?>
			</select>
			<input type="hidden" name="isRateId" id="isRateId" value="<?php echo $isRateId; ?>"   >
			</label>
			</div>
		</th> 
		<th style="padding-left: 6px;">
			<div class="griddiv"><label>
				<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">Cost Type</div>
				<select name="costType" id="costType" value="<?php ?>" class="gridfield" >
					<option value="1">Per Pax Cost</option>
					<option value="2">Group Cost</option>
				</select>
				</label>
			</div>
		</th>
		<th style="padding-left: 6px;">
			<div class="griddiv"><label>
				<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">GST SLAB</div>
				<select id="HAGST" name="HAGST" class="gridfield" displayname="Additional GST" autocomplete="off" style="width: 100%;">
					<?php
					$rs2 = "";												
					$rs2 = GetPageRecord('*', 'gstMaster', ' 1 and serviceType="Restaurant" and status=1 order by gstSlabName asc');
					while ($gstSlabData = mysqli_fetch_array($rs2)) {
					?>
						<option value="<?php echo $gstSlabData['id']; ?>"><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
					<?php
					}
					?>
				</select>
				</label>
			</div>
		</th>
		<th style="padding-left: 6px;">
			<div class="griddiv"><label>
				<div class="gridlable" style="text-align:left; font-weight: 400; padding: 8px 0px;">Cost</div>
				<input type="text" name="additionalcost" id="additionalcost" value="<?php ?>" class="gridfield" >
				</label>
			</div>
		</th>
		<th>
			<input type="button" value="Save" onclick="savehoteladditionalcost();" class="whitembutton" style="margin-top: 25px;border-radius: 3px;background-color: #233a49;color: #fff;font-size: 14px;" /> 
			<input type="hidden" name="hotelQuoteId111" id="hotelQuoteId111" value="<?php echo $_REQUEST['hotelQuoteId']; ?>">

		</th>
		<th><input type="button" value="+ ADD NEW" onclick="openinboundpop('action=addMewHotelAdditional&dayId=<?php echo $_REQUEST['dayId']; ?>&hotelQuoteId=<?php echo $_REQUEST['hotelQuoteId']; ?>&roomTariffId=<?php echo $_REQUEST['roomTariffId']; ?>','1000px');" class="whitembutton" style="margin-top: 25px;border-radius: 3px;background-color: #233a49;color: #fff;font-size: 14px;" /> </th>
	  	</tr>
	  	</thead>
	  	</table>
		
	  <div style="background-color:#f7f7f7;" id="loadhotelsearch2" >&nbsp;</div>
	  <div style="background-color:#feffbc; display:none;" id="loadHotelAdditionalservices" ></div>
		<script type="text/javascript">
		function getHotelAdditionalCost(){
			var isRateId = $('#isRateId').val();
			var additionalRateId = $('#additionalRateId').val();
			$('#loadhotelsearch2').load('loadsaveextra.php?action=loadHotelAdditionalCost&additionalRateId='+additionalRateId+'&isRateId='+isRateId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		}
		function savehoteladditionalcost(){
			var additionalRateId = $('#additionalRateId').val();
			var additionalCost = $('#additionalcost').val();
			var HAGST  = $('#HAGST').val();
			var isRateId  = $('#isRateId').val();
			var costType  = $('#costType').val();
			// var groupCost = $('#additionalGroupCost').val();
			var hotelQuoteId111 = $('#hotelQuoteId111').val(); 
			if(additionalRateId!='' ){
				$('#loadHotelAdditionalservices').load('loadsaveextra.php?action=addedit_additionalHotelQuotation&add=yes&additionalCost='+additionalCost+'&additionalRateId='+additionalRateId+'&hotelQuoteId='+hotelQuoteId111+'&isRateId='+isRateId+'&HAGST='+HAGST+'&costType='+costType+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
			}else{
				alert('All fields are required.'); 
			}
		}
		<?php if($_REQUEST['hotelQuoteId']!= ''){ ?>
			getHotelAdditionalCost();
		<?php } ?>
		</script>
	</div>
<?php
} 
 
if($_REQUEST['action'] == 'addMewHotelAdditional' && $_REQUEST['dayId'] != '' && $_REQUEST['hotelQuoteId'] != '' && $_REQUEST['roomTariffId']!=''){
	// Hotel Additional Start From Hotel 
	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' id="'.$_REQUEST['hotelQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);
	?>
	<div class="inboundheader">
		<span id="hotelcounding">Add New Hotel Additional </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #ffffff; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
		<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="addNewHotelAdditional" target="actoinfrm" id="addNewHotelAdditional">
	  	<table>
		  	<thead>
			  	<tr>
				<th>
					<div class="griddiv" style="margin-left: 20px;"><label>
						<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">Additional Name</div>
						<input type="text" name="hotelAdditional" id="hotelAdditional" value="" class="gridfield validate"  displayname="Additional Name" >
						</label>
					</div> 
				</th>

				<th style="padding-left: 6px;"><div class="griddiv"><label>
					<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">GST SLAB</div>		
					<select name="gstTax" id="gstTax" class="gridfield"  displayname="GST SLAB" style="padding:8px;">
						<option value="0">SELECT GST SLAB</option>
						<?php
						$rs2 = "";												
						$rs2 = GetPageRecord('*', 'gstMaster', ' 1 and serviceType="Restaurant" and status=1 order by gstSlabName asc');
						while ($gstSlabData = mysqli_fetch_array($rs2)) {
						?>
							<option value="<?php echo $gstSlabData['id']; ?>"><?php echo $gstSlabData['gstSlabName']; ?>&nbsp;(<?php echo $gstSlabData['gstValue']; ?>)</option>
						<?php
						}
						?>
					</select>
					</label>
					</div>
				</th>
				<th style="padding-left: 6px;"><div class="griddiv"><label>
					<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">Currency</div>		
					<select name="currencyId" id="currencyId" class="gridfield validate"  displayname="Currency" style="padding:8px;">
						<option value="0">SELECT CURRENCY</option>
						<?php
						$currQuery='  status=1 and deletestatus=0 order by name asc';
						$currQuery2=GetPageRecord('*','queryCurrencyMaster',$currQuery);
						while($currencyData=mysqli_fetch_array($currQuery2)){
						?>
						<option value="<?php echo strip($currencyData['id']); ?>" <?php if($currencyData['setDefault']==1 ){ ?> selected="selected" <?php } ?> ><?php echo ucfirst($currencyData['name']); ?></option>
						<?php } ?>
					</select>
					</label>
					</div>
				</th>
				<th style="padding-left: 6px;">
					<div class="griddiv"><label>
						<div class="gridlable" style="text-align: left;font-weight: 400;padding: 8px 0px;">Cost Type</div>
						<select name="costType" id="costType"  class="gridfield validate"  displayname="Cost Type" >
							<option value="1">Per Pax Cost</option>
							<option value="2">Group Cost</option>
						</select>
						</label>
					</div>
				</th>
				<th style="padding-left: 6px;">
					<div class="griddiv"><label>
						<div class="gridlable" style="text-align:left; font-weight: 400; padding: 8px 0px;">Cost</div>
						<input type="text" name="additionalCost" id="additionalCost"   class="gridfield validate"  displayname="Cost" >
						</label>
					</div>
				</th>
				<th>
					<input type="button" name="Submit" value="   + ADD   " onclick="formValidation('addNewHotelAdditional','submitbtn','0');" class="whitembutton" style="margin-top: 25px;border-radius: 3px;background-color: #233a49;color: #fff;font-size: 14px;" /> 
					<input type="hidden" value="add_MewHotelAdditional" name="action"/>
					<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
					<input type="hidden" name="hotelId" id="hotelId" value="<?php echo $hotelQuotData['supplierId']; ?>">
					<input type="hidden" value="<?php echo $_REQUEST['roomTariffId']; ?>" name="roomTariffId"/>
					<input type="hidden" name="hotelQuoteId" id="hotelQuoteId" value="<?php echo $_REQUEST['hotelQuoteId']; ?>">
				</th>
				<th><input type="button" value=" BACK TO SEARCH" onclick="openinboundpop('action=addHotelAdditionalService&dayId=<?php echo $_REQUEST['dayId']; ?>&hotelQuoteId=<?php echo $_REQUEST['hotelQuoteId']; ?>&roomTariffId=<?php echo $_REQUEST['roomTariffId']; ?>','1000px');" class="whitembutton" style="margin-top: 25px;border-radius: 3px;background-color: #233a49;color: #fff;font-size: 14px;" /> </th>
			  	</tr>
		  	</thead>
	  	</table>
	  	</form>
	</div>
<?php
} 


if(trim($_REQUEST['action'])=='add_MewHotelAdditional' && trim($_REQUEST['hotelAdditional'])!='' && trim($_REQUEST['dayId'])!='' && trim($_REQUEST['hotelQuoteId'])!='' && trim($_REQUEST['hotelId'])!='' && trim($_REQUEST['roomTariffId'])!='' && trim($_REQUEST['costType'])!='' && trim($_REQUEST['currencyId'])!=''){

	$hotelAdditional=clean($_REQUEST['hotelAdditional']);
	$currencyId = $_REQUEST['currencyId'];
	$gstTax = $_REQUEST['gstTax'];
	$costType=clean($_REQUEST['costType']);
	$additionalCost = $_REQUEST['additionalCost'];

	$dayId = $_REQUEST['dayId'];
	$hotelQuoteId=clean($_REQUEST['hotelQuoteId']);
	$hotelId=clean($_REQUEST['hotelId']);
	$roomTariffId=clean($_REQUEST['roomTariffId']);
	$quotationId = $_REQUEST['quotationId'];

	$d="";
	$d=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$hotelId.'"');
	$hotelData=mysqli_fetch_array($d);


	$dateAdded = time();

	$rsr=GetPageRecord('*','additionalHotelMaster','name="'.$hotelAdditional.'" '); 
	if(mysqli_num_rows($rsr) > 0){
        ?>
        <script>
        parent.alert('Additional Hotel Already Exist!');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
    }
    else{
        $namevalue ='name="'.$hotelAdditional.'",dateAdded="'.$dateAdded.'",status=1,addedBy="'.$_SESSION['userid'].'"'; 
        $lastid = addlistinggetlastid('additionalHotelMaster',$namevalue); 

        $hotelAdditional = $hotelData['hotelAdditional'].','.$lastid;

		updatelisting(_PACKAGE_BUILDER_HOTEL_MASTER_,'hotelAdditional="'.$hotelAdditional.'"',' id="'.$hotelId.'"');
		
		$namevalue ='hotelId="'.$hotelId.'",rateId="'.$roomTariffId.'",gsttax="'.$gstTax.'",personWise="'.$costType.'",currencyId="'.$currencyId.'",status=1,isQuoteRate=1,additionalCost="'.$additionalCost.'",additionalName="'.$lastid.'",dateAdded="'.$dateAdded.'",addedBy="'.$_SESSION['userid'].'"';
		$lastId2 = addlistinggetlastid('dmcAdditionalHotelRate',$namevalue);
        ?>
        <script>
        parent.openinboundpop('action=addHotelAdditionalService&dayId=<?php echo $_REQUEST['dayId']; ?>&hotelQuoteId=<?php echo $_REQUEST['hotelQuoteId']; ?>&roomTariffId=<?php echo $_REQUEST['roomTariffId']; ?>','1000px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
        </script> 
        <?php
    }

}

if($_REQUEST['action'] == 'editQuotationHotelRate' && $_REQUEST['hotelQuoteId'] != ''){

	$qhQuery2='';
	$qhQuery2=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,'id="'.$_REQUEST['hotelQuoteId'].'"');
	$qhData2=mysqli_fetch_array($qhQuery2);


	$c="";
	$c=GetPageRecord('*',_QUOTATION_MASTER_,' id="'.$qhData2['quotationId'].'"'); 
	$quotationData=mysqli_fetch_array($c);

	$singleRoom = $quotationData['sglRoom'];
	$doubleRoom = $quotationData['dblRoom'];
	$tripleRoom = $quotationData['tplRoom'];
	$twinRoom   = $quotationData['twinRoom'];
	$EBedChild = $quotationData['childwithNoofBed'];
	$NBedChild = $quotationData['childwithoutNoofBed'];
	$EBedAdult = $quotationData['extraNoofBed'];
	$sixBedRoom = $quotationData['sixNoofBedRoom'];
	$eightBedRoom = $quotationData['eightNoofBedRoom'];
	$tenBedRoom = $quotationData['tenNoofBedRoom'];
	$quadBedRoom = $quotationData['quadNoofRoom'];
	$teenBedRoom = $quotationData['teenNoofRoom'];

	$isChildBFQ = $quotationData['isChildBreakfast'];
	$isChildDNQ = $quotationData['isChildDinner'];
	$isChildLHQ = $quotationData['isChildLunch'];

	$rs1=GetPageRecord('*',_QUERY_MASTER_,' id="'.$quotationData['queryId'].'"'); 
	$queryData = mysqli_fetch_array($rs1);


    // hotel data
	$d=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$qhData2['supplierId'].'"');
	$hotelData=mysqli_fetch_array($d);
	?>

	<div class="inboundheader"><?php echo $hotelData['hotelName']; ?> Edit Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i></div>

	<div style="padding: 10px 0;" class="inboundContent divBox">
		<style type="text/css">
			.divBox .w150{
				width: 150px;
			    display: inline-block;
			    border: 1px solid #DDD;
			    PADDING: 5PX;
			}
		</style>
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
		<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="editQuotationHotelRate" target="actoinfrm" id="editQuotationHotelRate"> 

			<div class="griddiv w150" >
			<label>
			<div class="gridlable">Room&nbsp;Type <span class="redmind"></span></div>
			<select id="roomType2" name="roomType2" class="gridfield" displayname="Room Type" onchange="getRoomPrice<?php echo ($qhData2['id']); ?>(this.value)"  > 
			<?php  
			$roomTypeArray = explode(',',rtrim($hotelData['roomType'],','));
			foreach($roomTypeArray as $roomArray){
			$rs="";  
			$rs=GetPageRecord('*',_ROOM_TYPE_MASTER_,'id="'.$roomArray.'"'); 
			$resListing=mysqli_fetch_array($rs);	
			?>
			<option value="<?php echo strip($resListing['id']); ?>"  <?php if($resListing['id']==$qhData2['roomType']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
			<?php } ?>
			</select>
			</label>
			</div>
		
			<div class="griddiv w150" >
			<label> 
			<div class="gridlable">Meal&nbsp;Plan <span class="redmind"></span></div>
			<select id="mealPlan22" name="mealPlan2" class="gridfield  " displayname="Meal Plan" autocomplete="off"    > 
			<?php   
			$rs='';  
			$rs=GetPageRecord('*',_MEAL_PLAN_MASTER_,' deletestatus=0 and status=1 order by id asc'); 
			while($resListing=mysqli_fetch_array($rs)){  

			?>
			<option value="<?php echo strip($resListing['id']); ?>"  <?php if($resListing['id']==$qhData2['mealPlan']){ ?>selected="selected"<?php } ?>><?php echo strip($resListing['name']); ?></option>
			<?php } ?>
			</select></label>
			</div>
 

			<div class="griddiv w150">
				<label>  
				<div class="gridlable">Currency<span class="redmind"></span></div>
				<select id="currencyId2" name="currencyId2" class="gridfield validate" displayname="Currency" autocomplete="off"  onchange="getROE(this.value,'currencyVal124');"    >
				 <option value="">Select</option>
					<?php 
					$currencyId = ($qhData2['currencyId']>0)?$qhData2['currencyId']:$baseCurrencyId;
					$currencyValue = ($qhData2['currencyValue']>0)?$qhData2['currencyValue']:getCurrencyVal($currencyId);
					$select=''; 
					$where=''; 
					$rs='';  
					$select='*';    
					$where=' deletestatus=0 and status=1 order by name asc';  
					$rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where); 
					while($resListing=mysqli_fetch_array($rs)){   
					?>
					<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['id']==$currencyId){ ?>selected="selected"<?php } ?> ><?php echo strip($resListing['name']); ?></option>
					<?php } ?>
					</select>
				</label>
			</div>	

			<div class="griddiv w150" >
			<label> 
				<div class="gridlable">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
				<input class="gridfield validate" name="currencyValue2" displayname="ROI Value"  id="currencyVal124" value="<?php echo trim($currencyValue); ?>" style="display:inline-block;width: 100px;" >
			</label>
			</div>

			<div class="griddiv w150" ><label>
			<div class="gridlable">Single</div>
			<input name="singleoccupancy2" type="text" class="gridfield"  id="singleoccupancy2" maxlength="12" onkeyup="numericFilter(this);" style="width: 100px;" value="<?php echo $qhData2['singleoccupancy']; ?>"/>
			<input name="singleNoofRoom2" type="text" class="gridfield"  id="singleNoofRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['singleNoofRoom']; ?>"/>
			</label>
			</div>

		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Double</div>
			<input name="doubleoccupancy2" type="text" class="gridfield"  id="doubleoccupancy2" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;" value="<?php echo $qhData2['doubleoccupancy']; ?>"/>
			<input name="doubleNoofRoom2" type="text" class="gridfield"  id="doubleNoofRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['doubleNoofRoom']; ?>"/>
			</label>
			</div>
		
			<?php  if($twinRoom>0){ ?>
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Twin</div>
			<input name="twinoccupancy2" type="text" class="gridfield"  id="twinoccupancy2" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;" value="<?php echo $qhData2['twinoccupancy']; ?>"/>
			<input name="twinNoofRoom2" type="text" class="gridfield"  id="twinNoofRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['twinNoofRoom']; ?>"/>
			</label>
			</div>
		
			<?php } if($tripleRoom>0){ ?>
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Triple Room</div>
			<input name="tripleoccupancy2" type="text" class="gridfield"  id="tripleoccupancy2" value="<?php echo $qhData2['tripleoccupancy']; ?>" maxlength="12" onkeyup="numericFilter(this);"   style="width: 100px;" />
			<input name="tripleNoofRoom2" type="text" class="gridfield"  id="tripleNoofRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['tripleNoofRoom']; ?>"/>
			</label>
			</div>
		
   	 		<?php } if($quadBedRoom>0){ ?>
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Quad Room</div>
			<input name="quadRoomCost2" type="text" class="gridfield"  id="quadRoomCost2" value="<?php echo $qhData2['quadRoom']; ?>" maxlength="12" onkeyup="numericFilter(this);"   style="width: 100px;" />
			<input name="quadNoofRoom2" type="text" class="gridfield"  id="quadNoofRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['quadNoofRoom']; ?>"/>
			</label>
			</div>
		
    		<?php } if($sixBedRoom>0){ ?>
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Six&nbsp;Bed&nbsp;Room</div>
			<input name="sixBedRoomCost2" type="text" class="gridfield"  id="sixBedRoomCost2" value="<?php echo $qhData2['sixBedRoom']; ?>" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;"/>
			<input name="sixNoofBedRoom2" type="text" class="gridfield"  id="sixNoofBedRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['sixNoofBedRoom']; ?>"/>
			</label>
			</div>
    		<?php } if($eightBedRoom>0){ ?>
			<div class="griddiv w150" ><label>
			<div class="gridlable">Eight&nbsp;Bed&nbsp;Room</div>
			<input name="eightBedRoomCost2" type="text" class="gridfield"  id="eightBedRoomCost2" value="<?php echo $qhData2['eightBedRoom']; ?>" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;"/>
			<input name="eightNoofBedRoom2" type="text" class="gridfield"  id="eightNoofBedRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['eightNoofBedRoom']; ?>"/>
			</label>
			</div>
    		<?php } if($tenBedRoom>0){ ?>
			<div class="griddiv w150" ><label>
			<div class="gridlable">Ten&nbsp;Bed&nbsp;Room</div>
			<input name="tenBedRoomCost2" type="text" class="gridfield"  id="tenBedRoomCost2" value="<?php echo $qhData2['tenBedRoom']; ?>" maxlength="12" onkeyup="numericFilter(this);"  style="width:100px;"/>
			<input name="tenNoofBedRoom2" type="text" class="gridfield"  id="tenNoofBedRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['tenNoofBedRoom']; ?>"/>
			</label>
			</div>
   	 		<?php } if($teenBedRoom>0){ ?>
			<div class="griddiv w150" ><label>
			<div class="gridlable">Teen Room</div>
			<input name="teenRoomCost2" type="text" class="gridfield"  id="teenRoomCost2" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;" value="<?php echo $qhData2['teenRoom']; ?>"/>
			<input name="teenNoofRoom2" type="text" class="gridfield"  id="teenNoofRoom2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['teenNoofRoom']; ?>"/>
			</label>
			</div>
    		<?php } if($EBedAdult>0){ ?>
			<div class="griddiv w150" ><label>
			<div class="gridlable">Extra&nbsp;Bed&nbsp;(Adult)</div>
			<input name="extraBed2" type="text" class="gridfield"  id="extraBed2" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;" value="<?php echo $qhData2['extraBed']; ?>"/>
			<input name="extraNoofBed2" type="text" class="gridfield"  id="extraNoofBed2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['extraNoofBed']; ?>"/>
			</label>
			</div>
    		<?php } if($EBedChild>0){ ?>
			<div class="griddiv w150" ><label>
			<div class="gridlable">Extra&nbsp;Bed&nbsp;(Child)</div>
			<input name="childwithbed2" type="text" class="gridfield"  id="childwithbed2" maxlength="12" onkeyup="numericFilter(this);" style="width: 100px;" value="<?php echo $qhData2['childwithbed']; ?>"/>
			<input name="childwithNoofBed2" type="text" class="gridfield"  id="childwithNoofBed2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['childwithNoofBed']; ?>"/>
			</label>
			</div>
    		<?php } if($NBedChild>0){ ?>
			<div class="griddiv w150" ><label>
			<div class="gridlable">Child&nbsp;W/B</div>
			<input name="childwithoutbed2" type="text" class="gridfield"  id="childwithoutbed2" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;" value="<?php echo $qhData2['childwithoutbed']; ?>"/>
			<input name="childwithoutNoofBed2" type="text" class="gridfield"  id="childwithoutNoofBed2" maxlength="12" onkeyup="numericFilter(this);" style="width: 40px;" value="<?php echo $qhData2['childwithoutNoofBed']; ?>"/>
			</label>
			</div>
    		<?php }  ?>

			<div class="griddiv w150" ><label>
			<div class="gridlable">Breakfast(A)</div>
			<input name="breakfast2" type="text" class="gridfield"  id="breakfast2" maxlength="12" onkeyup="numericFilter(this);"  style="width: 100px;" value="<?php echo $qhData2['breakfast']; ?>"/>
			</label>
			</div>
		
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Lunch(A) </div>
			<input name="lunch2" type="text" class="gridfield"  id="lunch2"  style="width: 100px;" onkeyup="numericFilter(this);" maxlength="12" value="<?php echo $qhData2['lunch']; ?>"/>
			</label>
			</div>
		
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Dinner(A)</div>
			<input name="dinner2" type="text" class="gridfield"  id="dinner2" maxlength="12" onkeyup="numericFilter(this);" style="width: 120px;" value="<?php echo $qhData2['dinner']; ?>" />
			</label>
			</div>
		
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Breakfast(C)</div>
			<input name="breakfastChild2" type="text" class="gridfield"  id="breakfastChild2" value="<?php echo $qhData2['childBreakfast']; ?>"  maxlength="12" onkeyup="numericFilter(this);" style="width: 100px;" />
			</label>
			</div>
		
		
			<div class="griddiv w150" ><label>
			<div class="gridlable">Lunch(C)</div>
			<input name="lunchChild2" type="text" class="gridfield"  id="lunchChild2" value="<?php echo $qhData2['childLunch']; ?>" onkeyup="numericFilter(this);" maxlength="12" style="width: 100px;" />
			</label>
			</div>
		
		
		
			<div class="griddiv w150"  ><label>
			<div class="gridlable">Dinner(C)</div>
			<input name="dinnerChild2" type="text" class="gridfield" id="dinnerChild2" value="<?php echo $qhData2['childDinner']; ?>" maxlength="12" onkeyup="numericFilter(this);" style="width: 100px;" />
			</label>
			</div>
		
		
			<div class="griddiv w150"  style="width: 639px;" ><label>
			<div class="gridlable">Remarks</div>
			<input name="remarks2" type="text" class="gridfield"  id="remarks2"  value="<?php echo $qhData2['remark']; ?>" />
			</label>
			</div>
			<!-- new added for hotel checkin and checkout fields-->
			
			<div class="griddiv w150"  style="" ><label>
			<div class="gridlable">Check In</div>
			<input name="checkIn"  id="checkIn" type="text" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $qhData2['checkin']; ?>" />
			</label>
			</div>
			<div class="griddiv w150"  style="" ><label>
			<div class="gridlable">Check Out</div>
			<input name="checkOut"  id="checkOut" type="text" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $qhData2['checkout']; ?>" />
			</label>
			</div>
				 
			<input name="hotelQuoteId2" type="hidden" id="hotelQuoteId2" value="<?php echo $_REQUEST['hotelQuoteId']; ?>" />
			<input name="action" type="hidden" id="action2" value="saveQuotationHotelRate" />
		</form>
		</div>
		<script type="text/javascript">
			function getRoomPrice<?php echo ($qhData2['id']); ?>(roomTypeId) {
				$.ajax({
					url: "loadQuotationCodes.php",
					type: "POST",
					data: { 'action' : 'editHotelPrice', 'serviceid' : '<?php echo ($qhData2['supplierId']);?>','fromDate' : '<?php echo strtotime($queryData['fromDate']);?>','toDate' : '<?php echo strtotime($queryData['fromDate']);?>','roomTypeId' : roomTypeId },
					dataType: 'json',
					cache: false,
					success: function(data) {
						$('#singleoccupancy2').val(data.singleoccupancy);
						$('#doubleoccupancy2').val(data.doubleoccupancy);
						$('#twinoccupancy2').val(data.twinoccupancy);
						$('#tripleoccupancy2').val(data.tripleoccupancy);
						$('#quadRoom2').val(data.quadRoom);
						$('#sixBedRoom2').val(data.sixBedRoom);
						$('#eightBedRoom2').val(data.eightBedRoom);
						$('#tenBedRoom2').val(data.tenBedRoom);
						$('#teenRoom2').val(data.teenRoom);
						$('#extraBed2').val(data.extraBed);
						$('#childwithbed2').val(data.childwithbed);
						$('#childwithoutbed2').val(data.childwithoutbed);


						$('#breakfast2').val(data.breakfast);
						$('#lunch2').val(data.lunch);
						$('#dinner2').val(data.dinner);

						
						$('#breakfastChild2').val(data.breakfastChild);
						$('#lunchChild2').val(data.lunchChild);
						$('#dinnerChild2').val(data.dinnerChild);


						$('#remarks2').val(data.remarks); 
					}
				});
			}
		</script>
		<style type="text/css">
			.inboundContent .griddiv{
				min-width: 130px;
			}
		</style>
	</div>
	<div id="buttonsbox" class="inboundfooter">
		<table border="0" align="right" cellpadding="0" cellspacing="0">
			<tr>
				<td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('editQuotationHotelRate','submitbtn','0');" /></td>
				<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="closeinbound();" /></td>
			</tr>
		</table>
	</div>
	<?php
}
if($_REQUEST['action'] == 'saveQuotationHotelRate' && $_REQUEST['hotelQuoteId2'] != ''){

	$namevalue ='mealPlan="'.$_REQUEST['mealPlan2'].'",roomType="'.$_REQUEST['roomType2'].'",singleoccupancy="'.$_REQUEST['singleoccupancy2'].'",singleNoofRoom="'.$_REQUEST['singleNoofRoom2'].'",doubleoccupancy="'.$_REQUEST['doubleoccupancy2'].'",doubleNoofRoom="'.$_REQUEST['doubleNoofRoom2'].'",twinoccupancy="'.$_REQUEST['twinoccupancy2'].'",twinNoofRoom="'.$_REQUEST['twinNoofRoom2'].'",tripleoccupancy="'.$_REQUEST['tripleoccupancy2'].'",tripleNoofRoom="'.$_REQUEST['tripleNoofRoom2'].'",extraBed="'.$_REQUEST['extraBed2'].'",extraNoofBed="'.$_REQUEST['extraNoofBed2'].'",childwithbed="'.$_REQUEST['childwithbed2'].'",childwithNoofBed="'.$_REQUEST['childwithNoofBed2'].'",childwithoutbed="'.$_REQUEST['childwithoutbed2'].'",childwithoutNoofBed="'.$_REQUEST['childwithoutNoofBed2'].'",sixBedRoom="'.$_REQUEST['sixBedRoomCost2'].'",sixNoofBedRoom="'.$_REQUEST['sixNoofBedRoom2'].'",eightBedRoom="'.$_REQUEST['eightBedRoomCost2'].'",eightNoofBedRoom="'.$_REQUEST['eightNoofBedRoom2'].'",tenBedRoom="'.$_REQUEST['tenBedRoomCost2'].'",tenNoofBedRoom="'.$_REQUEST['tenNoofBedRoom2'].'",quadRoom="'.$_REQUEST['quadRoomCost2'].'",quadNoofRoom="'.$_REQUEST['quadNoofRoom2'].'",teenRoom="'.$_REQUEST['teenRoomCost2'].'",teenNoofRoom="'.$_REQUEST['teenNoofRoom2'].'",breakfast="'.$_REQUEST['breakfast2'].'",lunch="'.$_REQUEST['lunch2'].'",dinner="'.$_REQUEST['dinner2'].'",childBreakfast="'.$_REQUEST['breakfastChild2'].'",childLunch="'.$_REQUEST['lunchChild2'].'",childDinner="'.$_REQUEST['dinnerChild2'].'",remark="'.$_REQUEST['remarks2'].'",checkin="'.$_REQUEST['checkIn'].'",checkout="'.$_REQUEST['checkOut'].'",currencyId="'.$_REQUEST['currencyId2'].'",currencyValue="'.$_REQUEST['currencyValue2'].'"';

	// die("try it please check");
	$updatelist = updatelisting(_QUOTATION_HOTEL_MASTER_,$namevalue,'id="'.trim($_REQUEST['hotelQuoteId2']).'"');
	?>
	<script>
		parent.$('#pageloading').hide(); 
		parent.$('#pageloader').hide(); 
		parent.warningalert('Hotel Rate Updated!');
		parent.closeinbound();
		parent.loadquotationmainfile();
	</script>
	<?php
}

if($_REQUEST['action'] == 'vewsupplementcostofHotel' && $_REQUEST['id'] != ''){

   $select1='*';
   $where1='id="'.$_REQUEST['hotelQuoteId'].'"';
   $rs1=GetPageRecord($select1,_QUOTATION_HOTEL_MASTER_,$where1);
   $dmcroommastermain=mysqli_fetch_array($rs1);

   $wheresupc='id='.$_REQUEST['id'].'';
   $rssupc=GetPageRecord('*',_DMC_ROOM_TARIFF_MASTER_,$wheresupc);
   $supplementCostc=mysqli_fetch_array($rssupc);

   // hotel data
	$d=GetPageRecord('*',_PACKAGE_BUILDER_HOTEL_MASTER_,' id="'.$dmcroommastermain['supplierId'].'"');
	$hotelData=mysqli_fetch_array($d);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding"><?php echo $hotelData['hotelName']; ?> Supplement Cost</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding: 10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
			<table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC" class="hotelds tablesorter gridtable">
				<thead style="font-weight:500;">
				   <tr>
 					  <th width="6%" align="left" bgcolor="#F4F4F4" >Single</th>
					  <th width="6%" align="left" bgcolor="#F4F4F4" >Double</th> 
					  <th width="12%" align="left" bgcolor="#F4F4F4" >Extra&nbsp;Bed(Adult)</th>
				  	  <th width="12%" align="left" bgcolor="#F4F4F4" >Extra&nbsp;Bed(Child)</th>
					  <th width="8%" align="left" bgcolor="#F4F4F4" >Child W/O</th>
				   </tr>
		      </thead>
				   <tbody>
				   	<tr>
		   	  		  <td align="left"><?php if ($dmcroommastermain['singleoccupancy']!=0) { echo $supplementCostc['singleoccupancy']; }?></td>
				   	  <td align="left"><?php if ($dmcroommastermain['doubleoccupancy']!=0) { echo $supplementCostc['doubleoccupancy'];} ?></td> 
				   	  <td align="left"><?php if ($dmcroommastermain['extraBed']!=0) {echo $supplementCostc['extraBed'];} ?></td>
				   	  <td align="left"><?php if ($dmcroommastermain['childwithbed']!=0) { echo $supplementCostc['childwithbed'];}  ?></td>
				   	  <td align="left"><?php if ($dmcroommastermain['childwithoutbed']!=0) { echo $supplementCostc['childwithoutbed'];} ?></td>
 				   </tr>
				   </tbody>
		   </table>
			</form>
		</div>
	</div>

	<?php
}
 
 
// Transfer
if($_REQUEST['action'] == 'addServiceTransfer' && $_REQUEST['dayId']!=''){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);
	$totalPaxVal= $quotationData['adult'];
	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);


	?>
 	<div class="inboundheader" > Select Transfer - <?php echo date('d-m-Y', strtotime($dayData['srdate'])); ?><i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i><span class="griddiv" style="position:static;">
 	     	</span></div>
	<div style="padding:10px;" id="transferbox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addtransferroomprice" target="actoinfrm" id="addtransferroomprice">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
			<tbody>
			<tr style="background-color:transparent !important;"> 
			<td width="200" align="left" style="display:none">
				<div class="griddiv" style="position:static;"><label>
				<div>From</div>
				<select id="startDay" name="startDay" class="gridfield validate" displayname="Start Day" autocomplete="off"   >
				<?php
				$day=1;
				$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0   order by id asc');
				while($QueryDaysData=mysqli_fetch_array($a)){
				if($dayData['cityId']==$QueryDaysData['cityId']){
				?>
				<option value="<?php echo strip($QueryDaysData['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData['srdate'])); ?>,<?php echo strip($QueryDaysData['cityId']); ?>" <?php if(strip($QueryDaysData['id']) == $_REQUEST['dayId']){ ?> selected="selected" <?php } ?> >Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
				<?php
				}
				$day++;
				} ?>
				</select>
				</label>
				</div>			
			</td>

			<td width="200" align="left" style="display:none">
				<div class="griddiv" style="position:static;"><label>
				<div>To</div>
				<select id="endDay" name="endDay" class="gridfield validate" displayname="End Day" autocomplete="off"   >
				<?php
				$day=1;
				$b=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
				while($QueryDaysData1=mysqli_fetch_array($b)){

				if($dayData['cityId']==$QueryDaysData1['cityId']){
				?>
				<option value="<?php echo strip($QueryDaysData1['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData1['srdate'])); ?>,<?php echo strip($QueryDaysData1['cityId']); ?>"  <?php if($dayData['id']==$QueryDaysData1['id']){ ?>selected="selected" <?php } ?> >Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData1['cityId']);?></option>
				<?php
				}
				$day++;
				} ?>
				</select>
				</label>
				</div>			
			</td>
				

			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label> <div>&nbsp;</div>
						<select id="destWise3" name="destWise3" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%; padding: 8px 10px; border: 1px solid #ccc; border-radius: 3px;" >
						<option value="1">Selected Destination</option>
						<option value="2">All Destinations</option>
						</select>
					</label>
					<script>
					  function getdestWise(){
						if($('#destWise3').val()==2){
							$('#destinationId3').load('loadAllDestinations.php');
						}

						if($('#destWise3').val()==1){
							$('#destinationId3').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
						}
						$('#select2-destinationId3-container').attr('title','Select');
						$('#select2-destinationId3-container').text('Select');
					  }
					  </script>
			    </div>
			</td>

			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div>Destination</div>
						<select id="destinationId3" name="destinationId3" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" onchange="loadTransferfun();">
							<?php
							$day=1;
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'" and cityId="'.$cityId.'"  and addstatus=0  group by cityId order by id asc');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							$day++;
							} ?>
						</select>
					</label>
				</div>
			</td>
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
				<div>Type</div>
				<select id="sic_pvt3" name="sic_pvt3" class="gridfield"  >
					<option value="2">PVT</option>
					<option value="1">SIC</option>
					
				</select>
				</label>
				</div>			
			</td>
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
				<div>Transfer Type</div>
				<select id="transferType3" name="transferType3" class="gridfield" onchange="getTransferName();"  >
					<option value="">All TransferType</option>
					<?php
					$b=GetPageRecord('*','transferTypeMaster','deletestatus=0 and status=1 order by id asc');
					while($transferData=mysqli_fetch_array($b)){
					?>
					<option value="<?php echo strip($transferData['id']); ?>"><?php echo $transferData['name']; ?></option>
					<?php
					} ?>
				</select>
				</label>
				</div>			
			</td>
			
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
					<div class="gridlable" style="width:100%;">Transfer Name</div>
					<select id="transferId3" name="transferId3" class="gridfield"  autocomplete="off" >
					   
				  	</select>
					</label>
			    </div> 
			</td> 

			<!-- started vehicle type  -->
			<td width="15%" align="left" valign="middle">
              <div class="griddiv"><label>
               <div class="gridlable">Vehicle Type</div>
			   <select id="vehicleType" name="vehicleType" class="gridfield " displayname="Title" autocomplete="off">
			   		<option value="0">All Vehicles</option>
					<?php

					$rs = GetPageRecord('*', 'vehicleTypeMaster', '1 and status=1 and deletestatus=0 order by name asc');

					while ($resListing = mysqli_fetch_array($rs)) {

					?>

						<option value="<?php echo $resListing['id']; ?>" 
						<?php if ($queryData['vehicleId'] == $resListing['id']) { ?> selected="selected" <?php } ?>>
							<?php echo strip($resListing['name'].' ('.$resListing['capacity']).' Pax )'; ?></option>

					<?php } ?>

					</select>
              </label>
             </div>
			</td>
			<!-- ended vehicle type  -->

			<td width="8%" align="left" valign="middle">
				<input name="transferCategory3" type="hidden" id="transferCategory3" value="transfer">
			    <input style="margin-top: 10px;" type="button" name="Submit" value="   Search   " class="bluembutton" onclick="loadsearchtransferfunction();">		    </td>
			</tr>
			</tbody>
			</table>
			</form>
			<script src="plugins/select2/select2.full.min.js"></script>
			<script>
			$(document).ready(function() {
				$('.select2').select2();
			});
			</script>
			<style>
			.select2-container--open{
			z-index: 9999999999 !important;
			width: 100%;
			}

			.select2-container {
			box-sizing: border-box;
			display: inline-block;
			margin: 0;
			position: relative;
			vertical-align: middle;
			width: 100% !important;
			margin-top: 6px !important;
			}

			.select2-container--default .select2-selection--single {
			    HEIGHT: 35px;

				}
			</style>
		</div>
		<div style="background-color:#feffbc;display:none;" id="loadtransfersave" ></div>
	  	<div style="background-color:#f7f7f7;" id="loadtransfersearch3" >&nbsp;</div>
		<script type="text/javascript">

				function getTransferName(){

				let transferTypeId = $("#transferType3").val();
				$("#transferId3").load(`searchaction.php?action=getTransferNameAction&transferTypeId=${transferTypeId}&destinationId=<?php echo $dayData['cityId']; ?>`);
				}
				getTransferName();

			 function loadTransferfun(){
		   		var destinationId = $('#destinationId3').val(); 
		   		$('#transferId3').load('load_transfer.php?destinationId='+destinationId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		    }
			function addtransfertoquotations(tarifId,supplierId,capacity,tableN){ 
				var totalPax=$('#totalPax2'+ tarifId).val(); 
				var cityId = $('#destinationId3').val();
				var transferType =$('#transferType3').val(); 
				var noOfVehicles =$('#noOfVehicles2'+tarifId).val(); 
				var totalPaxVal = '<?php echo $totalPaxVal; ?>';
				var vehicleconf = false;
				var vcapacity = Number(capacity*noOfVehicles); 
				if(vcapacity>=Number(totalPaxVal)){
					vehicleconf = true;
				}else{
					vehicleconf = confirm('Vehicle Capacity is less('+vcapacity+') than the total adult('+totalPaxVal+'). Do you still want to take this vehicle Type?');
				}	
				
				if(vehicleconf==true){
				if(tarifId > 0){
					$('#loadtransfersave').load('loadsavetransfer.php?add=yes&tarifId='+tarifId+'&serviceid='+tarifId+'&tableN='+tableN+'&costType=1&supplierId='+supplierId+'&cityId='+cityId+'&transferCategory=transfer&dayId=<?php echo $_REQUEST['dayId']; ?>&serviceType=transfer&totalPax='+totalPax+'&noOfVehicles='+noOfVehicles);
					selectthis2('#selectthis2'+tarifId);
				}else{
					alert('All fields are required.');
				}
			}

			}
			
			function loadsearchtransferfunction(){ 
				var vehicleTypeId = $('#vehicleType').val(); 
				var transferId =$('#transferId3').val();
				var destWise =$('#destWise3').val();
				var cityId =$('#destinationId3').val();
				var sic_pvt =$('#sic_pvt3').val();
				var transferType =$('#transferType3').val();
				$('#loadtransfersearch3').load('loadtransfersearch.php?destWise='+destWise+'&cityId='+cityId+'&vehicleTypeId='+encodeURI(vehicleTypeId)+'&transferId='+transferId+'&sic_pvt='+sic_pvt+'&transferType='+transferType+'&transferCategory=transfer&dayId=<?php echo $_REQUEST['dayId']; ?>');
			}
			<?php if($_REQUEST['transferCategory']!='' ){ ?>
			loadsearchtransferfunction();
			<?php } ?>
		</script>
	</div>
	<?php
}
// Transportation services start
if($_REQUEST['action'] == 'addServiceTransportation' && $_REQUEST['dayId']!=''){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);
	$totalPaxVal = $quotationData['adult'];
	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	?>
	<div class="inboundheader" style="position:relative;">
 		<?php 
 		$isSupplement = $isGuestType = $transferQuoteId = 0;
 		if($_REQUEST['transferQuoteId']>0 && $_REQUEST['stype'] == 'transferSupplement'){
 			$headingName = 'Supplement Transportation';
 			$isSupplement = 1;
 			$transferQuoteId = $_REQUEST['transferQuoteId'];

 			$rs12=GetPageRecord(' * ',_QUOTATION_TRANSFER_MASTER_,'id="'.$transferQuoteId.'"'); 
			$transferQuoteData = mysqli_fetch_array($rs12); 
			$transferId=$transferQuoteData['transferNameId'];

 		}else{
 			$headingName = 'Transportation';
 			$isGuestType = 1;
 		} 
 		echo $headingName; if($queryData['dayWise']==1){ echo "&nbsp;|&nbsp;".date('D j M Y', strtotime($dayData['srdate'])); }  ?><i class="fa fa-times" aria-hidden="true" style="position: absolute;top: 5px; right: 10px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;
	</div>
 	<div style="padding:10px;" id="transferbox">

		<input type="hidden" id="transferQuoteId3" value="<?php echo $transferQuoteId; ?>">
		<input type="hidden" id="isSupplement3" value="<?php echo $isSupplement; ?>">
		<input type="hidden" id="isGuestType3" value="<?php echo $isGuestType; ?>">
		<!-- hiddend fields -->
	
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addtransferroomprice" target="actoinfrm" id="addtransferroomprice">
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
		<tbody>
		<tr style="background-color:transparent !important;">

			<td width="10%" align="left">
				<div class="griddiv" style="position:static;"><label>
				<div>From</div>
				<select id="startDay3" name="startDay" class="gridfield validate" displayname="Start Day" autocomplete="off"   >
				<?php
				$day=1;
				$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0   order by id asc');
				while($QueryDaysData=mysqli_fetch_array($a)){
				// if($dayData['cityId']==$QueryDaysData['cityId']){
				?>
				<option value="<?php echo strip($QueryDaysData['id'].'_'.$day); ?>" <?php if(strip($QueryDaysData['id']) == $_REQUEST['dayId']){ ?> selected="selected" <?php } ?> >Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
				<?php
				// }
				$day++;
				} ?>
				</select>
				</label>
				</div>			
			</td>

			<td width="10%" align="left" >
				<div class="griddiv" style="position:static;"><label>
				<div>To</div>
				<select id="endDay3" name="endDay" class="gridfield validate" displayname="End Day" autocomplete="off"   >
				<?php
				$day=1;
				$b=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
				while($QueryDaysData1=mysqli_fetch_array($b)){

				// if($dayData['cityId']==$QueryDaysData1['cityId']){
				?>
				<option value="<?php echo strip($QueryDaysData1['id'].'_'.$day); ?>"  <?php if($dayData['id']==$QueryDaysData1['id']){ ?>selected="selected" <?php } ?> >Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData1['cityId']);?></option>
				<?php
				// }
				$day++;
				} ?>
				</select>
				</label>
				</div>			
			</td>
				

			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label> <div>&nbsp;</div>
						<select id="destWise3" name="destWise" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%; padding: 8px 10px; border: 1px solid #ccc; border-radius: 3px;" >
						<option value="1">Selected Destination</option>
						<option value="2">All Destinations</option>
						</select>
					</label>
					<script type="text/javascript">
					  function getdestWise(){
						if($('#destWise3').val()==2){
							$('#destinationId3').load('loadAllDestinations.php');
						}
						if($('#destWise3').val()==1){
							$('#destinationId3').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
						}
						$('#select2-destinationId3-container').attr('title','Select');
						$('#select2-destinationId3-container').text('Select');
					  }
					  </script> 
			    </div>
			</td>
			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div>Destination</div>
						<select id="destinationId3" name="destinationId1" class="gridfield select2" displayname="Select Destination" autocomplete="off" onchange="loadTransferfun();">
							<?php
							$day=1;
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'" and cityId="'.$cityId.'"  and addstatus=0  group by cityId order by id asc');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							$day++;
							} ?>
						</select>
					</label>
				</div>
			</td>
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
				<div>Transfer Type</div>
				<select id="transferType3" name="transferType" class="gridfield"  >
					<option value="0">All TransferType</option>
					<?php
					$b=GetPageRecord('*','transferTypeMaster','deletestatus=0 and status=1 order by id asc');
					while($transferData=mysqli_fetch_array($b)){
					?>
					<option value="<?php echo strip($transferData['id']); ?>"><?php echo $transferData['name']; ?></option>
					<?php
					} ?>
				</select>
				</label>
				</div>			
			</td>
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
					<div class="gridlable" style="width:100%;">Transportation</div>
					<select id="transferId3" name="transferId1" class="gridfield"  autocomplete="off" displayname="Transfer Name"   >
						<?php
			            $rstransfer=GetPageRecord('*',_PACKAGE_BUILDER_TRANSFER_MASTER,' transferCategory="transportation"  and FIND_IN_SET("'.$dayData['cityId'].'",destinationId) or destinationId=0 and status=1 order by transferName asc');
			            while($transferD=mysqli_fetch_array($rstransfer)){
			            ?>
	                	<option value="<?php echo $transferD['id']; ?>" <?php if($transferId==$transferD['id']){?>selected<?php } ?>><?php echo $transferD['transferName']; ?></option>
	                	<?php } ?>
				  	</select>
					</label>
			    </div> 
			</td>

			<!-- <td width="15%" align="left" valign="middle">
              <div class="griddiv"><label>
               <div class="gridlable">Vehicle&nbsp;Name</div>
                <select id="vehicleModelId3" name="vehicleModelId1" class="gridfield validate"  autocomplete="off" displayname="Vehicle Name">
					<option value="0">All Vehicles</option>
					<?php
					$rs=GetPageRecord('*',_VEHICLE_MASTER_MASTER_,' 1 and status=1 and deletestatus=0 order by model asc');
					while($vehiclData=mysqli_fetch_array($rs)){
					?>
					<option value="<?php echo $vehiclData['id']; ?>" <?php if($queryData['vehicleId']==$vehiclData['id']){ ?> selected="selected" <?php } ?>><?php echo $vehiclData['model']; ?></option>
					<?php } ?>
               </select>
              	</label>
             	</div>         
         	</td> -->


			<!-- transportatio started vehicle type  -->
			<td width="15%" align="left" valign="middle">
              <div class="griddiv"><label>
               <div class="gridlable">Vehicle Type</div>
			   <select id="vehicleType" name="vehicleType" class="gridfield " displayname="Title" autocomplete="off">
			   		<option value="0">All Vehicles</option>
					<?php 
					$rs = GetPageRecord('*', 'vehicleTypeMaster', '1 and status=1 and deletestatus=0 order by name asc'); 
					while ($resListing = mysqli_fetch_array($rs)) { 
					?> 
						<option value="<?php echo $resListing['id']; ?>" <?php if ($queryData['vehicleId'] == $resListing['id']) { ?> selected="selected" <?php } ?>>
							<?php echo strip($resListing['name'].' ('.$resListing['capacity']).' Pax )'; ?></option>

					<?php } ?>

					</select>
              </label>
             </div>
			</td>
		<!-- ended vehicle type  -->

         	<td width="12%" align="left" valign="middle"><div class="griddiv">
				<label>
				<div class="gridlable">Cost&nbsp;Type</div>
				<select id="transferCostType3" name="transferCostType3" class="gridfield validate" displayname="Transfer Cost Type" autocomplete="off" style="width: 100% !important;">
				<option value="2">Package Cost</option>
				<option value="1">Per Day Cost</option>
				</select>
				</label>
				</div>
			</td>
			<td width="8%" align="left" valign="middle">
				<input name="transferCategory" type="hidden" id="transferCategory3" value="transportation">
			    <input style="margin-top: 10px;" type="button" name="Submit" value="   Search  " class="bluembutton" onclick="loadsearchtransferfunction();">		    </td>
			</tr>
			</tbody>
			</table>
			</form>
			<script src="plugins/select2/select2.full.min.js"></script>
			<script>
			$(document).ready(function() {
				$('.select2').select2();
			});
			</script>
			<style>
			.select2-container--open{
			z-index: 9999999999 !important;
			width: 100%;
			}

			.select2-container {
			box-sizing: border-box;
			display: inline-block;
			margin: 0;
			position: relative;
			vertical-align: middle;
			width: 100% !important;
			margin-top: 6px !important;
			}

			.select2-container--default .select2-selection--single {
			    HEIGHT: 35px;

				}
			</style>
		</div>
		<div style="background-color:#feffbc;display:none;" id="loadtransfersave" ></div>
	  	<div style="background-color:#f7f7f7;" id="loadtransfersearch" >&nbsp;</div>
		<script type="text/javascript">
 
		    function loadTransferfun(){ 
		   		var destinationId = $('#destinationId3').val(); 
		   		$('#transferId3').load('load_transfer.php?transferCategory=transportation&destinationId='+destinationId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		    }
		    loadTransferfun(); 
		    	
			function addtransfertoquotations(tarifId,supplierId,capacity,tableN){
				var noOfVehicles=$('#noOfVehicles2'+ tarifId).val();
				var totalPax=$('#totalPax2'+ tarifId).val(); 
				var noOfDays =$('#noOfDays2'+tarifId).val(); 
				var startDay =$('#startDay3').val();
				var endDay =$('#endDay3').val();
				var cityId = $('#destinationId3').val();
				var costType =$('#transferCostType3').val();
				var isGuestType =$('#isGuestType3').val();
				var isSupplement =$('#isSupplement3').val();
				var transferQuoteId =$('#transferQuoteId3').val();

				var totalPaxVal = '<?php echo $totalPaxVal; ?>';
				var vehicleconf = false;
				var vcapacity = Number(capacity*noOfVehicles);

				if(Number(vcapacity)>=Number(totalPaxVal)){
					vehicleconf = true;
				}else{
					vehicleconf = confirm('Vehicle Capacity is less('+vcapacity+') than the total adult('+totalPaxVal+')');
				}	
				
				if(vehicleconf==true){

				if(tarifId > 0 ){
					$('#loadtransfersave').load('loadsavetransfer.php?add=yes&tarifId='+tarifId+'&serviceid='+tarifId+'&tableN='+tableN+'&supplierId='+supplierId+'&cityId='+cityId+'&transferCategory=transportation&isGuestType='+isGuestType+'&isSupplement='+isSupplement+'&transferQuoteId='+transferQuoteId+'&startDay='+startDay+'&endDay='+endDay+'&costType='+costType+'&noOfDays='+noOfDays+'&dayId=<?php echo $_REQUEST['dayId']; ?>&noOfVehicles='+noOfVehicles+'&totalPax='+totalPax);
				}else{
					alert('All fields are required.');
				}
			}
			}

			function loadsearchtransferfunction(){ 

				var startDay =$('#startDay3').val();
				var endDay =$('#endDay3').val(); 
				var vehicleTypeId = $('#vehicleType').val(); 
				var transferId = $('#transferId3').val();
				var destWise = $('#destWise3').val();
				var cityId = $('#destinationId3').val();
				var transferType = $('#transferType3').val();
				var costType =$('#transferCostType3').val();

				var isGuestType =$('#isGuestType3').val();
				var isSupplement =$('#isSupplement3').val();
				var transferQuoteId =$('#transferQuoteId3').val();

				if(transferId > 0 || isSupplement ==1 ){
					$('#loadtransfersearch').load('loadtransfersearch.php?destWise='+destWise+'&cityId='+cityId+'&vehicleTypeId='+encodeURI(vehicleTypeId)+'&transferId='+transferId+'&transferType='+transferType+'&costType='+costType+'&isGuestType='+isGuestType+'&isSupplement='+isSupplement+'&transferQuoteId='+transferQuoteId+'&transferCategory=transportation&startDay='+startDay+'&endDay='+endDay+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
				}else{
					alert("Please select Transportation Name!");
				}
			}
			<?php if($_REQUEST['transferCategory']!='' || (isset($_REQUEST['transferQuoteId']) && $_REQUEST['stype'] == 'transferSupplement')){ ?>
			loadsearchtransferfunction('');
			<?php } ?>

			function getVehicleModel1() {
             var vehicleId = $('#vehicleType3').val();
             $("#vehicleModelId3").load('loadvehiclemodel.php?vehicleTypeId='+vehicleId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
            }
            function selectthis(ele){
				$(ele).html('Selected');
				$(ele).removeAttr('onclick');
				$(ele).css('background-color','#d88319');
			}
		</script>
	</div>
	<?php
}
 
 
if($_REQUEST['action'] == 'addServiceFerry' && $_REQUEST['dayId']!=''){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery); 
	?>
 	<div class="inboundheader" > Select Ferry - <?php echo date('d-m-Y', strtotime($dayData['srdate'])); ?><i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i><span class="griddiv" style="position:static;">
 	     	</span></div>
	 <div style="padding:10px;" id="transferbox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addFerryService" target="actoinfrm" id="addFerryService">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
			<tbody>
			<tr style="background-color:transparent !important;">
				<td width="20%" align="left">
					<div class="griddiv" style="position:static;">
						<label> <div>&nbsp;</div>
							<select id="destWise" name="destWise" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%; padding: 8px 10px; border: 1px solid #ccc; border-radius: 3px;" >
							<option value="1">Selected Destination</option>
							<option value="2">All Destinations</option>
							</select>
						</label>
						<script>
						  function getdestWise(){
							if($('#destWise').val()==2){
								$('#destinationId1').load('loadAllDestinations.php');
							}
							if($('#destWise').val()==1){
								$('#destinationId1').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
							}
							$('#select2-destinationId1-container').text('Select');

						  }
						  </script>
				    </div>
				</td>

			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div>Destination</div>
						<select id="destinationId1" name="destinationId1" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" onchange="loadFerryfun();">
							<?php
							$day=1;
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'" and cityId="'.$cityId.'"  and addstatus=0  group by cityId order by id asc');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							$day++;
							} ?>
						</select>
					</label>
				</div>
			</td>
			
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
					<div class="gridlable" style="width:100%;">Ferry Service Name</div>
					<select id="ferryServiceId" name="ferryServiceId" class="gridfield" onclick="getPickUptime();" onchange="getPickUptime();" autocomplete="off"    >
					    <option value="0">Select Ferry</option>
						<?php
			            $ferryServiceQ=GetPageRecord('*','ferryPriceMaster',' 1 and FIND_IN_SET("'.$dayData['cityId'].'",destinationId) and status=1 order by name asc');
			            while($ferryServiceData=mysqli_fetch_array($ferryServiceQ)){
			            ?>
	                	<option value="<?php echo $ferryServiceData['id']; ?>"><?php echo $ferryServiceData['name']; ?></option>
	                	<?php } ?>
				  	</select>
					</label>
			    </div> 
			</td>
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
				<div>Select Ferry Seat</div>
				<select id="ferrySeatId" name="ferrySeatId" class="gridfield" >
					<option value="0">All Ferry Seat</option>
					<?php
					$bc1='';
					$bc1=GetPageRecord('*','ferryClassMaster',' deletestatus=0 and status=1 order by name asc');
					while($ferrySeatData=mysqli_fetch_array($bc1)){
					?>
					<option value="<?php echo strip($ferrySeatData['id']); ?>"><?php echo $ferrySeatData['name']; ?></option>
					<?php
					} ?>
				</select>
				</label>
				</div>			
			</td>

			<td width="15%" align="left">
				<div class="griddiv" style="position:static;"><label>
				<div>Select Arrival Time</div>

				<select id="ferryTime" name="ferryTime" class="gridfield" >
					<option value="0">Select Time</option>
					
				</select>

				</label>
				</div>			
			</td>

			<td width="8%" align="left" valign="middle">
			    <input style="margin-top: 10px;" type="button" name="Submit" value="   Search   " class="bluembutton" onclick="loadsearchferryfunction();">	
			</td>
			</tr>
			</tbody>
			</table>
			</form>
			<script src="plugins/select2/select2.full.min.js"></script>
			<script>
			$(document).ready(function() {
				$('.select2').select2();
			});
			</script>
			<style>
			.select2-container--open{
				z-index: 9999999999 !important;
				width: 100%;
			}

			.select2-container {
				box-sizing: border-box;
				display: inline-block;
				margin: 0;
				position: relative;
				vertical-align: middle;
				width: 100% !important;
				margin-top: 6px !important;
			}
			.select2-container--default .select2-selection--single {
			    HEIGHT: 35px;
			}
			</style>
		</div>
		<div style="background-color:#feffbc;display:none;" id="loadferrytime" ></div>
		<div style="background-color:#feffbc;display:none;" id="loadferrysave" ></div>
	  	<div style="background-color:#f7f7f7;" id="loadferrysearch" >&nbsp;</div>
		<script type="text/javascript">
			 function loadFerryfun(){
		   		var destinationId = $('#destinationId1').val(); 
				   var ferryServiceIds =$('#ferryServiceId').val();
		   		$('#ferryServiceId').load('loadferryservices.php?action=getDestinations&destinationId='+destinationId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');   
				$('#ferryTime').load('loadferryservices.php?action=getferryTime&ferryServiceId='+ferryServiceIds+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		    }
			function addferrytoquotations(rateId,tableN,ferryServiceId){
				var cityId = $('#destinationId1').val();
				var ferryTimeId = $('#ferryTime').val(); 
				if(rateId > 0 && tableN > 0){
					$('#loadferrysave').load('loadsaveferry.php?add=yes&ferryTimeId='+ferryTimeId+'&rateId='+rateId+'&tableN='+tableN+'&ferryServiceId='+ferryServiceId+'&cityId='+cityId+'&dayId=<?php echo $_REQUEST['dayId']; ?>&currencyId=<?php echo $quotationData['currencyId']; ?>');
					selectthis('#selectthis'+rateId);
				}else{
					alert('All fields are required.');
				}
			}
			function loadsearchferryfunction(){ 
				var ferrySeatId = $('#ferrySeatId').val(); 
				var ferryTimeId = $('#ferryTime').val(); 
				var ferryServiceId =$('#ferryServiceId').val();
				var destWise =$('#destWise').val();
				var cityId =$('#destinationId1').val();
				$('#loadferrysearch').load('loadferrysearch.php?ferryTimeId='+ferryTimeId+'&destWise='+destWise+'&cityId='+cityId+'&ferryServiceId='+ferryServiceId+'&ferrySeatId='+ferrySeatId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
			}
			// loadsearchferryfunction();
			
			function getPickUptime(){
				var ferryServiceIds =$('#ferryServiceId').val();
				$('#ferryTime').load('loadferryservices.php?action=getferryTime&ferryServiceId='+ferryServiceIds+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
			}

			// function loadFerryfun(){
			
			// }
		</script>
	</div>
	<?php
}
 
// sdfsdfs
if($_REQUEST['action'] == 'addServiceActivity' && $_REQUEST['dayId']!=''){

 	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);
	
	$pax = $quotationData['adult']+$quotationData['child'];
	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);
	?>
	<div class="inboundheader" style="position:relative;">
 		<?php echo 'SightSeeing'; if($queryData['dayWise']==1){ echo "&nbsp;|&nbsp;".date('D j M Y', strtotime($dayData['srdate'])); }  ?><i class="fa fa-times" aria-hidden="true" style="position: absolute;top: 5px; right: 10px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;
	</div>
	<div class="addeditpagebox " style="display:nones;position:relative;padding: 10px!important;">
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice" style="width: 100% !important;">
		<table width="100%" border="0" cellpadding="3" cellspacing="0" class="tablesorter ">
		  <tbody>
		  <tr style="background-color:transparent !important;">
			<td width="15%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div class="gridlable">Destination Type</div>
						<select id="destWise3" name="destWise3" class="gridfield validate" onChange="getdestWise();"  >
						<option value="1">Selected Destination</option>
						<option value="2">All Destinations</option>
						</select>
					</label>
					<script>
					  function getdestWise(){
						if($('#destWise3').val()==2){
							$('#destinationId3').load('loadAllDestinations.php');
						}

						if($('#destWise3').val()==1){
							$('#destinationId3').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
						}
						$('#select2-destinationId3-container').text('Select');
					  }
					  </script>
			    </div>
			</td>
			<td width="10%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div class="gridlable">Destination</div>
						<select id="destinationId3" name="destinationId3" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" >
							<?php
							$day=1;
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'" and cityId="'.$cityId.'"  and addstatus=0  group by cityId order by id asc');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							$day++;
							} ?>
						</select>
					</label>
				</div>
			</td>
		    <td width="12%" align="left">
		    	<div class="griddiv" style="position:static;">
					<label>
						<div class="gridlable">From&nbsp;Day</div>
						<select id="startDayId3" name="startDayId3" class="gridfield validate" displayname="Start Day" autocomplete="off" >
						<?php
						$day=1;
						$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
						while($QueryDaysData=mysqli_fetch_array($a)){
						//if($dayData['cityId']==$QueryDaysData['cityId']){
						?>
						<option value="<?php echo strip($QueryDaysData['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData['srdate'])); ?>,<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['srdate']==$QueryDaysData['srdate']){ ?>  selected="selected" <?php } ?>>Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
						<?php
						//}
						$day++;
						} ?>
						</select>
					</label>
				</div>
			</td>
		    <td width="12%" align="left">
		    	<div class="griddiv" style="position:static;">
					<label>
						<div class="gridlable">To&nbsp;Day</div>
						<select id="endDayId3" name="endDayId3" class="gridfield validate" displayname="Start Day" autocomplete="off" >
						<?php
						$day=1;
						$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
						while($QueryDaysData=mysqli_fetch_array($a)){
						//if($dayData['cityId']==$QueryDaysData['cityId']){
						?>
						<option value="<?php echo strip($QueryDaysData['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData['srdate'])); ?>,<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['srdate']==$QueryDaysData['srdate']){ ?>  selected="selected" <?php } ?>>Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
						<?php
						//}
						$day++;
						} ?>
						</select>
					</label>
				</div>
			</td>

			<td width="8%">
		<div class="griddiv"><label>

			<div class="gridlable">Transfer&nbsp;Type</div>

			<select id="ActransferType" name="ActransferType" class="gridfield " autocomplete="off">
				
				<option value="1" <?php if ($editresult['transferType'] == '1') { ?> selected="selected" <?php } ?>>SIC</option>
				
				<option value="2" <?php if ($editresult['transferType'] == '2') { ?> selected="selected" <?php } ?>>PVT</option>
				
				<option value="3" <?php if ($editresult['transferType'] == '3') { ?> selected="selected" <?php } ?>>VIP</option>

				<option value="4" <?php if ($editresult['transferType'] == '4' || !isset($editresult['transferType'])) { ?> selected="selected" <?php } ?>>Ticket Only</option>
				
			</select>

			</label>

		</div>
	</td>

			<td width="10%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div class="gridlable">&nbsp;</div>
						<select id="defaultWise3" name="defaultWise3" class="gridfield" autocomplete="off"  >
							<option value="2">All Sightseeing</option>
							<option value="1" >Default Sightseeing</option>
						</select>
					</label>
				</div>
			</td>
			<td width="auto" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div class="gridlable">Sightseeing Name</div>
						<input name="activityName" type="text" class="gridfield " id="activityName" placeholder="Enter Keyword " value="<?php echo urldecode($_REQUEST['activityName']); ?>" />
					</label>
		  		</div>							
		 	</td> 
			<td width="8%" align="left" valign="middle">
				<input name="quotationId3" type="hidden" id="quotationId3" value="<?php echo  $quotationData['id']; ?>">
			    <button type="button" style="background:#233a49; color:#fff;"  name="Submit" value="" class="whitembutton searchBtn"  onclick="loadsearchactivityfunction();"><i class="fa fa-search"></i>&nbsp;&nbsp;&nbsp;Search   </button></td>
			</tr>
	</tbody></table>
		</form>
	</div>
	<div style="background-color:#feffbc; padding:0px; display:none;" id="loadsaveactivity" ></div>
	<div style="background-color:#f7f7f7; padding:10px;" id="loadactivitysearch" ></div>
	<script>
		// guide BOX
		loadsearchactivityfunction();
		function loadsearchactivityfunction(){
			var startDayId = encodeURI($('#startDayId3').val());
			var endDayId = encodeURI($('#endDayId3').val());
			var defaultWise = encodeURI($('#defaultWise3').val());

			var destinationId = encodeURI($('#destinationId3').val());
			var destWise = encodeURI($('#destWise3').val());
			var ActransferType = encodeURI($('#ActransferType').val());
			var activityName = encodeURI($('#activityName').val());

			var dayId = encodeURI(<?php echo ($_REQUEST['dayId']>0)?$_REQUEST['dayId']:0; ?>);
			var quotationId = encodeURI($('#quotationId3').val());

			$('#loadactivitysearch').load('loadactivitysearch.php?startDayId='+startDayId+'&endDayId='+endDayId+'&defaultWise='+defaultWise+'&destinationId='+destinationId+'&destWise='+destWise+'&dayId='+dayId+'&quotationId='+quotationId+'&transferType='+ActransferType+'&activityName='+activityName);
		}

		function addguidetoquotations(dmcId,serviceId,totalDays,tableN){
			var quotationId = encodeURI($('#quotationId3').val());
			var destinationId = encodeURI($('#destinationId3').val());
			var noOfVehicles = encodeURI($('#noOfVehicles'+dmcId).val());
			var slabId = encodeURI($('#slabId3'+dmcId+serviceId).val());
			var dayId = encodeURI(<?php echo ($_REQUEST['dayId']>0)?$_REQUEST['dayId']:0; ?>);
			if(serviceId>0 && dayId>0){
				$('#loadsaveactivity').load('loadsaveactivity.php?add=yes&dmcId='+dmcId+'&serviceId='+serviceId+'&quotationId='+quotationId+'&slabId='+slabId+'&destinationId='+destinationId+'&dayId='+dayId+'&tableN='+tableN+'&totalDays='+totalDays+'&noOfVehicles='+noOfVehicles);
			}else{
				alert('All fields are required.');
			}
		}
		function selectthisE(ele,tblN){
			$('#selectBtnE'+ele+tblN).html('&nbsp;Selected');
			$('#selectBtnE'+ele+tblN).removeAttr('onclick');
			$('#selectBtnE'+ele+tblN).css('background-color','#d88319');
		}
	</script>
	<?php
}
 
if($_REQUEST['action'] == 'addServiceEntrance' && $_REQUEST['dayId']!=''  ){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	$day1 = 1;
	$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
	while($dayData1 = mysqli_fetch_array($dayQuery1)){
		if(strip($dayData1['id']) == $_REQUEST['dayId']){ break; }
		$day1++;
	}
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	$nation=GetPageRecord('*','nationalityMaster','id ="'.$queryData['nationality'].'"');
	$nationData=mysqli_fetch_array($nation);
	
	if($nationData['countryId'] == $defaultCountryId || ($nationData['countryId'] == 0 && $nationData['name'] == 'Local')){
		$nationType = 'Local';
	}else if($nationData['countryId'] == 0 && $nationData['name'] == 'Foreign'){
		$nationType = 'Foreign';	
	}else if($nationData['countryId'] == 0 && $nationData['name'] == 'Bimstec'){
		$nationType = 'Bimstec';	
	}else{
		$nationType = 'Local';
	}

	if($nationData['countryId'] == $defaultCountryId || ($nationData['countryId'] == 0 && $nationData['name'] == 'Local')){
		$nationType = 'Local';
	}else if($nationData['countryId'] != $defaultCountryId || ($nationData['countryId'] == 0 && $nationData['name'] == 'Foreign')){
		$nationType = 'Foreign';	
	}else if($nationData['countryId'] == 0 && $nationData['name'] == 'Bimstec'){
		$nationType = 'Bimstec';	
	}else{
		$nationType = 'Local';
	}
	?>
 	<div class="inboundheader" > Add Monument &nbsp;&nbsp;Pax&nbsp;Nationality: <?php echo $nationType ?> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i></div>
		<div class="addeditpagebox addtopaboxlist" style="display:nonec;padding:10px">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
			<table width="100%" border="0" cellpadding="0" cellspacing="0"  class="tablesorter gridtable">
			  	<tr style="background-color:transparent !important;">
				    <td width="15%" align="left" valign="top">
				    	<div class="griddiv" style="position:static;">
							<label>
								<div>Location Type</div>
								<select id="destWise2" name="destWise2" class="gridfield validate" onChange="getdestWise();" autocomplete="off" >
									<option value="1">Selected Destination</option>
									<option value="2">All Destinations</option>
								</select>
							</label>
							<script>
							function getdestWise(){
								if($('#destWise2').val()==2){
									$('#destinationId2').load('loadAllDestinations.php');
								}
								if($('#destWise2').val()==1){
									$('#destinationId2').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
								}
							}
						  </script>
						  <style>
							.select2-selection--single {
								display: inline-block !important;
								outline: 0px;
								padding-bottom: 0px;
								width: 100%;
								background-color: #FFFFFF !important;
								font-size: 14px;
								border: 1px #e0e0e0 solid !important;
								box-sizing: border-box !important;
								height: auto !important;
								padding: 2px;
								margin-top: 4px;
								border-radius: 2px !important;
							}
							.select2-container--default .select2-selection--single .select2-selection__arrow {
							top: 9px !important;
							}
						  </style>
				    	</div>
					</td>
				    <td width="15%" align="left" valign="top">
						<!-- select destination -->
						<div class="griddiv" style="position:static;">
						<label>
						<div>Destination</div>
						<select id="destinationId2" name="destinationId2" class="gridfield validate select2" displayname="Select Destination" autocomplete="off"   >
						<?php
						$day=1;
						$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and cityId="'.$cityId.'"  group by cityId  order by id asc');
						while($QueryDaysData=mysqli_fetch_array($a)){
						?>
						<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
						<?php
						$day++;
						} ?>
						</select>
						</label>
						</div>				
					</td>
				    <td width="10%" align="left" valign="top">
				    	<div class="griddiv" style="position:static;">
							<label>
								<div>Transfer Type</div>
								<select id="transferType2" name="transferType2" class="gridfield validate" autocomplete="off"  >
								<option value="3">Ticket Only</option>
								<option value="1">SIC</option>
								<option value="2">PVT</option>
								</select>
							</label>
				    	</div>
					</td> 
					
					<td width="10%" align="left" valign="top" >
						<div class="griddiv" style="position:static;"><label>
							<div>From Day</div>
							<select id="startDay2" name="startDay2" class="gridfield validate" displayname="Start Day" autocomplete="off"   >
							<?php
							$day = $day1;
							$starDayQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and id >= "'.$dayData['id'].'"  order by srdate asc');
							while($QueryDaysData=mysqli_fetch_array($starDayQuery)){
								if($cityId==$QueryDaysData['cityId']){
								?>
								<option value="<?php echo strip($QueryDaysData['id']); ?>"  <?php if(strip($QueryDaysData['id']) == $_REQUEST['dayId']){ ?>  selected="selected" <?php } ?> >Night <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
								<?php
								} else{
									break;
								}
								$day++;
							} ?>
							</select>
							</label>
					  </div>
				  	</td>
				  	<td width="10%" align="left" valign="top" >
					  	<div class="griddiv" style="position:static;">
						  	<label>
								<div>To Day</div>
								<select id="endDay2" name="endDay2" class="gridfield validate" displayname="End Day" autocomplete="off"   >
								<?php
								$day = $day1;
								$starDayQuery=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0   and id >= "'.$dayData['id'].'" order by srdate asc');
								while($QueryDaysData=mysqli_fetch_array($starDayQuery)){
									if($cityId==$QueryDaysData['cityId']){
									?>
									<option value="<?php echo strip($QueryDaysData['id']); ?>"  <?php if(strip($QueryDaysData['id']) == $_REQUEST['dayId']){ ?>  selected="selected" <?php } ?> >Night <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
									<?php
									} else{
										break;
									}
									$day++;
								}
								?>
							</select>
							</label>
					  	</div>
				  	</td> 
				  	<td width="10%" align="left" valign="top">
				    	<div class="griddiv" style="position:static;">
							<label>
								<div class="gridlable">&nbsp;</div>
								<select id="defaultWise2" name="defaultWise2" class="gridfield validate" autocomplete="off"  >
								<option value="0">All Entrance</option>
								<option value="1">Default Entrance</option>
								</select>
							</label>
				    	</div>
					</td> 
					<td  align="left" valign="top">
						<div class="griddiv" style="position:static;margin-bottom: 0;"><label>
							<div style="width:100%;">Search..</div>
							<input name="entranceName2" type="text" class="gridfield " id="entranceName2" placeholder="Search Monument"  displayname="Monument Name" value="<?php echo urldecode($_REQUEST['entranceName']); ?>" />
							</label>
					  	</div>	
					</td>
					<td width="10%" align="left" valign="top" valign="middle">
						<br>
			    		<button type="button"  name="Submit" value="" class="whitembutton searchBtn"  onclick="loadsearchentrancefunction();"><i class="fa fa-search"></i>&nbsp;&nbsp;&nbsp;Search   </button></td>
					    <!-- <input type="button" name="Submit" value="   Search   " class="bluembutton"  style="margin-top:6px;" onclick="loadsearchentrancefunction();"> -->
					</td>
				</tr>
				
			</table>
		</form>
		<script src="plugins/select2/select2.full.min.js"></script>
		<script>
		$(document).ready(function() {
		$('.select2').select2();
		});
		</script>
		<style>
		.select2-container--open{
		z-index: 9999999999 !important;
		width: 100%;
		}

		.select2-container {
		box-sizing: border-box;
		display: inline-block;
		margin: 0;
		position: relative;
		vertical-align: middle;
		width: 100% !important;
		}
		</style>

		</div>
		<div style="background-color:#feffbc; padding:0px; display:none;" id="loadentrancesaveentrance" ></div>
		<div style="background-color:#f7f7f7; " id="loadentrancesearch" ></div>
		<script>
			// ENTRANCE BOX
			loadsearchentrancefunction();
			function loadsearchentrancefunction(){ 
				var destinationId =$('#destinationId2').val(); 
				var destWise =$('#destWise2').val(); 
				var startDayId = encodeURI($('#startDay2').val());
				var endDayId = encodeURI($('#endDay2').val());
				var transferType = encodeURI($('#transferType2').val());
				var defaultWise = encodeURI($('#defaultWise2').val());
				var entranceName =  $('#entranceName2').val(); 
				$('#loadentrancesearch').load('loadentrancesearch.php?entranceName='+encodeURI(entranceName)+'&destinationId='+destinationId+'&transferType='+transferType+'&defaultWise='+defaultWise+'&destWise='+destWise+'&startDayId='+startDayId+'&endDayId='+endDayId+'');
			}

			function addentrancetoquotations(entranceId,dmcId,tableN,cityId,isopen){
				if(isopen==0){ 
					if(entranceId!='' && cityId!=''){
 						var startDayId = encodeURI($('#startDay2').val());
 						var noOfVehicle = encodeURI($('#noOfVehicle'+dmcId).val());
						var endDayId = encodeURI($('#endDay2').val());
						var transferType = encodeURI($('#transferType2').val());
						$('#loadentrancesaveentrance').load('loadsaveentrance.php?action=addedit_QuotationEntrance&add=yes&entranceId='+entranceId+'&dmcId='+dmcId+'&tableN='+tableN+'&cityId='+cityId+'&transferType='+transferType+'&startDayId='+startDayId+'&endDayId='+endDayId+'&noOfVehicle='+noOfVehicle+'&calculationType=<?php echo $quotationData['calculationType'];?>');
						selectthis('#selectthis'+dmcId);
					}else{
						alert('All fields are required.');
					}
				}else{
					alert('Monument is remain closed on every <?php echo date('l', strtotime($dayData['srdate'])); ?>...!');
				}
			}
		</script>
	<?php

}

if($_REQUEST['action'] == 'addServiceFlight' && $_REQUEST['dayId']!=''  ){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	$day1 = 1;
	$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
	while($dayData1 = mysqli_fetch_array($dayQuery1)){
		if(strip($dayData1['id']) == $_REQUEST['dayId']){ break; }
		$day1++;
	}
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	$escortQuery=GetPageRecord('*','totalPaxSlab','quotationId ="'.$dayData['quotationId'].'" and status=1');
	$escortData=mysqli_fetch_array($escortQuery);
	?>
 	<div class="inboundheader" style="position:relative;">Add Flight 
		<div style="display: initial;margin-left: 30px;">
			<?php if($escortData['foreignEscort']>0 || $escortData['localEscort']>0 ) { ?>
			<input type="checkbox" style="display:initial;" checked name="isGuestType" id="isGuestType">Guest
			<?php }if($escortData['foreignEscort']>0) { ?>
			<input type="checkbox" style="display:initial;" checked name="isForeignEscort" id="isForeignEscort">Foreign&nbsp;Escort <?php } ?>
			<?php if($escortData['localEscort']>0) { ?>
			<input type="checkbox" style="display:initial;" checked name="isLocalEscort" id="isLocalEscort">Local&nbsp;Escort <?php } ?>
		</div>
		<i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i>
	</div>

	<div class="addeditpagebox addtopaboxlist" style="display:nonec;padding:10px">
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
		<table width="100%" border="0" cellpadding="0" cellspacing="0"  class="tablesorter gridtable">
		  	<tr style="background-color:transparent !important;">
			    
				<td width="15%" align="left">
					<div class="griddiv" style="position:static;">
					<label> 
						<div class="gridlable">&nbsp;</div>
						<select id="destWise2" name="destWise2" class="gridfield validate" onChange="getdestWise2();" autocomplete="off" >
						<option value="1">Selected Destination</option>
						<option value="2">All Destinations</option>
						</select>
					</label>
					<script type="text/javascript">
					  	function getdestWise2(){
							if($('#destWise2').val()==2){
								$('#departureFrom2').load('loadAllDestinations.php');
								$('#arrivalTo2').load('loadAllDestinations.php');
							}
							if($('#destWise2').val()==1){
								$('#departureFrom2').load('loadAllDestinations.php?serviceType=flight&dayId=<?php echo $_REQUEST['dayId']; ?>');
								$('#arrivalTo2').load('loadAllDestinations.php?serviceType=flight&dayId=<?php echo $_REQUEST['dayId']; ?>');
							}
							$('#select2-departureFrom2-container').attr('title','Select');
							$('#select2-departureFrom2-container').text('Select');

							$('#select2-arrivalTo2-container').attr('title','Select');
							$('#select2-arrivalTo2-container').text('Select');
						}
					</script>
				    </div>
				</td>
			    <td width="15%" align="left">
			    	<div class="griddiv" style="position:static;">
			    		<label>
						<div class="gridlable">Departure&nbsp;From</div>
						<select id="departureFrom2" name="departureFrom2" class="gridfield validate select2" displayname="Departure From" >
							<?php
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0 group by cityId ');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  ><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							} ?>
						</select>
						</label>
					</div>
				</td>
			  	<td width="15%" align="left">
			  		<div class="griddiv" style="position:static;">
			  			<label>
						<div class="gridlable">Arrival&nbsp;To</div>
						<select id="arrivalTo2" name="arrivalTo2" class="gridfield validate select2" displayname="Arrival To" autocomplete="off"   >
						<?php
						$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  group by cityId ');
						while($QueryDaysData=mysqli_fetch_array($a)){ ?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  ><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
						} ?>
						</select>
						</label>
					</div>
				</td>  
				<td align="left" valign="top">
					<div class="griddiv" style="position:static;margin-bottom: 0;"><label>
						<div style="width:100%;">Search..</div>
						<input name="flightName2" type="text" class="gridfield " id="flightName2" placeholder="Search Flight"  displayname="Flight Name" value="<?php echo urldecode($_REQUEST['flightName']); ?>" />
						</label>
				  	</div>	
				</td>
				<td width="10%" align="left" valign="top" valign="middle">
					<br>
		    		<button type="button"  name="Submit" value="" class="whitembutton searchBtn"  onclick="loadsearchflightfunction();"><i class="fa fa-search"></i>&nbsp;&nbsp;&nbsp;Search   </button>
		    	</td> 
				</td>
			</tr>
			
		</table>
	</form>
	<script src="plugins/select2/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
	$('.select2').select2();
	});
	</script>
	<style>
		.select2-container--open{
		z-index: 9999999999 !important;
		width: 100%;
		}

		.select2-container {
		box-sizing: border-box;
		display: inline-block;
		margin: 0;
		position: relative;
		vertical-align: middle;
		width: 100% !important;
		}
	</style>

	</div>
	<div style="background-color:#feffbc; padding:0px; display:none;" id="loadflightsaveflight" ></div>
	<div style="background-color:#f7f7f7; " id="loadflightsearch" ></div>
	<script>
		// flight BOX
		loadsearchflightfunction();
		function loadsearchflightfunction(){ 
			var departureFrom =$('#departureFrom2').val(); 
			var destWise =$('#destWise2').val(); 
			var flightName =  $('#flightName2').val(); 
			$('#loadflightsearch').load('loadflightsearch.php?flightName='+encodeURI(flightName)+'&departureFrom='+departureFrom+'&destWise='+destWise+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		}

		function addflighttoquotations(flightId,dmcId,tableN,cityId){

			var isGuestType = $('#isGuestType2').prop('checked') ? 1 : 0;
			var isLocalEscort = $('#isLocalEscort2').prop('checked') ? 1 : 0;
			var isForeignEscort = $('#isForeignEscort2').prop('checked') ? 1 : 0;

			var departureFrom = $('#departureFrom2').val();
			var arrivalTo = $('#arrivalTo2').val(); 
				
			if(flightId!='' && cityId!=''){
				$('#loadflightsaveflight').load('loadsaveflight.php?action=addedit_Quotationflight&add=yes&flightId='+flightId+'&dmcId='+dmcId+'&tableN='+tableN+'&isGuestType='+isGuestType+'&isLocalEscort='+isLocalEscort+'&isForeignEscort='+isForeignEscort+'&departureFrom='+departureFrom+'&arrivalTo='+arrivalTo+'&cityId='+cityId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
				selectthis('#selectthis'+dmcId);
			}else{
				alert('All fields are required.');
			}
		}  
	</script>
	<?php
}

if($_REQUEST['action'] == 'addServiceTrains' && $_REQUEST['dayId']!=''  ){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	$day1 = 1;
	$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
	while($dayData1 = mysqli_fetch_array($dayQuery1)){
		if(strip($dayData1['id']) == $_REQUEST['dayId']){ break; }
		$day1++;
	}
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	$escortQuery=GetPageRecord('*','totalPaxSlab','quotationId ="'.$dayData['quotationId'].'" and status=1');
	$escortData=mysqli_fetch_array($escortQuery);
	?>
 	<div class="inboundheader" style="position:relative;">Add Train 
		<div style="display: initial;margin-left: 30px;">
			<?php if($escortData['foreignEscort']>0 || $escortData['localEscort']>0 ) { ?>
			<input type="checkbox" style="display:initial;" checked name="isGuestType" id="isGuestType">Guest
			<?php }if($escortData['foreignEscort']>0) { ?>
			<input type="checkbox" style="display:initial;" checked name="isForeignEscort" id="isForeignEscort">Foreign&nbsp;Escort <?php } ?>
			<?php if($escortData['localEscort']>0) { ?>
			<input type="checkbox" style="display:initial;" checked name="isLocalEscort" id="isLocalEscort">Local&nbsp;Escort <?php } ?>
		</div>
		<i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i>
	</div>

	<div class="addeditpagebox addtopaboxlist" style="display:nonec;padding:10px">
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
		<table width="100%" border="0" cellpadding="0" cellspacing="0"  class="tablesorter gridtable">
		  	<tr style="background-color:transparent !important;">
			    
				<td width="15%" align="left">
					<div class="griddiv" style="position:static;">
					<label> 
						<div class="gridlable">&nbsp;</div>
						<select id="destWise2" name="destWise2" class="gridfield validate" onChange="getdestWise2();" autocomplete="off" >
						<option value="1">Selected Destination</option>
						<option value="2">All Destinations</option>
						</select>
					</label>
					<script type="text/javascript">
					  	function getdestWise2(){
							if($('#destWise2').val()==2){
								$('#departureFrom2').load('loadAllDestinations.php');
								$('#arrivalTo2').load('loadAllDestinations.php');
							}
							if($('#destWise2').val()==1){
								$('#departureFrom2').load('loadAllDestinations.php?serviceType=train&dayId=<?php echo $_REQUEST['dayId']; ?>');
								$('#arrivalTo2').load('loadAllDestinations.php?serviceType=train&dayId=<?php echo $_REQUEST['dayId']; ?>');
							}
							$('#select2-departureFrom2-container').attr('title','Select');
							$('#select2-departureFrom2-container').text('Select');

							$('#select2-arrivalTo2-container').attr('title','Select');
							$('#select2-arrivalTo2-container').text('Select');
						}
					</script>
				    </div>
				</td>
			    <td width="15%" align="left">
			    	<div class="griddiv" style="position:static;">
			    		<label>
						<div class="gridlable">Departure&nbsp;From</div>
						<select id="departureFrom2" name="departureFrom2" class="gridfield validate select2" displayname="Departure From" >
							<?php
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0 group by cityId ');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  ><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							} ?>
						</select>
						</label>
					</div>
				</td>
			  	<td width="15%" align="left">
			  		<div class="griddiv" style="position:static;">
			  			<label>
						<div class="gridlable">Arrival&nbsp;To</div>
						<select id="arrivalTo2" name="arrivalTo2" class="gridfield validate select2" displayname="Arrival To" autocomplete="off"   >
						<?php
						$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  group by cityId ');
						while($QueryDaysData=mysqli_fetch_array($a)){ ?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  ><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
						} ?>
						</select>
						</label>
					</div>
				</td> 
				 
				<td align="left" valign="top">
					<div class="griddiv" style="position:static;margin-bottom: 0;"><label>
						<div style="width:100%;">Search..</div>
						<input name="trainName2" type="text" class="gridfield " id="trainName2" placeholder="Search train"  displayname="train Name" value="<?php echo urldecode($_REQUEST['trainName']); ?>" />
						</label>
				  	</div>	
				</td>
				<td width="10%" align="left" valign="top" valign="middle">
					<br>
		    		<button type="button"  name="Submit" value="" class="whitembutton searchBtn"  onclick="loadsearchtrainfunction();"><i class="fa fa-search"></i>&nbsp;&nbsp;&nbsp;Search   </button>
		    	</td> 
				</td>
			</tr>
			
		</table>
	</form>
	<script src="plugins/select2/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
	$('.select2').select2();
	});
	</script>
	<style>
		.select2-container--open{
		z-index: 9999999999 !important;
		width: 100%;
		}

		.select2-container {
		box-sizing: border-box;
		display: inline-block;
		margin: 0;
		position: relative;
		vertical-align: middle;
		width: 100% !important;
		}
	</style>

	</div>
	<div style="background-color:#feffbc; padding:0px; display:none;" id="loadtrainsavetrain" ></div>
	<div style="background-color:#f7f7f7; " id="loadtrainsearch" ></div>
	<script>
		// train BOX
		loadsearchtrainfunction();
		function loadsearchtrainfunction(){ 
			var departureFrom =$('#departureFrom2').val(); 
			var destWise =$('#destWise2').val(); 
			var trainName =  $('#trainName2').val(); 
			$('#loadtrainsearch').load('loadtrainsearch.php?trainName='+encodeURI(trainName)+'&departureFrom='+departureFrom+'&destWise='+destWise+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		}

		function addtraintoquotations(trainId,dmcId,tableN,cityId){

			var isGuestType = $('#isGuestType2').prop('checked') ? 1 : 0;
			var isLocalEscort = $('#isLocalEscort2').prop('checked') ? 1 : 0;
			var isForeignEscort = $('#isForeignEscort2').prop('checked') ? 1 : 0;

			var departureFrom = $('#departureFrom2').val();
			var arrivalTo = $('#arrivalTo2').val();
			if(trainId!='' && cityId!=''){
				$('#loadtrainsavetrain').load('loadsavetrains.php?action=addedit_Quotationtrain&add=yes&trainId='+trainId+'&dmcId='+dmcId+'&tableN='+tableN+'&isGuestType='+isGuestType+'&isLocalEscort='+isLocalEscort+'&isForeignEscort='+isForeignEscort+'&departureFrom='+departureFrom+'&arrivalTo='+arrivalTo+'&cityId='+cityId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
				selectthis('#selectthis'+dmcId);
			}else{
				alert('All fields are required.');
			}
		} 

	</script>
	<?php

} 

if($_REQUEST['action'] == 'addServiceMealPlan' && $_REQUEST['dayId']!=''  ){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	$day1 = 1;
	$dayQuery1=GetPageRecord('*','newQuotationDays',' quotationId="'.$dayData['quotationId'].'"  and addstatus=0  order by id asc');
	while($dayData1 = mysqli_fetch_array($dayQuery1)){
		if(strip($dayData1['id']) == $_REQUEST['dayId']){ break; }
		$day1++;
	}
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	$escortQuery=GetPageRecord('*','totalPaxSlab','quotationId ="'.$dayData['quotationId'].'" and status=1');
	$escortData=mysqli_fetch_array($escortQuery);
	?>
 	<div class="inboundheader" style="position:relative;">Add Restaurant 
		<i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>
	</div>

	<div class="addeditpagebox addtopaboxlist" style="display:nonec;padding:10px">
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
		<table width="100%" border="0" cellpadding="0" cellspacing="0"  class="tablesorter gridtable">
		  	<tr style="background-color:transparent !important;">
			    
				<td width="15%" align="left" valign="top">
			    	<div class="griddiv" style="position:static;">
						<label>
							<div>Location Type</div>
							<select id="destWise2" name="destWise2" class="gridfield validate" onChange="getdestWise();" autocomplete="off" >
								<option value="1">Selected Destination</option>
								<option value="2">All Destinations</option>
							</select>
						</label>
						<script>
						function getdestWise(){
							if($('#destWise2').val()==2){
								$('#destinationId2').load('loadAllDestinations.php');
							}
							if($('#destWise2').val()==1){
								$('#destinationId2').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
							}
						}
					  </script>
					  <style>
						.select2-selection--single {
							display: inline-block !important;
							outline: 0px;
							padding-bottom: 0px;
							width: 100%;
							background-color: #FFFFFF !important;
							font-size: 14px;
							border: 1px #e0e0e0 solid !important;
							box-sizing: border-box !important;
							height: auto !important;
							padding: 2px;
							margin-top: 4px;
							border-radius: 2px !important;
						}
						.select2-container--default .select2-selection--single .select2-selection__arrow {
						top: 9px !important;
						}
					  </style>
			    	</div>
				</td>
			    <td width="15%" align="left" valign="top">
					<!-- select destination -->
					<div class="griddiv" style="position:static;">
					<label>
					<div>Destination</div>
					<select id="destinationId2" name="destinationId2" class="gridfield validate select2" displayname="Select Destination" autocomplete="off"   >
					<?php
					$day=1;
					$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and cityId="'.$cityId.'"  group by cityId  order by id asc');
					while($QueryDaysData=mysqli_fetch_array($a)){
					?>
					<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
					<?php
					$day++;
					} ?>
					</select>
					</label>
					</div>				
				</td>

				<td align="left" valign="top">
					<div class="griddiv" style="position:static;margin-bottom: 0;"><label>
						<div style="width:100%;">Search..</div>
						<input name="restaurantName2" type="text" class="gridfield " id="restaurantName2" placeholder="Search train"  displayname="train Name" value="<?php echo urldecode($_REQUEST['restaurantName']); ?>" />
						</label>
				  	</div>	
				</td>
				<td width="10%" align="left" valign="top" valign="middle">
					<br>
		    		<button type="button"  name="Submit" value="" class="whitembutton searchBtn"  onclick="loadsearchrestaurantfunction();"><i class="fa fa-search"></i>&nbsp;&nbsp;&nbsp;Search   </button>
		    	</td> 
				</td>
			</tr>
			
		</table>
	</form>
	<script src="plugins/select2/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
	$('.select2').select2();
	});
	</script>
	<style>
		.select2-container--open{
		z-index: 9999999999 !important;
		width: 100%;
		}

		.select2-container {
		box-sizing: border-box;
		display: inline-block;
		margin: 0;
		position: relative;
		vertical-align: middle;
		width: 100% !important;
		}
	</style>

	</div>
	<div style="background-color:#feffbc; padding:0px; display:none;" id="loadsaverestaurant" ></div>
	<div style="background-color:#f7f7f7; " id="loadrestaurantsearch" ></div>
	<script>
		// restaurant BOX
		loadsearchrestaurantfunction();
		function loadsearchrestaurantfunction(){ 
			var destinationId =$('#destinationId2').val(); 
			var destWise =$('#destWise2').val(); 
			var restaurantName =  $('#restaurantName2').val(); 
			$('#loadrestaurantsearch').load('loadrestaurantsearch.php?restaurantName='+encodeURI(restaurantName)+'&destinationId='+destinationId+'&destWise='+destWise+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		}

		function addrestauranttoquotations(restaurantId,dmcId,tableN,cityId){
			if(restaurantId!='' && cityId!=''){
				$('#loadsaverestaurant').load('loadsaverestaurants.php?action=addedit_QuotationRestaurant&add=yes&restaurantId='+restaurantId+'&dmcId='+dmcId+'&tableN='+tableN+'&cityId='+cityId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
				selectthis('#selectthis'+dmcId);
			}else{
				alert('All fields are required.');
			}
		} 

	</script>
	<?php
}

// Additional Requirements block starts
if($_REQUEST['action'] == 'addServiceAdditional' && $_REQUEST['dayId']!=''){

	$dayId = $_REQUEST['dayId'];
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];

	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	?>
		
	<div class="inboundheader" > Additional  <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #ffffff; cursor:pointer; " onClick="closeinbound();"></i></div>
	<div class="addeditpagebox addtopaboxlist"style=" padding:0px;">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice3">
				<table width="100%" border="0" cellpadding="8" cellspacing="10" style="margin-top: 20px;">
					<tr>
						<!-- new added fields	 -->
						<td align="left" style="padding: 0px; width: 23%;">
						<div class="griddiv"><label>
						<div class="gridlable">Destinations<span class="redmind"></span></div>
					<select id="destWise" name="destWise"  class="gridfield validate" displayname="Destination" autocomplete="off" onChange="getdestWise();" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 3px;">
								<option value="1">Selected Destination</option>
								<option value="2">All Destination</option>
					</select>
						</label>
						<script>
						function getdestWise(){
								if($('#destWise').val()==2){
									$('#destinationId').load('loadadditionaldestination.php?action=allDestination&dayId=<?php echo $_REQUEST['dayId']; ?>');
								}

								if($('#destWise').val()==1){
									$('#destinationId').load('loadadditionaldestination.php?action=selectedDestination&dayId=<?php echo $_REQUEST['dayId']; ?>');
								}

							}
					  </script>

							</div>
						</td>
						<!-- new added destination -->
						
						<td align="left" style="padding: 0px; width: 23%;">
						<div class="griddiv"><label>
							<div class="gridlable">Destination Name<span class="redmind"></span></div>
							<select id="destinationId" name="destinationId" class="gridfield validate select2" displayname="Select Destination" autocomplete="off"   >
								
					<?php
					
					$day=1;
					$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  and cityId="'.$cityId.'"  group by cityId order by id asc');
					while($QueryDaysData=mysqli_fetch_array($a)){
						
					?>
					<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($_REQUEST['dayId']==$QueryDaysData['id']){ ?> selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
					<?php
					$day++;
					} ?>
					</select>
							</label>
							</div>
						</td>
					<td >
					<div class="griddiv" style="position:static;">
						<label>
							<div class="gridlable">Additional Name</div>
						<input type="text" id="additionalName" name="additionalName" class="gridfield" displayname="Additional Name">
						</label>
						</div>
					</td>
						<td style=" width:11%;">
						<button class="bluembutton" type="button" onclick="SearchAdditionRequirement('<?php echo $dayId; ?>','<?php echo $cityId; ?>','<?php echo $dayData['quotationId']; ?>','<?php echo $dayData['queryId']; ?>');">Search</button>
					</td>

					<td align="left" style="padding: 0px; width: 35%; display:none;">
						<div class="griddiv" style="position:static;">
						<label>
							<div class="gridlable">Additional</div>
							<select id="additionalId2" name="additionalId2" class="gridfield validate" displayname="Additional Name" onchange="getAdditionalCost(this.value)" autocomplete="off" >
							<option value="0">Select </option>
								<?php
								$select='';
								$where='';
								$rs='';
								$select='*';
						
								$wheres=' deletestatus=0 and status=1 order by name asc';
								$rs=GetPageRecord($select,_EXTRA_QUOTATION_MASTER_,$wheres);
								while($resListings=mysqli_fetch_array($rs)){
								?>
								<option value="<?php echo strip($resListings['id']); ?>"><?php echo strip($resListings['name']); ?></option>
								<?php } ?>
							</select>
							<select id="startDay" name="startDay" class="gridfield validate" displayname="Start Day" autocomplete="off" style="display:none;" >
									<?php
									$day=1;
									$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
									while($QueryDaysData=mysqli_fetch_array($a)){
									if($dayData['cityId']==$QueryDaysData['cityId']){
									?>
									<option value="<?php echo strip($QueryDaysData['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData['srdate'])); ?>,<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['srdate']==$QueryDaysData['srdate']){ ?>  selected="selected" <?php } ?>>Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
									<?php
									}
									$day++;
									} ?>
						  </select>
						</label>
						</div>					
					</td>
					<td align="left" style="padding: 0px; display:none;">
						<div class="griddiv" style="position:static;">
							<label>
								<div class="gridlable">Cost Type</div>
								<select id="additionalcostType" name="additionalcostType" class="gridfield validate" onchange="selectcost();">
									<option value="1">Per Person</option>
									<option value="2">Total Cost</option>
							 	</select>
							</label>
						</div>					
					</td>
					
					</tr>
					<tr>
					<td align="left" style="padding: 0px; display:none;">
						<div class="griddiv" style="position:static;">
							<label>
								<div class="gridlable">Currency</div>
								<input type="text" id="additionalCurrency" class="gridfield" name="additionalCurrency" value="">
								
							</label>
						</div>					
					</td>

					<td align="left" style="padding: 0px; display:none;">
						<div class="griddiv" style="position:static;">
							<label>
								<div class="gridlable"> Per&nbsp;Pax&nbsp;Cost </div>
								<input name="adultCost" type="text" class="gridfield number_only " id="additionalAdultCost" displayname="Per Pax Cost" value="" />
							</label>
						</div>					
					</td>
					<td align="left"  style="display: none;">
						<div class="griddiv" style="position:static;">
							<label>
								<div class="gridlable">Child Cost </div>
								<input name="childCost" type="text" class="gridfield number_only " id="additionalchildCost" displayname="Per Pax Cost" value="" />
							</label>
						</div>					
					</td>
				 
					<td align="left" class="tot" style="padding: 0px; display:none;">
						<div class="griddiv" style="position:static;">
							<label>
								<div class="gridlable">Group&nbsp;Cost </div>
								<input name="groupCost" type="text" class="gridfield number_only " id="additionalGroupCost" displayname="Group Cost" value="" />
							</label>
						</div>					
					</td>
				
					<td colspan="5" style="background-color: #f7f7f7;">
					<span id="numrowsfound" style="font-size: 16px; font-weight: 500;background-color: #f7f7f7;line-height: 3;"></span>
						<div class="addBtn addBtn2222" onclick="openinboundpop('action=addadditionaltomaster&dayId=<?php echo $_REQUEST['dayId']; ?>&quotationId=<?php echo $quotationData['id']; ?>&queryId=<?php echo $queryData['id']; ?>&destinationId=<?php echo $dayData['cityId']; ?>&d=<?php echo $startdatevar; ?>','400px');"> + Add New </div>
				
					</td>
					</tr>
					
					<!-- <td width="79" valign="top" style="padding-left:0px;">
						<input name="queryId" type="hidden" id="queryId" value="<?php echo $queryData['id']; ?>">
						<input name="quotationId" type="hidden" id="quotationId" value="<?php echo  $quotationData['id']; ?>">
						<input type="button" name="Submit" value=" + Add New "class="bluembutton"  style="margin-top:20px;" onclick="openinboundpop('action=addadditionaltomaster&dayId=<?php echo $_REQUEST['dayId']; ?>&quotationId=<?php echo $quotationData['id']; ?>&queryId=<?php echo $queryData['id']; ?>&destinationId=<?php echo $dayData['cityId']; ?>&d=<?php echo $startdatevar; ?>','400px');"></td> -->
						
					
				</table>
			</form>
		</div>

		<script src="plugins/select2/select2.full.min.js"></script>
		<script>
		$(document).ready(function() {
		$('.select2').select2();
		});
		</script>
		<style>

			
			.addBtn2222{
				padding: 8px 12px !important;
				background-color: #7a96ff;
				color: #fff!important;
				font-weight: 500;
				float: right;
			}
		.select2-container--open{
			z-index: 9999999999 !important;
			width: 100%;
		}

		.select2-container {
			box-sizing: border-box;
			display: inline-block;
			margin: 0;
			position: relative;
			vertical-align: middle;
			width: 100% !important;
		}
		.select2-selection--single{
			height: 33px !important;
    		margin-top: 5px !important;
		}
		.select2-selection--single .select2-selection__arrow {
		    height: 26px;
		    position: absolute;
		    top: 6px !important;
		}
		.select2-container--default .select2-selection--single .select2-selection__rendered{
			line-height: 30px;
		}
		.searchAdd{
			color: #ffffff;
			font-size: 17px;
			font-weight: 500;
			padding: 6px 17px;
			margin-top: 10px;
			border-radius: 3px;
			cursor: pointer;
			background-color: #333333!important;
    		border: 1px solid #7a96ff!important;
    		border-bottom: 2px solid #fdbd0e!important;
		}
		.addBtn1{
			width: fit-content !important;
			/* position: absolute; */
			right: 30px;
			top: 2px;
			padding: 8px 12px !important;
			background-color: #7a96ff;
			color: #fff;
			border-color:  #7a96ff;
			cursor: pointer;
		} 

		#inboundpopbg .inboundpop{
			padding:10px 10px 40px 10px !important; 
			margin-bottom: 40px !important;
			/* padding: 10px !important; */
		}
		#inboundpopbg .inboundheader{
			position: relative;
			background-color: #233a49 !important;
			padding: 10px !important;
			color: #fff !important;
			font-weight: 600 !important;
			border-radius: 4px !important;
			font-size: 15px !important;
			text-transform: uppercase;
			overflow: hidden;
			border-bottom: 1px solid #ddd !important;
		}

		</style>
		<div id="loadadditionalsearch" style="display:noane; max-height: 270px; margin: 0px 9px; overflow: auto; background: #f7f7f7;">
		</div>
		<div id="loadmealplanboxgetMealCost" style="display:none;"></div>
		<div style="background-color:#feffbc; padding:0px; display:none;" id="loadmealplanbox"></div>
		<script>
			function selectcost(){ 
				var costType = $('#additionalcostType').val();
				if(costType==1){
					$('.pp').show();
					$('.tot').hide();
					$('#additionalGroupCost').val('');
				}
				if(costType==2){
					$('.pp').hide();
					$('.tot').show();
					$('#additionalAdultCost').val('');
				}
			} 

			selectcost();

			function SearchAdditionRequirement(dayId,cityId,quotationId,queryId){
					var destWise = $("#destWise").val();
					var destinationId = $("#destinationId").val();
					var additionalId2 = $("#additionalId2").val();
					var additionalcostType = $("#additionalcostType").val();
					var additionalAdultCost = $("#additionalAdultCost").val();
					var startDay = $("#startDay").val();
					var additionalName = $("#additionalName").val();

					$("#loadadditionalsearch").load('loadadditionalsearch.php?&destWise='+destWise+'&destinationId='+destinationId+'&additionalId2='+additionalId2+'&additionalcostType='+additionalcostType+'&additionalAdultCost='+additionalAdultCost+'&startDay='+startDay+'&additionalName='+encodeURI(additionalName)+'&cityId=<?php echo $cityId ?>&queryId=<?php echo $queryData['id'] ?>&quotationId=<?php echo $quotationData['id'] ?>&dayId=<?php echo $_REQUEST['dayId']; ?>');
			}

				if(destinationId!=''){
			SearchAdditionRequirement();
				}
		

			// function getAdditionalCost(additionalId){
			// 	//var additionalId = $('#additionalId').val();
			// 	$('#loadmealplanbox').load('loadsaveextra.php?action=loadAdditionalCost&additionalId='+additionalId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
			// }


			// MEALPLAN BOX
			function addadditionaltoquotations(additionalId,currencyId,quotationId,queryId,dayId,startDay,tableN){
				var startDay = $('#startDay').val();

					$('#loadmealplanbox').load('loadsaveextra.php?action=addedit_QuotationExtra&queryId='+queryId+'&add=yes&additionalId='+additionalId+'&startDay='+encodeURI(startDay)+'&quotationId='+quotationId+'&currencyId='+currencyId+'&dayId='+dayId+'&startDay='+startDay+'&tableN='+tableN);
				
				}
				function selectthis(ele){
								$(ele).html('Selected');
								$(ele).removeAttr('onclick');
								$(ele).css('background-color','#d88319');
							}

			<?php if($_REQUEST['additionalId'] = ''){ ?>
			getAdditionalCost();
			<?php } ?>

		</script>
	<?php
}
// Additional Requirements Block ends


// sdfsdf
if($_REQUEST['action'] == 'addServiceEnroute' && $_REQUEST['dayId']!=''){

 	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	$enrouteId = 0;
	if($_REQUEST['enrouteId'] != '' && $_REQUEST['enrouteId'] != 0 ){
		$enrouteId = $_REQUEST['enrouteId'];
	}
	?>

 	<div class="inboundheader" > Add Enroute <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i></div>

		<div class="addeditpagebox addtopaboxlist" style="display:nones;padding:10px">
			<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice">
 			<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable">
				<tbody>
					<tr style="background-color:transparent !important;">
					<td width="24%" align="left"><div class="griddiv" style="position:static;">
						<label> <div>&nbsp;</div>
							<select id="destWise" name="destWise" class="gridfield validate" onChange="getdestWise();" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" >
							<option value="1">Selected Destination</option>
							<option value="2">All Destinations</option>
							</select>
						</label>
						<script>
					  function getdestWise(){
						if($('#destWise').val()==2){
							$('#destinationId').load('loadAllDestinations.php');
						}

						if($('#destWise').val()==1){
							$('#destinationId').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
						}

					  }
					  </script>
			    </div></td>
					<td width="21%" align="left"> 
					<!-- select destination -->
					<div class="griddiv" style="position:static;">
					<label>
					<div>Destination</div>
					<select id="destinationId" name="destinationId" class="gridfield validate select2" displayname="Select Destination" autocomplete="off"   >
					<?php 
					$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0   and cityId = "'.$dayData['cityId'].'"  group by cityId  order by id asc');
					while($QueryDaysData=mysqli_fetch_array($a)){
					?>
					<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
					<?php 
					} ?>
					</select>
					</label>
					</div>
					</td>
					 <td width="21%" align="left"><div class="griddiv" style="position:static;">
						<label> <div>&nbsp;</div>
							<select id="defaultWise" name="defaultWise" class="gridfield validate" autocomplete="off" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" >
							<option value="1">Default Enroute</option>
							<option value="2">All Enroute</option>
							</select>
						</label>
			    </div></td>
					<td width="8%" align="left" valign="middle">
						<input name="enrouteId" type="hidden" id="enrouteId" value="<?php echo $enrouteId; ?>">
						<input name="queryId" type="hidden" id="queryId" value="<?php echo $queryData['id']; ?>">
						<input name="quotationId" type="hidden" id="quotationId" value="<?php echo  $quotationData['id']; ?>">
						<input type="button" name="Submit" value="   Search   " class="bluembutton"  style="margin-top:20px;" onclick="loadsearchenroutefunction();"></td>
					</tr>
				</tbody>
			</table>
			</form>
			<script src="plugins/select2/select2.full.min.js"></script>
			<script>
			$(document).ready(function() {
			$('.select2').select2();
			});
			</script>
			<style>
			.select2-container--open{
			z-index: 9999999999 !important;
			width: 100%;
			}

			.select2-container {
			box-sizing: border-box;
			display: inline-block;
			margin: 0;
			position: relative;
			vertical-align: middle;
			width: 100% !important;
			}
			</style>
		</div>
		<div style="background-color:#f7f7f7; padding:10px;" id="loadenroutesearch" ></div>
		<script>
			// ENROUTE BOX
			loadsearchenroutefunction();
			function loadsearchenroutefunction(){
				var dayId = '<?php echo $dayData['id']; ?>';
				var queryId =$('#queryId').val();
				var defaultWise =$('#defaultWise').val();
				var destinationId =$('#destinationId').val();
				var quotationId =$('#quotationId').val();
				$('#loadenroutesearch').load('loadenroutesearch.php?dayId='+dayId+'&destinationId='+destinationId+'&defaultWise='+defaultWise);
			}

			function addenroutetoquotations(enrouteId,destinationId){
				var dayId = '<?php echo $dayData['id']; ?>';
				if(enrouteId > 0 && destinationId > 0){
					$('#loadenroutesaveenroute').load('loadsaveenroute.php?add=yes&enrouteId='+enrouteId+'&dayId='+dayId+'&destinationId='+destinationId);
				selectthis('#selectthis'+enrouteId);
				}else{
					alert('All fields are required.');
				}
			}
			function selectthis(ele){
				$(ele).html('Selected');
				$(ele).removeAttr('onclick');
				$(ele).css('background-color','#d88319');
			}

		</script>
	<?php

}

if($_REQUEST['action'] == 'addServiceGuide' && $_REQUEST['dayId']!=''){

 	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	$cityId = $dayData['cityId'];
	//quotation data
	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,'id ="'.$dayData['quotationId'].'"');
	$quotationData=mysqli_fetch_array($quotQuery);
	
	$pax = $quotationData['adult']+$quotationData['child'];
	//Query data
	$queQuery=GetPageRecord('*',_QUERY_MASTER_,'id ="'.$dayData['queryId'].'"');
	$queryData=mysqli_fetch_array($queQuery);

	$guideId = 0;
	if($_REQUEST['guideId'] != '' && $_REQUEST['guideId'] != 0 ){
		$guideId = $_REQUEST['guideId'];
	}
	?>
	<div class="inboundheader" style="position:relative;">
 		<?php 
 		$isSupplement = $isGuestType = $guideQuoteId = 0;
 		if($_REQUEST['guideQuoteId']>0 && $_REQUEST['stype'] == 'guideSupplement'){
 			$headingName = 'Supplement Tour Escort';
 			$isSupplement = 1;
 			$guideQuoteId = $_REQUEST['guideQuoteId'];
 		}else{
 			// $headingName = 'Guide';
 			$headingName = 'Tour Escort';
 			$isGuestType = 1;
 		} 
 		echo $headingName; if($queryData['dayWise']==1){ echo "&nbsp;|&nbsp;".date('D j M Y', strtotime($dayData['srdate'])); }  ?><i class="fa fa-times" aria-hidden="true" style="position: absolute;top: 5px; right: 10px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;
	</div>
	<div class="addeditpageboxs addtopaboxlist" style="display:nones;position:relative;padding: 10px!important;">
		<form action="frm_action.crm" method="post" enctype="multipart/form-data" name="addhotelroomprice" target="actoinfrm" id="addhotelroomprice" style="width: 100% !important;">
		<table width="100%" border="0" cellpadding="3" cellspacing="0" class="tablesorter ">
		  <tbody>
		  <tr style="background-color:transparent !important;">
		  	<td width="20%" align="left" style="display:nonse;">
				<input type="hidden" id="guideQuoteId3" value="<?php echo $guideQuoteId; ?>">
				<input type="hidden" id="isSupplement3" value="<?php echo $isSupplement; ?>">
				<input type="hidden" id="isGuestType3" value="<?php echo $isGuestType; ?>">
				<!-- hiddend fields -->
				<span>Service&nbsp;Type</span> <br>
				<select id="serviceType3" name="serviceType3" class="gridfield guideselect" displayname="Service Type" onChange="showPaxRange(this.value,'showPaxRange_div');" autocomplete="off" >
				<option value="0"><?php echo $headingName; ?> </option>
				<!-- <option value="1">Porter </option> -->
				</select>
			</td>
			<script>
			function showPaxRange(val,id){
				if(val == 1){
					$('#'+id).hide();
				}else{
					$('#'+id).show()
				}
			}
			</script>
			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label> <div>Destination Type</div>
						<select id="destWise3" name="destWise3" class="gridfield validate" onChange="getdestWise();"  >
						<option value="2">All Destinations</option>
						<option value="1">Selected Destination</option>
						</select>
					</label>
					<script>
					  function getdestWise(){
						if($('#destWise3').val()==2){
							$('#destinationId3').load('loadAllDestinations.php');
						}

						if($('#destWise3').val()==1){
							$('#destinationId3').load('loadAllDestinations.php?dayId=<?php echo $_REQUEST['dayId']; ?>');
						}
						$('#select2-destinationId3-container').text('Select');

					  }
					  </script>
			    </div>
			</td>
			<td width="20%" align="left">
				<div class="griddiv" style="position:static;">
					<label>
						<div>Destination</div>
						<select id="destinationId3" name="destinationId3" class="gridfield validate select2" displayname="Select Destination" autocomplete="off" >
							<?php
							$day=1;
							$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'" and cityId="'.$cityId.'"  and addstatus=0  group by cityId order by id asc');
							while($QueryDaysData=mysqli_fetch_array($a)){
							?>
							<option value="<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['dayId']==$QueryDaysData['id']){ ?>  selected="selected" <?php } ?>><?php echo getDestination($QueryDaysData['cityId']);?></option>
							<?php
							$day++;
							} ?>
						</select>
						<script src="plugins/select2/select2.full.min.js"></script>
						<script>
						$(document).ready(function() {
							$('.select2').select2();
						});
						</script>
						<style>
						 	.select2-selection--single {
								display: inline-block !important;
								outline: 0px;
								padding-bottom: 0px;
								width: 100%;
								background-color: #FFFFFF !important;
								font-size: 14px;
								border: 1px #e0e0e0 solid !important;
								box-sizing: border-box !important;
								height: auto !important;
								padding: 2px;
								margin-top: 4px;
								border-radius: 2px !important;
							}
							.select2-container--default .select2-selection--single .select2-selection__arrow {
								top: 9px !important;
							}
							.select2-container--open{
								z-index: 9999999999 !important;
								width: 100%;
							}

							.select2-container {
								box-sizing: border-box;
								display: inline-block;
								margin: 0;
								position: relative;
								vertical-align: middle;
								width: 100% !important;
							}
						  </style>
					</label>
				</div>
			</td>
			<td width="12%" align="left" id="showPaxRange_div">
				<span>Pax&nbsp;Range</span> <br>
				<select id="paxRange3" name="paxRange3" class="gridfield guideselect" autocomplete="off"  >
					<option value="0" >All Pax</option>
					<option value="1_5" <?php if($pax >= 1 && $pax <= 5){ ?>selected="selected"<?php } ?>>1-5 Pax</option>
					<option value="6_14" <?php if($pax >= 6 && $pax <= 14){ ?>selected="selected"<?php } ?>>6-14 Pax</option>
					<option value="15_40" <?php if($pax >= 15 && $pax <= 40){ ?>selected="selected"<?php } ?>>15-40 Pax</option>
				</select>
			</td>
			<td width="15%" align="left">
				<span>&nbsp;</span> <br>
				<select id="defaultWise3" name="defaultWise3" class="gridfield" autocomplete="off"  >
					<option value="2">All Tour Escort</option>
						<option value="1" >Default Tour Escort</option>
				</select>
			</td>
		    <td width="17%" align="left">
				<span>From&nbsp;Day</span> <br>
				<select id="startDayId3" name="startDayId3" class="gridfield validate" displayname="Start Day" autocomplete="off" style="display:none1; padding: 5px 5px; border-radius: 3px;" >
				<?php
				$day=1;
				$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
				while($QueryDaysData=mysqli_fetch_array($a)){
				//if($dayData['cityId']==$QueryDaysData['cityId']){
				?>
				<option value="<?php echo strip($QueryDaysData['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData['srdate'])); ?>,<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['srdate']==$QueryDaysData['srdate']){ ?>  selected="selected" <?php } ?>>Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
				<?php
				//}
				$day++;
				} ?>
				</select></td>
		    <td width="17%" align="left">
				<span>To&nbsp;Day</span> <br>
				<select id="endDayId3" name="endDayId3" class="gridfield validate" displayname="Start Day" autocomplete="off" style="display:none1; padding: 5px 5px; border-radius: 3px;" >
				<?php
				$day=1;
				$a=GetPageRecord('*','newQuotationDays',' quotationId="'.$quotationData['id'].'"  and addstatus=0  order by id asc');
				while($QueryDaysData=mysqli_fetch_array($a)){
				//if($dayData['cityId']==$QueryDaysData['cityId']){
				?>
				<option value="<?php echo strip($QueryDaysData['id']); ?>,<?php echo date('Y-m-d', strtotime($QueryDaysData['srdate'])); ?>,<?php echo strip($QueryDaysData['cityId']); ?>"  <?php if($dayData['srdate']==$QueryDaysData['srdate']){ ?>  selected="selected" <?php } ?>>Day <?php echo $day; ?> - <?php echo getDestination($QueryDaysData['cityId']);?></option>
				<?php
				//}
				$day++;
				} ?>
				</select> </td>

			<td width="8%" align="left" valign="middle">
				<br>
				<input name="guideId3" type="hidden" id="guideId3" value="<?php echo $guideId; ?>">
				<input name="queryId3" type="hidden" id="queryId3" value="<?php echo $queryData['id']; ?>">
				<input name="quotationId3" type="hidden" id="quotationId3" value="<?php echo  $quotationData['id']; ?>">
			    <input type="button" name="Submit" value="   Search   " class="bluembutton"  style="padding: 4px 1px !important; margin: 0; border-radius: 3px;" onclick="loadsearchguidefunction();"></td>
			</tr>
	</tbody></table>
		</form>
	</div>
	<div style="background-color:#feffbc; padding:0px; display:none;" id="loadguidesaveguide" ></div>
	<div style="background-color:#f7f7f7; padding:10px;" id="loadguidesearch" ></div>
	<script>
		// guide BOX
		loadsearchguidefunction();
		function loadsearchguidefunction(){
			var isGuestType =$('#isGuestType3').val();
			var isSupplement =$('#isSupplement3').val();
			var guideQuoteId =$('#guideQuoteId3').val();
			
			var startDayId =$('#startDayId3').val();
			var endDayId =$('#endDayId3').val();
			var queryId =$('#queryId3').val();
			var defaultWise =$('#defaultWise3').val();

			var destinationId =$('#destinationId3').val();
			var destWise =$('#destWise3').val();

			var dayId = <?php echo ($_REQUEST['dayId']>0)?$_REQUEST['dayId']:0; ?>;

			var serviceType =$('#serviceType3').val();
			var paxRange =$('#paxRange3').val();
			var quotationId =$('#quotationId3').val();
			$('#loadguidesearch').load('loadguidesearch.php?startDayId='+startDayId+'&endDayId='+endDayId+'&serviceType='+serviceType+'&paxRange='+paxRange+'&defaultWise='+defaultWise+'&isGuestType='+isGuestType+'&isSupplement='+isSupplement+'&guideQuoteId='+guideQuoteId+'&destinationId='+destinationId+'&destWise='+destWise+'&dayId='+dayId+'&quotationId='+quotationId);
		}

		function addguidetoquotations(tariffId,dayId,destinationId,totalDays,tableN){
			var quotationId =$('#quotationId3').val();
			var isGuestType =$('#isGuestType3').val();
			var isSupplement =$('#isSupplement3').val();
			var guideQuoteId =$('#guideQuoteId3').val();
			var slabId =$('#slabId3'+tariffId).val();
			if(tariffId>0 && dayId>0){
				$('#loadguidesaveguide').load('loadsaveguide.php?add=yes&tariffId='+tariffId+'&serviceid='+tariffId+'&quotationId='+quotationId+'&slabId='+slabId+'&isGuestType='+isGuestType+'&isSupplement='+isSupplement+'&guideQuoteId='+guideQuoteId+'&destinationId='+destinationId+'&dayId='+dayId+'&tableN='+tableN+'&totalDays='+totalDays);
			}else{
				alert('All fields are required.');
			}
		}
		function selectthisE(ele,tblN){
			$('#selectBtnE'+ele+tblN).html('&nbsp;Selected');
			$('#selectBtnE'+ele+tblN).removeAttr('onclick');
			$('#selectBtnE'+ele+tblN).css('background-color','#d88319');
		}
	</script>
	<?php
} 
// end of the add service to quotations

// start add to master alert action and frmaction
if($_REQUEST['action'] == 'addhoteltomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	if ($_GET['id'] != '') {

			$id = clean($_GET['id']);

			$select1 = '*';

			$where1 = 'id=' . $id . '';

			$rs1 = GetPageRecord($select1, _PACKAGE_BUILDER_HOTEL_MASTER_, $where1);
			$editresult = mysqli_fetch_array($rs1);


			$rs1 = '';

			$rs1 = GetPageRecord('*', _ADDRESS_MASTER_, ' addressParent="' . $editresult['id'] . '" and addressType="hotel"');

			$addressData = mysqli_fetch_array($rs1);
		}

	?>

	<div class="contentclass" style="overflow:auto;">

		<h1 style="text-align:left;"><?php if ($_REQUEST['id'] != '') {
			echo 'Edit';
		} else {
			echo 'Add';
		} ?> Hotel</h1>

		<div id="contentbox" class="addeditpagebox" style="  padding:16px; overflow:scroll; text-align:left; margin-bottom:0px; height: 470px;">

			<form action="inboundpop.php" method="post" enctype="multipart/form-data" name="addmasters" target="actoinfrm" id="addmasters">



				<div style="display: inline-block;width: 47%;">

					<div class="griddiv"><label>

							<div class="gridlable">Hotel&nbsp;Chain</div>
							<select id="hotelChain" name="hotelChain" class="gridfield " displayname="Hotel Chain">
								<option value="">Select</option>
								<?php
								$rs = GetPageRecord('*', 'chainhotelmaster', ' 1 and status=1 order by name asc');
								while ($resListing = mysqli_fetch_array($rs)) {
								?>
									<option value="<?php echo ($resListing['id']); ?>" <?php if ($resListing['id'] == $editresult['hotelChain']) { ?>selected="selected" <?php } ?>><?php echo ($resListing['name']); ?></option>
								<?php } ?>
							</select>

						</label>

					</div>

					<div class="griddiv"><label>

							<div class="gridlable"> Hotel &nbsp;Name<span class="redmind"></span></div>

							<input name="hotelName" type="text" class="gridfield validate" id="hotelName1" displayname="Hotel Name" value="<?php echo stripslashes($editresult['hotelName']); ?>" />

						</label>

					</div>

					<div class="griddiv"><label>
							<div class="gridlable">Destination<span class="redmind"></span></div>
							<select id="hotelCity" name="hotelCity" class="gridfield validate" displayname="Destination" autocomplete="off">
								<option value="">Select</option>
								<?php
								$select = '';
								$where = '';
								$rs = '';
								$select = '*';
								$where = ' 1 and deletestatus = 0 order by name asc';
								$rs = GetPageRecord($select, _DESTINATION_MASTER_, $where);
								while ($resListing = mysqli_fetch_array($rs)) {
								?>
									<option value="<?php echo ($resListing['name']); ?>" <?php if ($resListing['name'] == $editresult['hotelCity']) { ?>selected="selected" <?php } ?>><?php echo ($resListing['name']); ?></option>

								<?php } ?>
							</select>
						</label>
					</div>

					<div class="griddiv"><label>
							<div class="gridlable">Hotel&nbsp;Category</div>
							<select id="hotelCategoryId" name="hotelCategoryId" class="gridfield " autocomplete="off" displayname="Hotel Category">
								<?php
								$rs3 = '';
								$rs3 = GetPageRecord('*', 'hotelCategoryMaster', ' 1 and deletestatus=0 and status=1 order by hotelCategory asc');
								while ($hotelCategoryData = mysqli_fetch_array($rs3)) {
								?>
									<option value="<?php echo $hotelCategoryData['id']; ?>" <?php if ($hotelCategoryData['id'] == $editresult['hotelCategoryId']) { ?>selected="selected" <?php } ?>><?php echo $hotelCategoryData['hotelCategory'] . " Star"; ?></option>
								<?php
								}
								?>
							</select>
						</label>
					</div>

					<div class="griddiv"><label>
							<div class="gridlable">Hotel&nbsp;Type</div>
							<select id="hotelTypeId" name="hotelTypeId" class="gridfield " autocomplete="off" displayname="Hotel Category">
								<?php
								$rs3 = '';
								$rs3 = GetPageRecord('*', 'hotelTypeMaster', ' 1 and deletestatus=0 and status=1 order by name asc');
								while ($hotelTypeData = mysqli_fetch_array($rs3)) {
								?>
									<option value="<?php echo $hotelTypeData['id']; ?>" <?php if ($hotelTypeData['id'] == $editresult['hotelTypeId']) { ?>selected="selected" <?php } ?>><?php echo $hotelTypeData['name']; ?></option>
								<?php
								}
								?>
							</select>



						</label>

					</div>

					<div class="griddiv" style="display:none;"><label>

							<div class="gridlable">Photo Upload</div>

							<input name="hotelImage" type="file" class="gridfield" id="hotelImage" />

							<input type="hidden" name="oldhotleImage" id="oldhotleImage" value="<?php echo $editresult['hotelImage']; ?>" />

						</label>

					</div>

					<div class="griddiv"><label>

							<div class="gridlable">Hotel Link</div>

							<input name="url" type="text" class="gridfield" id="url" value="<?php echo $editresult['url']; ?>" />

						</label>

					</div>

					<div class="griddiv"><label>

							<div class="gridlable">Weekend Days<span class="redmind"></span></div>

							<select id="weekend" name="weekend" class="gridfield " autocomplete="off" displayname="Weekend Days" onchange="allweekend(this)" onclick="allweekend(this)">

								<?php
								$select1 = '*';
								$where1 = ' 1 and deletestatus=0 and status=1';
								$rs1 = GetPageRecord($select1, _WEEKEND_MASTER_, $where1);
								while ($resListing11 = mysqli_fetch_array($rs1)) {

								?>

									<option value="<?php echo ($resListing11['id']); ?>" <?php if ($resListing11['id'] == $editresult['weekendDays']) { ?>selected="selected" <?php } ?>><?php echo ($resListing11['name']); ?></option>

								<?php } ?>

							</select>



						</label>

						<div id="loadweekend"><br>

							<div class="gridlable">Days<span class="redmind"></span></div>

							<div style="border:1px #e0e0e0 solid;margin-top:5px;background-color:#FFFFFF;padding:2px;overflow: auto;height: 29px;">

								<?php

								if ($editresult['weekendDays'] != '') { ?>

									<?php

									$select = '';

									$where = '';

									$rs = '';

									$select = '*';

									$where = ' name!="" and deletestatus=0 and id="' . $editresult['weekendDays'] . '" order by id desc';

									$rs = GetPageRecord($select, _WEEKEND_MASTER_, $where);

									$resListing = mysqli_fetch_array($rs);

									$weekendDays = explode(",", $resListing['weekendDays']);

									foreach ($weekendDays as $key => $value) {

										if ($value == 1) {

											$days = 'Monday';
										}

										if ($value == 2) {

											$days = 'Tuesday';
										}

										if ($value == 3) {

											$days = 'Wednesday';
										}

										if ($value == 4) {

											$days = 'Thursday';
										}

										if ($value == 5) {

											$days = 'Friday';
										}

										if ($value == 6) {

											$days = 'Saturday';
										}

										if ($value == 7) {

											$days = 'Sunday';
										}
									?><div style="padding:3px 10px; float:left; color:#FFFFFF; background-color:#2C8CB1; width:fit-content; margin:3px; border-radius:3px;"><?php echo  $days; ?></div>

									<?php } ?>

								<?php } ?>

							</div>

						</div>

					</div>
					<script type="text/javascript" src="js/jquery.timepicker.js"></script>
					<script type="text/javascript">
						$(document).ready(function() {
							$('.timepicker2').timepicker();
							$('.select2').select2();
						});
					</script>

					<!--only use for check in time-->
					<div class="griddiv" style=""><label>
						<div class="gridlable" style="width: 100%;">Check-In&nbsp;Time <span class="redmind"></span></div>
						<input type="text" id="checkInTime" name="checkInTime" value="<?php if ($editresult['checkInTime'] != '') {
							echo  date('H:i', strtotime($editresult['checkInTime']));
						} else {
							echo "12:00";
						}  ?>" class="gridfield  timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59" data-show-2400="true" />
						</label>

					</div>



				</div>

				<div style="display: inline-block; margin-left: 30px; width: 48%;">

					<div class="griddiv">

						<label>
							<div class="gridlable">Hotel Amenities</div>

							<select name="hotel_amenities[]" multiple="multiple" class="gridfield js-example-basic-multiple" id="hotel_amenitiesId" displayname="Hotel Amenities" autocomplete="off">

								<option value="">Select</option>

								<?php

								$select = '';

								$where = '';

								$rs = '';

								$select = '*';

								$where = ' 1 order by name asc';

								$rs = GetPageRecord($select, _AMENITIES_MASTER_, $where);

								while ($resListing = mysqli_fetch_array($rs)) {

									$hotelamenities = array_map('trim', explode(",", $editresult['amenities']));

								?>

									<option value="<?php echo strip($resListing['id']); ?>" <?php foreach ($hotelamenities as $key => $value) {
																								if ($resListing['id'] == $value) {
																									echo 'selected="selected"';
																								}
																							} ?>><?php echo strip($resListing['name']); ?></option>

								<?php } ?>

							</select>

						</label>

					</div>

					<div class="griddiv">

						<label>
							<div class="gridlable">Room Type</div>

							<select name="roomType[]" multiple="multiple" class="gridfield validate js-example-basic-multiple" id="roomtypeId" displayname="Room Type" autocomplete="off">

								<option value="">Select</option>

								<?php

								$select = '';

								$where = '';

								$rs = '';

								$select = '*';

								$where = ' name!="" and deletestatus=0 and status=1 order by name asc';

								$rs = GetPageRecord($select, _ROOM_TYPE_MASTER_, $where);

								while ($resListing = mysqli_fetch_array($rs)) {

									$roomTypeArrya = array_map('trim', explode(",", $editresult['roomType']));

								?>

									<option value="<?php echo strip($resListing['id']); ?>" <?php foreach ($roomTypeArrya as $key => $value) {
																								if ($resListing['id'] == $value) {
																									echo 'selected="selected"';
																								}
																							} ?>><?php echo strip($resListing['name']); ?></option>

								<?php } ?>

							</select>

						</label>

					</div>

					<div class="griddiv">


						<label>

							<div class="gridlable">Supplier</div>

							<select id="supplier" name="supplier" class="gridfield " autocomplete="off">
								<!--only use for supplier status-->
								<option value="1" <?php if ($editresult['supplier'] == 1) { ?> selected="selected" <?php } ?>>Yes</option>

								<option value="0" <?php if ($editresult['supplier'] == 0) { ?> selected="selected" <?php } ?>>No</option>

							</select>

						</label>

					</div>

					<table width="100%" border="0" cellspacing="0" cellpadding="1">

						<tr>

							<td width="50%">


								<div class="griddiv">

									<label>

										<div class="gridlable">Country<span class="redmind"></span></div>

										<select id="countryId2" name="countryId2" class="gridfield validate" displayname="Country" autocomplete="off" onchange="selectstate();">
											<option value="0">Select Country</option>
											<?php

											$rs = "";
											$DefaultCountry = 'India';
											$rs = GetPageRecord('*', _COUNTRY_MASTER_, ' deletestatus=0 and status=1 order by name asc');
											while ($countryData = mysqli_fetch_array($rs)) {
												if ($addressData['countryId'] != '') {
													$isDefaultCountry = $countryData['id'] == $addressData['countryId'];
												} else {
													$isDefaultCountry = $countryData['name'] === $DefaultCountry;
												}
											?>
												<option value="<?php echo strip($countryData['id']); ?>" <?php if ($countryData['id'] == $isDefaultCountry) { ?>selected="selected" <?php } ?>><?php echo strip($countryData['name']); ?></option>

											<?php } ?>

										</select>
									</label>

								</div>
							</td>

							<td>
								<div class="griddiv">

									<label>

										<div class="gridlable">State </div>

										<select id="stateId2" name="stateId2" class="gridfield" displayname="State" autocomplete="off" onchange="selectcity();">

											<?php

											$rs = "";

											$rs = GetPageRecord('*', _STATE_MASTER_, ' id="' . $addressData['stateId'] . '" order by name asc');

											while ($stateData = mysqli_fetch_array($rs)) {

											?>

												<option value="<?php echo strip($stateData['id']); ?>"><?php echo strip($stateData['name']); ?></option>

											<?php } ?>

										</select>
									</label>

								</div>
							</td>

						</tr>

						<tr>

							<td width="50%">
								<div class="griddiv">

									<label>

										<div class="gridlable">City </div>

										<select id="cityId2" name="cityId2" class="gridfield" displayname="City" autocomplete="off">

											<?php

											$rs = "";

											$rs = GetPageRecord('*', _STATE_MASTER_, ' id="' . $addressData['cityId'] . '" order by name asc');

											while ($cityData = mysqli_fetch_array($rs)) {

											?>

												<option value="<?php echo strip($cityData['id']); ?>"><?php echo strip($cityData['name']); ?></option>

											<?php } ?>

										</select>

									</label>

								</div>
							</td>

							<td>
								<div class="griddiv"><label>

										<div class="gridlable">Pin&nbsp;Code </div>

										<input name="pinCode" type="text" class="gridfield" id="pinCode" value="<?php echo $addressData['pinCode']; ?>" maxlength="15" />

									</label>

								</div>
							</td>

						</tr>

					</table>

					<div class="griddiv"><label>

							<div class="gridlable">Address</div>

							<input name="hotelAddress" type="text" class="gridfield" id="hotelAddress" value="<?php echo $editresult['hotelAddress']; ?>" />

						</label>

					</div>

					<div class="griddiv"><label>

							<div class="gridlable">GSTN</div>

							<input name="gstn" type="text" class="gridfield" id="gstn" value="<?php echo $editresult['gstn']; ?>" />

						</label>

					</div>

					<div class="griddiv">

						<div class="gridlable" style="width: 100%;">Hotel Status (Active/Inactive) <span class="redmind"></span></div>

						<label>
							<!--for status-->
							<select id="status" type="text" class="gridfield" name="status" displayname="Status" autocomplete="off" style="width: 100%;">

								<option value="1" <?php if ($editresult['status'] == '1') { ?>selected="selected" <?php } ?>>Active</option>

								<option value="0" <?php if ($editresult['status'] == '0') { ?>selected="selected" <?php } ?>>In Active</option>

							</select>

						</label>

					</div>



					<div class="griddiv" style="">

						<div class="gridlable" style="width: 100%;">Check-Out&nbsp;Time <span class="redmind"></span></div>

						<label>
							<!--for checkout time-->
							<input type="text" id="checkOutTime" name="checkOutTime" value="<?php if ($editresult['checkOutTime'] != '') { echo  date('H:i', strtotime($editresult['checkOutTime']));
							} else { echo "11:00"; } ?>" class="gridfield  timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="11:00" data-max-time="10:59" data-show-2400="true" />

						</label>

					</div>








				</div>

				<script>
					function selectcity() {

						var stateId = $('#stateId2').val();

						$('#cityId2').load('loadcity.php?id=' + stateId + '&selectId=<?php echo $addressData['cityId']; ?>');

					}

					function selectstate() {

						var countryId = $('#countryId2').val();

						$('#stateId2').load('loadstate.php?action=hotelstateselection&id=' + countryId + '&selectId=<?php echo $addressData['stateId']; ?>');

					}
					selectstate();
					<?php

					if ($_GET['id'] != '') {

					?>

						selectstate();

						selectcity();

					<?php } ?>
				</script>
	<div style="display: block;width: 100%;">
		<div class="griddiv">
			<table width="100%" border="0" cellspacing="2" cellpadding="0" id="contactpersonIdTable">
			<tr><td colspan="6">Contact Person<span class="redmind"></span>&nbsp;&nbsp;&nbsp;<span onclick="addMoreContactPerson()" class="ppbtn"> + Add More</span> </td></tr>
			<?php 
			$countCP = 1;
			$rs1 = '';
			$rs1 = GetPageRecord('*', 'hotelContactPersonMaster', ' corporateId="' . $editresult['id'] . '" order by primaryvalue asc');
			if(mysqli_num_rows($rs1)>0){
				while($suppCPData = mysqli_fetch_array($rs1)){ 
					?>
					<input type="hidden" name="contactPId<?php echo $countCP; ?>" id="contactPId<?php echo $countCP; ?>" value="<?php echo $suppCPData['id']; ?>">
					<tr id="contactPersonId<?php echo $countCP; ?>">
						<td width="70">
							<div class="griddiv">
								<label>
									<div class=""></div>
									<select id="division<?php echo $countCP; ?>" name="division<?php echo $countCP; ?>" class="gridfield" displayname="Division" autocomplete="off" placeholder="Division">
										<?php  
										$selectd='*';    
										$whered=' deletestatus=0 and status=1 order by name asc';  
										$rsd=GetPageRecord($selectd,_DIVISION_MASTER_,$whered); 
										while($resListingd=mysqli_fetch_array($rsd)){  
										?>
										<option value="<?php echo strip($resListingd['id']); ?>" <?php if ($suppCPData['division'] == $resListingd['id']) { ?> selected="selected" <?php } ?>><?php echo strip($resListingd['name']); ?></option>
										<?php } ?>
									</select>
								</label>
							</div>
						</td>
						<td width="70">
							<div class="griddiv"><label>
									<input name="contactPerson<?php echo $countCP; ?>" type="text" class="gridfield validate" id="contactPerson<?php echo $countCP; ?>" value="<?php echo $suppCPData['contactPerson']; ?>" displayname="Contact Person" maxlength="100" placeholder="Contact Person" >
								</label>
							</div>
						</td>
						<td width="70">
							<div class="griddiv"><label>
									<input name="designation<?php echo $countCP; ?>" type="text" class="gridfield validate" id="designation<?php echo $countCP; ?>" value="<?php echo $suppCPData['designation']; ?>" displayname="Designation" placeholder="Designation" >
								</label>
							</div>
						</td>
						<td width="40">
							<div class="griddiv"><label>
									<input name="countryCode<?php echo $countCP; ?>" type="text" class="gridfield validate" id="countryCode<?php echo $countCP; ?>" value="+91" displayname="Country Code" placeholder="+91" >
								</label>
							</div>
						</td>
						<td width="80">
							<div class="griddiv"><label>
									<input name="phone<?php echo $countCP; ?>" type="text" class="gridfield validate" id="phone<?php echo $countCP; ?>" value="<?php echo $suppCPData['phone']; ?>" displayname="Phone" placeholder="Phone" >
								</label>
							</div>
						</td>
						<td width="120">
							<div class="griddiv"><label>
									<input name="email<?php echo $countCP; ?>" type="email" class="gridfield validate " id="email<?php echo $countCP; ?>" value="<?php echo $suppCPData['email']; ?>" displayname="Email" placeholder="Email"  required />
								</label>
							</div>
						</td>
						<td width="25" align="center">
							<img src="images/deleteicon.png" onclick="removeContactPerson(<?php echo $countCP; ?>);" style="cursor:pointer;">'
						</td>
					</tr>
					<?php 
					$countCP++;
				} 
			}else{ ?>
				<tr id="contactPersonId<?php echo $countCP; ?>">
					<td width="70">
						<div class="griddiv">
							<label>
								<select id="division<?php echo $countCP; ?>" name="division<?php echo $countCP; ?>" class="gridfield" displayname="Division" autocomplete="off" placeholder="Division">
									<?php  
									$selectd='*';    
									$whered=' deletestatus=0 and status=1 order by name asc';  
									$rsd=GetPageRecord($selectd,_DIVISION_MASTER_,$whered); 
									while($resListingd=mysqli_fetch_array($rsd)){  
									?>
									<option value="<?php echo strip($resListingd['id']); ?>" <?php if ($suppCPData['division'] == $resListingd['id']) { ?> selected="selected" <?php } ?>><?php echo strip($resListingd['name']); ?></option>
									<?php } ?> 
								</select>
							</label>
						</div>
					</td>
					<td width="70">
						<div class="griddiv"><label>
								<input name="contactPerson<?php echo $countCP; ?>" type="text" class="gridfield validate" id="contactPerson<?php echo $countCP; ?>" value="<?php echo $suppCPData['contactPerson']; ?>" displayname="Contact Person" maxlength="100" placeholder="Contact Person" >
							</label>
						</div>
					</td>
					<td width="70">
						<div class="griddiv"><label>
								<input name="designation<?php echo $countCP; ?>" type="text" class="gridfield validate" id="designation<?php echo $countCP; ?>" value="<?php echo $suppCPData['designation']; ?>" displayname="Designation" placeholder="Designation" >
							</label>
						</div>
					</td>
					<td width="40">
						<div class="griddiv"><label>
								<input name="countryCode<?php echo $countCP; ?>" type="text" class="gridfield validate" id="countryCode<?php echo $countCP; ?>" value="+91" displayname="Country Code" placeholder="+91" >
							</label>
						</div>
					</td>
					<td width="80">
						<div class="griddiv"><label>
								<input name="phone<?php echo $countCP; ?>" type="text" class="gridfield validate" id="phone<?php echo $countCP; ?>" value="<?php echo $suppCPData['phone']; ?>" displayname="Phone" placeholder="Phone" >
							</label>
						</div>
					</td>
					<td width="120">
						<div class="griddiv"><label>
								<input name="email<?php echo $countCP; ?>" type="email" class="gridfield validate " id="email<?php echo $countCP; ?>" value="<?php echo $suppCPData['email']; ?>" displayname="Email" placeholder="Email"  required />
							</label>
						</div>
					</td>
				</tr>
			<?php $countCP++;
			} ?>
			</table>
			<input type="hidden" name="countCP" id="countCP" value="<?php echo $countCP; ?>">
			<script>
			function removeContactPerson(countCP) {
				$('#contactPersonId'+countCP).remove();
			}	
			function addMoreContactPerson() {
				var countCP = $('#countCP').val();
				$('#countCP').val(parseInt(countCP, 10)+1);
				$("#contactpersonIdTable").append('<tr id="contactPersonId'+countCP+'">'
						+'<td width="70">'
							+'<div class="griddiv mb2">'
								+'<label>'
									+'<select id="division'+countCP+'" name="division'+countCP+'" class="gridfield" displayname="Division" autocomplete="off" placeholder="Division">'
										<?php  
										$selectd='*';    
										$whered=' deletestatus=0 and status=1 order by name asc';  
										$rsd=GetPageRecord($selectd,_DIVISION_MASTER_,$whered); 
										while($resListingd=mysqli_fetch_array($rsd)){  
										?>
										+'<option value="<?php echo strip($resListingd['id']); ?>"><?php echo strip($resListingd['name']); ?></option>'
										<?php } ?>
									+'</select>'
								+'</label>'
							+'</div>'
						+'</td>'
						+'<td width="70">'
							+'<div class="griddiv mb2"><label>'
									+'<input name="contactPerson'+countCP+'" type="text" class="gridfield validate" id="contactPerson'+countCP+'" value="" displayname="Contact Person" maxlength="100" placeholder="Contact Person">'
								+'</label>'
							+'</div>'
						+'</td>'
						+'<td width="70">'
							+'<div class="griddiv mb2"><label>'
									+'<input name="designation'+countCP+'" type="text" class="gridfield validate" id="designation'+countCP+'" value="" displayname="Designation" placeholder="Designation">'
								+'</label>'
							+'</div>'
						+'</td>'
						+'<td width="40">'
							+'<div class="griddiv mb2"><label>'
									+'<input name="countryCode'+countCP+'" type="text" class="gridfield validate" id="countryCode'+countCP+'" value="+91" displayname="Country Code" placeholder="+91">'
								+'</label>'
							+'</div>'
						+'</td>'
						+'<td width="80">'
							+'<div class="griddiv mb2"><label>'
									+'<input name="phone'+countCP+'" type="text" class="gridfield validate" id="phone'+countCP+'" value="" displayname="Phone" placeholder="Phone">'
								+'</label>'
							+'</div>'
						+'</td>'
						+'<td width="120">'
							+'<div class="griddiv mb2"><label>'
									+'<input name="email'+countCP+'" type="email" class="gridfield validate " id="email'+countCP+'" value="" displayname="Email" placeholder="Email" required />'
								+'</label>'
							+'</div>'
						+'</td>'
						+'<td width="25" align="center">'
							+'<img src="images/deleteicon.png" onclick="removeContactPerson('+countCP+');" style="cursor:pointer;">'
						+'</td>'
					+'</tr>');
			}
			</script>
			<style type="text/css">
				.ppbtn {
				    background-color: #7a96ff;
				    padding: 1px 6px !important;
				    margin-left: 10px;
				    color: #FFFFFF!important;
				    font-size: 10px;
				    border: 1px #7a96ff solid;
				    cursor: pointer;
				}
				.mb2 {
				    margin-bottom: 2px!important;
				}
			</style>
		</div>
		<div class="griddiv"><label>
			<div class="gridlable">Hotel Information</div>
			<textarea name="hoteldetail" rows="2" class="gridfield" id="hoteldetail"><?php echo stripslashes(stripslashes($editresult['hoteldetail'])); ?></textarea>
			</label>
		</div>
		<div class="griddiv"><label>
			<div class="gridlable">Policy</div>
			<textarea name="hotelpolicy" rows="2" class="gridfield" id="hotelpolicy"><?php echo $editresult['policy']; ?></textarea>
			</label>
		</div>
		<div class="griddiv"><label>
			<div class="gridlable">T&C </div>
			<textarea name="hoteltermandcondition" rows="2" class="gridfield" id="hoteltermandcondition"><?php echo stripslashes($editresult['termAndCondition']); ?></textarea>
			</label>
		</div>
	</div>
	<input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
	<input name="action" type="hidden" id="action" value="add_hoteltomaster" />
	<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
	</form>
	</div>
		<div id="buttonsbox" style="text-align:center;">

			<table border="0" align="right" cellpadding="0" cellspacing="0">

				<tr>
					<td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Save " onclick="formValidation('addmasters','submitbtn','0');" /></td>

					<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="closeinbound();" /></td>

				</tr>

			</table>

		</div>
	</div>



	<!--<link href="css/main.css" rel="stylesheet" type="text/css" />

	-->
	<script type="text/javascript" src="plugins/select2/select2.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {

			$('.js-example-basic-multiple').select2();

			$('.js-example-basic-single').select2();

		});

		$(document).ready(function() {


			$("#checkallroomType").click(function() {

				if (this.checked) {

					$('.Checkedrmtype').each(function() {

						this.checked = true;

					})

				} else {

					$('.Checkedrmtype').each(function() {

						this.checked = false;

					})

				}

			});

			$("#checkallamnties").click(function() {

				if (this.checked) {

					$('.Checkedamen').each(function() {

						this.checked = true;

					})

				} else {

					$('.Checkedamen').each(function() {

						this.checked = false;

					})

				}

			});



		});

		function allweekend(e) {

			var weekendid = e.value;

			$("#loadweekend").load('loadWeekendDays.php?id=' + weekendid);

			$("#editweekend").hide();

		}
	</script>


	<style>
		.select2-container {

			width: 100% !important;
			;

		}

		.select2-container--open {

			z-index: 9999999999 !important;

		}
	</style>

	<?php
}

if(trim($_REQUEST['action'])=='add_hoteltomaster' && trim($_REQUEST['hotelName'])!=''){


	$hotelName=clean($_POST['hotelName']); 
	$url=clean($_POST['url']); 
  
	$hotelCity=clean($_POST['hotelCity']); 
	$hotelChain=clean($_POST['hotelChain']); 
   	$hotelchainname=clean($_POST['name']); 
	$showOnHome=clean($_POST['showOnHome']);  
	$hotelAddress=clean($_POST['hotelAddress']);  
	$hotelCategoryId=clean($_POST['hotelCategoryId']); 
	$hotelTypeId=clean($_POST['hotelTypeId']); 
	$hoteldetail=cleanNonAsciiCharactersInString($_POST['hoteldetail']);
	$hotelpolicy=clean($_POST['hotelpolicy']);
	$hoteltermandcondition=clean($_POST['hoteltermandcondition']);
	//$hotelImage=clean($_POST['hotelImage']);
	$gstn=clean($_POST['gstn']);
	$supplier=$_POST['supplier'];
	//add checkin and check out code
	$checkInTime=date('H:i:s', strtotime($_POST['checkInTime']));
	$checkOutTime=date('H:i:s', strtotime($_POST['checkOutTime']));
    
	
	$weekendid=$_POST['weekend'];
	$hoteldetail=clean($_POST['hoteldetail']);
	$hotel_amenities = implode(',', $_POST['hotel_amenities']);  
	$roomType = implode(',', $_POST['roomType']); 
	// $weekendDays = implode(',', $_POST['weekendDays']); 
	$status=clean($_POST['status']); 
	 
	$countryId=($_POST['countryId2']); 
	$stateId=clean($_POST['stateId2']);
	$cityId=clean($_POST['cityId2']);  
	$pinCode=clean($_POST['pinCode']); 
	 
	 
	if(!empty($_FILES['hotelImage']['name'])){  
		$hotelImageN = str_replace(" ","_",trim($_FILES['hotelImage']['name']));
		$file_name=time().$hotelImageN;  
		copy($_FILES['hotelImage']['tmp_name'],"packageimages/".$file_name);
		$hotelIMagName=$file_name; 
	}
	
	$dateAdded=time();


	$addnewyes = checkduplicate(_PACKAGE_BUILDER_HOTEL_MASTER_,' hotelName="'.$hotelName.'" and hotelCity="'.$hotelCity.'" ');
	if($addnewyes=='yes'){ ?>
		<script>
		alert('Hotel is already exist!!');
		</script>
	 	<?php 
	}else{
		$namevalue ='hotelName="'.$hotelName.'",hotelCity="'.$hotelCity.'",policy="'.$hotelpolicy.'",termAndCondition="'.$hoteltermandcondition.'",hotelChain="'.$hotelChain.'",hotelAddress="'.$hotelAddress.'",hoteldetail="'.$hoteldetail.'",hotelCategoryId="'.$hotelCategoryId.'",hotelTypeId="'.$hotelTypeId.'",hotelImage="'.$hotelIMagName.'",gstn="'.$gstn.'",status="'.$status.'",url="'.$url.'",roomType="'.$roomType.'",supplier="'.$supplier.'",amenities="'.$hotel_amenities.'",weekendDays="'.$weekendid.'",hotelCategoryName="'.$reCateHot['name'].'",checkInTime="'.$checkInTime.'",checkOutTime="'.$checkOutTime.'"';  
		$HlastId = addlistinggetlastid(_PACKAGE_BUILDER_HOTEL_MASTER_,$namevalue); 

		$namevalue ='addressParent="'.$HlastId.'",countryId="'.$countryId.'",stateId="'.$stateId.'",cityId="'.$cityId.'",address="'.$hotelAddress.'",pinCode="'.$pinCode.'",gstn="'.$gstn.'",primaryAddress=1,addressType="hotel"';
	    addlistinggetlastid(_ADDRESS_MASTER_,$namevalue);

	    // email shoud add if already added as an operations and now adding with non-operations
	    // Loop for all contact person details
	    $countCP = 1;
	    while($countCP <= $_POST['countCP']){
			$cp_person=trim($_POST["contactPerson".$countCP]);
			$cp_designation=trim($_POST["designation".$countCP]);
			$cp_phone=str_replace(' ', '', trim($_POST["phone".$countCP]));
			$cp_email=trim($_POST["email".$countCP]);
			$cp_id=trim($_POST["contactPId".$countCP]);
			$cp_countryCode=trim($_POST["countryCode".$countCP]);
			$cp_division=trim($_POST["division".$countCP]);
			if($cp_division>0 && $cp_email!=''){
				$primaryval=trim($_POST["primaryvalue"]);
				if($countCP==1){
					$cp_primaryvalue=1;
				} else {
					$cp_primaryvalue=0;
				}
				$addnewyes = checkduplicate('hotelContactPersonMaster','email="'.$cp_email.'" and division=3');
				if($addnewyes=='yes' && $cp_division==3){ ?>
					<script>
					// alert('Unable to add hotel details, Email is already exist used as an operations.');
					</script>
				 	<?php 
				}else{
					 
					$cp_allvalue ='contactPerson="'.$cp_person.'",corporateId="'.$HlastId.'",designation="'.$cp_designation.'",phone="'.trim($cp_phone).'",email="'.trim($cp_email).'",countryCode="'.$cp_countryCode.'",primaryvalue="'.$cp_primaryvalue.'",division="'.$cp_division.'"';
					$cp_id2 = addlisting('hotelContactPersonMaster',$cp_allvalue);

				}
			}
			$countCP++;
		} 

		if($supplier=='1'){ 
		
			$select1='*';  
			$where1='name="'.$hotelCity.'"'; 
			$rs1=GetPageRecord($select1,'destinationMaster',$where1); 
			$destD=mysqli_fetch_array($rs1); 
			
			$rs2='';
			$rs2=GetPageRecord('*',_SUPPLIERS_MASTER_,' name="'.$hotelName.'" and destinationId="'.$destD['id'].'" '); 
			$suppD=mysqli_fetch_array($rs2); 
			if($suppD['id']>0){ 
				$lastId = $suppD['id'];
				$countCP = 1;
			    while($countCP <= $_POST['countCP']){
					$cp_person=trim($_POST["contactPerson".$countCP]);
					$cp_designation=trim($_POST["designation".$countCP]);
					$cp_phone=str_replace(' ', '', trim($_POST["phone".$countCP]));
					$cp_email=trim($_POST["email".$countCP]);
					$cp_id=trim($_POST["contactPId".$countCP]);
					$cp_countryCode=trim($_POST["countryCode".$countCP]);
					$cp_division=trim($_POST["division".$countCP]);
					if($cp_division>0 && $cp_email!=''){
						$primaryval=trim($_POST["primaryvalue"]);
						if($countCP==1){
							$cp_primaryvalue=1;
						} else {
							$cp_primaryvalue=0;
						}

						$addnewyes3 = checkduplicate('suppliercontactPersonMaster',' email="'.encode($cp_email).'" and division=3 and corporateId!="'.$lastId.'"');
						if($addnewyes3=='yes' && $cp_division==3){ ?>
							<script>
							// alert('Unable to add contact detail, Email is already exist used as an operations.');
							</script>
						 	<?php 
						}else{
							$addnewyes4 = checkduplicate('suppliercontactPersonMaster',' email="'.encode($cp_email).'" and corporateId="'.$lastId.'"');
							if($addnewyes4=='yes'){
							 	$allcountCP ='contactPerson="'.$cp_person.'",designation="'.$cp_designation.'",phone="'.encode($cp_phone).'",countryCode="'.$cp_countryCode.'",primaryvalue="'.$cp_primaryvalue.'",division="'.$cp_division.'"';
								updatelisting('suppliercontactPersonMaster',$allcountCP,' email="'.encode($cp_email).'" and corporateId="'.$lastId.'"');
							}else{
							 	$allcountCP ='contactPerson="'.$cp_person.'",corporateId="'.$lastId.'",designation="'.$cp_designation.'",phone="'.encode($cp_phone).'",email="'.encode($cp_email).'",countryCode="'.$cp_countryCode.'",primaryvalue="'.$cp_primaryvalue.'",division="'.$cp_division.'"';
								addlisting('suppliercontactPersonMaster',$allcountCP);
							}
						}
					}
					$countCP++;
				} 
			}else{

				$dateAdded=time();
				$namevalue ='name="'.$hotelName.'",aliasname="'.$hotelName.'",contactPerson="'.$contactPerson.'",addedBy='.$_SESSION['userid'].',dateAdded='.$dateAdded.',companyTypeId=1,supplierMainType=1,paymentTerm=1,agreement=0,destinationId="'.$destD['id'].'"'; 
				$lastId = addlistinggetlastid(_SUPPLIERS_MASTER_,$namevalue);  
				
				$namevalue ='addressParent="'.$lastId.'",countryId="'.$countryId.'",stateId="'.$stateId.'",cityId="'.$cityId.'",address="'.$hotelAddress.'",pinCode="'.$pinCode.'",gstn="'.$gstn.'",primaryAddress="1",addressType="supplier"';  
				addlistinggetlastid(_ADDRESS_MASTER_,$namevalue);
					
				$countCP = 1;
			    while($countCP <= $_POST['countCP']){
					$cp_person=trim($_POST["contactPerson".$countCP]);
					$cp_designation=trim($_POST["designation".$countCP]);
					$cp_phone=str_replace(' ', '', trim($_POST["phone".$countCP]));
					$cp_email=trim($_POST["email".$countCP]);
					$cp_id=trim($_POST["contactPId".$countCP]);
					$cp_countryCode=trim($_POST["countryCode".$countCP]);
					$cp_division=trim($_POST["division".$countCP]);
					if($cp_division>0 && $cp_email!=''){
						$primaryval=trim($_POST["primaryvalue"]);
						if($countCP==1){
							$cp_primaryvalue=1;
						} else {
							$cp_primaryvalue=0;
						}

						$addnewyes3 = checkduplicate('suppliercontactPersonMaster',' email="'.encode($cp_email).'" and division=3');
						if($addnewyes3=='yes' && $cp_division==3){ ?>
							<script>
							// alert('Unable to add contact detail, Email is already exist used as an operations.');
							</script>
						 	<?php 
						}else{
						 	$allcountCP ='contactPerson="'.$cp_person.'",corporateId="'.$lastId.'",designation="'.$cp_designation.'",phone="'.encode($cp_phone).'",email="'.encode($cp_email).'",countryCode="'.$cp_countryCode.'",primaryvalue="'.$cp_primaryvalue.'",division="'.$cp_division.'"';
							addlisting('suppliercontactPersonMaster',$allcountCP);
						}
					}
					$countCP++;
				}

				$gotohotelprice='';
				if($lastIdSupplier!=''){
					//packagehotelmaster&view=yes&hotelId=VGxFOVBRPT0=&supplierId=VGxFOVBRPT0=
					$gotohotelprice = "&view=yes&hotelId=".encode($addid)."&supplierId=".encode($lastId);
				}
			}
		} ?>

		<script>
		//parent.closeinbound();
		//parent.loadquotationmainfile();
		var hotelname = encodeURI('<?php echo $hotelName; ?>');
		 parent.openinboundpop('action=addServiceHotel&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $_REQUEST['daydate']; ?>&hotelname='+hotelname+'','1200px');
		//parent.$('#pageloading').hide();
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();


	</script>

	<?php	} 
	exit();

 }
//for addTransferTimeDetails
if($_REQUEST['action'] == 'addTransferTimeDetails' && $_REQUEST['transferQuoteId'] != ''){ 
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
		$dayData = mysqli_fetch_array($dayQuery);

	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_TRANSFER_MASTER_,'id="'.$_REQUEST['transferQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);
	// hotel data
	$d=GetPageRecord('*',_PACKAGE_BUILDER_TRANSFER_MASTER,' id="'.$hotelQuotData['transferNameId'].'"');
	$transferData=mysqli_fetch_array($d); 
	
	$dv=GetPageRecord('*','vehicleTypeMaster',' id="'.$hotelQuotData['vehicleType'].'"');
	$vehicleData=mysqli_fetch_array($dv); 
	

	$c1=GetPageRecord('*','quotationTransferTimelineDetails',' transferQuoteId="'.$hotelQuotData['id'].'" and quotationId="'.$hotelQuotData['quotationId'].'"');
	$transferTimelineData=mysqli_fetch_array($c1);

	if($transferTimelineData['departureDate']!=NULL && $transferTimelineData['departureDate']!='1970-01-01'){
		$departureDate = date('Y-m-d',strtotime($transferTimelineData['departureDate']));
	}else{
		$departureDate = date('Y-m-d',strtotime($dayData['srdate']));
	}
	

 
	?>
	<style>
		.addeditpagebox .griddiv{
			border: none;
		}
	</style>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Transfer Timeline Details | <?php echo date('d M Y ',strtotime($dayData['srdate']))?></span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<thead>
					<tr style="background-color:transparent !important;">
					<td width="13%"><strong>Transfer&nbsp;Name</strong><br>
					<?php echo strip($transferData['transferName']);  ?>
					</td>
					<td width="13%"><strong>Transfer&nbsp;Type</strong><br>
					<?php if($hotelQuotData['transferType']==1){ echo 'SIC'; }elseif($hotelQuotData['transferType']==2){ echo 'PVT'; }  ?>
					<input type="hidden" name="TransferTypeName" value="<?php echo $hotelQuotData['transferType']; ?>">
					</td>
					<!-- <td colspan="4" width="50px"><strong>&nbsp;&nbsp;&nbsp;</strong></td> -->
					<td width="13%">
						<div class="griddiv" style="position:static;color: #333333;">
						<label for="mode" style="font-size:12px;">
						<div class="gridlable"><strong>Mode</strong></div>
						<select id="mode" name="mode" class="gridfield validate" displayname="Mode" autocomplete="off" onchange="transferMode()" style="width: 120px;">
							<option value="">Select Mode</option>
							<option value="flight" <?php if($transferTimelineData['mode']  == 'flight') {  ?> selected="selected" <?php } ?> >Flight</option>
							<option value="train"  <?php if($transferTimelineData['mode']  == 'train') {  ?> selected="selected" <?php } ?> >Train</option>
							<option value="Local"  <?php if($transferTimelineData['mode']  == 'Local') {  ?> selected="selected" <?php } ?> >Local</option>
						</select>
						</label>
						</div>
					</td>
					<!-- <td id="transferTypeId" style="display:none;">
						<div class="griddiv" style="position:static;color: #333333;">
						<label for="mode" style="font-size:12px;">
						<div class="gridlable"><strong>Transfer&nbsp;Type</strong></div>
						<select id="TransferTypeName" name="TransferTypeName" class="gridfield validate" displayname="Transfer Type" autocomplete="off" style="width: 120px;">
							<option value="SIC" <?php if($transferTimelineData['TransferType']  == 'SIC') {  ?> selected="selected" <?php } ?> >SIC</option>
							<option value="PVT"  <?php if($transferTimelineData['TransferType']  == 'PVT') {  ?> selected="selected" <?php } ?> >PVT</option>
							
						</select>
						</label>
						</div>
					</td> -->
					<td colspan="3">&nbsp;</td>
					</tr>
				</thead>
				<tbody>
				<tr id="firstrowId" style="background-color:transparent !important;">
					<td>
						<div class="griddiv" style="position:static;color: #333333;">
						<label for="arrivalFrom" style="font-size:12px;"><strong>Arrival From</strong></label>
						<input name="arrivalFrom" type="text" class="gridfield" id="arrivalFrom" value="<?php echo strip($transferTimelineData['arrivalFrom']);  ?>" > 
						</div>
					</td>

					<td>
					 <div class="griddiv"><label for="arrivalTime" style="font-size:12px;color: #333333;"><strong>ARV/DPT&nbsp;Time</strong></label>
					   <input type="text" id="arrivalTime" name="arrivalTime" style="text-align:left;width:90%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" value="<?php if($transferTimelineData['arrivalTime']!='') { echo  date('H:i',strtotime($transferTimelineData['arrivalTime'])); }  ?>"  class="gridfield  timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"/>
                     </div>
                    </td>
					
					<td width="14%"	>
						<div class="griddiv" id="flightName">
							<label for="flightName" style="font-size:12px;color: #333333;"><strong>Flight&nbsp; Name</strong></label>
 							<input name="flightName" type="text" class="gridfield" id="flightName" value="<?php echo strip($transferTimelineData['flightName']);  ?>">
						</div>
						<div class="griddiv"  id="trainName" style="display: none;">
							<label for="trainName" style="font-size:12px;color: #333333;"><strong>Train&nbsp; Name</strong></label>
 							<input name="trainName" type="text" class="gridfield" id="trainName" value="<?php echo strip($transferTimelineData['trainName']);  ?>">
						</div>

					</td>
					<td>
						<div class="griddiv"  id="flightNumber">
							<label for="flightNumber" style="font-size:12px;color: #333333;"><strong>Flight&nbsp; Number</strong></label>
 								<input name="flightNumber" type="text" class="gridfield" id="flightNumber" value="<?php echo strip($transferTimelineData['flightNumber']);  ?>">
						</div>

						<div class="griddiv" style="display: none;" id="TrainNumber">
							<label for="TrainNumber" style="font-size:12px;color: #333333;"><strong>Train&nbsp; Number</strong></label>
 								<input name="TrainNumber" type="text" class="gridfield" id="TrainNumber" value="<?php echo strip($transferTimelineData['trainNumber']);  ?>">
						</div>

					</td>

					<td id="airportNameId">
						<div class="griddiv"  >
							<label for="airportName" style="font-size:12px;color: #333333;"><strong>Airport Name</strong></label>
 							<input name="airportName" type="text" class="gridfield" id="airportName" value="<?php echo strip($transferTimelineData['airportName']);  ?>">
						</div>

					</td>
  

			  	</tr> 
			  	<tr style="background-color:transparent !important;">
				
				<td id="firstrowId1" style="display:none;">
				<div class="griddiv"  >
							<label for="pickupAddress" style="font-size:12px;color: #333333;"><strong>Date</strong></label>
							<input type="date" name="departureDate" class="gridfield" id="departureDate" value="<?= $departureDate; ?>">
						</div>
				
				</td>
				<?php if($hotelQuotData['transferType']==2){ ?>
				<td id="firstrowId2" style="display:none;">
				<div class="griddiv"  >
							<label for="pickupAddress" style="font-size:12px;color: #333333;"><strong>Vehicle Type</strong></label>
							<input type="text" name="vehicleTypeName" class="gridfield" id="vehicleTypeName" value="<?php echo $vehicleData['name']; ?>">
						</div>
				
				</td>
				<?php  } ?>
				  <td><div class="griddiv"><label for="pickupTime" style="font-size:12px;color: #333333;"><strong>Pick&nbsp;Up&nbsp;Time</strong></label>
 					    <input type="text" id="pickupTime" name="pickupTime" style="text-align:left;width:90%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" value="<?php if($transferTimelineData['pickupTime']!='') { echo  date('H:i',strtotime($transferTimelineData['pickupTime'])); }  ?>"  class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"/>
                       </div>
                    </td>

                    <td><div class="griddiv"><label for="dropTime" style="font-size:12px;color: #333333;"><strong>Drop&nbsp;Time</strong></label> 
					   <input type="text" id="dropTime" name="dropTime" style="text-align:left;width:90%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" value="<?php if($transferTimelineData['dropTime']!='') { echo  date('H:i',strtotime($transferTimelineData['dropTime'])); }  ?>"  class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"/>
                       </div>
                    </td> 
					
					<td>
						<div class="griddiv"  >
							<label for="pickupAddress" style="font-size:12px;color: #333333;"><strong>Pickup Address</strong></label>
 							<input name="pickupAddress" type="text" class="gridfield" id="pickupAddress" value="<?php echo strip($transferTimelineData['pickupAddress']);  ?>">
						</div>

					</td>
					<td>
						<div class="griddiv"  >
							<label for="dropAddress" style="font-size:12px;color: #333333;"><strong>Drop Address</strong></label>
 							<input name="dropAddress" type="text" class="gridfield" id="dropAddress" value="<?php echo strip($transferTimelineData['dropAddress']);  ?>">
						</div>
					</td> 

					<td >
						<label for="dropAddress" style="font-size:12px;color: #333333;"><strong>&nbsp;</strong></label>
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_hoteltomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
 						<input type="hidden" value="<?php echo $hotelQuotData['id']; ?>" name="transferQuoteId"/>
						<input name="action" type="hidden" id="action" value="add_TransferTimeline">
  					</td>

			  	</tr>    
		  		<script type="text/javascript">
                	function transferMode(){
                		var mode = $('#mode').val();
                		
                		if (mode == 'train') {
                		   $('#trainName').show();
                		   $('#TrainNumber').show();
                		   $('#airportNameId').hide();

                		   $('#flightName').hide();
                		   $('#flightNumber').hide();
						   $('#firstrowId1').hide();
						   $('#firstrowId2').hide();
						   $('#secrowId').show();
                		   $('#firstrowId').show();
                		}
                		if (mode == 'flight') {
                		   $('#flightName').show();
                		   $('#flightNumber').show();

						   $('#airportNameId').show();

                		   $('#trainName').hide();
                		   $('#TrainNumber').hide();
						   $('#firstrowId1').hide();
						   $('#firstrowId2').hide();
						   $('#secrowId').show();
                		   $('#firstrowId').show();
                		}
						if (mode == 'Local') {
                		   $('#firstrowId1').show();
                		   $('#firstrowId2').show();
                		   $('#secrowId').hide();
                		   $('#firstrowId').hide();
							
                		}

                	}
                	transferMode();
				
                </script>
				<script type="text/javascript" src="js/jquery.timepicker.js"></script> 
				<script type="text/javascript"> 
					$(document).ready(function(){
						$('.timepicker2').timepicker();	
					});  
				</script>
				</tbody>
			</table>
			</form>
		</div>
	</div>

	<?php
}

if(trim($_REQUEST['action'])=='add_TransferTimeline' && trim($_REQUEST['transferQuoteId'])!=''){

	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_TRANSFER_MASTER_,' id="'.$_REQUEST['transferQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);

	$c1=GetPageRecord('id','quotationTransferTimelineDetails',' transferQuoteId="'.$hotelQuotData['id'].'" and quotationId="'.$hotelQuotData['quotationId'].'"');
	if(mysqli_num_rows($c1) == 0){

		
		if(!empty($_REQUEST['arrivalTime'])){
			$arrivalTime = date('H:i:s', strtotime($_REQUEST['arrivalTime']));
		}else{
			$arrivalTime = '';
		}
		if(!empty($_REQUEST['dropTime'])){
           $dropTime = date('H:i:s', strtotime($_REQUEST['dropTime']));
		}else{
           $dropTime = '';
		}
		if(!empty($_REQUEST['pickupTime'])){
		   $pickupTime = date('H:i:s', strtotime($_REQUEST['pickupTime']));
		}else{
           $pickupTime = '';
		}
		if(!empty($_REQUEST['departureDate'])){
			$departureDate = date('Y-m-d', strtotime($_REQUEST['departureDate']));
		 }else{
			$departureDate = '';
		 }

		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",departureDate="'.$departureDate.'",transferType="'.$_REQUEST['TransferTypeName'].'",dayId="'.$_REQUEST['dayId'].'",supplierId="'.$hotelQuotData['supplierId'].'",transferQuoteId="'.$hotelQuotData['id'].'",arrivalFrom="'.$_REQUEST['arrivalFrom'].'",trainName="'.$_REQUEST['trainName'].'",trainNumber="'.$_REQUEST['TrainNumber'].'",flightName="'.$_REQUEST['flightName'].'",flightNumber="'.$_REQUEST['flightNumber'].'",vehicleName="'.$_REQUEST['vehicleName'].'",airportName="'.$_REQUEST['airportName'].'",pickupAddress="'.$_REQUEST['pickupAddress'].'",dropAddress="'.$_REQUEST['dropAddress'].'",VehicleModel="'.$_REQUEST['VehicleModel'].'",arrivalTime="'.$arrivalTime.'",dropTime="'.$dropTime.'",mode="'.$_REQUEST['mode'].'",pickupTime="'.$pickupTime.'"';
		$hotelSupHot = addlistinggetlastid('quotationTransferTimelineDetails',$namevalue);

	}else{
		$transferTimelineData=mysqli_fetch_array($c1);
		$where = " id ='".$transferTimelineData['id']."'";

		
		if(!empty($_REQUEST['arrivalTime'])){
			$arrivalTime = date('H:i:s', strtotime($_REQUEST['arrivalTime']));
		}else{
			$arrivalTime = '';
		}
		if(!empty($_REQUEST['dropTime'])){
           $dropTime = date('H:i:s', strtotime($_REQUEST['dropTime']));
		}else{
           $dropTime = '';
		}
		if(!empty($_REQUEST['pickupTime'])){
		   $pickupTime = date('H:i:s', strtotime($_REQUEST['pickupTime']));
		}else{
           $pickupTime = '';
		}
		if(!empty($_REQUEST['departureDate'])){
			$departureDate = date('Y-m-d', strtotime($_REQUEST['departureDate']));
		 }else{
			$departureDate = '';
		 }


		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",departureDate="'.$departureDate.'",transferType="'.$_REQUEST['TransferTypeName'].'",dayId="'.$_REQUEST['dayId'].'",supplierId="'.$hotelQuotData['supplierId'].'",transferQuoteId="'.$hotelQuotData['id'].'",arrivalFrom="'.$_REQUEST['arrivalFrom'].'",trainName="'.$_REQUEST['trainName'].'",trainNumber="'.$_REQUEST['TrainNumber'].'",flightName="'.$_REQUEST['flightName'].'",flightNumber="'.$_REQUEST['flightNumber'].'",vehicleName="'.$_REQUEST['vehicleName'].'",airportName="'.$_REQUEST['airportName'].'",pickupAddress="'.$_REQUEST['pickupAddress'].'",dropAddress="'.$_REQUEST['dropAddress'].'",VehicleModel="'.$_REQUEST['VehicleModel'].'",arrivalTime="'.$arrivalTime.'",dropTime="'.$dropTime.'",mode="'.$_REQUEST['mode'].'",pickupTime="'.$pickupTime.'"';
		$hotelSupHot = updatelisting('quotationTransferTimelineDetails',$namevalue,$where);
	}
 	?>
	<script>
		parent.closeinbound();
		parent.loadquotationmainfile();
  		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}

if(trim($_REQUEST['action'])=='add_SupplementHotel' && trim($_REQUEST['hotelQuoteId'])!=''){

	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_HOTEL_MASTER_,' id="'.$_REQUEST['hotelQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);

	$c1=GetPageRecord('*','quotationRoomSupplimentMaster',' hotelQuoteId="'.$hotelQuotData['id'].'" and quotationId="'.$hotelQuotData['quotationId'].'"');
	if(mysqli_num_rows($c1) == 0){

		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",dayId="'.$_REQUEST['dayId'].'",supplierId="'.$hotelQuotData['supplierId'].'",supplierMasterId="'.$hotelQuotData['supplierMasterId'].'",hotelQuoteId="'.$hotelQuotData['id'].'",mealPlan="'.$_REQUEST['mealPlan'].'",roomType="'.$_REQUEST['roomType'].'",singleoccupancy="'.$_REQUEST['singleoccupancy'].'",doubleoccupancy="'.$_REQUEST['doubleoccupancy'].'",twinoccupancy="'.$_REQUEST['doubleoccupancy'].'",tripleoccupancy="'.$_REQUEST['tripleoccupancy'].'",childwithbed="'.$_REQUEST['childwbed'].'",childwithoutbed="'.$_REQUEST['childwobed'].'",lunch="'.$_REQUEST['lunch'].'",dinner="'.$_REQUEST['dinner'].'",extraadult="'.$_REQUEST['extraadult'].'"';
		$hotelSupHot = addlistinggetlastid('quotationRoomSupplimentMaster',$namevalue);

	}
	?>
	<script>
		parent.closeinbound();
		parent.loadquotationmainfile();
  		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}

if($_REQUEST['action'] == 'addtransfertomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Transfer/Transportation</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_transfertomaster" target="actoinfrm" id="add_transfertomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="    float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Transfer/Transportation Name<span class="redmind"></span></div>
						<input name="transferName" type="text" class="gridfield validate" id="transferName" displayname="Transfer Name" value="">
						</label>
						</div>

						<div class="griddiv" style="position:static;">
							<label>
								<div>Category</div>
								<select id="transferCategory" name="transferCategory" class="gridfield" displayname="Transfer Category" autocomplete="off"  >
								  <option value="transportation">Transportation</option>
								  <option value="transfer" >Transfer</option>
								</select>
							</label>
						</div>  
						<div style="display: grid;grid-template-columns: 1fr 1fr;grid-gap: 10px;">

						<div class="griddiv">
							<label>
								<div class="gridlable">Vehical Type</div>
								<select id="vehicleId" name="vehicleId" class="gridfield"  autocomplete="off" onchange="getVehicleModel()">
									<option value="all">All Vehicle Type</option>
									<?php
									$rs=GetPageRecord('name,id','vehicleTypeMaster',' 1 order by name asc');
									while($resListing=mysqli_fetch_array($rs)){
									?>
									<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
									<?php } ?>
							  </select>
							</label>
						</div>

						<div class="griddiv">
							<label>
								<div class="gridlable">Transfer Type</div>
								<select id="transferType" name="transferType" class="gridfield"  autocomplete="off">
									<?php
									$rs=GetPageRecord('name,id','transferTypeMaster','1 and deletestatus=0 and status=1 order by id asc');
									while($resListing=mysqli_fetch_array($rs)){
									?>
									<option value="<?php echo strip($resListing['id']); ?>"><?php echo strip($resListing['name']); ?></option>
									<?php } ?>
							  </select>
							</label>
						</div>
					</div>

						<div class="griddiv">
							<label>
								<div class="gridlable">Vehical Model</div>
								  <select id="vehicleModelId" name="vehicleModelId" class=" gridfield"  autocomplete="off">
								  	<option value="all">All Vehicles</option>
									<?php
									$select='*';
									$where=' 1 order by id asc';
									$rs=GetPageRecord($select,_VEHICLE_MASTER_MASTER_,$where);
									while($resListing=mysqli_fetch_array($rs)){
									?>
									<option value="<?php echo $resListing['id']; ?>" <?php if($queryData['vehicleId']==$resListing['id']){ ?> selected="selected" <?php } ?>><?php echo $resListing['model']; ?></option>
									<?php } ?>
                                  </select>
							</label>
						</div>

						<script type="text/javascript">
                                 function getVehicleModel() {
						              var vehicleId = $('#vehicleId').val();
						              $("#vehicleModelId").load('loadvehiclemodel.php?vehicleTypeId='+vehicleId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
						            }
						</script>

					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_transfertomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $_REQUEST['cityId']; ?>" name="cityId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input type="hidden" value="<?php echo $_REQUEST['tc']; ?>" name="tc"/>
						<input name="action" type="hidden" id="action" value="add_transfertomaster">
						<?php if($_REQUEST['tc'] == 2){ ?>
						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceTransportation&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','1200px');">
						<?php } else{ ?>
						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceTransfer&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','1200px');">
						<?php } ?>
 						

 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>

	<?php
}
if(trim($_REQUEST['action'])=='add_transfertomaster' && trim($_REQUEST['transferName'])!=''){

	$transferName=clean($_REQUEST['transferName']);
	$vehicleId=clean($_REQUEST['vehicleId']);
	$vehicleModelId=clean($_REQUEST['vehicleModelId']);
	$transferCategory=clean($_REQUEST['transferCategory']);
	$transferType=clean($_REQUEST['transferType']);

	$quotationId = $_REQUEST['quotationId'];
	$cityId = $_REQUEST['cityId'];
	$queryId = $_REQUEST['queryId'];
	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];

	$selfSupplier = getSelfSupplier();
	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	$dateAdded=time();
	$namevalue ='transferName="'.$transferName.'",transferType="'.$transferType.'",destinationId="'.$cityId.'",transferCategory="'.$transferCategory.'",status="1"';
	$lastid=addlistinggetlastid(_PACKAGE_BUILDER_TRANSFER_MASTER,$namevalue);

	$namevalue ='fromDate="'.date('Y-m-d').'",toDate="'.date('Y-m-d', strtotime('12/31')).'",vehicleTypeId="'.$vehicleId.'",vehicleModelId="'.$vehicleModelId.'",transferType="'.$transferType.'",currencyId="'.$resListing['id'].'",status="1",supplierId="'.$selfSupplier.'",serviceid="'.$lastid.'",transferNameId="'.$lastid.'"';
	 $lastId2 = addlistinggetlastid(_DMC_TRANSFER_RATE_MASTER_,$namevalue);


 
	?>
	<script>
		//parent.closeinbound();
		parent.loadquotationmainfile();
		<?php if($_REQUEST['tc'] == 2){ ?>
		var action = "addServiceTransportation";
		<?php } else{ ?>
		var action = "addServiceTransfer";
		<?php } ?>	
		var transferNameId = encodeURI('<?php echo $lastid; ?>'); 
		parent.openinboundpop('action='+action+'&dayId=<?php echo $_REQUEST['dayId']; ?>&transferNameId='+transferNameId+'','1200px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();

	</script>
	<?php
}

 
// Add New restaurant Form start here============================

if($_REQUEST['action'] == 'addNewRestaurant'){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add New Restaurant</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="loadsaveMealplans.php" method="get"  name="addedit_newQuotationMeals" target="actoinfrm" id="addedit_newQuotationMeals">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Restaurant Name<span class="redmind"></span></div>
						<input type="text" name="newmealPlanName" class="gridfield validate" id="newmealPlanName" displayname="Restaurant Name" value="">
						</label>
						</div>
						
						<div class="griddiv" style="position:static;">
						<label>
							<div class="gridlable">Meal&nbsp;Type</div> 
							<select id="mealPlanmealType" name="mealPlanmealType" class="gridfield validate" displayname="Meal Type" autocomplete="off">
							<option value="">Select Meal Type</option>
							<?php   
							$rs2=GetPageRecord('*','restaurantsMealPlanMaster','status = 1 and deletestatus=0'); 
							while($userss=mysqli_fetch_array($rs2)){
								?>
								<option value="<?Php echo $userss['id']; ?>"><?Php echo $userss['name']; ?></option>
								<?php 
							} ?>
							</select>
						</label>
					  </div>

						<div class="griddiv"><label> 
						<div class="gridlable">Currency<span class="redmind"></span></div> 
						<select id="currencyId" name="currencyId" class="gridfield validate" displayname="Currency" autocomplete="off" >  
						 <?php  
						
						 $select=''; 
						 $where=''; 
						 $rs='';  
						 $select='*';    
						 $where=' deletestatus=0 and status=1 order by name asc';  
						 $rs=GetPageRecord($select,_QUERY_CURRENCY_MASTER_,$where); 
						 while($resListing=mysqli_fetch_array($rs)){   
						?> 
						<option value="<?php echo strip($resListing['id']); ?>" <?php if($resListing['setDefault'] == 1){ echo "selected"; } ?> ><?php echo strip($resListing['name']); ?></option> 
						<?php } ?> 
						</select> 
						</label>  
						</div>

						<div class="griddiv">
							<label>
								<div class="gridlable"> Per Pax Cost <span class="redmind"></div>
								<input name="mealPlanadultCost" type="number" class="gridfield number_only "  id="mealPlanadultCost" displayname="Per Pax Cost" value="">
							</label>
						</div>

					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value=" Save" onclick="formValidation('addedit_newQuotationMeals','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $_REQUEST['destinationId']; ?>" name="destinationId"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="cityId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input name="action" type="hidden" id="action" value="addedit_newQuotationMeals">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>
<?php

}
// Add New restuarant Form end here ============================
if(trim($_REQUEST['action'])=='add_NewRestaurant' && trim($_REQUEST['newrestaurant'])!=''){


	$newrestaurant=clean($_REQUEST['newrestaurant']);
 	$ContactPerson=clean($_REQUEST['ContactPerson']);
	$restuarantprice=clean($_REQUEST['restuarantprice']);


	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$destinationId = $_REQUEST['destinationId'];

	$rs1=GetPageRecord('*',_DESTINATION_MASTER_,'id="'.clean($_REQUEST['destinationId']).'"');
	$destData=mysqli_fetch_array($rs1);
	$additionalCity = stripslashes($destData['name']);

	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];


	$dateAdded=time();
	$namevalue ='name="'.$newrestaurant.'",contactperson="'.$ContactPerson.'",price="'.$restuarantprice.'",status="1"';
	$lastid=addlistinggetlastid('suppliersMaster',$namevalue);

	?>
<script>
	parent.openinboundpop('action=addServiceMealPlan&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $fromDate; ?>&additionalId=<?php echo $lastid; ?>','800px');
	parent.$('#pageloading').hide();
	parent.$('#pageloader').hide();

	</script>

	<?php
}

// Add New restuarant end here ============================
if($_REQUEST['action'] == 'addadditionaltomaster'){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Additional</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
	
			<form action="inboundpop.php" method="post" enctype="multipart/form-data" name="addmasters" target="actoinfrm" id="addmasters">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="destinationId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<div class="griddiv"><label>

						<div class="gridlable">Additional Name<span class="redmind"></span></div>

						<input name="name" type="text" class="gridfield validate" id="name" displayname="Additional Name" value="<?php echo $name; ?>" maxlength="100" />

					</label>

				</div>
				<!-- new added for destination fields by islam -->
				
				<div class="griddiv"><label>
							<div class="gridlable">Destination<span class="redmind"></span></div>
							<select id="destinationIda" multiple="multiple" name="destinationId[]" class="gridfield js-example-basic-multiple" displayname="Destination" autocomplete="off">
							<option value="All" <?php if($editdestinationId=='All') { echo 'selected="selected"';} ?> >All</option>
								<?php
								$select = '';
								$where = '';
								$rs = '';
								$select = '*';
								$where = ' 1 and deletestatus = 0 order by name asc';
								$rs = GetPageRecord($select, _DESTINATION_MASTER_, $where);
								$alldest=explode(',',$editdestinationId);  
								while ($resListing = mysqli_fetch_array($rs)) {
								?>
								<option value="<?php echo strip($resListing['id']); ?>" <?php foreach($alldest as $key => $value){ if($resListing['id']==$value){ echo 'selected="selected"'; } } ?> ><?php echo strip($resListing['name']); ?></option> <?php } ?> 
							</select>
						</label>
				</div>
				
				<script>
			$('.js-example-basic-multiple').select2();  
	 		// $('.js-example-basic-multiple').on("select2:select", function (e) { 
        //    var data = e.params.data.text;
        //    if(data=='All'){
        //     $(".js-example-basic-multiple > option").prop("selected","selected");
        //     $(".js-example-basic-multiple").trigger("change");
        //    }
    //   }); 
				</script>
					<style>
		.select2-container {

			width: 100% !important;
			;

		}

		.select2-container--open {

			z-index: 9999999999 !important;

		}
	</style>

				<div class="griddiv"><label>

						<div class="gridlable">Currency<span class="redmind"></span></div>

						<select id="currencyId" name="currencyId" class="gridfield validate" displayname="Currency" autocomplete="off">

							<option value="">Select</option>

							<?php

							$select = '';

							$where = '';

							$rs = '';

							$select = '*';

							$where = ' deletestatus=0 and status=1 order by name asc';

							$rs = GetPageRecord($select, _QUERY_CURRENCY_MASTER_, $where);

							while ($resListing = mysqli_fetch_array($rs)) {

							?>

								<option value="<?php echo strip($resListing['id']); ?>" <?php if ($resListing['id'] == $currencyId) { ?>selected="selected" <?php } ?>><?php echo strip($resListing['name']); ?></option>

							<?php } ?>

						</select>

					</label>

				</div>

				<div class="griddiv">

					<label>

						<div class="gridlable">Cost Type<span class="redmind"></span></div>

						<select id="costType" type="text" class="gridfield" name="costType" autocomplete="off" style="width: 100%;" onchange="selectcost();">

							<option value="0">Select Cost Type</option>

							<option value="1" <?php if ($editresult['costType'] == '1') { ?>selected="selected" <?php } ?>>Per Person</option>

							<option value="2" <?php if ($editresult['costType'] == '2') { ?>selected="selected" <?php } ?>>Group Cost</option>

						</select>
					</label>

					<script>
						function selectcost() {

							var costType = $('#costType').val();

							if (costType == 0) {

								$('.pp').hide();

								$('.tot').hide();

								$('#adultCost').val('');

								$('#childCost').val('');
								$('#infantCost').val('');

								$('#groupCost').val('');

							}



							if (costType == 1) {

								$('.pp').show();

								$('.tot').hide();

								$('#groupCost').val('');

							}



							if (costType == 2) {

								$('.pp').hide();

								$('.tot').show();

								$('#adultCost').val('');

								$('#childCost').val('');
								$('#infantCost').val('');

							}

						}

						selectcost();
					</script>

				</div>

				<div class="griddiv pp" style="display:none;"><label>

						<div class="gridlable" style="width:100%">Adult&nbsp;Cost</div>

						<input name="adultCost" type="number" class="gridfield" id="adultCost" displayname="Adult Cost" value="<?php echo $adultCost; ?>" maxlength="6" />

					</label>

				</div>

				<div class="griddiv pp" style="display:none;"><label>

				<div class="gridlable" style="width:100%">Child&nbsp;Cost</div>

				<input name="childCost" type="number" class="gridfield" id="childCost" displayname="Child Cost" value="<?php echo $childCost; ?>" maxlength="6" />

				</label>

				</div>

				<div class="griddiv pp" style="display:none;"><label>

				<div class="gridlable" style="width:100%">Infant&nbsp;Cost</div>

				<input name="infantCost" type="number" class="gridfield" id="infantCost" displayname="Infant Cost" value="<?php echo $infantCost; ?>" maxlength="6" />

				</label>

				</div>





				<div class="griddiv tot" style="display:none;"><label>

						<div class="gridlable">Group Cost</div>

						<input name="groupCost" type="number" class="gridfield" id="groupCost" displayname="Group Cost" value="<?php echo $groupCost; ?>" maxlength="6" />

					</label>

				</div>

				<div class="griddiv"><label>

						<div class="gridlable">Status</div>

						<select id="status" type="text" class="gridfield" name="status" displayname="Status" autocomplete="off" style="width: 100%;">

							<option value="1" <?php if ($editresult['status'] == '1') { ?>selected="selected" <?php } ?>>Active</option>

							<option value="0" <?php if ($editresult['status'] == '0') { ?>selected="selected" <?php } ?>>In Active</option>

						</select>
					</label>

				</div>

				<div class="griddiv"><label>

						<div class="gridlable">Add Image</div>

						<input name="AdditionalImage" type="file" class="gridfield" id="trainImage" />

					</label>

				</div>
				<div class="griddiv"><label>

					<div class="gridlable">Description</div>

						<textarea name="additionalDetail" rows="5" class="gridfield" id="additionalDetail"><?php echo strip($editresult['otherInfo']); ?></textarea>

							</label>

				</div>



				<input name="editId" type="hidden" id="editId" value="<?php echo $id; ?>" />
				<input type="hidden" name="fromQuotation" id="fromQuotation" value="<?php echo 'fromQuotation' ?>">

				<input name="module" type="hidden" id="module" value="<?php echo 'extraquotation'; ?>" />

				<input name="action" type="hidden" id="action" value="addedit_additionalRequirement" />

			</form>

			<div id="buttonsbox" style="text-align:center;">

				<table border="0" align="right" cellpadding="0" cellspacing="0">

					<tr>
						<td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addmasters','submitbtn','0');" /></td>

						<td style="padding-right:20px;"><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="closeinbound();" /></td>

					</tr>

				</table>

				</div>

		</div>
	</div>
<?php
} 
if(trim($_POST['action'])=='addedit_additionalRequirement' && trim($_POST['name'])!=''){ 
	$name=clean($_POST['name']);
	$fromDate = $_REQUEST['daydate'];
	$status=clean($_POST['status']);
	$adultCost=clean($_POST['adultCost']);  
	$childCost=clean($_POST['childCost']);  
	$infantCost=clean($_POST['infantCost']);  
	$groupCost=clean($_POST['groupCost']);  
	$costType=clean($_POST['costType']);  
	$currencyId=clean($_POST['currencyId']);
	$additionalDetail=clean($_POST['additionalDetail']);
	$destinationList = implode(',', $_POST['destinationId']); 

	$fromQuotation=clean($_POST['fromQuotation']); 
	if(!empty($_FILES['AdditionalImage']['name'])){  
		$file_name=time().$_FILES['AdditionalImage']['name'];  
		copy($_FILES['AdditionalImage']['tmp_name'],"packageimages/".$file_name); 
	}else{ 
		$file_name=$_REQUEST['AdditionalImage2'];
	}
	$dateAdded=time();
	
	// duplicate added code
	$rsr=GetPageRecord('*',_EXTRA_QUOTATION_MASTER_,'name="'.$name.'" ');
	// $editresult=mysqli_num_rows($rsr);
	if(mysqli_num_rows($rsr) > 0){
        ?>
        <script>
        parent.alert('This name Already Exist!');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
		exit();
    }else{
		$namevalue ='name="'.$name.'",status="'.$status.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",infantCost="'.$infantCost.'",dateAdded="'.$dateAdded.'",addedBy="'.$_SESSION['userid'].'",groupCost="'.$groupCost.'",costType="'.$costType.'",currencyId="'.$currencyId.'",file_extra="'.$file_name.'",destinationId="'.$destinationList.'",additionalId="'.$additionalDetail.'"';  

			$adds = addlisting(_EXTRA_QUOTATION_MASTER_,$namevalue); 
	
		}
		?>
		<script>
			// parnt.closeinbound();
			// parent.loadquotationmainfile(); 
			parent.openinboundpop('action=addServiceAdditional&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $fromDate; ?>','800px');
			parent.$('#pageloading').hide();
			parent.$('#pageloader').hide();
			
		</script>	
		<?php
	 } 
 
if($_REQUEST['action'] == 'addflighttomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Flight</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_flighttomaster" target="actoinfrm" id="add_flighttomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="    float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Flight Name<span class="redmind"></span></div>
						<input name="flightName" type="text" class="gridfield validate" id="flightName" displayname="Flight Name" value="">
						</label>
						</div>

					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_flighttomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="destinationId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input name="action" type="hidden" id="action" value="add_flighttomaster">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>

<?php
}

if(trim($_REQUEST['action'])=='add_flighttomaster' && trim($_REQUEST['flightName'])!=''){


	$flightName=clean($_REQUEST['flightName']);
	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];


	$dateAdded=time();
	$namevalue ='flightName="'.$flightName.'",status="1"';
	$lastid=addlistinggetlastid('packageBuilderAirlinesMaster',$namevalue);

	?>
	<script>
		parent.openinboundpop('action=addServiceFlight&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $fromDate; ?>&flightId=<?php echo $lastid; ?>','1200px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();

	</script>
	<?php
}


if($_REQUEST['action'] == 'addtraintomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Train</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_traintomaster" target="actoinfrm" id="add_traintomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="    float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Train Name<span class="redmind"></span></div>
						<input name="trainName" type="text" class="gridfield validate" id="trainName" displayname="Train Name" value="">
						</label>
						</div>

					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_traintomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="destinationId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input name="action" type="hidden" id="action" value="add_traintomaster">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>

<?php
}

if(trim($_REQUEST['action'])=='add_traintomaster' && trim($_REQUEST['trainName'])!=''){


	$trainName=clean($_REQUEST['trainName']);
	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];


	$dateAdded=time();
	$namevalue ='trainName="'.$trainName.'",status="1"';
	$lastid=addlistinggetlastid('packageBuilderTrainsMaster',$namevalue);

	?>
	<script>
		parent.openinboundpop('action=addServiceTrains&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $fromDate; ?>&trainId=<?php echo $lastid; ?>','1200px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}

// Add Guide to Master
if($_REQUEST['action'] == 'addguidetomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add TourEscort</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="tomasterform" target="actoinfrm" id="tomasterform">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Guide Name<span class="redmind"></span></div>
						<input name="guideName" type="text" class="gridfield validate" id="guideName" displayname="Guide Name" value="">
						</label>
						</div>
 
					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('tomasterform','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="cityId"/>
 						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input name="action" type="hidden" id="action" value="add_guidetomaster">
 						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceGuide&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','1000px');">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>
	<?php
}

if(trim($_REQUEST['action'])=='add_guidetomaster' && trim($_REQUEST['guideName'])!=''){

	$guideName=clean($_REQUEST['guideName']);
	$perPaxCost = clean($_REQUEST['perPaxCost']);
	if($perPaxCost>0){
		$adultCost = $perPaxCost;
	}else{
		$adultCost = clean($_REQUEST['adultCost']);
	}
	
	$childCost = clean($_REQUEST['childCost']);
	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$fromDate = $_REQUEST['daydate'];
	$cityId = $_REQUEST['cityId'];
	$selfSupplier = getSelfSupplier();
	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	$dateAdded=time();

	$rsr=GetPageRecord('*',_GUIDE_SUB_CAT_MASTER_,'name="'.$guideName.'" ');
	$editresult=mysqli_num_rows($rsr);
	if(mysqli_num_rows($rsr) > 0){
        ?>
        <script>
        parent.alert('This Guide Name Already Exist !');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
		exit();
    }
    else{

		$namevalue ='name="'.$guideName.'",destinationId="'.$cityId.'",status="1"';
		$lastid=addlistinggetlastid(_GUIDE_SUB_CAT_MASTER_,$namevalue);
		?>
		<script>
			parent.openinboundpop('action=addServiceGuide&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','1000px');
			parent.$('#pageloading').hide();
			parent.$('#pageloader').hide();
		</script>
		<?php
	}


	// $namevalue ='fromDate="'.date('Y-m-d',strtotime($fromDate)).'",toDate="'.date('Y-m-d',strtotime($fromDate)).'",ticketAdultCost="'.$adultCost.'",ticketchildCost="'.$childCost.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",currencyId="'.$resListing['id'].'",status=1,supplierId="'.$selfSupplier.'",serviceid="'.$lastid.'",entranceNameId="'.$lastid.'"';
	 // $lastId2 = addlistinggetlastid(_DMC_ENTRANCE_RATE_MASTER_,$namevalue);
	?>
	<script>
		parent.openinboundpop('action=addServiceGuide&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','1000px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}

// Add Guide to Master
if($_REQUEST['action'] == 'addactivitytomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Sightseeing</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="tomasterform" target="actoinfrm" id="tomasterform">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Sightseeing Name<span class="redmind"></span></div>
						<input name="activityName" type="text" class="gridfield validate" id="activityName" displayname="Activity Name" value="">
						</label>
						</div>
 
					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('tomasterform','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="cityId"/>
 						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input name="action" type="hidden" id="action" value="add_activitytomaster">
 						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceActivity&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','1000px');">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>
	<?php
}

if(trim($_REQUEST['action'])=='add_activitytomaster' && trim($_REQUEST['activityName'])!=''){

	$activityName=clean($_REQUEST['activityName']);
	$perPaxCost = clean($_REQUEST['perPaxCost']);
	if($perPaxCost>0){
		$adultCost = $perPaxCost;
	}else{
		$adultCost = clean($_REQUEST['adultCost']);
	}
	
	$childCost = clean($_REQUEST['childCost']);
	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$fromDate = $_REQUEST['daydate'];
	$cityId = $_REQUEST['cityId'];
	$otherActivityCity = getDestination($_REQUEST['cityId']);
	$selfSupplier = getSelfSupplier();
	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	$dateAdded=time();

	$rsr=GetPageRecord('*',_PACKAGE_BUILDER_OTHER_ACTIVITY_MASTER_,'otherActivityName="'.$activityName.'" and otherActivityCity="'.$otherActivityCity.'" ');
	$editresult=mysqli_num_rows($rsr);
	if(mysqli_num_rows($rsr) > 0){
        ?>
        <script>
        parent.alert('This Activity Name Already Exist !');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
		exit();
    }
    else{
	    	
		$namevalue ='otherActivityName="'.$activityName.'",otherActivityCity="'.$otherActivityCity.'",status=1';
		$lastid=addlistinggetlastid(_PACKAGE_BUILDER_OTHER_ACTIVITY_MASTER_,$namevalue);

		?>
		<script>
			parent.openinboundpop('action=addServiceActivity&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','1000px');
			parent.$('#pageloading').hide();
			parent.$('#pageloader').hide();
		</script>
		<?php
	}


	// $namevalue ='fromDate="'.date('Y-m-d',strtotime($fromDate)).'",toDate="'.date('Y-m-d',strtotime($fromDate)).'",ticketAdultCost="'.$adultCost.'",ticketchildCost="'.$childCost.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",currencyId="'.$resListing['id'].'",status=1,supplierId="'.$selfSupplier.'",serviceid="'.$lastid.'",entranceNameId="'.$lastid.'"';
	 // $lastId2 = addlistinggetlastid(_DMC_ENTRANCE_RATE_MASTER_,$namevalue);
	?>
	<script>
		parent.openinboundpop('action=addServiceActivity&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','1000px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
} 

if($_REQUEST['action'] == 'addentrancetomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Entrance</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_entrancetomaster" target="actoinfrm" id="add_entrancetomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Entrance Name<span class="redmind"></span></div>
						<input name="entranceName" type="text" class="gridfield validate" id="entranceName" displayname="Entrance Name" value="">
						</label>
						</div>
 
					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_entrancetomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="cityId"/>
 						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input name="action" type="hidden" id="action" value="add_entrancetomaster">
 						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceEntrance&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','800px');">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>
	<?php
}

if(trim($_REQUEST['action'])=='add_entrancetomaster' && trim($_REQUEST['entranceName'])!=''){

	$entranceName=clean($_REQUEST['entranceName']);
	$perPaxCost = clean($_REQUEST['perPaxCost']);
	if($perPaxCost>0){
		$adultCost = $perPaxCost;
	}else{
		$adultCost = clean($_REQUEST['adultCost']);
	}
	
	$childCost = clean($_REQUEST['childCost']);
	

	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];
	$cityId = $_REQUEST['cityId'];
	$entranceCity = getDestination($cityId);
	$selfSupplier = getSelfSupplier();
	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	$dateAdded=time();

	$rsr=GetPageRecord('*',_PACKAGE_BUILDER_ENTRANCE_MASTER_,'entranceName="'.$entranceName.'" and entranceCity="'.$entranceCity.'" ');
	$editresult=mysqli_num_rows($rsr);
	if(mysqli_num_rows($rsr) > 0){
        ?>
        <script>
        parent.alert('This Activity Name Already Exist !');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
		exit();
    }
    else{
	    	
		$namevalue ='entranceName="'.$entranceName.'",entranceCity="'.$entranceCity.'",status="1"';
		$lastid=addlistinggetlastid(_PACKAGE_BUILDER_ENTRANCE_MASTER_,$namevalue);

		?>
		<script>
			parent.openinboundpop('action=addServiceGuide&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','1000px');
			parent.$('#pageloading').hide();
			parent.$('#pageloader').hide();
		</script>
		<?php
	}


	// $namevalue ='fromDate="'.date('Y-m-d',strtotime($fromDate)).'",toDate="'.date('Y-m-d',strtotime($fromDate)).'",ticketAdultCost="'.$adultCost.'",ticketchildCost="'.$childCost.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",currencyId="'.$resListing['id'].'",status="1",supplierId="'.$selfSupplier.'",serviceid="'.$lastid.'",entranceNameId="'.$lastid.'"';
	 // $lastId2 = addlistinggetlastid(_DMC_ENTRANCE_RATE_MASTER_,$namevalue);

	?>
	<script>
		parent.openinboundpop('action=addServiceEntrance&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','1200px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}
 
if($_REQUEST['action'] == 'addactivitiestomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);

	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Activity</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>

	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_entrancetomaster" target="actoinfrm" id="add_entrancetomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Activity Name<span class="redmind"></span></div>
						<input name="activityName" type="text" class="gridfield validate" id="activityName" displayname="Activity Name" value="">
						</label>
						</div>

						<div class="griddiv"><label>
						<div class="gridlable">Supplier<span class="redmind"></span></div>
						<select id="supplierId" name="supplierId" class="gridfield validate" displayname="Supplier" autocomplete="off" > 
						<?php     
						$rs1a=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and activityType=3  order by name asc'); 
						while($supplierData=mysqli_fetch_array($rs1a)){   
						?>
						<option value="<?php echo strip($supplierData['id']); ?>" ><?php echo strip($supplierData['name']); ?></option>
						<?php } ?>
						</select>
						</label>
						</div>

						<div class="griddiv">
						<label>
						  <table width="100%">
						  	 <tr>
						  	 	<td width="33%"><div class="gridlable">Activity Cost(<?php echo trim($resListing['name']); ?>)</div>
						<input name="activityCost" type="text" class="gridfield" id="activityCost" displayname="Activity Cost" value="" onkeyup="getPerPaxCost();" ></td>
						  	 	<td width="33%"><div class="gridlable">Pax Range</div>
						<input name="maxPax" type="text" class="gridfield" id="maxPax" displayname="Pax Range" value="" onkeyup="getPerPaxCost();" ></td>
						  	 	
						  	 	<td width="33%"><div class="gridlable">Per Pax Cost(<?php echo trim($resListing['name']); ?>)</div>
						<input name="perPaxCost" type="text" class="gridfield" id="perPaxCost" displayname="Per Pax Cost" value="" onkeyup="getPerPaxCost();" ></td>
						  	 </tr>
						  </table>
						</label>
						</div>
					</td>
			  	</tr>
				</tbody>
			</table>
			
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_entrancetomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $dayData['cityId']; ?>" name="cityId"/>
 						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input name="action" type="hidden" id="action" value="add_acticitiestomaster">
 						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceActivity&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','800px');">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	<script>
		function getPerPaxCost(){ 
		    var activityCost = $('#activityCost').val();
			var maxpax = $('#maxPax').val();  
			var ppCost = Math.round(activityCost/maxpax);
			if(ppCost == 'NaN' || ppCost== Infinity){
			$('#perPaxCost').val(activityCost);
			}else{
			$('#perPaxCost').val(ppCost);
			}
		}
	</script>		
	</div>  
	<?php
}
if(trim($_REQUEST['action'])=='add_acticitiestomaster' && trim($_REQUEST['activityName'])!=''){

	$activityName=clean($_REQUEST['activityName']);
	$activityCost = clean($_REQUEST['activityCost']);
	$supplierId = clean($_REQUEST['supplierId']);
	$perPaxCost = clean($_REQUEST['perPaxCost']);
	$maxPax = clean($_REQUEST['maxPax']);

	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];
	$cityId = $_REQUEST['cityId'];
	$activityCity = getDestination($cityId);
	$rs="";
	$rs=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,' setDefault=1 order by name asc');  
	$resListing=mysqli_fetch_array($rs);

	$dateAdded=time();
	// duplicate added code quatation started
	$rsr=GetPageRecord('*',_PACKAGE_BUILDER_OTHER_ACTIVITY_MASTER_,'otherActivityName="'.$activityName.'" ');
	$editresult=mysqli_num_rows($rsr);
	if(mysqli_num_rows($rsr) > 0 && $_POST['editId'] < 1){
        ?>
        <script>
        parent.alert('This Activity Name Already Exist !');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
		exit();
    }
    else{
		$namevalue ='otherActivityName="'.$activityName.'",otherActivityCity="'.$activityCity.'",status="1"';
		$lastid=addlistinggetlastid(_PACKAGE_BUILDER_OTHER_ACTIVITY_MASTER_,$namevalue);

		$namevalue ='fromDate="'.date('Y-m-d',strtotime($fromDate)).'",toDate="'.date('Y-m-d',strtotime($fromDate)).'",activityCost="'.$activityCost.'",currencyId="'.$resListing['id'].'",status="1",supplierId="'.$supplierId.'",serviceid="'.$lastid.'",otherActivityNameId="'.$lastid.'",maxpax="'.$maxPax.'",perPaxCost="'.$perPaxCost.'"';
		$lastId2 = addlistinggetlastid('dmcotherActivityRate',$namevalue);

		?>
		<script>
			parent.openinboundpop('action=addServiceActivity&dayId=<?php echo $_REQUEST['dayId']; ?>&cityId=<?php echo $dayData['cityId']; ?>','800px');
			parent.$('#pageloading').hide();
			parent.$('#pageloader').hide();
		</script>
		<?php
	}
	// duplicate added code quatation ended
} 

if($_REQUEST['action'] == 'addenroutetomaster'){
	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Enroute</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_enroutetomaster" target="actoinfrm" id="add_enroutetomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">

						<div class="griddiv"><label>
						<div class="gridlable">Enroute Name<span class="redmind"></span></div>
						<input name="enrouteName" type="text" class="gridfield validate" id="enrouteName" displayname="Enroute Name" value="">
						</label>
						</div>

						<div class="griddiv"><label>
						<div class="gridlable">Per Pax Cost(<?php echo getCurrencyName($defualtCurrencyId);?>)<span class="redmind"></span></div>
						<input name="adultCost" type="text" class="gridfield" id="adultCost" displayname="Per Pax Cost" value="">
						</label>
						</div>
 
					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 50%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td width="100" align="left">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_enroutetomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $dayData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $_REQUEST['destId']; ?>" name="destinationId"/>
						<input type="hidden" value="<?php echo $dayData['queryId']; ?>" name="queryId"/>
						<input name="action" type="hidden" id="action" value="add_enroutetomaster">
 						<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceEnroute&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','600px');">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div> 
	<?php
}
if(trim($_REQUEST['action'])=='add_enroutetomaster' && trim($_REQUEST['enrouteName'])!=''){

	$enrouteName=clean($_REQUEST['enrouteName']);
	$adultCost = clean($_REQUEST['adultCost']);
	$childCost = clean($_REQUEST['childCost']);

	$quotationId = $_REQUEST['quotationId'];
	$queryId = $_REQUEST['queryId'];
	$startDayId = $_REQUEST['dayId'];
	$fromDate = $_REQUEST['daydate'];
	$destinationId = $_REQUEST['destinationId'];

	$rs1=GetPageRecord('*',_DESTINATION_MASTER_,'id="'.clean($_REQUEST['destinationId']).'"');
	$destData=mysqli_fetch_array($rs1);
	$enrouteCity = stripslashes($destData['name']);
 
	$dateAdded=time();
	$namevalue ='enrouteName="'.$enrouteName.'",enrouteCity="'.$enrouteCity.'",adultCost="'.$adultCost.'",childCost="'.$childCost.'",status="1"';
	$lastid=addlistinggetlastid(_PACKAGE_BUILDER_ENROUTE_MASTER_,$namevalue);

	?>
	<script>
		parent.openinboundpop('action=addServiceEnroute&enrouteId=<?php echo $lastid; ?>&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $_REQUEST['daydate']; ?>','1200px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}
 
// ///////////////////
if(trim($_REQUEST['action'])=='saveQuotationDetails' && trim($_REQUEST['quotationId'])!='' && trim($_REQUEST['dayroe'])!=''){
 
	$currencyId = $_REQUEST['curren'];
	$dayroe = $_REQUEST['dayroe'];
	if($_REQUEST['asOnDate'] == '01-01-1970'){
		$asOnDate = date('Y-m-d');
	}else{
		$asOnDate = date('Y-m-d',strtotime($_REQUEST['asOnDate']));
	}

	$isInc_exc = $_REQUEST['isInc_exc'];
	// $isUni_Mark = $_REQUEST['isUni_Mark'];
	$markup = $_REQUEST['markup'];
	$markupType = $_REQUEST['markupType'];
	$languageType = $_REQUEST['languageType'];
	$otherLocation = $_REQUEST['otherLocation'];
	$otherLocationCost = $_REQUEST['otherLocationCost'];
	$isOtherLocation = $_REQUEST['isOtherLocation'];
	$isSupp_TRR = $_REQUEST['isSupp_TRR'];
	$flightCostType = $_REQUEST['flightcosttype'];
	$visacosttype = $_REQUEST['visacosttype'];
	$passportcosttype = $_REQUEST['passportcosttype'];
	$insurancecosttype = $_REQUEST['insurancecosttype'];
	$viewQuotation = $_REQUEST['viewQuotation'];
	$costType = $_REQUEST['costType'];
	$discountType = $_REQUEST['discountType'];
	$discount = $_REQUEST['discount'];
	$gitincexNameId = $_REQUEST['gitincexNameId'];
	$fitincexNameId = $_REQUEST['fitincexNameId'];
	$overviewNameId = $_REQUEST['overviewNameId'];

	if($gitincexNameId>0 && $gitincexNameId!='undefined'){
		$fitGitId=$gitincexNameId;
	}elseif($fitincexNameId>0 && $fitincexNameId!='undefined'){
		$fitGitId=$fitincexNameId;
	}

	if($overviewNameId>0 && $overviewNameId!='undefined'){
		$overviewId=$overviewNameId;
	}

	if($_REQUEST['isOtherLocation']==0){
		$otherLocation = 0;
		$otherLocationCost = 0;
	}
	// $itineraryintrText
	// $itinerarysummText

	// serviceupgradationText,optionaltourText

	$overviewText=$highlightsText=$inclusion=$exclusion=$tncText=$specialText=$paymentpolicy=$remarks=$itineraryintrText=$itinerarysummText=$serviceupgradationText=$optionaltourText='';
	if($isInc_exc == 1){
		$overviewText = mysqli_real_escape_string(db(),urldecode($_REQUEST['overviewText']));
		$itineraryintrText = mysqli_real_escape_string(db(),urldecode($_REQUEST['itineraryintrText']));
		$itinerarysummText = mysqli_real_escape_string(db(),urldecode($_REQUEST['itinerarysummText']));
		$highlightsText = mysqli_real_escape_string(db(),urldecode($_REQUEST['highlightsText']));
		$inclusion = mysqli_real_escape_string(db(),urldecode($_REQUEST['inclusionText']));
		$serviceupgradationText = mysqli_real_escape_string(db(),urldecode($_REQUEST['serviceupgradationText']));
		$optionaltourText = mysqli_real_escape_string(db(),urldecode($_REQUEST['optionaltourText']));
		$exclusion = mysqli_real_escape_string(db(),urldecode($_REQUEST['exclusionText']));
		$tncText = mysqli_real_escape_string(db(),urldecode($_REQUEST['termsconditionText']));
		$specialText = mysqli_real_escape_string(db(),urldecode($_REQUEST['cancelationText']));
		$paymentpolicy = mysqli_real_escape_string(db(),urldecode($_REQUEST['paymentpolicyText']));
		$remarks = mysqli_real_escape_string(db(),urldecode($_REQUEST['remarksText']));
	} 

	// isUni_Mark="'.$isUni_Mark.'",isSer_Mark="'.$isSer_Mark.'", 
	$quoteQuery = 'currencyId="'.$currencyId.'",isTransport="'.$_REQUEST['isTransport'].'",serviceTax="'.$_REQUEST['serviceTax'].'",gstType="'.$_REQUEST['gstType'].'",discount="'.$discount.'",tcs="'.$_REQUEST['tcsTax'].'",dayroe="'.$dayroe.'",asOnDate="'.$asOnDate.'",flightCostType="'.$flightCostType.'",overviewText="'.$overviewText.'",itineraryintrText="'.$itineraryintrText.'",itinerarysummText="'.$itinerarysummText.'",highlightsText="'.$highlightsText.'",inclusion="'.$inclusion.'",exclusion="'.$exclusion.'",serviceupgradationText="'.$serviceupgradationText.'",optionaltourText="'.$optionaltourText.'",tncText="'.$tncText.'",specialText="'.$specialText.'",paymentpolicy="'.$paymentpolicy.'",remarks="'.$remarks.'",isInc_exc="'.$isInc_exc.'",isOtherLocation="'.$isOtherLocation.'",languageId="'.$languageType.'",otherLocation="'.$otherLocation.'",otherLocationCost="'.$otherLocationCost.'",isSupp_TRR="'.$isSupp_TRR.'",viewQuotation="'.$viewQuotation.'",saveQuotaiton="1",costType="'.$costType.'",discountType="'.$discountType.'",discount="'.$discount.'",markup="'.$markup.'",markupType="'.$markupType.'",visaCostType="'.$visacosttype.'",passportCostType="'.$passportcosttype.'",insuranceCostType="'.$insurancecosttype.'",fitGitId="'.$fitGitId.'",overviewId="'.$overviewId.'"';
	$wheretnc = 'id="'.decode($_REQUEST['quotationId']).'"';
	// die("testing");
	$edit = updatelisting(_QUOTATION_MASTER_,$quoteQuery,$wheretnc);

}

if(trim($_REQUEST['action'])=='addServiceTypeMarkup' && trim($_REQUEST['quotationId'])!='' ){

	$hotel = $_REQUEST['serMarkup_hotel'];
	$hotelMarkupType = $_REQUEST['hotelMarkupType'];
	$package = $_REQUEST['serMarkup_package'];
	$packageMarkupType = $_REQUEST['packageMarkupType'];
	$guide = $_REQUEST['serMarkup_guide'];
	$guideMarkupType = $_REQUEST['guideMarkupType'];
	$activity = $_REQUEST['serMarkup_activity'];
	$activityMarkupType = $_REQUEST['activityMarkupType'];
	$entrance = $_REQUEST['serMarkup_entrance'];
	$entranceMarkupType = $_REQUEST['entranceMarkupType'];
	$transfer = $_REQUEST['serMarkup_transfer'];
	$transferMarkupType = $_REQUEST['transferMarkupType'];
	$ferry = $_REQUEST['serMarkup_ferry'];
	$ferryMarkupType = $_REQUEST['ferryMarkupType'];
	$train = $_REQUEST['serMarkup_train'];
	$trainMarkupType = $_REQUEST['trainMarkupType'];
	$flight = $_REQUEST['serMarkup_flight'];
	$flightMarkupType = $_REQUEST['flightMarkupType'];
	$restaurant = $_REQUEST['serMarkup_restaurant'];
	$restaurantMarkupType = $_REQUEST['restaurantMarkupType'];
	$other = $_REQUEST['serMarkup_other'];
	$otherMarkupType = $_REQUEST['otherMarkupType'];
	$visa = $_REQUEST['serMarkup_visa'];
	$visaMarkupType = $_REQUEST['visaMarkupType'];
	$passport = $_REQUEST['serMarkup_passport'];
	$passportMarkupType = $_REQUEST['passportMarkupType'];
	$insurance = $_REQUEST['serMarkup_insurance'];
	$insuranceMarkupType = $_REQUEST['insuranceMarkupType'];

	$namevalue11 =' markupType="'.$_REQUEST['markupType'].'",markup="'.$_REQUEST['markup'].'",isUni_Mark="'.$_REQUEST['isUni_Mark'].'",isSer_Mark="'.$_REQUEST['isSer_Mark'].'"';
	$where11='id="'.decode($_REQUEST['quotationId']).'"';
	$update11 = updatelisting(_QUOTATION_MASTER_,$namevalue11,$where11);

	$c12=GetPageRecord('*','quotationServiceMarkup',' quotationId="'.decode($_REQUEST['quotationId']).'"');
	if( mysqli_num_rows($c12) > 0){
	    $namevalue ='package="'.$package.'",hotel="'.$hotel.'",guide="'.$guide.'",activity="'.$activity.'",entrance="'.$entrance.'",transfer="'.$transfer.'",ferry="'.$ferry.'",train="'.$train.'",flight="'.$flight.'",restaurant="'.$restaurant.'",other="'.$other.'",visa="'.$visa.'",passport="'.$passport.'",insurance="'.$insurance.'",packageMarkupType="'.$packageMarkupType.'",hotelMarkupType="'.$hotelMarkupType.'",guideMarkupType="'.$guideMarkupType.'",activityMarkupType="'.$activityMarkupType.'",entranceMarkupType="'.$entranceMarkupType.'",transferMarkupType="'.$transferMarkupType.'",ferryMarkupType="'.$ferryMarkupType.'",trainMarkupType="'.$trainMarkupType.'",flightMarkupType="'.$flightMarkupType.'",restaurantMarkupType="'.$restaurantMarkupType.'",otherMarkupType="'.$otherMarkupType.'",visaMarkupType="'.$visaMarkupType.'",passportMarkupType="'.$passportMarkupType.'",insuranceMarkupType="'.$insuranceMarkupType.'"';

		$where='quotationId="'.decode($_REQUEST['quotationId']).'"';
		$update = updatelisting('quotationServiceMarkup',$namevalue,$where);
	}
	?>
	<script>
		loadquotationmainfile();
	</script>
	<?php
}

if(trim($_REQUEST['action'])=='addAdditionalExperience' && trim($_REQUEST['quotationId'])!='' && trim($_REQUEST['additionalId'])!=''){

	$quotationId=clean(decode($_REQUEST['quotationId']));
	$update = updatelisting(_QUOTATION_MASTER_,' isAddExp="'.$_REQUEST['isAddExp'].'"','id="'.$quotationId.'"');

	$c12=GetPageRecord('*','quotationAdditionalMaster',' quotationId="'.$quotationData['id'].'" and additionalId="'.$_REQUEST['additionalId'].'" and adultCost="'.$_REQUEST['adultCost'].'" ');
	if( mysqli_num_rows($c12) > 0){
		$namevalue ='additionalId="'.$_REQUEST['additionalId'].'",adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'",quotationId="'.$quotationId.'"';
		$where = 'quotationId="'.$quotationData['id'].'" and additionalId="'.$_REQUEST['additionalId'].'" ';
		$update = updatelisting('quotationAdditionalMaster',$namevalue,$where); //Corrrection made here!
	}else{
		$namevalue ='additionalId="'.$_REQUEST['additionalId'].'",adultCost="'.$_REQUEST['adultCost'].'",childCost="'.$_REQUEST['childCost'].'",infantCost="'.$_REQUEST['infantCost'].'",quotationId="'.$quotationId.'"';
		$add=addlistinggetlastid('quotationAdditionalMaster',$namevalue);
	}
	?>
	<script>
		loadAddtionalDatafun();
	</script>
	<?php
}

if(trim($_REQUEST['action'])=='upload_quotBannerAction' && trim($_REQUEST['quotationId'])!='' && ($_FILES["file"]["name"])!=''){
	if($_FILES['file']['name']!=''){
		$file_name=$_FILES['file']['name'];
		$file_name=time().'_'.$file_name;
		copy($_FILES['file']['tmp_name'],"dirfiles/".$file_name);
	}else{
		$file_name = "";
	}

	$add = updatelisting(_QUOTATION_MASTER_,'image="'.$file_name.'"','id="'.$_REQUEST['quotationId'].'"');
	if($add == 'yes'){
         echo json_encode(array("color" => 'blue',"msgs" => "Uploaded"));
	}else{
         echo json_encode(array("color" => 'red',"msgs" => "Error"));
	}
	?>
	<script type="text/javascript">
		$('#showaddmarkup').show();
	</script>
	<?php
}

if(trim($_REQUEST['action'])=='additinerary_plan'  && trim($_REQUEST['dayId'])!=''){

	$QueryDaysQuery=GetPageRecord('*','newQuotationDays',' id="'.trim($_REQUEST['dayId']).'"');
	$QueryDaysData=mysqli_fetch_array($QueryDaysQuery);

	$dayTitle=preg_replace('/\\\\/','',urldecode($QueryDaysData['title']));
	$dayDescription=preg_replace('/\\\\/','',urldecode($QueryDaysData['description']));

	?>
	<div style="border: 1px solid #3b4fb5;margin-top: 10px;"> 
	<script type="text/javascript">
	textEditor1();
	function textEditor1(){
		tinymce.remove(".textEditor1");
		tinymce.init({
			selector: ".textEditor1",
			themes: "modern",
			plugins: [
			"advlist autolink lists link image charmap print preview anchor",
			"searchreplace visualblocks code fullscreen"
			],
			toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
		});
	}
	
	</script>
	<table width="100%" border="0" cellpadding="10" cellspacing="0" bgcolor="#3b4fb5">
	<tr>
	<td width="66%"  style="color:#fff;position: relative;"><?php echo getDestination($QueryDaysData['cityId']);?> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; cursor:pointer; " onclick="loadoverviewpage('<?php echo $QueryDaysData['quotationId']; ?>');"></i></td>
	</tr>
	</table>
	</div>
 
	<div style="padding:10px;position: relative;border: 1px solid #3b4fb5;padding-top: 0;display:none;" id="listBox2" >
	<i class="fa fa-plus" onclick="showBox(1);" style="position:absolute;top: -33px;right: 43px;color: white;font-size: 15px;cursor:pointer;padding: 5px;border: 1px solid;"><span style="font-size: 20px;font-weight: bold;"> Add New</span></i>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable addeditpagebox">
	<thead>
    <tr>
    <th width="4%" align="center" valign="middle" class="header" style="padding-bottom: 10px;">#</th>
    <!--<th align="left" class="header" style="padding-bottom: 10px;">image</th>-->
    <th align="left" class="header" style="padding-bottom: 10px;">Title/Description</th>
    <th align="left" class="header" style="padding-bottom: 10px;">Language</th>
	<th align="left" class="header" style="padding-bottom: 10px;">Action</th>
    </tr>
    </thead>	
	<tbody>
	<?php
	$no=1;
	$rssa1=GetPageRecord('*','iti_subjectmaster','1 and ( fromDestinationId="'.$QueryDaysData['cityId'].'" or toDestinationId="'.$QueryDaysData['cityId'].'" ) and deletestatus=0 and status=1 order by dateAdded desc');
	if(mysqli_num_rows($rssa1) > 0){
		while($resultlists1=mysqli_fetch_array($rssa1)){
			$name = $resultlists1['otherTitle'];
			$description = $resultlists1['description'];
			?>
			<tr>
			<td align="center" valign="middle"><?php echo $no; ?></td>
			<td width="85%" align="left">
				<textarea  rows="5" id="selectTitle<?php echo $resultlists1['id']; ?>" style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;display:none;"  placeholder="Remark"><?php echo stripslashes(($name)); ?>
				</textarea>
				<textarea rows="5" id="selectDescription<?php echo $resultlists1['id']; ?>" style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;display:none;"  placeholder="Remark"><?php echo stripslashes($description); ?></textarea>


				<div id="Title<?php echo $resultlists1['id']; ?>"><strong><?php echo strip_tags($name); ?></strong></div>
				<div id="lanDesc<?php echo $resultlists1['id'];?>"><?php echo substr(strip_tags($description),0,400); ?></div>

				<textarea id="hidddenTitle<?php echo $resultlists1['id']; ?>" style="display: none;visibility: hidden;"><?php echo stripslashes($name); ?></textarea>
				<textarea id="hidddenDesc<?php echo $resultlists1['id']; ?>" style="display: none;visibility: hidden;"><?php echo stripslashes($description); ?></textarea>
			</td>
			<td align="left">
			<select id="languageType<?php echo $resultlists1['id']; ?>" name="languageType" class="gridfield" displayname="Language Type" autocomplete="off" onchange="changeLang<?php echo $resultlists1['id']; ?>(this.value);"  style="padding: 8px; border: 1px #ccc solid; width: 160px;"  >
			 	<option value="0">Default</option>
				<?php 
				 $rs=GetPageRecord('id,name','tbl_languagemaster','1 and status=1 and deletestatus=0');
				$totalrow = mysqli_num_rows($rs);
				while($languageDetails=mysqli_fetch_array($rs)){
				?>
				<option value="<?php echo $languageDetails['id']; ?>"><?php echo trim($languageDetails['name']); ?></option>
				<?php } ?>
			</select>	
			</td>
			<td width="10%" align="left">
			<input  type="button" class="whitembutton submitBtn" id="selectTitle<?php echo $resultlists1['id']; ?>" value="&nbsp;Select&nbsp;" onclick="selectTitle(<?php echo $resultlists1['id']; ?>);" style="background-color: #3b4fb5 !important;margin: 0;color: white;border-radius:2px;">

			<?php
			$rs=GetPageRecord('id,title,description,languageId','subjectLanguageMaster','1 and status=1 and subjectId="'.$resultlists1['id'].'"');
			while($languageTitle=mysqli_fetch_array($rs)){

				$rts=GetPageRecord('id','tbl_languagemaster','1 and id="'.$languageTitle['languageId'].'"');
				$languageId=mysqli_fetch_array($rts);
				?>
				<textarea  id="language<?php echo $resultlists1['id']; ?>Title<?php echo $languageId['id'] ?>" style="display: none;visibility: hidden;"><?php echo trim(stripslashes($languageTitle['title'])) ?></textarea>
				<textarea  id="language<?php echo $resultlists1['id']; ?>Desc<?php echo $languageId['id'] ?>" style="display: none;visibility: hidden;"><?php echo stripslashes($languageTitle['description']) ?></textarea>
				<?php
			}	
			?>
			<script>
				function changeLang<?php echo $resultlists1['id']; ?>(id){
					if(id == 0){ 
						var newtitle = $("#hidddenTitle<?php echo $resultlists1['id']; ?>").val();
						var newdesc = $("#hidddenDesc<?php echo $resultlists1['id']; ?>").val();
					}else{
						var newwtitle = $("#language<?php echo  $resultlists1['id']; ?>Title"+id).val();
						if(newwtitle == "" || newwtitle == undefined){
							var newtitle = "";    
						}else{
							var newtitle = $("#language<?php echo  $resultlists1['id']; ?>Title"+id).val();    
						} 

						var newwdesc  = $("#language<?php echo  $resultlists1['id']; ?>Desc"+id).val();
						if(newwdesc == "" || newwdesc == undefined){
							var newdesc = "";    
						}else{
							var newdesc = $("#language<?php echo  $resultlists1['id']; ?>Desc"+id).val();    
						}
					}
					$("#Title<?php echo $resultlists1['id']; ?>").html('<strong>'+newtitle+'</strong>');
					$("#selectTitle<?php echo $resultlists1['id']; ?>").val(newtitle);

					$("#lanDesc<?php echo $resultlists1['id']; ?>").html('<p>'+newdesc.substring(0, 300)+'</p>');
					$("#selectDescription<?php echo $resultlists1['id']; ?>").val(newdesc);
				} 		
			</script>
			</td>
			</tr>
			
			
			<?php 
			$no++;  
		}
	}
	else{ ?>
		<tr>
		<td colspan="4" align="center" >No Data Found !</td>
		</tr>
		<?php
	} ?>
	</tbody>
	</table>
	</div>

	<div style="padding:10px;border: 1px solid #3b4fb5;" id="detailBox">
	<table width="100%" border="0" cellpadding="5" cellspacing="0">
	  	<tr>
			<td width="50%"><div style="font-size:12px;">Title</div>
				<input name="daySubject" type="text" id="daySubject"  style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;"  value="<?php echo trim(stripslashes($dayTitle)); ?>" >
			</td>
	  	</tr>
	  	<tr>
			<td>
				<div style="font-size:12px;">Description</div>
			  	<textarea name="dayDescription" class="textEditor1" rows="5" id="dayDescription" style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;box-shadow:none;"  placeholder="Remark"><?php echo trim(stripslashes($dayDescription)); ?></textarea> 
			</td>
		</tr>
		 <tr>
		<td>
		<input  type="button" class="whitembutton" value=" + Title/Description" onclick="showBox(2);">
		<!-- <input  type="button" class="whitembutton" value=" + Description" onclick="showBox(4);">  &nbsp; -->
		<input  type="button" class="whitembutton"  value="&nbsp;Close&nbsp;" onclick="loadoverviewpage('<?php echo $QueryDaysData['quotationId']; ?>');" style=" margin: 0; ">&nbsp;
		<input name="Save" type="button" class="whitembutton submitBtn" id="Save" value="&nbsp;Save&nbsp;" onclick="saveitinerarydata();" style="background-color: #3b4fb5 !important;margin: 0;color: white;">

        &nbsp;
        <span id="msgShow" style="color:green;display:none;">Successfully Added.</span>

 		 </td>
		</tr>
	</table>

	</div>
	<script>

		<?php
		//echo $QueryDaysData['title'];
		if($QueryDaysData['title']==''){ ?>
			showBox(2);
		<?php } else { ?>
			showBox(1);
		<?php } ?>

		function showBox(box){
			$('#listBox2').hide();
			if(box == 2){
			 	$('#listBox2').show();
				$('#detailBox').hide();
			}
			if(box == 1){
				$('#listBox2').hide();
				$('#detailBox').show();
			}
		}

		function selectDesc(id){
			var selectDesc = $('#selectDescription'+id).val(); 
			//$('#dayDescription').text(decodeURI(selectDesc));
			tinymce.get('dayDescription').setContent(selectDesc);
  
			$('#listBox2').hide();
			$('#detailBox').show();
		}

		function selectTitle(id){
			var selectTitle = $('#selectTitle'+id).val();
			$('#daySubject').val(decodeURI(selectTitle));
			
			var selectDesc = $('#selectDescription'+id).val(); 
			tinymce.get('dayDescription').setContent(selectDesc);
			 
			$('#listBox2').hide();
			$('#detailBox').show();
			
		}

		function saveitinerarydata(){
			var daySubject = $('#daySubject').val();
			var dayDescription = tinymce.get("dayDescription").getContent();
			var savequotationitinerary = 'savequotationitinerary';
			$.ajax({
				type: "POST",
				url: 'inboundpop.php',
				data: {title: encodeURI(daySubject), description: encodeURI(dayDescription), dayid: <?php echo $QueryDaysData['id']; ?>, action: savequotationitinerary, quotationId: '<?php echo $QueryDaysData['quotationId']; ?>'},
				success: function(data){
				    $('#msgShow').show();
				    setTimeout(function(){
				        $('#msgShow').hide(); 
				    }, 1000);  
				    loadquotationmainfile();

				}
			});
		}

		function loadoverviewpage(id){
			tinymce.remove(".textEditor1"); 
	  		closeinbound();
	  		loadquotationmainfile(); 
	  	}
		</script>
	<?php

}

if(trim($_REQUEST['action'])=='savequotationitinerary'  && $_REQUEST['dayid']!=''){
	$namevalue ='title="'.addslashes($_REQUEST['title']).'",description="'.addslashes($_REQUEST['description']).'"';
	$where='id="'.$_REQUEST['dayid'].'"';
	updatelisting('newQuotationDays',$namevalue,$where);
	 
} 
if(trim($_REQUEST['action'])=='selectDescription'  && $_REQUEST['dayid']!=''){
    
    $rs=GetPageRecord('*','iti_subjectmaster','id="'.$_REQUEST['itineryinfoId'].'"');
    $itineryinfoDetails=mysqli_fetch_array($rs);
    $description = $itineryinfoDetails['description'];	
    echo $description;die();
}

//select Mode
if(trim($_REQUEST['action'])=='addtransferMode' && trim($_REQUEST['dayId'])!='' ){

	$QueryDaysQuery=GetPageRecord('*','newQuotationDays',' id="'.trim($_REQUEST['dayId']).'"');
	$QueryDaysData=mysqli_fetch_array($QueryDaysQuery);
?>

	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Select Mode</span>
		<i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer;" onclick="closeinbound();"></i>
	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_transferMode" target="actoinfrm" id="add_transferMode">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<?php
				$modeSql=GetPageRecord('*','quotationModeMaster',' 1 and quotationId="'.$QueryDaysData['quotationId'].'" and dayId ="'.$_REQUEST['dayId'].'"');
				$modeData=mysqli_fetch_array($modeSql);
				?>
				<tr style="background-color:transparent !important;"> 
					<td width="30" align="left">
						<div class="griddiv labelbox">
							<input name="mode" type="radio" id="train" value="train" <?php if($modeData['name'] == 'train'){ echo "checked";} ?> >
							<label class="label" for="train">Train</label>
						</div>
					</td>
					<td width="30" align="left">
						<div class="griddiv labelbox">
							<input name="mode" type="radio" id="flight" value="flight" <?php if($modeData['name'] == 'flight'){ echo "checked";} ?> >
							<label class="label" for="flight">Flight</label>
						</div>
					</td>
			  	</tr>
				</tbody>
			</table>
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style=" float: left;width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">
					<td  align="right" colspan="3" style="    border-bottom: #ffffff 1px solid;">
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_transferMode','submitbtn','0');">
						<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
						<input type="hidden" value="<?php echo $QueryDaysData['srdate']; ?>" name="daydate"/>
						<input type="hidden" value="<?php echo $QueryDaysData['quotationId']; ?>" name="quotationId"/>
						<input type="hidden" value="<?php echo $QueryDaysData['queryId']; ?>" name="queryId"/>
 						<input name="action" type="hidden" id="action" value="add_transferMode">
 					</td>
			  	</tr>
				</tbody>
			</table>
			</form>
		</div>
	</div>
	<style>
	.labelbox{
	    border-radius: 5px;
		border: 1px solid;
		overflow: hidden;
	    border-bottom: 3px #7a96ff solid!important;
		text-align: center;
	}

	.labelbox input + .label {
		color: #000!important;
		background-color: #fff;
	}
	.labelbox input:checked + .label {
		color: #fff!important;
		background-color: #233a49;
	}
	.labelbox input{
		position: absolute;
    	visibility: hidden;
	}
	.labelbox .label {
		display: inline-block;
		max-width: 100%;
		width: 100%;
		font-size: 12px;
		height: 20px;
		padding: 7px 0 0;
	}
	</style>
	<?php
}

if(trim($_REQUEST['action'])=='add_transferMode'){

 	if(trim($_REQUEST['mode'])!=''){
		$mode=clean($_REQUEST['mode']);

		$quotationId = $_REQUEST['quotationId'];
		$queryId = $_REQUEST['queryId'];
		$dayId = $_REQUEST['dayId'];
		$dateAdded=time();
		$namevalue ='name="'.$mode.'",quotationId="'.$quotationId.'",queryId="'.$queryId.'",dayId="'.$dayId.'",dateAdded="'.$dateAdded.'"';
		$where1 = 'quotationId="'.$_REQUEST['quotationId'].'" and dayId ="'.$_REQUEST['dayId'].'"';

		$modeSql=GetPageRecord('*','quotationModeMaster',$where1);
		$modenum=mysqli_num_rows($modeSql);

		if($modenum > 0){
			$update=updatelisting('quotationModeMaster',$namevalue,$where1);
		}else{
			$add=addlistinggetlastid('quotationModeMaster',$namevalue);
		}
	}
	?>
	<script>
	parent.closeinbound();
	parent.loadquotationmainfile();
	parent.$('#pageloading').hide();
	parent.$('#pageloader').hide();
  	</script>
	<?php
}


//for addFlightTimeDetails
if($_REQUEST['action'] == 'addFlightTimeDetails' && $_REQUEST['flightQuoteId'] != ''){
	$c1=GetPageRecord('*','flightTimeLineMaster',' flightQuoteId="'.$_REQUEST['flightQuoteId'].'" ');
	
	

	$c=GetPageRecord('*','quotationFlightMaster',' id="'.$_REQUEST['flightQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);
	
// 		from and to geting 
		$jfrom = getDestination($hotelQuotData['departureFrom']); 
		$jto= getDestination($hotelQuotData['arrivalTo']);

	if(mysqli_num_rows($c1) > 0){
		$entTimeData= mysqli_fetch_array($c1);
		$id = $entTimeData['id'];
		$departureDate = date('Y-m-d', strtotime($entTimeData['departureDate']));
		$departureTime = date('H:i', strtotime($entTimeData['departureTime'])); 
		$arrivalTime = date('H:i', strtotime($entTimeData['arrivalTime'])); 
		$arrivalDate = date('Y-m-d', strtotime($entTimeData['arrivalDate'])); 
		$via = $entTimeData['via'];
		$remark = $entTimeData['remark'];
	}else{
		$id = "";
		$departureDate = date('Y-m-d',strtotime($hotelQuotData['fromDate']));
		$departureTime = date('H:i'); 
		$arrivalTime = date('H:i'); 
		$arrivalDate = date('Y-m-d'); 
		$via = $entTimeData['via'];
		$remark = $entTimeData['remark']; 

	}
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Flight Timeline  </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">


                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Departure&nbsp;From</strong></label>
					<input type="text" id="departurefrom" name="departurefrom" value="<?=  $jfrom ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
					   
                       </div>
                    </td>



                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Departure&nbsp;To</strong></label>
					<input type="text" id="departureto" name="departureto" value="<?=  $jto ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
					   
                       </div>
                    </td>
                    
                    
                    
                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Via&nbsp;</strong></label>
					<input type="text" id="via" name="via" value="<?php echo $via ;?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
					   
                       </div>
                    </td>


                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Departure&nbsp;Date</strong></label>
					<input type="date" id="departureDate" name="departureDate" value="<?=  $departureDate ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
					   
                       </div>
                    </td>
                   
					

                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Departure&nbsp;Time</strong></label>
                    <input type="text" id="departuretime" name="departuretime" value="<?=  $departureTime ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" 
					class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"/>
                    
                    </div>
                    </td>
                    

                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>ARRIVAL&nbsp;DATE</strong></label>
					<input type="date" id="Arrivaldate" name="Arrivaldate" value="<?=  $arrivalDate ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
					   
                       </div>
                    </td>
                    
					<td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>ARRIVAL&nbsp;TIME</strong></label>
 					   <input type="text" id="Arrivaltime" name="Arrivaltime" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $arrivalTime; ?>"/>
					   
                       </div>
                    </td>
                    
                    </tr>
                    <!--<tr>-->

                    <!-- <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Arrival&nbsp;Date</strong></label> 
					<input type="date" id="arrivalDate" name="arrivalDate" value="<?= $arrivalDate; ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
                       </div>
                    </td>

					<td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Arrival&nbsp;Time</strong></label> 
					   <input type="text" id="arrivalTime" name="arrivalTime" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"  value="<?php echo $arrivalTime; ?>"/>
                       </div>
                    </td> -->

					

			  	<!--</tr>-->
			  	<tr>
			  	    <table>
			  	        <tr>
			  	            <td width="90%"><div class="griddiv" style="border:none;">
						<label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Remark&nbsp;</strong></label> 
				 <input type="text" id="remark" name="remark" value="<?php echo $remark;?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield" />
                       </div>
                    </td>
					<td >
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_hoteltomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $id; ?>" name="flightTimeId"/>
						<input type="hidden" value="<?php echo $_REQUEST['flightId'] ?>" name="flightId"/>
						<input type="hidden" value="<?php echo $_REQUEST['dayId'] ?>" name="dayId"/>
 						<input type="hidden" value="<?php echo $_REQUEST['flightQuoteId']; ?>" name="flightQuoteId"/>
						<input name="action" type="hidden" id="action" value="add_FlightTimeline">
  					</td>

			  	        </tr>
			  	    </table>
			  	</tr>
				</tbody>
			</table>
			<script type="text/javascript" src="js/jquery.timepicker.js"></script>  
			<script type="text/javascript"> 
				$(document).ready(function(){
					$('.timepicker2').timepicker();	
				});  
			</script>
			</form>
		</div>
	</div>
	<?php
}

// train time line
if($_REQUEST['action'] == 'addTrainTimeDetails' && $_REQUEST['trainQuoteId'] != ''){
	$c1=GetPageRecord('*','trainTimeLineMaster',' trainQuoteId="'.$_REQUEST['trainQuoteId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');

	$c=GetPageRecord('*','quotationTrainsMaster',' id="'.$_REQUEST['trainQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);

	if(mysqli_num_rows($c1) > 0){
		$entTimeData= mysqli_fetch_array($c1);
		$id = $entTimeData['id'];
		$departureDate = date('Y-m-d', strtotime($entTimeData['departureDate']));
		$departureTime = date('H:i', strtotime($entTimeData['departureTime'])); 
		$arrivalTime = date('H:i', strtotime($entTimeData['arrivalTime'])); 
		$arrivalDate = date('Y-m-d', strtotime($entTimeData['arrivalDate'])); 
		$remark = $entTimeData['remark']; 
	}else{
		$id = "";
		$departureDate = date('Y-m-d',strtotime($hotelQuotData['fromDate']));
		$departureTime = date('H:i'); 
		$arrivalTime = date('H:i'); 
		$arrivalDate = date('Y-m-d'); 
		$remark = $entTimeData['remark']; 

	}
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Train Timeline  </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">

                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Departure&nbsp;Date</strong></label>
					<input type="date" id="departureDate" name="departureDate" value="<?=  $departureDate ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
					   
                       </div>
                    </td>

					<td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Departure&nbsp;Time</strong></label>
 					   <input type="text" id="departureTime" name="departureTime" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $departureTime; ?>"/>
					   
                       </div>
                    </td>

                    <td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Arrival&nbsp;Date</strong></label> 
					<input type="date" id="arrivalDate" name="arrivalDate" value="<?= $arrivalDate; ?>" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;"/>
                       </div>
                    </td>

					<td width="15%"><div class="griddiv" style="border:none;"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Arrival&nbsp;Time</strong></label> 
					   <input type="text" id="arrivalTime" name="arrivalTime" style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"  value="<?php echo $arrivalTime; ?>"/>
                       </div>
                    </td>

					<td width="40%"><div class="griddiv" style="border:none;">
						<label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Remark&nbsp;</strong></label> 
				 <input type="text" id="remark" name="remark" <?php 
				echo $remark; ?> style="text-align:left;width:90%;padding: 3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield"/>
                       </div>
                    </td>
					<td >
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_hoteltomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $id; ?>" name="trainTimeId"/>
						<input type="hidden" value="<?php echo $_REQUEST['trainId'] ?>" name="trainId"/>
						<input type="hidden" value="<?php echo $_REQUEST['dayId'] ?>" name="dayId"/>
 						<input type="hidden" value="<?php echo $_REQUEST['trainQuoteId']; ?>" name="trainQuoteId"/>
						<input name="action" type="hidden" id="action" value="add_TrainTimeline">
  					</td>


			  	</tr>
				</tbody>
			</table>
			<script type="text/javascript" src="js/jquery.timepicker.js"></script>  
			<script type="text/javascript"> 
				$(document).ready(function(){
					$('.timepicker2').timepicker();	
				});  
			</script>
			</form>
		</div>
	</div>
	<?php
}

		if(trim($_REQUEST['action'])=='add_TrainTimeline' && trim($_REQUEST['trainQuoteId'])!=''){


			$departureTime = date('H:i:s', strtotime($_REQUEST['departureTime']));
			$arrivalTime = date('H:i:s', strtotime($_REQUEST['arrivalTime']));
			$departureDate = date('Y-m-d', strtotime($_REQUEST['departureDate']));
			$arrivalDate = date('Y-m-d', strtotime($_REQUEST['arrivalDate']));
			$remark = $_REQUEST['remark'];
			$trainId = $_REQUEST['trainId'];
			$dayId = $_REQUEST['dayId'];

		$c=GetPageRecord('*','quotationTrainsMaster',' id="'.$_REQUEST['trainQuoteId'].'"');
		$trainQuotData=mysqli_fetch_array($c);

		$c1=GetPageRecord('*','trainTimeLineMaster',' trainQuoteId="'.$_REQUEST['trainQuoteId'].'"');
		if(mysqli_num_rows($c1) == 0 && trim($_REQUEST['trainTimeId']) < 1){

			$namevalue ='quotationId="'.$trainQuotData['quotationId'].'",trainQuoteId="'.$_REQUEST['trainQuoteId'].'",departureTime="'.$departureTime.'",arrivalTime="'.$arrivalTime.'",departureDate="'.$departureDate.'",arrivalDate="'.$arrivalDate.'",remark="'.$remark.'",trainId="'.$trainId.'",dayId="'.$dayId.'",status=1';
			$hotelSupHot = addlistinggetlastid('trainTimeLineMaster',$namevalue);
		}else{
			$namevalue ='quotationId="'.$trainQuotData['quotationId'].'",trainQuoteId="'.$_REQUEST['trainQuoteId'].'",departureTime="'.$departureTime.'",arrivalTime="'.$arrivalTime.'",departureDate="'.$departureDate.'",arrivalDate="'.$arrivalDate.'",remark="'.$remark.'",trainId="'.$trainId.'",dayId="'.$dayId.'",status=1';
			$updatelist = updatelisting('trainTimeLineMaster',$namevalue,'id="'.trim($_REQUEST['trainTimeId']).'"');
		}
		?>
		<script>
			parent.closeinbound();
			parent.loadquotationmainfile();
			parent.$('#pageloading').hide();
			parent.$('#pageloader').hide();
		</script>
		<?php
		}


//for addEntranceTimeDetails
if($_REQUEST['action'] == 'addEntranceTimeDetails' && $_REQUEST['entranceQuoteId'] != ''){

	
	$c=GetPageRecord('*','quotationEntranceMaster',' id="'.$_REQUEST['entranceQuoteId'].'" ');
	$entQuoteData = mysqli_fetch_assoc($c);

	$e=GetPageRecord('*','packageBuilderEntranceMaster',' id="'.$entQuoteData['entranceNameId'].'" ');
	$entData = mysqli_fetch_assoc($e);

	if($entQuoteData['transferType']==1){
		$tranferType = 'SIC';
	}elseif($entQuoteData['transferType']==2){
		$tranferType = 'PVT';
	}


	$c1=GetPageRecord('*','quotationEntranceTimelineDetails',' hotelQuoteId="'.$_REQUEST['entranceQuoteId'].'" ');
	if(mysqli_num_rows($c1) > 0){
		$entTimeData= mysqli_fetch_array($c1);
		$id = $entTimeData['id'];
		$startTime = date('H:i', strtotime($entTimeData['startTime']));
		$endTime = date('H:i', strtotime($entTimeData['endTime'])); 
		$dropTime = date('H:i', strtotime($entTimeData['dropTime'])); 
		$pickupTime = date('H:i', strtotime($entTimeData['pickupTime'])); 
		$departureDate = date('Y-m-d', strtotime($entTimeData['departureDate'])); 
		$pickupAddress = $entTimeData['pickupAddress']; 
		$dropAddress = $entTimeData['dropAddress']; 
	}else{
		$id = "";
		$startTime = "";
		$endTime = "";
		$dropTime = "";
		$pickupTime = "";
		$departureDate = $entQuoteData['fromDate'];
	}
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Monument Timeline  </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
					<tr>
						<td align="left" colspan="7" style="font-weight: 500;font-size:15px;">Monument Name:- <?php echo $entData['entranceName'].' | '.$tranferType; ?></td>
					</tr>
				<tr style="background-color:transparent !important;">

                    <td width=" 15%;">
						<div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Start&nbsp;Time</strong><br></label>
 					   <input type="text" id="startTime" name="startTime" style="text-align:left;width:100%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $startTime; ?>"/>
					   
                       </div>
                    </td>

                    <td width=" 15%;"><div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>End&nbsp;Time</strong><br></label> 
					   <input type="text" id="endTime" name="endTime" style="text-align:left;width:100%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"  value="<?php echo $endTime; ?>"/>
                       </div>
                    </td>

					<td colspan="5">&nbsp;</td>

					
			  	</tr>

				<tr>
				<td colspan="7" ><div style="font-weight:500;font-size: 15px;">Transfer Information</div></td>
				</tr>
				<tr>
				<td>
						<div class="griddiv">
						<label>
							<div class="gridlable">Date</div>
						<input type="date" id="departureDate" name="departureDate" class="gridfield" value="<?= $departureDate; ?>"/>
						</label>
						</div>
					</td>

					<td>
						<div class="griddiv">
						<label>
							<div class="gridlable">Pick-up Time</div>
						<input type="text" id="pickupTime" name="pickupTime" style="text-align:left;width:100%;padding:3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"  value="<?php echo $pickupTime; ?>"/>
						</label>
						</div>
					</td>

					<td>
						<div class="griddiv">
						<label>
							<div class="gridlable">Drop Time</div>
						<input type="text" id="dropTime" name="dropTime" style="text-align:left;width:100%;padding:3px;border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true"  value="<?php echo $dropTime; ?>"/>
						</label>
						</div>
					</td>

					<td>
						<div class="griddiv">
						<label>
							<div class="gridlable">Pick-up Address</div>
						<input type="text" id="pickupAddress" name="pickupAddress" class="gridfield"  value="<?php echo $pickupAddress; ?>"/>
						</label>
						</div>
					</td>

					<td>
						<div class="griddiv">
						<label>
							<div class="gridlable">Drop Address</div>
						<input type="text" id="dropAddress" name="dropAddress" class="gridfield" value="<?php echo $dropAddress; ?>"/>
						</label>
						</div>
					</td>

					<td >
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_hoteltomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $id; ?>" name="entranceTimeId"/>
 						<input type="hidden" value="<?php echo $_REQUEST['entranceQuoteId']; ?>" name="entranceQuoteId"/>
						<input name="action" type="hidden" id="action" value="add_EntranceTimeline">
  					</td>
				</tr>
				</tbody>
			</table>
			<script type="text/javascript" src="js/jquery.timepicker.js"></script>  
			<script type="text/javascript"> 
				$(document).ready(function(){
					$('.timepicker2').timepicker();	
				});  
			</script>
			</form>
		</div>
	</div>

<?php
}
?>


<?php
if(trim($_REQUEST['action'])=='add_EntranceTimeline' && trim($_REQUEST['entranceQuoteId'])!=''){
	// quotation hotel data entranceTimeId 
	$c=GetPageRecord('*','quotationEntranceMaster',' id="'.$_REQUEST['entranceQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);

	$c1=GetPageRecord('*','quotationEntranceTimelineDetails',' hotelQuoteId="'.$_REQUEST['entranceQuoteId'].'"');
	if(mysqli_num_rows($c1) == 0 && trim($_REQUEST['entranceTimeId']) < 1){

		if($_REQUEST['startTime']!=''){
		$startTime = date('H:i:s', strtotime($_REQUEST['startTime']));
		}else{
			$startTime='';
		}

		if($_REQUEST['endTime']!=''){
			$endTime = date('H:i:s', strtotime($_REQUEST['endTime']));
		}else{
			$endTime = '';
		}
		
		if($_REQUEST['dropTime']!=''){
			$dropTime = date('H:i:s', strtotime($_REQUEST['dropTime']));
		}else{
			$dropTime = '';
		}
		if($_REQUEST['pickupTime']!=''){
			$pickupTime = date('H:i:s', strtotime($_REQUEST['pickupTime']));
		}else{
			$pickupTime = '';	
		}
		
		$departureDate = date('Y-m-d', strtotime($_REQUEST['departureDate']));
		$pickupAddress = $_REQUEST['pickupAddress'];
		$dropAddress = $_REQUEST['dropAddress'];

		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",supplierId="'.$hotelQuotData['supplierId'].'",hotelQuoteId="'.$_REQUEST['entranceQuoteId'].'",startTime="'.$startTime.'",endTime="'.$endTime.'",dropTime="'.$dropTime.'",pickupTime="'.$pickupTime.'",departureDate="'.$departureDate.'",pickupAddress="'.$pickupAddress.'",dropAddress="'.$dropAddress.'"';
		$hotelSupHot = addlistinggetlastid('quotationEntranceTimelineDetails',$namevalue);
	}else{
		if($_REQUEST['startTime']!=''){
			$startTime = date('H:i:s', strtotime($_REQUEST['startTime']));
			}else{
				$startTime='';
			}
	
			if($_REQUEST['endTime']!=''){
				$endTime = date('H:i:s', strtotime($_REQUEST['endTime']));
			}else{
				$endTime = '';
			}
			
			if($_REQUEST['dropTime']!=''){
				$dropTime = date('H:i:s', strtotime($_REQUEST['dropTime']));
			}else{
				$dropTime = '';
			}
			if($_REQUEST['pickupTime']!=''){
				$pickupTime = date('H:i:s', strtotime($_REQUEST['pickupTime']));
			}else{
				$pickupTime = '';	
			}
			
			$departureDate = date('Y-m-d', strtotime($_REQUEST['departureDate']));
			$pickupAddress = $_REQUEST['pickupAddress'];
			$dropAddress = $_REQUEST['dropAddress'];
	
		$namevalue ='startTime="'.$_REQUEST['startTime'].'",endTime="'.$_REQUEST['endTime'].'",dropTime="'.$dropTime.'",pickupTime="'.$pickupTime.'",departureDate="'.$departureDate.'",pickupAddress="'.$pickupAddress.'",dropAddress="'.$dropAddress.'"';
		$updatelist = updatelisting('quotationEntranceTimelineDetails',$namevalue,'id="'.trim($_REQUEST['entranceTimeId']).'"');
	}
	?>
	<script>
		parent.closeinbound();
		parent.loadquotationmainfile();
  		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}
?>


<?php
if(trim($_REQUEST['action'])=='add_FlightTimeline' && trim($_REQUEST['flightQuoteId'])!=''){
	// quotation hotel data entranceTimeId 


// departurefrom,departureto,via,departureDate,departuretime,Arrivaldate, Arrivaltime,remark


        $departurefrom = $_REQUEST['departurefrom'];
        $departureto = $_REQUEST['departureto'];
        $via = $_REQUEST['via'];
        
		$departureTime = date('H:i:s', strtotime($_REQUEST['departuretime']));
		$arrivalTime = date('H:i:s', strtotime($_REQUEST['Arrivaltime']));
		$departureDate = date('Y-m-d', strtotime($_REQUEST['departureDate']));
		$arrivalDate = date('Y-m-d', strtotime($_REQUEST['Arrivaldate']));
		$remark = $_REQUEST['remark'];
		
		$flightId = $_REQUEST['flightId'];
		$dayId = $_REQUEST['dayId'];

	$c=GetPageRecord('*','quotationFlightMaster',' id="'.$_REQUEST['flightQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);
	
	

	$c1=GetPageRecord('*','flightTimeLineMaster',' flightQuoteId="'.$_REQUEST['flightQuoteId'].'"');
	if(mysqli_num_rows($c1) == 0 && trim($_REQUEST['flightTimeId']) < 1){

		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",flightQuoteId="'.$_REQUEST['flightQuoteId'].'",departureTime="'.$departureTime.'",arrivalTime="'.$arrivalTime.'",departureDate="'.$departureDate.'",arrivalDate="'.$arrivalDate.'",remark="'.$remark.'",departurefrom="'.$departurefrom.'",departureto="'.$departureto.'",via="'.$via.'",flightId="'.$flightId.'",dayId="'.$dayId.'",status=1';
		$hotelSupHot = addlistinggetlastid('flightTimeLineMaster',$namevalue);
	}else{
		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",flightQuoteId="'.$_REQUEST['flightQuoteId'].'",departureTime="'.$departureTime.'",arrivalTime="'.$arrivalTime.'",departureDate="'.$departureDate.'",arrivalDate="'.$arrivalDate.'",remark="'.$remark.'",departurefrom="'.$departurefrom.'",departureto="'.$departureto.'",via="'.$via.'",flightId="'.$flightId.'",dayId="'.$dayId.'",status=1';
		$updatelist = updatelisting('flightTimeLineMaster',$namevalue,'id="'.trim($_REQUEST['flightTimeId']).'"');
	}
	?>
	<script>
		parent.closeinbound();
		parent.loadquotationmainfile();
  		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}
?>


<?php
//for addEntranceTimeDetails
if($_REQUEST['action'] == 'addActivityTimeDetails' && $_REQUEST['activityQuoteId'] != ''){
	$c1=GetPageRecord('*','quotationActivityTimelineDetails',' hotelQuoteId="'.$_REQUEST['activityQuoteId'].'" ');
	if(mysqli_num_rows($c1) > 0){
		$entTimeData= mysqli_fetch_array($c1);
		$startTime = date('H:i', strtotime($entTimeData['startTime']));
		$endTime = date('H:i', strtotime($entTimeData['endTime'])); 
		$id = $entTimeData['id'];
	}else{
		$id = "";
		$startTime = "";
		$endTime = "";
	}
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add SightSeeing Timeline  </span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>	</div>
	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
			<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
			<table  border="0" cellpadding="0" cellspacing="0" class="tablesorter gridtable" style="width: 100%!important; padding:5px; border:0px #e3e3e3 solid;background-color: #fff;">
				<tbody>
				<tr style="background-color:transparent !important;">

                    <td><div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>Start&nbsp;Time</strong></label>
 					   <input type="text" id="startTime" name="startTime" style="text-align:left;width:90%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $startTime;?>"/>
                       </div>
                    </td>

                    <td><div class="griddiv"><label for="ArribleTime" style="font-size:12px;color: #333333;"><strong>End&nbsp;Time</strong></label>
 					   <input type="text" id="endTime" name="endTime" style="text-align:left;width:90%;padding: 3px;
    border: 1px solid #ccc;border-radius: 2px;" class="gridfield timepicker2" data-time-format="H:i" placeholder="00:00" data-step="5" data-min-time="12:00" data-max-time="11:59"  data-show-2400="true" value="<?php echo $endTime;?>"/>
                       </div>
                    </td>

					<td >
						<input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_hoteltomaster','submitbtn','0');">
						<input type="hidden" value="<?php echo $id; ?>" name="activityTimeId"/>
 						<input type="hidden" value="<?php echo $_REQUEST['activityQuoteId']; ?>" name="activityQuoteId"/>
						<input name="action" type="hidden" id="action" value="add_ActivityTimeline">
  					</td>
			  	</tr>
				</tbody>
			</table>
			<script type="text/javascript" src="js/jquery.timepicker.js"></script>   
			<script type="text/javascript"> 
				$(document).ready(function(){
				 	$('.timepicker2').timepicker();	
					
				});  
			</script>
			</form>
		</div>
	</div>

<?php
}
?>

<?php
if(trim($_REQUEST['action'])=='add_ActivityTimeline' && trim($_REQUEST['activityQuoteId'])!=''){
	// quotation hotel data
	$c=GetPageRecord('*',_QUOTATION_OTHER_ACTIVITY_MASTER_,' id="'.$_REQUEST['activityQuoteId'].'"');
	$hotelQuotData=mysqli_fetch_array($c);

	$c1=GetPageRecord('*','quotationActivityTimelineDetails',' hotelQuoteId="'.$_REQUEST['activityQuoteId'].'" ');
	if(mysqli_num_rows($c1) == 0 && trim($_REQUEST['activityTimeId']) < 1){ 
		$startTime = date('H:i:s', strtotime($_REQUEST['startTime']));
		$endTime = date('H:i:s', strtotime($_REQUEST['endTime'])); 
		$namevalue ='quotationId="'.$hotelQuotData['quotationId'].'",dayId="'.$_REQUEST['dayId'].'",hotelQuoteId="'.$hotelQuotData['id'].'",startTime="'.$startTime.'",endTime="'.$endTime.'"';
		$hotelSupHot = addlistinggetlastid('quotationActivityTimelineDetails',$namevalue); 
	}else{
		$namevalue ='startTime="'.$_REQUEST['startTime'].'",endTime="'.$_REQUEST['endTime'].'"';
		$updatelist = updatelisting('quotationActivityTimelineDetails',$namevalue,'id="'.trim($_REQUEST['activityTimeId']).'"');
	}
	?>
	<script>
		parent.closeinbound();
		parent.loadquotationmainfile();
  		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
	</script>
	<?php
}

// Add New Restaurant end here ============================
if($_REQUEST['action'] == 'addeditrestauranttomaster'){

	$dayQuery=GetPageRecord('*','newQuotationDays',' id="'.$_REQUEST['dayId'].'"');
	$dayData = mysqli_fetch_array($dayQuery);
	?>
	<div style="font-size:16px;padding:10px;position:relative;background-color: #f1f1f1;">
		<span id="hotelcounding">Add Restaurant</span> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onclick="closeinbound();"></i>
	</div>
	<div style="padding:20px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" style="padding:0px;">
	
			<form action="inboundpop.php" method="post" enctype="multipart/form-data" name="addmasters" target="actoinfrm" id="addmasters">
				<div class="griddiv">
					<label>
						<div class="gridlable">Restaurant Name<span class="redmind"></span></div>
						<input name="serviceName" type="text" class="gridfield validate" id="serviceName" displayname="Restaurant Name" value="<?php echo $serviceName; ?>" maxlength="100" />
					</label>
				</div> 
				<input type="hidden" value="<?php echo $_REQUEST['dayId']; ?>" name="dayId"/>
				<input type="hidden" value="<?php echo $_REQUEST['destinationId']; ?>" name="cityId"/>
				<input type="hidden" value="<?php echo $dayData['quotationId']; ?>" name="quotationId"/>
				<input name="action" type="hidden" id="action" value="addedit_restauranttomaster" />
			</form>
			<div id="buttonsbox" style="text-align:center;">
				<table border="0" align="right" cellpadding="0" cellspacing="0">
					<tr>
						<td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('addmasters','submitbtn','0');" /></td> 
						<td style="padding-right:20px;">
							<input type="button" name="Submit" value=" Back To Search " class="bluembutton" onclick="openinboundpop('action=addServiceMealPlan&dayId=<?php echo $_REQUEST['dayId']; ?>&d=<?php echo $dayData['srdate']; ?>','800px');">
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
	<?php
}

// Additional Restaurant start
if(trim($_POST['action'])=='addedit_restauranttomaster' && trim($_POST['serviceName'])!=''){ 
	$serviceName=clean($_POST['serviceName']);
	$destinationId = $_POST['destinationId']; 
	$dateAdded=time();
	
	// duplicate added code
	$rsr=GetPageRecord('*',_INBOUND_MEALPLAN_MASTER_,'mealPlanName="'.$serviceName.'" ');
	// $editresult=mysqli_num_rows($rsr);
	if(mysqli_num_rows($rsr) > 0){
        ?>
        <script>
        parent.alert('This Restaurant Name Already Exist!');
		parent.$('#pageloader').hide();
		parent.$('#pageloading').hide();
        </script> 
        <?php 
		exit();
    }
    else{
		$namevalue ='mealPlanName="'.$serviceName.'",status=1,destinationId="'.$destinationId.'"';  
		$adds = addlisting(_INBOUND_MEALPLAN_MASTER_,$namevalue); 
	}
	?>
	<script>
		parent.openinboundpop('action=addServiceMealPlan&dayId=<?php echo $_REQUEST['dayId']; ?>','800px');
		parent.$('#pageloading').hide();
		parent.$('#pageloader').hide();
		
	</script>	
	<?php
} 


if($_REQUEST['action'] == 'supplimentServiceType' && trim($_REQUEST['destinationId'])!='' && trim($_REQUEST['serviceType'])!='' ){

	$rs=GetPageRecord('*',_DESTINATION_MASTER_,' id="'.trim($_REQUEST['destinationId']).'" order by id asc');
	$resListing=mysqli_fetch_array($rs);

	$queQuery=GetPageRecord('nationality',_QUERY_MASTER_,'id in ( select queryId from quotationMaster where id="'.$_REQUEST['quotationId'].'") ');
	$queryData=mysqli_fetch_array($queQuery);

	$nation=GetPageRecord('countryId','nationalityMaster','id ="'.$queryData['nationality'].'"');
	$nationData=mysqli_fetch_array($nation);

	$quotQuery=GetPageRecord('*',_QUOTATION_MASTER_,' id="'.trim($_REQUEST['quotationId']).'"');
	$quotationData=mysqli_fetch_array($quotQuery);

	if($nationData['countryId'] == $defaultCountryId || ($nationData['countryId'] == 0 && $nationData['name'] == 'Local')){
		$nationType = 'Local';
	}else if($nationData['countryId'] == 0 && $nationData['name'] == 'Foreign'){
		$nationType = 'Foreign';	
	}else if($nationData['countryId'] == 0 && $nationData['name'] == 'Bimstec'){
		$nationType = 'Bimstec';	
	}else{
		$nationType = 'Local';
	}
	?>
 	<div class="inboundheader" > <?php if($_REQUEST['serviceType']==1){ echo 'SightSeeing'; }elseif($_REQUEST['serviceType']==2){ echo 'Tour Escort'; }elseif($_REQUEST['serviceType']==3){
 	 echo 'Monument'.'&nbsp;&nbsp;&nbsp;&nbsp;Traveller Country: '.$nationType; 
 	} ?> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>

	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
			
		<?php if($_REQUEST['serviceType']==1){ ?>
		<table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#E6E6E6" class="tablesorter gridtable" id="entrancesicTable">
				<thead>
				<tr style="border: 1px solid #fff;
    border-bottom: 1px solid #E6E6E6;">
					<th align="left">&nbsp;&nbsp;Name</th>
					<th align="center"> Supplier </th>
					<th align="center"> SightSeeing&nbsp;Cost </th>
					<th align="center"> Pax&nbsp;Range</th>
					<th align="center"> PerPax&nbsp;Cost</th>
					<th align="center">&nbsp;</th>
				</tr>
				</thead>
				<tbody>
				<?php
				$where='';
				$rs=''; 
				$where=' otherActivityCity = "'.trim($resListing['name']).'" and status=1 and deletestatus=0 order by otherActivityName asc';
				$rsw=GetPageRecord('*',_PACKAGE_BUILDER_OTHER_ACTIVITY_MASTER_,$where);
				if(mysqli_num_rows($rsw)>0){
					while($resListing=mysqli_fetch_array($rsw)){

	 					$rs121=GetPageRecord('id',_QUOTATION_OTHER_ACTIVITY_MASTER_,'otherActivityName="'.$resListing['id'].'" and quotationId="'.$quotationData['id'].'"');
						$isAlreadyAdded=mysqli_num_rows($rs121);
						if($isAlreadyAdded == 0){

						$where1=' otherActivityNameId = "'.$resListing['id'].'"  and status=1 and id not in (select additionalId from quotationAdditionalMaster where quotationId="'.$_REQUEST['quotationId'].'" and serviceType="Activity") order by id desc';
						$rs11=GetPageRecord('*','dmcotherActivityRate',$where1);
						if(mysqli_num_rows($rs11)>0){
						while($dmcroommastermain=mysqli_fetch_array($rs11)){
						?>
	 					<tr>
						<td align="left"><?php echo strip($resListing['otherActivityName']); ?></td>
						<td align="center"><?php echo getsupplierCompany($dmcroommastermain['supplierId']); ?></td>
						<td align="center"><?php echo  getCurrencyName($dmcroommastermain['currencyId']).'&nbsp;'.strip($dmcroommastermain['activityCost']); ?></td>
						<td align="center">Upto&nbsp;<?php echo strip($dmcroommastermain['maxpax']); ?>&nbsp;Pax</td>
						<td align="center"><?php echo getCurrencyName($dmcroommastermain['currencyId']).'&nbsp;'.round($dmcroommastermain['perPaxCost']); ?></td>
			           	<td align="center" valign="middle"><div style="width: fit-content !important; padding: 8px !important;" class="editbtnselect" id="selectbut<?php echo urlencode($dmcroommastermain['id']); ?>" onclick="savesaveSupplimentfun('<?php echo urlencode($dmcroommastermain['id']); ?>','<?php echo urlencode($_REQUEST['destinationId']); ?>','<?php echo urlencode($_REQUEST['serviceType']); ?>');"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div>
						<div class="editbtnselect" id="selectedbut<?php echo urlencode($dmcroommastermain['id']); ?>" style="border-radius: 50% !important; display:none;" ><i class="fa fa-check" aria-hidden="true"></i></div></td>
					</tr>
					<?php } }else{
						
						?>
	 					<tr>
						<td align="left"><?php echo strip($resListing['otherActivityName']); ?></td>
						<td align="center"><select style="width: 100px;" id="supplierId<?php echo urlencode($resListing['id']); ?>" name="supplierId" class="newbox" displayname="Supplier" autocomplete="off" > 
						<?php     
						$rs1a=GetPageRecord('*',_SUPPLIERS_MASTER_,' deletestatus=0 and name!="" and activityType=3  order by name asc'); 
						while($supplierData=mysqli_fetch_array($rs1a)){   
						?>
						<option value="<?php echo strip($supplierData['id']); ?>" ><?php echo strip($supplierData['name']); ?></option>
						<?php } ?>
						</select></td>
						<td align="center"><?php echo getCurrencyName($defaultCurrencyId);?>&nbsp;
						    <input name="activityCost" type="text" class="newbox numeric " id="activityCost<?php echo urlencode($resListing['id']); ?>" value="0" onkeyup="getPerPaxCost<?php echo urlencode($resListing['id']); ?>();" style="width: 80px;"/></td> 
						<td align="center"><div>Upto&nbsp;<input name="maxPax" type="text" class="newbox numeric " id="maxPax<?php echo urlencode($resListing['id']); ?>" value="1" onkeyup="getPerPaxCost<?php echo urlencode($resListing['id']); ?>();" style="width:30px;"/>&nbsp;Pax</div></td>					<td align="center"><?php echo getCurrencyName($defaultCurrencyId);?><input name="perPaxCost" type="text" class="newbox numeric " readonly="" id="perPaxCost<?php echo urlencode($resListing['id']); ?>" value="0" style="width: 80px;" /></td>   
			           	<td align="center" valign="middle"><div style="width: fit-content !important; padding: 8px !important;" class="editbtnselect" id="selectbut<?php echo urlencode($resListing['id']); ?>" onclick="savesaveSupplimentfunNull('<?php echo urlencode($resListing['id']); ?>','<?php echo urlencode($_REQUEST['destinationId']); ?>','<?php echo urlencode($_REQUEST['serviceType']); ?>');"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div> 
						<div class="editbtnselect" id="selectedbut<?php echo urlencode($resListing['id']); ?>" style="border-radius: 50% !important; display:none;" ><i class="fa fa-check" aria-hidden="true"></i></div></td>
						<script>
							function getPerPaxCost<?php echo urlencode($resListing['id']); ?>(){ 
							
								var activityCost = $('#activityCost<?php echo urlencode($resListing['id']); ?>').val();
								var maxpax = $('#maxPax<?php echo urlencode($resListing['id']); ?>').val();  
								var ppCost = Math.round(activityCost/maxpax);
								 
								if(ppCost == 'NaN' || ppCost== Infinity){
								$('#perPaxCost<?php echo urlencode($resListing['id']); ?>').val(activityCost);
								}else{
								$('#perPaxCost<?php echo urlencode($resListing['id']); ?>').val(ppCost);
								}
							 }
								
							function addactivitytoquotationsNull(activityId){
								var queryId = '<?php echo $queryData['id']; ?>';
								var quotationId = '<?php echo $quotationData['id']; ?>';
								var startDay = '<?php echo strip($dayData['id']); ?>,<?php echo strtotime($dayData['srdate']); ?>,<?php echo strip($dayData['cityId']); ?>';
								var activityCost = Number($('#activityCost'+activityId).val());
								var maxPax = Number($('#maxPax'+activityId).val());
								var perPaxCost = Number($('#perPaxCost'+activityId).val());
								var supplierId = Number($('#supplierId'+activityId).val());
		
									$('#loadActivitybox').load('loadsaveOtherActivity.php?action=addedit_QuotationotherActivityNullAmt&searhqueryId='+queryId+'&add=yes&quotationId='+quotationId+'&startDay='+startDay+'&activityId='+activityId+'&activityCost='+activityCost+'&maxPax='+maxPax+'&perPaxCost='+perPaxCost+'&supplierId='+supplierId+'&dayId=<?php echo $_REQUEST['dayId']; ?>');
		
							}
		
							function selectthis(ele){
								$(ele).html('Selected');
								$(ele).removeAttr('onclick');
								$(ele).css('background-color','#d88319');
							}
					</script>
					</tr>
					<?php 
					} 
					} }
				}else{
					?>
					<tr>
						<td align="center" colspan="4">&nbsp;No Active Rates Found!!</td>
					</tr>
					<?php
				} 
				?>
				</tbody>
	</table>
		 <?php } ?>

		<?php if($_REQUEST['serviceType']==2){  ?>
		 <table border="1" cellpadding="0" cellspacing="0" bordercolor="#F4F4F4" class="tablesorter gridtable"  id="entrancesicTable" >
			<thead>
				<tr>
				  <th height="20" align="left" >&nbsp;</th>
 					<th height="20" align="left" style="border-left:hidden; padding-left:5px;"> Tour Escort&nbsp;Name</th>
					<th height="20" align="center" > Day Type</th>
					<th height="20" align="center" > Cost</th>
					<th height="20" align="center" style="border-left:hidden;">&nbsp;</th>
				</tr>
			</thead>
			<tbody>
			<?php
			$c1=0;
			$whereDate = ' and "'.$quotationData['fromDate'].'" BETWEEN fromDate and toDate and "'.$quotationData['toDate'].'" BETWEEN fromDate and toDate ';

			$where1=' supplierId in (select id from '._SUPPLIERS_MASTER_.' where  deletestatus=0 and guideType=2 )  and serviceid in ( select id from '._GUIDE_SUB_CAT_MASTER_.' where serviceType=0 and status=1 and deletestatus=0 ) and id not in (select additionalId from quotationAdditionalMaster where quotationId="'.$_REQUEST['quotationId'].'" and serviceType="Guide") and status=1 '.$whereDate.' order by id desc';
			$rs1=GetPageRecord('*','dmcGuidePorterRate',$where1);
			if(mysqli_num_rows($rs1)>0){ 	
				while($dmcroommastermain=mysqli_fetch_array($rs1)){

				if(trim($dmcroommastermain['dayType']) == 'fullday'){
					$dayType = "Full Day";
				}else{
					$dayType = "Half Day";
				}

				$aaaaaa=GetPageRecord('*',_GUIDE_SUB_CAT_MASTER_,' id="'.$dmcroommastermain['serviceid'].'"');
				$subCatData=mysqli_fetch_array($aaaaaa);

				?>

			  <tr>
			    <td align="left"><strong><?php echo ++$c1; ?>.</strong></td>
				<td align="left"><?php echo clean($subCatData['name']);  ?></td>
				<td align="center"><?php echo ($dayType);  ?></td>
				<td align="center"><?php echo getCurrencyName($dmcroommastermain['currencyId']).' '.clean($dmcroommastermain['price']);  ?></td>
			    <td align="center"><div class="editbtnselect" id="selectbut<?php echo urlencode($dmcroommastermain['id']); ?>" onclick="savesaveSupplimentfun('<?php echo urlencode($dmcroommastermain['id']); ?>','<?php echo urlencode($_REQUEST['destinationId']); ?>','<?php echo urlencode($_REQUEST['serviceType']); ?>');"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div>
				<div class="editbtnselect" id="selectedbut<?php echo urlencode($dmcroommastermain['id']); ?>" style="border-radius: 50% !important; display:none;" ><i class="fa fa-check" aria-hidden="true"></i></div></td>
			  </tr>
			<?php
			} 
			}else{
				?>
				<tr>
					<td align="center" colspan="4">&nbsp;No Active Rates Found!!</td>
				</tr>
				<?php
			} 
			?>
			</tbody>
		  </table>
		<?php } ?>

		<?php if($_REQUEST['serviceType']==3){  ?>
		 <table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#F4F4F4" class="tablesorter gridtable"  id="entrancesicTable">
		<thead>
			<tr>
			  <th height="20" align="left"  >&nbsp;</th>
				<th height="20" align="left" style="border-left:hidden; padding-left:5px;">Monument&nbsp;Name</th>
				<th height="30" align="center" >Adult Fees</th>
				<th height="20" align="center" >Child Fees</th>
				<th height="20" align="center" >Infant Fees</th>
				<th height="20" align="center" style="border-left:hidden;">&nbsp;Action</th>
			</tr>
		</thead>
	<tbody>
		<?php
		$c1=0;
		$select1='';
		$wher1='';
		$rs1='';
		$select1='*';

		$rscs=GetPageRecord('queryId',_QUOTATION_MASTER_,'id="'.$_REQUEST['quotationId'].'"');  
        $queryResult=mysqli_fetch_array($rscs);
        $queryId=$queryResult['queryId'];

		$marketTypeId = getQueryMaketType($queryId);
        $whereMarket = ' and marketType=1';
        if($marketTypeId>0){
	    $whereMarket = ' and marketType="'.$marketTypeId.'"';
        }
 

		$whereNationalityType = '';
		if($nationData['countryId'] == $defaultCountryId || ($nationData['countryId'] == 0 && $nationData['name'] == 'Local')){
			$whereNationalityType = ' and nationalityType=1';
		}else if($nationData['countryId'] != $defaultCountryId || ($nationData['countryId'] == 0 && $nationData['name'] == 'Foreign')){
			$whereNationalityType = ' and nationalityType=2';
		}else if($nationData['countryId'] == 0 && $nationData['name'] == 'Bimstec'){
			$whereNationalityType = ' and nationalityType=3';
		}else{
			$whereNationalityType = ' and nationalityType=1';
		}
 
		$whereDate = ' and "'.$quotationData['fromDate'].'" BETWEEN fromDate and toDate and "'.$quotationData['toDate'].'" BETWEEN fromDate and toDate ';

	$where12='entranceCity="'.trim($resListing['name']).'" and status=1 and deletestatus=0  order by entranceName asc';
	$rs12=GetPageRecord('*',_PACKAGE_BUILDER_ENTRANCE_MASTER_,$where12);
	while($editresult2=mysqli_fetch_array($rs12)){

		$entranceId=$editresult2['id'];
		$entranceName=$editresult2['entranceName'];

	 $where1=' supplierId in (select id from '._SUPPLIERS_MASTER_.' where  deletestatus=0 and (entranceType=4  or entranceType=1 )) and status=1 and entranceNameId="'.$editresult2['id'].'"  and supplierId>0 '.$whereNationalityType.' '.$whereMarket.' '.$whereDate.' order by id desc';
		$rs1=GetPageRecord($select1,_DMC_ENTRANCE_RATE_MASTER_,$where1);
		if(mysqli_num_rows($rs1)>0){ 
			while($dmcroommastermain=mysqli_fetch_array($rs1)){

			// $select2='entranceName,id';
			// $where2='id='.$dmcroommastermain['entranceNameId'].'';
			// $rs2=GetPageRecord($select2,_PACKAGE_BUILDER_ENTRANCE_MASTER_,$where2);
			// while($editresult2=mysqli_fetch_array($rs2)){
			// 	$entranceId=$editresult2['id'];
			// 	$entranceName=$editresult2['entranceName'];
			// }

			$rs121=GetPageRecord('id','quotationEntranceMaster','entranceNameId="'.$editresult2['id'].'" and quotationId="'.$quotationId.'"');
			$isAlreadyAdded=mysqli_num_rows($rs121);
			if($isAlreadyAdded == 0){



			$isopen=0;
			$rs2xs=GetPageRecord('id',_PACKAGE_BUILDER_ENTRANCE_MASTER_,'id='.$dmcroommastermain['entranceNameId'].' and FIND_IN_SET("'.date("l", strtotime($datestart)).'", closeDaysname)');
			if(mysqli_num_rows($rs2xs)>0){ $isopen=1;  }




			?>
			<tr>
			  <td align="left"><strong><?php echo ++$c1; ?>.</strong></td>
			<td align="left"><?php
			echo clean($entranceName);
			?></td>
			<td align="center"><?php
			$select2='name';
			$where2='id="'.$dmcroommastermain['currencyId'].'"';
			$rs2=GetPageRecord($select2,_QUERY_CURRENCY_MASTER_,$where2);
			$editresult2=mysqli_fetch_array($rs2);
			$cur=clean($editresult2['name']);
			?><?php echo $cur.' '.strip($dmcroommastermain['ticketAdultCost']); ?></td>

			<td align="center"><?php echo $cur.' '.strip($dmcroommastermain['ticketchildCost']); ?></td>
			<td align="center"><?php echo $cur.' '.strip($dmcroommastermain['ticketinfantCost']); ?></td>
			<td align="center" valign="middle"><div class="editbtnselect" id="selectbut<?php echo urlencode($dmcroommastermain['id']); ?>" onclick="savesaveSupplimentfun('<?php echo urlencode($dmcroommastermain['id']); ?>','<?php echo urlencode($_REQUEST['destinationId']); ?>','<?php echo urlencode($_REQUEST['serviceType']); ?>');"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div>
			<div class="editbtnselect" id="selectedbut<?php echo urlencode($dmcroommastermain['id']); ?>" style="border-radius: 50% !important; display:none;" ><i class="fa fa-check" aria-hidden="true"></i></div>
			</td>
		  </tr>
			<?php
			} } }  
			else{
			?>
			<tr>
		  <td align="left"><strong><?php echo ++$c1; ?>.</strong></td>
			<td align="left"><?php
			echo clean($entranceName);
			?></td>
			
			<?php
			$select2s='id,name';
			if(!empty($dmcroommastermain['currencyId'])){
			  $where2s='id="'.$dmcroommastermain['currencyId'].'"';
			}else{
			  $where2s='setDefault=1';	
			}
			$rs2=GetPageRecord($select2s,_QUERY_CURRENCY_MASTER_,$where2s);
			$editresult2s=mysqli_fetch_array($rs2);
			$cur=clean($editresult2s['name']);
			?>
			<td align="center"><?php echo $cur; ?>&nbsp;
			   <input name="adultCostSearchPage" type="text" class="newbox numeric " id="adultCostSearchPage<?php echo $editresult2['id']; ?>" value="0"  style="height: 20px;width: 60px;" />
			</td> 
			<td align="center"><?php echo $cur; ?>&nbsp;
			   <input name="childCostSearchPage" type="text" class="newbox numeric " id="childCostSearchPage<?php echo $editresult2['id']; ?>" value="0"  style="height: 20px;width: 60px;" />
			</td> 
			<td align="center"><?php echo $cur; ?>&nbsp;
			   <input name="infantCostSearchPage" type="text" class="newbox numeric " id="infantCostSearchPage<?php echo $editresult2['id']; ?>" value="0"  style="height: 20px;width: 60px;" />
			</td> 
			<?php
			$rs21=GetPageRecord('*','hoteloperationRestriction','entranceId="'.$entranceId.'" and "'.$quotationData['fromDate'].'" BETWEEN startDate and endDate');
			?>
			<td align="center" valign="middle">
			<?php
			$msgOpr = '';
			if(mysqli_num_rows($rs21) > 0){

			$oprResData=mysqli_fetch_array($rs21);
			$period = date('d-m-Y',strtotime($oprResData['startDate']))."&nbsp;to&nbsp;".date('d-m-Y',strtotime($oprResData['endDate']));
			?>
			
			<div style="width: fit-content !important; padding: 8px !important;cursor: pointer;background: #086908;color: white;border-radius: 5px;" class="editbtnselect2" onclick="confirm('<?php echo strip($entranceName); ?> - Monument restriction! \nReason:&nbsp;<?php echo strip($oprResData['reason']); ?> \nPeriod:<?php echo strip($period); ?>');" id="selectthis<?php echo $editresult2['id']; ?>" ><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;ySelect</div>
	
			<?php } else { ?>
	
			<div style="width: fit-content !important; padding: 8px !important;cursor: pointer;background: #086908;color: white;border-radius: 5px;" class="editbtnselect2" onclick="addentrancetoquotationsNull('<?php echo $editresult2['id']; ?>','<?php echo urlencode($_REQUEST['serviceType']); ?>','<?php echo urlencode($_REQUEST['destinationId']); ?>');" id="selectthis<?php echo $editresult2['id']; ?>" ><i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp;Select</div>
	
			<?php  } ?> 
		<div class="editbtnselect" id="selectedthis<?php echo $editresult2['id']; ?>" style="border-radius: 50% !important; display:none;" ><i class="fa fa-check" aria-hidden="true"></i></div>
			

		</td>			
			
		  </tr>
			<?php
		} }
		?>
		</tbody>
		</table>
		<?php } ?>

		<div id="saveSuppliment" style="display:none;"></div>
		<script>
			function savesaveSupplimentfun(id,destId,servicType){
				$('#selectbut'+id).hide();
				$('#selectedbut'+id).show(); 
				$('#saveSuppliment').load('saveSupplimentAcytivities.php?action=savesaveSupplimentdata&id='+id+'&destId='+destId+'&servicType='+servicType+'&quotationId=<?php echo encode($_REQUEST['quotationId']); ?>&isAddExp=<?php echo $_REQUEST['isAddExp']; ?>&dayId=<?php echo $_REQUEST['dayId']; ?>'); 
			}
			function savesaveSupplimentfunNull(activityId,destId,serviceType){
				$('#selectbut'+activityId).hide();
				$('#selectedbut'+activityId).show(); 
				
				var activityCost = Number($('#activityCost'+activityId).val());
				var maxPax = Number($('#maxPax'+activityId).val());
				var perPaxCost = Number($('#perPaxCost'+activityId).val());
				var supplierId = Number($('#supplierId'+activityId).val());
				
				$('#saveSuppliment').load('saveSupplimentAcytivities.php?action=savesaveSupplimentdataNull&add=yes&quotationId=<?php echo encode($_REQUEST['quotationId']); ?>&activityId='+activityId+'&destId='+destId+'&activityCost='+activityCost+'&maxPax='+maxPax+'&perPaxCost='+perPaxCost+'&supplierId='+supplierId+'&serviceType='+serviceType+'&isAddExp=<?php echo $_REQUEST['isAddExp']; ?>&dayId=<?php echo $_REQUEST['dayId']; ?>');
				 
			}
			function addentrancetoquotationsNull(entranceId,serviceType,destId){ 
			$('#selectthis'+entranceId).hide();
			$('#selectedthis'+entranceId).show();

				var adultCost = Number($('#adultCostSearchPage'+entranceId).val());
				var childCost = Number($('#childCostSearchPage'+entranceId).val());
				var infantCost = Number($('#infantCostSearchPage'+entranceId).val());
				// console.log(adultCost,childCost,destId,serviceType,entranceId);

				// $('#saveSuppliment').load('loadsaveentrance.php?action=addedit_QuotationEntranceNullAmt&add=yes&startDayId='+startDayId+'&endDayId='+endDayId+'&entanceId='+entanceId+'&adultCost='+adultCost+'&childCost='+childCost+'&supplierId='+supplierId+'&currencyId='+currencyId);

				$('#saveSuppliment').load('saveSupplimentAcytivities.php?action=saveNewSupplimentdata&destId='+destId+'&serviceType='+serviceType+'&quotationId=<?php echo encode($_REQUEST['quotationId']); ?>&isAddExp=<?php echo $_REQUEST['isAddExp']; ?>'+'&adultCost='+adultCost+'&childCost='+childCost+'&infantCost='+infantCost+'&entranceId='+entranceId);


			}
		</script>
		</div>
	</div>

	<?php
}
// quotation Overview not in use this block
if($_REQUEST['action'] == 'Itineraryoverview' && trim($_REQUEST['overviewNameId'])!='' && trim($_REQUEST['quotationId'])!=''){


	$rso=GetPageRecord('*',_OVERVIEW_MASTER_,' id="'.trim($_REQUEST['overviewNameId']).'" order by id asc');
	$resListingo=mysqli_fetch_array($rso);

	$rsq=GetPageRecord('*','quotationOverview',' quotationId="'.trim($_REQUEST['quotationId']).'" and overviewNameId="'.trim($_REQUEST['overviewNameId']).'"order by id asc');
	$editoverview=mysqli_fetch_array($rsq);

	?>

	<script type="text/javascript">
		// addTinyMCE(); 
	</script>

 	<div class="inboundheader" style="position:relative;background-color: #3b4fb5;color:#fff; ">Overview/ Inc&Exc/ T&C <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinboundoverview();"></i></div>

	<div style="padding:10px;" id="hotelBox">
		<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
   <div id="detailBox">	 
   <div style="text-align: center;padding: 10px 0;font-size: 14px;"> Do you want to save the Data </div>      
	<table width="100%" border="0" cellpadding="5" cellspacing="0">
	  <tr style="display: none;">
		<td width="50%"><div style="font-size:12px;">Highlight</div>
			<?php if($_REQUEST['languageType'] == "0") { ?>	
			<input name="itiSubject" type="text" id="itiSubject"  style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;"  value="<?php if(!empty($editoverview['highlight'])){ echo $editoverview['highlight']; }else{ echo stripslashes($resListingo['highlight']); } ?>"  >
			<?php } else { 
			$rsql=GetPageRecord('*','overviewLanguageMaster','overviewId="'.trim($_REQUEST['overviewNameId']).'" and languageId="'.trim($_REQUEST['languageType']).'"');
			$lanoverview=mysqli_fetch_array($rsql);	
			?>
				<input name="itiSubject" type="text" id="itiSubject"  style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;"  value="<?php if(!empty($lanoverview['highlight'])){ echo $lanoverview['highlight']; }else{ echo stripslashes($lanoverview['highlight']); } ?>"  >
		<?php } ?>
		</td>
	  </tr>
	  <tr style="display: none;">
		<td>
			<div style="font-size:12px;">Overview</div>
			<?php if($_REQUEST['languageType'] == "0") { ?>	
			<textarea name="itiOverview" class="textEditor" rows="5" id="itiOverview" style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;box-shadow:none;"  placeholder="Remark"><?php if(!empty($editoverview['overview'])) { echo $editoverview['overview']; }else{ echo stripslashes($resListingo['overview']);} ?></textarea> 
			<?php } else { 
				$rsql=GetPageRecord('*','overviewLanguageMaster','overviewId="'.trim($_REQUEST['overviewNameId']).'" and languageId="'.trim($_REQUEST['languageType']).'"');
				$lanoverview=mysqli_fetch_array($rsql); 
				?>
				<textarea name="itiOverview" class="textEditor" rows="5" id="itiOverview" style="font-size:12px; padding:6px; width:100%; box-sizing:border-box;box-shadow:none;"  placeholder="Remark"><?php echo stripslashes($lanoverview['overview']); ?></textarea>	
			 
			<?php } ?>
	  	 </td>
	  </tr>
		 <tr>
		<td>

		<input  type="button" class="whitembutton"  value="&nbsp;Close&nbsp;" onclick="closeinboundoverview();" style=" margin: 0; ">&nbsp;
		<input name="Save" type="button" class="whitembutton submitBtn" id="Save" value="&nbsp;Save&nbsp;" onclick="saveitineraryoverview('<?php echo $editoverview['id']; ?>');" style="background-color: #3b4fb5 !important;margin: 0;color: white;">
        &nbsp;
        <span id="msgShow" style="color:green;display:none;">Successfully Added.</span>

 		 </td>
		</tr>
	</table>
	</div>
	    <script type="text/javascript">
	    
	    	function saveitineraryoverview(id){
				var itiSubject = $('#itiSubject').val();
				var itiOverview = $('#itiOverview').val(); 
				var saveitineraryoverview = 'saveitineraryoverview';
				$.ajax({
					type: "POST",
					url: 'frmaction.php',
					data: {highlight: itiSubject,editId: id, overview: itiOverview, isAddOverview: '<?php echo $_REQUEST['isAddOverview']; ?>',overviewNameId: '<?php echo $_REQUEST['overviewNameId']; ?>', action: saveitineraryoverview, quotationId: '<?php echo $_REQUEST['quotationId']; ?>'},
					success: function(data){ 
						loadQuotationIncExc();
					  
					     tinymce.get('overviewText').setContent(itiOverview);
					     tinymce.get('highlightsText').setContent(itiSubject);
						closeinbound();
					}
				});
			}
			function closeinboundoverview() { 
				closeinbound();	
			}
	    </script>
	

		</div>
	</div>

	<?php
}

 
if($_REQUEST['action'] == 'editSupplimentService' && trim($_REQUEST['id'])!='' ){

	$rs=GetPageRecord('*','quotationAdditionalMaster',' id="'.trim($_REQUEST['id']).'" order by id asc');
	$resListing=mysqli_fetch_array($rs);

	if($resListing['serviceType']=='Activity'){

	$c121=GetPageRecord('*','packageBuilderotherActivityMaster',' id in (select otherActivityNameId from dmcotherActivityRate where id="'.$resListing['additionalId'].'") order by id asc');
	$activityDataName=mysqli_fetch_array($c121);
	$activityName=ucwords($activityDataName['otherActivityName']);
	}

	if($resListing['serviceType']=='Guide'){

	$c121=GetPageRecord('*',_GUIDE_SUB_CAT_MASTER_,' id in (select serviceid from dmcGuidePorterRate where id="'.$resListing['additionalId'].'") order by id asc');
	$activityDataName=mysqli_fetch_array($c121);
	$activityName=ucwords($activityDataName['name']);
	}

	if($resListing['serviceType']=='Entrance'){

		if($resListing['additionalId'] != 0){
			$c121=GetPageRecord('*',_PACKAGE_BUILDER_ENTRANCE_MASTER_,' id in (select entranceNameId from '._DMC_ENTRANCE_RATE_MASTER_.' where id="'.$resListing['additionalId'].'") order by id asc');
			$activityDataName=mysqli_fetch_array($c121);
			$activityName=ucwords($activityDataName['entranceName']);	
		}else{
			$c121=GetPageRecord('entranceName',_PACKAGE_BUILDER_ENTRANCE_MASTER_,' id="'.$resListing['entranceId'].'"'); 
			$entranceDataName=mysqli_fetch_array($c121);	
			$activityName=ucwords($entranceDataName['entranceName']);
		}

	}


	?>

	<div class="inboundheader" >Edit <?php echo $resListing['serviceType']; ?> <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #666666; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
	<form action="inboundpop.php" method="get" enctype="multipart/form-data" name="add_hoteltomaster" target="actoinfrm" id="add_hoteltomaster">
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
	<td><div class="griddiv" style="position:static;">
	<label> <div>Service&nbsp;Type</div>
	<select id="supplimentServiceType" name="supplimentServiceType" class="gridfield " autocomplete="off" style="width: 110px; padding: 5px; border: 1px solid #ccc; border-radius: 3px;" >
	<?php if($resListing['serviceType']=='Activity'){ ?><option value="1">SightSeeing</option><?php } ?>
	<?php if($resListing['serviceType']=='Guide'){ ?><option value="2">Tour Escort</option><?php } ?>
	<?php if($resListing['serviceType']=='Entrance'){ ?><option value="3">Monument</option><?php } ?>
	</select>
	</label>
	</div></td>
	<td><div class="griddiv" style="position:static;">
	<label> <div><?php if($resListing['serviceType']=='Activity'){ ?>SightSeeing<?php } ?>
	<?php if($resListing['serviceType']=='Guide'){ ?>Tour Escort<?php } ?>
	<?php if($resListing['serviceType']=='Entrance'){ ?>Monument<?php } ?></div>
	<input  name="activityName" type="text" id="activityName" style="padding: 8px;border:1px #ccc solid; padding-top: 7px;" readonly=""  value="<?php echo $activityName; ?>" readonly="" >
	</label>
	</div></td>
	<td><div class="griddiv" style="position:static;">
	<label> <div>Adult Cost (PP)</div>
	<input  name="adultCost" type="number" id="actadultCost" style="padding: 8px;border:1px #ccc solid; padding-top: 7px;width: 110px;" onkeyup="numericFilter(this);"  value="<?php echo $resListing['adultCost']; ?>" >
	</label>
	</div></td> 
	<?php  if($resListing['serviceType']=='Entrance'){ ?>
	<td><div class="griddiv" style="position:static;">
	<label> <div>Child Cost (PP)</div>
	<input  name="childCost" type="number" id="actchildCost" style="padding: 8px;border:1px #ccc solid; padding-top: 7px;width: 110px;" onkeyup="numericFilter(this);"  value="<?php echo $resListing['childCost']; ?>" >
	</label>
	</div></td> 
	<td><div class="griddiv" style="position:static;">
	<label> <div>Infant Cost (PP)</div>
	<input  name="infantCost" type="number" id="actinfantCost" style="padding: 8px;border:1px #ccc solid; padding-top: 7px;width: 110px;" onkeyup="numericFilter(this);"  value="<?php echo $resListing['infantCost']; ?>" >
	</label>
	</div></td> 
	<?php } ?>
	</tr>
	<tr>
	<td colspan="4"><input name="Submit" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="    Save    " onclick="formValidation('add_hoteltomaster','submitbtn','0');">
	<input type="hidden" value="<?php echo encode($_REQUEST['id']); ?>" name="deleteid"/></td>
	<input type="hidden" value="editSupplimentService" name="action"/></td>
	</tr>
	</table>

	</form>


	<div id="saveSuppliment" style="display:none;"></div>
	<script>
	function savesaveSupplimentfun(id,destId,servicType){
		$('#selectbut'+id).hide();
		$('#selectedbut'+id).show();

		$('#saveSuppliment').load('saveSupplimentAcytivities.php?action=savesaveSupplimentdata&id='+id+'&destId='+destId+'&servicType='+servicType+'&quotationId=<?php echo encode($_REQUEST['quotationId']); ?>&isAddExp=<?php echo $_REQUEST['isAddExp']; ?>&dayId=<?php echo $_REQUEST['dayId']; ?>');

	}
	</script>
	</div>
	</div>

	<?php
}



if($_REQUEST['action'] == 'addServiceWiseMarkup' && trim($_REQUEST['quotationId'])!='' ){ ?>
	<div class="inboundheader">Service&nbsp;Wise&nbsp;Markup<i class="fa fa-times" aria-hidden="true" onClick="closeinbound();"></i>&nbsp;</div>
	<div class="inboundbody">
		<div id="loadServiceWiseMarkupGst"></div>
		<script type="text/javascript">
			$('#loadServiceWiseMarkupGst').load('loadServiceWiseMarkupGst.php?quotationId=<?php echo trim($_REQUEST['quotationId']); ?>');
		</script>
	</div>
	<div class="inboundfooter">
		<table border="0" align="right" cellpadding="0" cellspacing="0">
		    <tbody>
		    	<tr>
	        	<td>
	        		<input name="cancel" type="button" class="whitembutton" id="cancel" value="Close" onclick="closeinbound();">
	        	</td>
	        	<td>
	        		<input name="submit" type="button" class="whitembutton saved" id="submit" value="Save All" onclick="updateSWMG();">
	        	</td>
		      </tr>
		   </tbody>
		</table>
	</div>
	<?php
}


if($_REQUEST['action']=="addNewVisaToMaster" || $_REQUEST['action']=="addNewPassportToMaster" || $_REQUEST['action']=="addNewInsuranceToMaster" && $_REQUEST['quotationId']!=''){

	?>

<div class="inboundheader" ><?php if($_REQUEST['action']=="addNewVisaToMaster"){ echo "Add New Visa"; }elseif($_REQUEST['action']=="addNewPassportToMaster"){ echo "Add New Passport"; }elseif($_REQUEST['action']=="addNewInsuranceToMaster"){ echo "Add New Insurance"; } ?><i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
	<form action="frm_action.crm" method="post" target="actoinfrm" name="addValueAddedServices" id="addValueAddedServices">
<table cellpadding="5" cellspacing="0" >	
<!-- <span class="redmind"></span> -->
			<div class="griddiv"><label>
				<div class="gridlable gridlable1"><?php if($_REQUEST['action']=="addNewVisaToMaster"){ echo "Visa Name"; }elseif($_REQUEST['action']=="addNewPassportToMaster"){ echo "Passport Name"; }elseif($_REQUEST['action']=="addNewInsuranceToMaster"){ echo "Insurance Name"; } ?></div>
					<input type="text" name="valueAddedCostName" id="valueAddedCostName" class="gridfield1" displayname="Visa Type" style="padding: 6px !important;width: 263px;">
				</label>
			</div>
			
			<div class="griddiv "><label>
				<div class="gridlable gridlable1"><?php if($_REQUEST['action']=="addNewVisaToMaster"){ echo "Visa Type"; }elseif($_REQUEST['action']=="addNewPassportToMaster"){ echo "Passport Type"; }elseif($_REQUEST['action']=="addNewInsuranceToMaster"){ echo "Insurance Type"; } ?></div>
				<?php if($_REQUEST['action']=="addNewVisaToMaster"){?>
				<select name="valueAddedTypeName" id="valueAddedTypeName" class="gridfield1" displayname="Visa Type" style="padding: 6px !important;width: 280px;">
				<option value="">Select</option>
				<?php 
					$vrs1 = GetPageRecord('*','visaTypeMaster','status=1');
					while($visad = mysqli_fetch_assoc($vrs1)){
						?>
						<option value="<?php echo $visad['id'] ?>"><?php echo $visad['name']; ?></option>
						<?php
					}
				
				?>
				</select>
				<?php }elseif($_REQUEST['action']=="addNewPassportToMaster"){ ?>
					<select name="valueAddedTypeName" id="valueAddedTypeName" class="gridfield1" displayname="Visa Type" style="padding: 6px !important;width: 280px;">
				<option value="">Select</option>
				<?php 
					$vrs1 = GetPageRecord('*','passportTypeMaster','status=1');
					while($visad = mysqli_fetch_assoc($vrs1)){
						?>
						<option value="<?php echo $visad['id'] ?>"><?php echo $visad['name']; ?></option>
						<?php
					}
				
				?>
				</select>
					
					<?php }elseif($_REQUEST['action']=="addNewInsuranceToMaster"){?>

						<select name="valueAddedTypeName" id="valueAddedTypeName" class="gridfield1" displayname="Visa Type" style="padding: 6px !important;width: 280px;">
				<option value="">Select</option>
				<?php 
					$vrs1 = GetPageRecord('*','InsuranceTypeMaster','status=1');
					while($visad = mysqli_fetch_assoc($vrs1)){
						?>
						<option value="<?php echo $visad['id'] ?>"><?php echo $visad['name']; ?></option>
						<?php
					}
				
				?>
				</select>
						
						<?php } ?>
				</label>
			</div>

			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Status</div>
				<select id="valueAddedstatus" type="text" class="gridfield" name="valueAddedstatus" displayname="Status" autocomplete="off" style="width: 280px;padding: 6px !important;">
				<option value="1" <?php if ($editresult['status'] == '1') { ?>selected="selected" <?php } ?>>Active</option>
				<option value="0" <?php if ($editresult['status'] == '0') { ?>selected="selected" <?php } ?>>In Active</option>
				</select>

				</label>
			</div>

			<input type="hidden" name="action" id="action" value="<?php echo $_REQUEST['action']; ?>">
		<input type="hidden" name="quotationId" id="quotationId" value="<?php echo $_REQUEST['quotationId']; ?>">

			<div id="buttonsbox" style="text-align:center;">
			<table border="0" align="right" cellpadding="0" cellspacing="0">
				<tr>
					<td><input name="addnewuserbtn" type="button" class="bluembutton submitbtn" id="addnewuserbtn" value="Save " onclick="formValidation('addValueAddedServices','submitbtn','0');" /></td>

					<td><input name="Cancel" type="button" class="whitembutton" id="Cancel" value="Cancel" onclick="closeinbound();" /></td>

				</tr>
			</table>
		</div>

			</table>
	</form>
			<style>
				#inboundpopbg .inboundpop {
					width: 300px;
				}
			</style>
	
<?php
}



if($_REQUEST['action']=="editQuotationVisaCost" && $_REQUEST['editId']!='' && $_REQUEST['quotationId']!=''){
	$editId = $_REQUEST['editId'];
	$quotationId = $_REQUEST['quotationId'];

$rsqv = GetPageRecord('*','quotationVisaRateMaster','quotationId="'.$_REQUEST['quotationId'].'" and id="'.$editId.'"');
$visaQuotData = mysqli_fetch_assoc($rsqv)
?>
<style>
	.inboundpop{
		width: 80% !important;
	}
</style>
<div class="inboundheader" >Update Visa Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
<table width="60%" cellpadding="5" cellspacing="0" >
		<tr>

			<td style="width: 100px">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Country<span class="redmind"></span></div>
						<select name="visaCountryIdV" id="visaCountryIdV" class="gridfield1 validate" displayname="Visa Name" style="padding: 6px !important; width: 109px !important;">
						<!-- <option value="0">Select</option> -->
					<?php 

					$rsV = GetPageRecord('id,name',_COUNTRY_MASTER_,'status=1 && deletestatus=0 && name!=""');
					 while($visaCData = mysqli_fetch_assoc($rsV)){
						?>
						<option value="<?php echo $visaCData['id']; ?>" <?php if($visaQuotData['visaCountryId']==$visaCData['id']){ ?> selected="selected" <?php } ?>><?php echo $visaCData['name']; ?></option>
						<?php
					 }
					?>
					</select>
					</label>
				</div>
				</td>
			<td style="width: 100px">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Visa&nbsp;Name<span class="redmind"></span></div>
					<select name="visaNameId" id="visaNameId2" class="gridfield1 validate" onchange="selectVisaCost(this.value);" displayname="Visa Name" style="padding: 6px !important; width: 136px !important;">
					<option value="0">Select Visa Cost</option>
				<?php 
				$rsV = GetPageRecord('*','visaCostMaster','status=1 && deletestatus=0');
				 while($visaData = mysqli_fetch_assoc($rsV)){
					?>
					<option value="<?php echo $visaData['id']; ?>" <?php if($visaQuotData['serviceid']==$visaData['id']){ ?> selected="selected" <?php } ?> ><?php echo $visaData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>
			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Visa&nbsp;Type<span class="redmind"></span></div>
				<select name="visaTypeId" id="visaTypeId" class="gridfield1 validate" displayname="Visa Type" style="padding: 6px !important; width: 136px !important;">
					<option value="0">Select Visa Type</option>
				<?php 
				$rsV = GetPageRecord('*','visaTypeMaster','status=1 && deletestatus=0');
				 while($visatypeData = mysqli_fetch_assoc($rsV)){
					?>
					<option value="<?php echo $visatypeData['id']; ?>" <?php if($visaQuotData['visaTypeId']==$visatypeData['id']){ ?> selected="selected" <?php } ?> ><?php echo $visatypeData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>

			<td style="width: 10%;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Currency<span class="redmind"></span></div>
					
					<select name="vscurrencyId" id="vscurrencyId" class="gridfield1 validate" onchange="getROE(this.value,'vscurrencyValue133');"displayname="Currency" style="padding: 6px !important;">
					<option value="">Select</option>
				<?php 

					$currencyId = ($visaQuotData['currencyId']>0)?$visaQuotData['currencyId']:$baseCurrencyId;
					$currencyValue = ($visaQuotData['currencyValue']>0)?$visaQuotData['currencyValue']:getCurrencyVal($currencyId);

					$rsc2='';
					$rsc2=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,'status=1'); 
				 	while($currencyData=mysqli_fetch_array($rsc2)){
				
					?>
					<option value="<?php echo $currencyData['id']; ?>" <?php if($visaQuotData['currencyId']==$currencyData['id']){ echo 'selected'; } ?> ><?php echo $currencyData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>

			<td style="padding-right: 0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
						<input type="text" name="vscurrencyValue" id="vscurrencyValue133" value="<?php echo trim($currencyValue); ?>" class="gridfield1" displayname="ROI Value">
					</label>
				</div>
			</td>

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Adult&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="adultCost1" id="adultCost1" value="<?php echo $visaQuotData['adultCost'] ?>" class="gridfield1" displayname="Adult Cost" style="width:80px;">
				</label>
			</div>
			</td>
			<!-- <td style="padding-left:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">No Of&nbsp;Pax</div>	
					<input type="text" name="adultPaxV" id="adultPaxV" value="<?php echo $visaQuotData['adultPax'] ?>" placeholder="Adult Pax" class="gridfield1" style="width: 56px !important;">
				 </label>
			</div>
			</td> -->

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Child&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="childCost1" id="childCost1" value="<?php echo $visaQuotData['childCost'] ?>" class="gridfield1" displayname="Child Cost">
				</label>
			</div>
			</td>
			<!-- <td style="padding-left:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">No Of&nbsp;Pax</div>	
					<input type="text" name="childPaxV" id="childPaxV" value="<?php echo $visaQuotData['childPax'] ?>" placeholder="Child Pax" class="gridfield1" style="width: 56px !important;">
				 </label>
			</div>
			</td> -->

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Infant&nbsp;Cost</div>
					<input type="text" name="infantCost1" id="infantCost1" value="<?php echo $visaQuotData['infantCost'] ?>" class="gridfield1" displayname="Infant Cost">
				</label>
			</div>
			</td>
			<!-- <td style="padding-left:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">No Of&nbsp;Pax</div>	
				<input type="text" name="infantPaxV" id="infantPaxV" value="<?php echo $visaQuotData['infantPax'] ?>" placeholder="Infant Pax" class="gridfield1" style="width: 56px !important;">
				</label>
			</div>
			</td> -->
			
		</tr>

		<tr>
		<td align="left"  >
				<div class="griddiv">
						<label>
							<div class="gridlable gridlable1">Date</div>
							<input type="date" name="visaDateV" id="visaDateV" class="gridfield1" value="<?= date('Y-m-d',strtotime($visaQuotData['visaDate'])); ?>" displayname="Processing Fee" style="width: 100px !important;">
						</label>
					</div>
				</td> 
		<td align="left"  >
				<div class="griddiv">
					<label>
						<div class="gridlable gridlable1">Processing&nbsp;Fee&nbsp;Type<span class="redmind"></span></div>
						<select name="markupType" id="markupType" class="gridfield1 validate" style="padding: 6px !important;width: 136px !important;">
							<option value="1" <?php if($visaQuotData['markupType']=='1'){ echo "selected"; } ?>>%</option>
							<option value="2" <?php if($visaQuotData['markupType']=='2'){ echo "selected"; } ?>>Flat</option>
						</select>
					</label>
				</div>
			</td> 

			<td align="left"  >
				<div class="griddiv">
					<label>
						<div class="gridlable gridlable1">Processing&nbsp;Fee</div>
						<input type="text" name="processingFee" id="processingFee" value="<?php echo $visaQuotData['processingFee'] ?>" class="gridfield1" displayname="Processing Fee" style="width: 120px !important;">
					</label>
				</div>
			</td> 
			<td align="left"  colspan="2">
				<div class="griddiv">
					<label>
						<div class="gridlable gridlable1">Embassy&nbsp;Fee</div>
						<input type="text" name="embassyFee" id="embassyFee" value="<?php echo $visaQuotData['embassyFee'] ?>" class="gridfield1" displayname="Embassy Fee" style="width: 145px;">
					</label>
				</div>
			</td> 
			<td align="left" >
				<div class="griddiv">
					<label>
						<div class="gridlable gridlable1">VFS&nbsp;Charges</div>
						<input type="text" name="vfsCharges" id="vfsCharges" value="<?php echo $visaQuotData['vfsCharges'] ?>" class="gridfield1" displayname="VFS Charges" style="width: 80px;">
					</label>
				</div>
			</td> 

			<td align="left">
					<div class="griddiv">
						<label>
							<div class="gridlable gridlable1">Validity</div>
							<input type="text" name="visaValidityV" id="visaValidityV" class="gridfield1" value="<?php echo $visaQuotData['visaValidity']; ?>" displayname="Visa Validity">
						</label>
					</div>
				</td> 
				<td align="left">
					<div class="griddiv">
						<label>
							<div class="gridlable gridlable1">Entry&nbsp;Type</div>
							<select name="entryTypeV" class="gridfield1" id="entryTypeV" style="padding: 6px !important; width: 85px !important;">

							<option value="1" <?php if($visaQuotData['entryType']==1){ echo 'selected'; } ?> >Single Entry</option>
							<option value="2" <?php if($visaQuotData['entryType']==2){ echo 'selected'; } ?> >Multiple Entry</option>
						
							</select>
						</label>
					</div>
				</td> 

			<td align="center">
				<div class="editbtnselect" id="selectthis" style="background: #233A49 !important;width:70px !important;margin-top: 5px;"  onclick="EditVisaCostToQuotation();" >Save
				</div>
			</td>
		</tr>
	
		

			<input type="hidden" name="visaRateId" id="visaRateId" value="<?php echo $visaQuotData['rateId']; ?>">
			<input type="hidden" name="editId" id="editId" value="<?php echo $visaQuotData['id']; ?>">
		
		<!-- <i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp; -->
	</tbody>
</table>
	<script>
		function EditVisaCostToQuotation(){
		var visaRateId = $("#visaRateId").val();
		var adultCost = $("#adultCost1").val();
		var childCost = $("#childCost1").val();
		var infantCost = $("#infantCost1").val();
		var adultPax = $("#adultPaxV").val();
		var childPax = $("#childPaxV").val();
		var infantPax = $("#infantPaxV").val();
		var visaTypeId = $("#visaTypeId").val();
		var visaNameId2 = $("#visaNameId2").val();
		var vscurrencyId = $("#vscurrencyId").val();
		var vscurrencyValue = $("#vscurrencyValue133").val();

		var vfsChargesv = $("#vfsCharges").val();
		var embassyFeev = $("#embassyFee").val();
		var processingFeev = $("#processingFee").val();
		var ProcessingFeeType = $("#markupType").val();
		var visaCountryId = $("#visaCountryIdV").val();
		var visaDate = $("#visaDateV").val();
		var visaValidity = $("#visaValidityV").val();
		var entryType = $("#entryTypeV").val();

		if(visaTypeId>0 && visaNameId2>0){

		$("#selectVisacost").load('loadValueAddedserviceCost.php?action=saveVisaCosttoQuotation&visaRateId='+visaRateId+'&adultCost='+adultCost+'&childCost='+childCost+'&infantCost='+infantCost+'&adultPax='+adultPax+'&childPax='+childPax+'&infantPax='+infantPax+'&visaNameId='+visaNameId2+'&visaType='+visaTypeId+'&currencyId='+vscurrencyId+'&currencyValue='+vscurrencyValue+'&ProcessingFeeType='+ProcessingFeeType+'&processingFeev='+processingFeev+'&embassyFeev='+embassyFeev+'&vfsChargesv='+vfsChargesv+'&quotationId=<?php echo $quotationId; ?>&editId=<?php echo $visaQuotData['id']; ?>&visaCountryId='+visaCountryId+'&visaDate='+encodeURI(visaDate)+'&visaValidity='+visaValidity+'&entryType='+entryType);

		}else{
			alert('Please, Select Visa Name or Type');
		}
	}
	</script>
	</div>
	</div>

<?php
}


if($_REQUEST['action']=="editQuotationInsuranceCost" && $_REQUEST['editId']!='' && $_REQUEST['quotationId']!=''){
	$editId = $_REQUEST['editId'];
	$quotationId = $_REQUEST['quotationId'];

$rsqI = GetPageRecord('*','quotationInsuranceRateMaster','quotationId="'.$_REQUEST['quotationId'].'" and id="'.$editId.'"');
$insuranceQuotData = mysqli_fetch_assoc($rsqI)
?>
<style>
	.inboundpop{
		width: 85% !important;
	}
</style>
<div class="inboundheader" >Update Insurance Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
<table width="65%" cellpadding="5" cellspacing="0" >
		<tr>
		<td style="width: 100px">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Country<span class="redmind"></span></div>
						<select name="travellingcountryIdIN" id="travellingcountryIdIN" class="gridfield1 validate" displayname="Travelling Country" style="padding: 6px !important; width: 80px !important;">
						<option value="0">Select</option>
					<?php 
					$rsc = GetPageRecord('*',_COUNTRY_MASTER_,'status=1 && deletestatus=0 && name!=""');
					 while($insCountryData = mysqli_fetch_assoc($rsc)){
						?>
						<option value="<?php echo $insCountryData['id']; ?>" <?php if($insCountryData['id']==$insuranceQuotData['countryId']){ echo 'selected'; } ?>><?php echo $insCountryData['name']; ?></option>
						<?php
					 }
					?>
					</select>
					</label>
				</div>
				</td>


				<td style="padding-right:0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">From&nbsp;Date<span class="redmind"></span></div>
						<input type="text" name="insuranceFromDateIN" id="insuranceFromDateIN" value="<?php if($insuranceQuotData['insuranceStartDate']!='0000-00-00'){ echo date('d-m-Y',strtotime($insuranceQuotData['insuranceStartDate'])); } ?>" class="gridfield1 calfieldicon" displayname="From Date" readonly  style="width:100px; border: 1px solid #ccc;">
					
					</label>
				</div>
				</td>

				<td style="padding-right:0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">To&nbsp;Date<span class="redmind"></span></div>
						<input type="text" name="insuranceToDateIN" id="insuranceToDateIN" value="<?php if($insuranceQuotData['insuranceEndDate']!='0000-00-00'){ echo date('d-m-Y',strtotime($insuranceQuotData['insuranceEndDate'])); } ?>" class="gridfield1 calfieldicon" displayname="To Date" readonly style="width:100px; border: 1px solid #ccc;">
						
					</label>
				</div>
				</td>
					 
				<script src="js/zebra_datepicker.js"></script>

				<script type="text/javascript">
					$('#insuranceToDateIN').Zebra_DatePicker({
						format: 'd-m-Y',
					});
					$('#insuranceFromDateIN').Zebra_DatePicker({
						format: 'd-m-Y',
					});
					
					 </script>
			<td style="width: 100px">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Insurance&nbsp;Name<span class="redmind"></span></div>
					<select name="insuranceNameId" id="insuranceNameId2" class="gridfield1 validate" onchange="selectInsuranceCost(this.value);" displayname="Insurance Name" style="padding: 6px !important; width: 130px !important;">
					<option value="0">Select Insurance Cost</option>
				<?php 
				$rsV = GetPageRecord('*','insuranceCostMaster','status=1 && deletestatus=0 and name!=""');
				 while($insData = mysqli_fetch_assoc($rsV)){
					?>
					<option value="<?php echo $insData['id']; ?>" <?php if($insuranceQuotData['serviceid']==$insData['id']){ ?> selected="selected" <?php } ?> ><?php echo $insData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>
			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Insurance&nbsp;Type<span class="redmind"></span></div>
				<select name="insuranceTypeId" id="insuranceTypeId" class="gridfield1 validate" displayname="Visa Type" style="padding: 6px !important; width: 130px !important;">
					<option value="0">Select Insurance Type</option>
				<?php 
				$rsV = GetPageRecord('*','InsuranceTypeMaster','status=1 && deletestatus=0 and name!=""');
				 while($insurancetypeData = mysqli_fetch_assoc($rsV)){
					?>
					<option value="<?php echo $insurancetypeData['id']; ?>" <?php if($insuranceQuotData['insuranceTypeId']==$insurancetypeData['id']){ ?> selected="selected" <?php } ?> ><?php echo $insurancetypeData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>
			<td style="width: 10%;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Currency<span class="redmind"></span></div>
					
					<select name="inscurrencyId" id="inscurrencyId" class="gridfield1 validate" onchange="getROE(this.value,'inscurrencyValue134');" displayname="Currency" style="padding: 6px !important;">
					<option value="">Select</option>
				<?php 

$currencyId = ($insuranceQuotData['currencyId']>0)?$insuranceQuotData['currencyId']:$baseCurrencyId;
$currencyValue = ($insuranceQuotData['currencyValue']>0)?$insuranceQuotData['currencyValue']:getCurrencyVal($currencyId);
					$rsc2='';
					$rsc2=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,'status=1'); 
				 	while($currencyData=mysqli_fetch_array($rsc2)){
				
					?>
					<option value="<?php echo $currencyData['id']; ?>" <?php if($insuranceQuotData['currencyId']==$currencyData['id']){ echo 'selected'; } ?> ><?php echo $currencyData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>

			<td style="padding-right: 0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
						<input type="text" name="inscurrencyValue" id="inscurrencyValue134" value="<?php echo trim($currencyValue); ?>" class="gridfield1" displayname="ROI Value">
					</label>
				</div>
			</td>

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Adult&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="insadultCost1" id="insadultCost1" value="<?php echo $insuranceQuotData['adultCost'] ?>" class="gridfield1" displayname="Adult Cost">
				</label>
			</div>
			</td>
			

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Child&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="inschildCost1" id="inschildCost1" value="<?php echo $insuranceQuotData['childCost'] ?>" class="gridfield1" displayname="Child Cost">
				</label>
			</div>
			</td>
		

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Infant&nbsp;Cost</div>
					<input type="text" name="insinfantCost1" id="insinfantCost1" value="<?php echo $insuranceQuotData['infantCost'] ?>" class="gridfield1" displayname="Infant Cost">
				</label>
			</div>
			</td>
			
			<td align="center">
				<div class="editbtnselect" id="selectthis" style="background:#233A49 ;width:70px !important; margin-top:5px; " onclick="EditInsuranceCostToQuotation();" >Save
				</div>
				</td>
		</tr>

			<input type="hidden" name="insuranceRateId" id="insuranceRateId" style="background: #233A49 !important;" value="<?php echo $insuranceQuotData['rateId']; ?>">
			<input type="hidden" name="editId" id="editId" value="<?php echo $insuranceQuotData['id']; ?>">
		
		<!-- <i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp; -->
	</tbody>
</table>
	<script>
		function EditInsuranceCostToQuotation(){
		var insuranceRateId = $("#insuranceRateId").val();
		var insadultCost1 = $("#insadultCost1").val();
		var inschildCost1 = $("#inschildCost1").val();
		var insinfantCost1 = $("#insinfantCost1").val();
		var adultPax = $("#adultPaxI").val();
		var childPax = $("#childPaxI").val();
		var infantPax = $("#infantPaxI").val();
		var insuranceType = $("#insuranceTypeId").val();
		var insuranceNameId2 = $("#insuranceNameId2").val();
		var inscurrencyId = $("#inscurrencyId").val();
		var inscurrencyValue = $("#inscurrencyValue134").val();
		var travellingcountryId = $("#travellingcountryIdIN").val();
		var insuranceFromDate = $("#insuranceFromDateIN").val();
		var insuranceToDate = $("#insuranceToDateIN").val();
		

		if(insuranceType>0 && insuranceNameId2>0){

		$("#selectInsurancecost").load('loadValueAddedserviceCost.php?action=saveInsuranceCosttoQuotation&insuranceRateId='+insuranceRateId+'&adultCost='+insadultCost1+'&childCost='+inschildCost1+'&infantCost='+insinfantCost1+'&adultPax='+adultPax+'&childPax='+childPax+'&infantPax='+infantPax+'&insuranceNameId='+insuranceNameId2+'&currencyId='+inscurrencyId+'&currencyValue='+inscurrencyValue+'&insuranceType='+insuranceType+'&quotationId=<?php echo $quotationId; ?>&editId=<?php echo $insuranceQuotData['id']; ?>&travellingcountryId='+travellingcountryId+'&insuranceFromDate='+encodeURI(insuranceFromDate)+'&insuranceToDate='+encodeURI(insuranceToDate));

		}else{
			alert('Please, Select Insurance Name or Type');
		}
	}
	</script>
	</div>
	</div>

<?php
}


if($_REQUEST['action']=="editQuotationPassCost" && $_REQUEST['editId']!='' && $_REQUEST['quotationId']!=''){
	$editId = $_REQUEST['editId'];
	$quotationId = $_REQUEST['quotationId'];

$rsqP = GetPageRecord('*','quotationPassportRateMaster','quotationId="'.$_REQUEST['quotationId'].'" and id="'.$editId.'"');
$passportQuotData = mysqli_fetch_assoc($rsqP)
?>
<style>
	.inboundpop{
		width: 80% !important;
	}
</style>
<div class="inboundheader" >Update Passport Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
<table width="65%" cellpadding="5" cellspacing="0" >
		<tr>
			<td style="width: 100px">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Passport&nbsp;Name<span class="redmind"></span></div>
					<select name="passNameId2" id="passNameId2" class="gridfield1 validate" onchange="selectInsuranceCost(this.value);" displayname="Insurance Name" style="padding: 6px !important; width: 170px !important;">
					<option value="0">Select Passport Name</option>
				<?php 
				$rsV = GetPageRecord('*','passportCostMaster','status=1 && deletestatus=0');
				 while($passData = mysqli_fetch_assoc($rsV)){
					?>
					<option value="<?php echo $passData['id']; ?>" <?php if($passportQuotData['serviceid']==$passData['id']){ ?> selected="selected" <?php } ?> ><?php echo $passData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>
			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Passport&nbsp;Type<span class="redmind"></span></div>
				<select name="passportTypeId" id="passportTypeId" class="gridfield1 validate" displayname="Visa Type" style="padding: 6px !important; width: 170px !important;">
					<option value="0">Select Passport Type</option>
				<?php 
				$rsP = GetPageRecord('*','passportTypeMaster','status=1 && deletestatus=0');
				 while($passtypeData = mysqli_fetch_assoc($rsP)){
					?>
					<option value="<?php echo $passtypeData['id']; ?>" <?php if($passportQuotData['passportTypeId']==$passtypeData['id']){ ?> selected="selected" <?php } ?> ><?php echo $passtypeData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>
			<td style="width: 10%;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Currency<span class="redmind"></span></div>
					
					<select name="pascurrencyId" id="pascurrencyId" class="gridfield1 validate" onchange="getROE(this.value,'pascurrencyValue135');" displayname="Currency" style="padding: 6px !important;">
					<option value="">Select</option>
				<?php 

$currencyId = ($passportQuotData['currencyId']>0)?$passportQuotData['currencyId']:$baseCurrencyId;
$currencyValue = ($passportQuotData['currencyValue']>0)?$passportQuotData['currencyValue']:getCurrencyVal($currencyId);

					$rsc2='';
					$rsc2=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,'status=1'); 
				 	while($currencyData=mysqli_fetch_array($rsc2)){
				
					?>
					<option value="<?php echo $currencyData['id']; ?>" <?php if($passportQuotData['currencyId']==$currencyData['id']){ echo 'selected'; } ?> ><?php echo $currencyData['name']; ?></option>
					<?php
				 }
				?>
				</select>
				</label>
			</div>
			</td>

			<td style="padding-right: 0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
						<input type="text" name="pascurrencyValue" id="pascurrencyValue135" value="<?php echo trim($currencyValue); ?>" class="gridfield1" displayname="ROI Value">
					</label>
				</div>
			</td>

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Adult&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="passadultCost1" id="passadultCost1" value="<?php echo $passportQuotData['adultCost'] ?>" class="gridfield1" displayname="Adult Cost">
				</label>
			</div>
			</td>
			<td style="padding-left:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">No Of&nbsp;Pax</div>	
					<input type="text" name="adultPaxP" id="adultPaxP" value="<?php echo $passportQuotData['adultPax'] ?>" placeholder="Adult Pax" class="gridfield1" style="width:56px !important;">
				 </label>
			</div>
			</td>

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Child&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="passchildCost1" id="passchildCost1" value="<?php echo $passportQuotData['childCost'] ?>" class="gridfield1" displayname="Child Cost">
				</label>
			</div>
			</td>
			<td style="padding-left:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">No Of&nbsp;Pax</div>	
					<input type="text" name="childPaxP" id="childPaxP" value="<?php echo $passportQuotData['childPax'] ?>" placeholder="Child Pax" class="gridfield1" style="width:56px !important;">
				 </label>
			</div>
			</td>

			<td style="padding-right:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Infant&nbsp;Cost</div>
					<input type="text" name="passinfantCost1" id="passinfantCost1" value="<?php echo $passportQuotData['infantCost'] ?>" class="gridfield1" displayname="Infant Cost">
				</label>
			</div>
			</td>
			<td style="padding-left:0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">No Of&nbsp;Pax</div>	
				<input type="text" name="infantPaxP" id="infantPaxP" value="<?php echo $passportQuotData['infantPax'] ?>" placeholder="Infant Pax" class="gridfield1" style="width:56px !important;">
				</label>
			</div>
			</td>
			<td align="center">
				<div class="editbtnselect" id="selectthis" style="background: #233A49 !important;" onclick="EditPassCostToQuotation();" >Save
				</div>
				</td>
		</tr>
	
		
			<input type="hidden" name="passportRateId" id="passportRateId" value="<?php echo $passportQuotData['rateId']; ?>">
			<input type="hidden" name="editId" id="editId" value="<?php echo $passportQuotData['id']; ?>">
		
		<!-- <i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp; -->
	</tbody>
</table>
	<script>
		function EditPassCostToQuotation(){
		var passportRateId = $("#passportRateId").val();
		var passadultCost1 = $("#passadultCost1").val();
		var passchildCost1 = $("#passchildCost1").val();
		var passinfantCost1 = $("#passinfantCost1").val();
		var adultPax = $("#adultPaxP").val();
		var childPax = $("#childPaxP").val();
		var infantPax = $("#infantPaxP").val();
		var passportTypeId = $("#passportTypeId").val();
		var passNameId2 = $("#passNameId2").val();
		var pascurrencyId = $("#pascurrencyId").val();
		var pascurrencyValue = $("#pascurrencyValue135").val();

		if(passportTypeId>0 && passNameId2>0){

		$("#selectPasscost").load('loadValueAddedserviceCost.php?action=savePassportCosttoQuotation&passportRateId='+passportRateId+'&adultCost='+passadultCost1+'&childCost='+passchildCost1+'&infantCost='+passinfantCost1+'&adultPax='+adultPax+'&childPax='+childPax+'&infantPax='+infantPax+'&passportNameId='+passNameId2+'&passportType='+passportTypeId+'&currencyId='+pascurrencyId+'&currencyValue='+pascurrencyValue+'&quotationId=<?php echo $quotationId; ?>&editId=<?php echo $passportQuotData['id']; ?>');

		}else{
			alert('Please, Select Passport Name or Type');
		}
	}
	</script>
	</div>
	</div>

<?php
}

// flight block

if($_REQUEST['action']=="editQuotationFlightCost" && $_REQUEST['editId']!='' && $_REQUEST['quotationId']!=''){
	$editId = $_REQUEST['editId'];
	$quotationId = $_REQUEST['quotationId'];

	$rsqv = GetPageRecord('*','quotationFlightMaster','quotationId="'.$_REQUEST['quotationId'].'" and id="'.$editId.'"');
	$flightQuotData = mysqli_fetch_assoc($rsqv)
?>
<style>
	.inboundpop{
		width: 80% !important;
	}
</style>
<div class="inboundheader" >Update Flight Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
	<table width="60%" cellpadding="5" cellspacing="0" >
		
		<tr>
		<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Flight&nbsp;Date<span class="redmind"></span></div>
					<input type="date" name="flightDateU" id="flightDateU" value="<?= date('Y-m-d',strtotime($flightQuotData['departureDate'])); ?>" class="gridfield1" displayname="ROI Value" style="width:105px;">
				</label>
			</div>
			</td>
			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">From&nbsp;Destination<span class="redmind"></span></div>
					
					<select name="flightFromDestionationU" id="flightFromDestionationU" value="0" class="gridfield1" displayname="Flight Destination" style="padding: 6px !important; width: 114px !important;">
					<?php 
					$rsFD = GetPageRecord('name,id',_DESTINATION_MASTER_,'name!="" and status=1 and deletestatus=0 order by name asc');
					while($fromDestD = mysqli_fetch_assoc($rsFD)){
						?>
						<option value="<?php echo $fromDestD['id']; ?>" <?php if($flightQuotData['departureFrom']==$fromDestD['id']){ echo 'selected'; } ?> ><?php echo $fromDestD['name']; ?></option>
						<?php
					}
					?>
					</select>
				</label>
			</div>
			</td>

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">To&nbsp;Destination<span class="redmind"></span></div>
					
					<select name="flightToDestionationU" id="flightToDestionationU" class="gridfield1" displayname="Flight Destination" style="padding: 6px !important; width: 112px !important;">
					<?php 
					$rsFD = GetPageRecord('name,id',_DESTINATION_MASTER_,'name!="" and status=1 and deletestatus=0 order by name asc');
					while($toDestD = mysqli_fetch_assoc($rsFD)){
						?>
						<option value="<?php echo $toDestD['id']; ?>" <?php if($flightQuotData['arrivalTo']==$toDestD['id']){ echo 'selected'; } ?> ><?php echo $toDestD['name']; ?></option>
						<?php
					}
					?>
					</select>
				</label>
			</div>
			</td>

			<td style="width: 100px">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Flight&nbsp;Name<span class="redmind"></span></div>
				<select name="flightNameIdU" id="flightNameIdU" class="gridfield1 validate" displayname="Flight Name" style="padding: 6px !important; width: 136px !important;">
					<option value="0">Select</option>
					<?php 
					$rsFQuery = GetPageRecord('*',_PACKAGE_BUILDER_FLIGHT_MASTER_,' flightName!="" and status=1 order by flightName asc');
				 	while($GuideData5 = mysqli_fetch_assoc($rsFQuery)){

						?>
						<option value="<?php echo $GuideData5['id']; ?>" <?php if($flightQuotData['flightId']==$GuideData5['id']){ echo 'selected="selected"'; } ?> ><?php echo strip($GuideData5['flightName']); ?></option>
						<?php
					}
					?>
				</select>
				</label>
			</div>
			</td> 

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Flight&nbsp;Number<span class="redmind"></span></div>
					<input type="text" name="fflightNumberU" id="fflightNumberU" value="<?php echo $flightQuotData['flightNumber']; ?>" class="gridfield1" displayname="ROI Value" style="width:105px;">
				</label>
			</div>
			</td>

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Flight&nbsp;Class<span class="redmind"></span></div>
					<select id="fflightClassU" name="fflightClassU" class="gridfield1 validate" displayname="Flight Class" autocomplete="off" style="width:105px;">
						<option value="First_Class" <?php if($flightQuotData['flightClass']=='First_Class'){ echo 'selected="selected"'; } ?>>First Class</option>
						<option value="Business_Class" <?php if($flightQuotData['flightClass']=='Business_Class'){ echo 'selected="selected"'; } ?> >Business Class</option>
						<option value="Economy_Class" <?php if($flightQuotData['flightClass']=='Economy_Class'){ echo 'selected="selected"'; } ?>>Economy Class</option>
						<option value="Premium_Economy_Class" <?php if($flightQuotData['flightClass']=='Premium_Economy_Class'){ echo 'selected="selected"'; } ?> >Premium Economy Class</option>
					</select> 
				</label>
			</div>
			</td>

			<td style="width: 10%;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Currency<span class="redmind"></span></div> 
				<select name="fcurrencyIdU" id="fcurrencyIdU" class="gridfield1 validate" onchange="getROE(this.value,'fcurrencyValue132');" displayname="Currency" style="padding: 6px !important;">
					<option value="">Select</option>
					<?php  
					$currencyId = ($visaRq['currencyId']>0)?$visaRq['currencyId']:$baseCurrencyId;
					$currencyValue = ($visaRq['currencyValue']>0)?$visaRq['currencyValue']:getCurrencyVal($currencyId);

					$rsc2='';
					$rsc2=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,'status=1'); 
				 	while($currencyData=mysqli_fetch_array($rsc2)){
					?>
					<option value="<?php echo $currencyData['id']; ?>" <?php if($currencyId==$currencyData['id']){ echo "selected"; } ?> ><?php echo $currencyData['name']; ?></option>
					<?php
				 	}
					?>
				</select>
				</label>
			</div>
			</td>
			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
					<input type="text" name="fcurrencyValueU" id="fcurrencyValue132U" value="<?php echo trim($currencyValue); ?>" class="gridfield1" displayname="ROI Value">
				</label>
			</div>
			</td>
			</tr>
			<tr>
			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Adult&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="fadultCostU" id="fadultCostU" value="<?php echo $flightQuotData['adultCost']; ?>" class="gridfield1" displayname="Adult Cost" style="width:105px;">
				
				</label>
			</div>
			</td>
		

			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Child&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="fchildCostU" id="fchildCostU" value="<?php echo $flightQuotData['childCost']; ?>" class="gridfield1" displayname="Child Cost" style="width:100px;">
				
				</label>
			</div>
			</td>
		

			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable">Infant&nbsp;Cost</div>
					<input type="text" name="finfantCostU" id="finfantCostU" value="<?php echo $flightQuotData['infantCost']; ?>" class="gridfield1" displayname="Infant Cost" style="width:100px;">
					
				</label>
			</div>
			</td>
		
			<td align="center">
				<div class="editbtnselect" id="selectthis" style="background: #233A49 !important;width:70px !important;margin-top: 5px;"  onclick="EditFlightCostToQuotation();" >Save
				</div>
			</td>
		</tr>
	
			<input type="hidden" name="flightRateId" id="flightRateId" value="<?php echo $flightQuotData['rateId']; ?>">
			<input type="hidden" name="editId" id="editId" value="<?php echo $flightQuotData['id']; ?>">
		
		<!-- <i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp; -->
	</tbody>
</table>
<div id="selectFlightCost" style="display:none;">loading...</div>
	<script>
	
		function EditFlightCostToQuotation(){
		var flightRateId = $("#flightRateId").val();
		var adultCost = $("#fadultCostU").val();
		var childCost = $("#fchildCostU").val();
		var infantCost = $("#finfantCostU").val();
		var flightFromDestionation = $("#flightFromDestionationU").val();
		var flightToDestionation = $("#flightToDestionationU").val();
		var flightNameId = $("#flightNameIdU").val();
		var fflightNumber = $("#fflightNumberU").val();
		var fflightClass = $("#fflightClassU").val();
		
		var fcurrencyId = $("#fcurrencyIdU").val();
		var currencyValue = $("#fcurrencyValue132U").val();

		
		var flightDate = $("#flightDateU").val();

		if(fflightNumber>0 && flightNameId>0){

		$("#selectFlightCost").load('loadValueAddedserviceCost.php?action=saveFlightCosttoQuotation&flightRateId='+flightRateId+'&adultCost='+adultCost+'&childCost='+childCost+'&infantCost='+infantCost+'&flightToDestionation='+flightToDestionation+'&flightFromDestionation='+flightFromDestionation+'&flightNameId='+flightNameId+'&flightNumber='+fflightNumber+'&currencyId='+fcurrencyId+'&currencyValue='+currencyValue+'&flightClass='+fflightClass+'&quotationId=<?php echo $quotationId; ?>&editId=<?php echo $flightQuotData['id']; ?>&flightDate='+encodeURI(flightDate));

		}else{
			alert('Please, Select Flight Name or Number');
		}
	}
	</script>
	</div>
	</div>

<?php
}


// Train block

if($_REQUEST['action']=="editQuotationTrainCost" && $_REQUEST['editId']!='' && $_REQUEST['quotationId']!=''){
	$editId = $_REQUEST['editId'];
	$quotationId = $_REQUEST['quotationId'];

	$rsqv = GetPageRecord('*','quotationTrainsMaster','quotationId="'.$_REQUEST['quotationId'].'" and id="'.$editId.'"');
	$trainQuotData = mysqli_fetch_assoc($rsqv)
?>
<style>
	.inboundpop{
		width: 80% !important;
	}
</style>
<div class="inboundheader" >Update Train Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
	<table width="60%" cellpadding="5" cellspacing="0" >
	
		<tr>
		<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Train&nbsp;Date<span class="redmind"></span></div>
					<input type="date" name="trainDateU" id="trainDateU" value="<?= date('Y-m-d',strtotime($trainQuotData['departureDate'])); ?>" class="gridfield1" displayname="ROI Value" style="width:105px;">
				</label>
			</div>
			</td>

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">From&nbsp;Destination<span class="redmind"></span></div>
					
					<select name="trainFromDestionationU" id="trainFromDestionationU" class="gridfield1" displayname="Train Destination" style="padding: 6px !important; width: 114px !important;">
					<?php 
					$rsFD = GetPageRecord('name,id',_DESTINATION_MASTER_,'name!="" and status=1 and deletestatus=0 order by name asc');
					while($fromDestD = mysqli_fetch_assoc($rsFD)){
						?>
						<option value="<?php echo $fromDestD['id']; ?>" <?php if($trainQuotData['departureFrom']==$fromDestD['id']){ echo 'selected'; } ?> ><?php echo $fromDestD['name']; ?></option>
						<?php
					}
					?>
					</select>
				</label>
			</div>
			</td>

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">To&nbsp;Destination<span class="redmind"></span></div>
					
					<select name="trainToDestionationU" id="trainToDestionationU" value="0" class="gridfield1" displayname="Train Destination" style="padding: 6px !important; width: 112px !important;">
					<?php 
					$rsFD = GetPageRecord('name,id',_DESTINATION_MASTER_,'name!="" and status=1 and deletestatus=0 order by name asc');
					while($toDestD = mysqli_fetch_assoc($rsFD)){
						?>
						<option value="<?php echo $toDestD['id']; ?>" <?php if($trainQuotData['arrivalTo']==$toDestD['id']){ echo 'selected'; } ?> ><?php echo $toDestD['name']; ?></option>
						<?php
					}
					?>
					</select>
				</label>
			</div>
			</td>

			<td style="width: 100px">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Train&nbsp;Name<span class="redmind"></span></div>
				<select name="trainNameIdU" id="trainNameIdU" class="gridfield1 validate" displayname="Train Name" style="padding: 6px !important; width: 136px !important;">
					<option value="0">Select</option>
					<?php 
					$rsFQuery = GetPageRecord('*','packageBuilderTrainsMaster',' trainName!="" and status=1 order by trainName asc');
				 	while($GuideData5 = mysqli_fetch_assoc($rsFQuery)){

						?>
						<option value="<?php echo $GuideData5['id']; ?>" <?php if($trainQuotData['trainId']==$GuideData5['id']){ echo 'selected'; } ?> ><?php echo strip($GuideData5['trainName']); ?></option>
						<?php
					}
					?>
				</select>
				</label>
			</div>
			</td> 

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Train&nbsp;Number<span class="redmind"></span></div>
					<input type="text" name="ftrainNumberU" id="ftrainNumberU" value="<?php echo $trainQuotData['trainNumber']; ?>" class="gridfield1" displayname="ROI Value" style="width:100px;">
				</label>
			</div>
			</td>

			<td>
			<div class="griddiv "><label>
				<div class="gridlable gridlable1">Train&nbsp;Class<span class="redmind"></span></div>
					<select id="ftrainClassU" name="ftrainClassU" class="gridfield1 validate" displayname="Flight Class" autocomplete="off" style="width:110px;">
						<option value="AC First Class" <?php if($trainQuotData['trainClass']=='AC First Class'){ echo 'selected'; } ?> >AC First Class</option>
						<option value="AC 2-Tier" <?php if($trainQuotData['trainClass']=='AC 2-Tier'){ echo 'selected'; } ?> >AC 2-Tier</option>
						<option value="AC 3-Tier" <?php if($trainQuotData['trainClass']=='AC 3-Tier'){ echo 'selected'; } ?> >AC 3-Tier</option>
						<option value="First Class" <?php if($trainQuotData['trainClass']=='First Class'){ echo 'selected'; } ?>>First Class</option>
						<option value="AC Chair Car" <?php if($trainQuotData['trainClass']=='AC Chair Car'){ echo 'selected'; } ?>>AC Chair Car</option>
						<option value="Second Sitting" <?php if($trainQuotData['trainClass']=='Second Sitting'){ echo 'selected'; } ?>>Second Sitting</option>
						<option value="Sleeper" <?php if($trainQuotData['trainClass']=='Sleeper'){ echo 'selected'; } ?>>Sleeper</option>
					</select> 
				</label>
			</div>
			</td>

			<td style="width: 10%;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Currency<span class="redmind"></span></div> 
				<select name="tcurrencyIdU" id="tcurrencyIdU" class="gridfield1 validate" onchange="getROE(this.value,'fcurrencyValue132');" displayname="Currency" style="padding: 6px !important;">
					<option value="">Select</option>
					<?php  
					$currencyId = ($visaRq['currencyId']>0)?$visaRq['currencyId']:$baseCurrencyId;
					$currencyValue = ($visaRq['currencyValue']>0)?$visaRq['currencyValue']:getCurrencyVal($currencyId);

					$rsc2='';
					$rsc2=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,'status=1'); 
				 	while($currencyData=mysqli_fetch_array($rsc2)){
					?>
					<option value="<?php echo $currencyData['id']; ?>" <?php if($currencyId==$currencyData['id']){ echo "selected"; } ?> ><?php echo $currencyData['name']; ?></option>
					<?php
				 	}
					?>
				</select>
				</label>
			</div>
			</td>
			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
					<input type="text" name="tcurrencyValueU" id="tcurrencyValueU" value="<?php echo trim($currencyValue); ?>" class="gridfield1" displayname="ROI Value">
				</label>
			</div>
			</td>
			</tr>
			<tr>
			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Adult&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="tadultCostU" id="tadultCostU" value="<?php echo $trainQuotData['adultCost']; ?>" class="gridfield1" displayname="Adult Cost" style="width:103px;">
					
				</label>
			</div>
			</td>
		

			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable gridlable1">Child&nbsp;Cost<span class="redmind"></span></div>
					<input type="text" name="tchildCostU" id="tchildCostU" value="<?php echo $trainQuotData['childCost']; ?>" class="gridfield1" displayname="Child Cost" style="width:100px;">
				</label>
			</div>
			</td>
		

			<td style="padding-right: 0px;">
			<div class="griddiv"><label>
				<div class="gridlable">Infant&nbsp;Cost</div>
					<input type="text" name="tinfantCostU" id="tinfantCostU" value="<?php echo $trainQuotData['infantCost']; ?>" class="gridfield1" displayname="Infant Cost" style="width:100px;">
				</label>
			</div>
			</td>

			<td align="center">
				<div class="editbtnselect" id="selectthis" style="background: #233A49 !important;width:70px !important;margin-top: 5px;"  onclick="EditTrainCostToQuotation();" >Save
				</div>
			</td>
		
		</tr> 
	
			<input type="hidden" name="trainRateId" id="trainRateId" value="<?php echo $trainQuotData['rateId']; ?>">
			<input type="hidden" name="editId" id="editId" value="<?php echo $trainQuotData['id']; ?>">
		
		<!-- <i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp; -->
	</tbody>
</table>
<div id="selectFlightCost" style="display:none;">loading...</div>
	<script>
	
		function EditTrainCostToQuotation(){
			
		var trainRateId = $("#trainRateId").val();
		var adultCost = $("#tadultCostU").val();
		var childCost = $("#tchildCostU").val();
		var infantCost = $("#tinfantCostU").val();
		var trainFromDestionation = $("#trainFromDestionationU").val();
		var trainToDestionation = $("#trainToDestionationU").val();
		var trainNameId = $("#trainNameIdU").val();
		var trainNumber = $("#ftrainNumberU").val();
		var trainClass = $("#ftrainClassU").val();
		
		var tcurrencyId = $("#tcurrencyId").val();
		var currencyValue = $("#tcurrencyValueU").val();

		var trainDate = $("#trainDateU").val();

		if(trainNumber>0 && trainNameId>0){

		$("#selectFlightCost").load('loadValueAddedserviceCost.php?action=saveTrainCosttoQuotation&trainRateId='+trainRateId+'&adultCost='+adultCost+'&childCost='+childCost+'&infantCost='+infantCost+'&trainFromDestionation='+trainFromDestionation+'&trainToDestionation='+trainToDestionation+'&trainNameId='+trainNameId+'&ftrainNumber='+trainNumber+'&currencyId='+tcurrencyId+'&currencyValue='+currencyValue+'&ftrainClass='+encodeURI(trainClass)+'&quotationId=<?php echo $quotationId; ?>&editId=<?php echo $trainQuotData['id']; ?>&trainDate='+encodeURI(trainDate));

		}else{
			alert('Please, Select Train Name or Number');
		}
	}
	</script>
	</div>
	</div>

<?php
}


// Train block

if($_REQUEST['action']=="editQuotationTransferCost" && $_REQUEST['editId']!='' && $_REQUEST['quotationId']!=''){
	$editId = $_REQUEST['editId'];
	$quotationId = $_REQUEST['quotationId'];

	$rsqv = GetPageRecord('*','quotationTransferMaster','quotationId="'.$_REQUEST['quotationId'].'" and id="'.$editId.'"');
	$transferQuotData = mysqli_fetch_assoc($rsqv)
?>
<style>
	.inboundpop{
		width: 80% !important;
	}
</style>
<div class="inboundheader" >Update Transfer Rate <i class="fa fa-times" aria-hidden="true" style="position: absolute; right: 15px; font-size: 18px; color: #fff; cursor:pointer; " onClick="closeinbound();"></i>&nbsp;</div>
	<div style="padding:10px;" id="hotelBox">
	<div class="addeditpagebox addtopaboxlist" id="hotelBoxSearch" style="padding:0px; max-height: 500px; overflow: auto;">
	<table width="60%" cellpadding="5" cellspacing="0" >

			<tr>

			<td>
				<div class="griddiv "><label>
					<div class="gridlable gridlable1">Date<span class="redmind"></span></div>
						<input type="date" name="ttransferDateU" id="ttransferDateU"  class="gridfield1" value="<?= date('Y-m-d',strtotime($transferQuotData['fromDate'])); ?>" displayname="Train Date" style="width:100px;">
					</label>
				</div>
				</td>
	
				<td>
				<div class="griddiv "><label>
					<div class="gridlable gridlable1">Destination<span class="redmind"></span></div>
						
						<select name="TransferDestionationU" id="TransferDestionationU" class="gridfield1" displayname="Train Destination" style="padding: 6px !important; width: 114px !important;">
						<?php 
						$rsFD = GetPageRecord('name,id',_DESTINATION_MASTER_,'name!="" and status=1 and deletestatus=0 order by name asc');
						while($fromDestD = mysqli_fetch_assoc($rsFD)){
							?>
							<option value="<?php echo $fromDestD['id']; ?>" <?php if($transferQuotData['destinationId']==$fromDestD['id']){ echo 'selected'; } ?> ><?php echo $fromDestD['name']; ?></option>
							<?php
						}
						?>
						</select>
					</label>
				</div>
				</td>
	
				<td>
				<div class="griddiv "><label>
					<div class="gridlable gridlable1">Transfer&nbsp;Type<span class="redmind"></span></div>
						
						<select name="transferTypeU" id="transferTypeU" value="0" class="gridfield1" displayname="Transfer Type" style="padding: 6px !important; width: 112px !important;">
						<?php 
						$rsFD = GetPageRecord('name,id','transferTypeMaster','name!="" and status=1 and deletestatus=0 order by name asc');
						while($transferType = mysqli_fetch_assoc($rsFD)){
							?>
							<option value="<?php echo $transferType['id']; ?>" <?php if($transferQuotData['transferQuotatoinType']==$transferType['id']){ echo 'selected'; } ?> ><?php echo $transferType['name']; ?></option>
							<?php
						}
						?>
						</select>
					</label>
				</div>
				</td>
	
				<td style="width: 100px">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Transfer&nbsp;Name<span class="redmind"></span></div>
					<select name="transferNameIdU" id="transferNameIdU" class="gridfield1 validate" displayname="Train Name" style="padding: 6px !important; width: 136px !important;">
						<option value="0">Select</option>
						<?php 
						$rsFQuery = GetPageRecord('*','packageBuilderTransportMaster',' transferName!="" and status=1 order by transferName asc');
						 while($GuideData5 = mysqli_fetch_assoc($rsFQuery)){
	
							?>
							<option value="<?php echo $GuideData5['id']; ?>" <?php if($transferQuotData['transferNameId']==$GuideData5['id']){ echo 'selected'; } ?> ><?php echo strip($GuideData5['transferName']); ?></option>
							<?php
						}
						?>
					</select>
					</label>
				</div>
				</td> 
	
				<td>
				<div class="griddiv "><label>
					<div class="gridlable gridlable1">Type<span class="redmind"></span></div>
						<select name="sicpvtTypeU" id="sicpvtTypeU" onchange="selectTransferType();" style="width:112px;">
						<option value="1" <?php if($transferQuotData['transferType']==1){ echo 'selected'; } ?>>SIC</option>
						<option value="2" <?php if($transferQuotData['transferType']==2){ echo 'selected'; } ?>>PVT</option>
						</select>
					</label>
				</div>
				</td>
	
				<td>
				<div class="griddiv "><label>
					<div class="gridlable gridlable1">Vehicle&nbsp;Type<span class="redmind"></span></div>
						<select id="vehicleTypeIdU" name="vehicleTypeIdU" class="gridfield1 validate" displayname="Flight Class" autocomplete="off" style="width:100px;padding:6px;">
							<?php 
								$rs = '';
								$rs = GetPageRecord('*','vehicleTypeMaster','name!="" and status=1');
								while($tptTypeData = mysqli_fetch_assoc($rs)){
							?>
							<option value="<?php echo $tptTypeData['id']; ?>" <?php if($transferQuotData['vehicleType']==$tptTypeData['id']){ echo 'selected'; } ?>><?php echo $tptTypeData['name']; ?></option>
							<?php } ?>
						</select> 
					</label>
				</div>
				</td>
	
				<td style="width: 10%;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Currency<span class="redmind"></span></div> 
					<select name="tfcurrencyIdU" id="tfcurrencyIdU" class="gridfield1 validate" onchange="getROE(this.value,'fcurrencyValue132');" displayname="Currency" style="padding: 6px !important;">
						<option value="">Select</option>
						<?php  
						$currencyId = ($visaRq['currencyId']>0)?$visaRq['currencyId']:$baseCurrencyId;
						$currencyValue = ($visaRq['currencyValue']>0)?$visaRq['currencyValue']:getCurrencyVal($currencyId);
	
						$rsc2='';
						$rsc2=GetPageRecord('*',_QUERY_CURRENCY_MASTER_,'status=1'); 
						 while($currencyData=mysqli_fetch_array($rsc2)){
						?>
						<option value="<?php echo $currencyData['id']; ?>" <?php if($currencyId==$currencyData['id']){ echo "selected"; } ?> ><?php echo $currencyData['name']; ?></option>
						<?php
						 }
						?>
					</select>
					</label>
				</div>
				</td>
				<td style="padding-right: 0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">R.O.E(<?php echo getCurrencyName($baseCurrencyId); ?>)<span class="redmind"></span></div>
						<input type="text" name="tfcurrencyValueU" id="tfcurrencyValueU" value="<?php echo trim($currencyValue); ?>" class="gridfield1" displayname="ROI Value">
					</label>
				</div>
				</td>
				<td style="padding-right: 0px;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Rep&nbsp;Cost<span class="redmind"></span></div>
						<input type="text" name="repCosttU" id="repCosttU" value="<?php echo $transferQuotData['representativeEntryFee']; ?>" class="gridfield1" displayname="Rep Cost">
						
					</label>
				</div>
				</td>
				</tr>

				<tr>
				<td style="padding-right: 0px;" class="SICClass">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Adult&nbsp;Cost<span class="redmind"></span></div>
						<input type="text" name="tfadultCostU" id="tfadultCostU" value="<?php echo $transferQuotData['adultCost']; ?>" class="gridfield1" displayname="Adult Cost" >
						
					</label>
				</div>
				</td>
	
				<td style="padding-right: 0px;" class="SICClass">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Child&nbsp;Cost<span class="redmind"></span></div>
						<input type="text" name="tfchildCostU" id="tfchildCostU" value="<?php echo $transferQuotData['childCost']; ?>" class="gridfield1" displayname="Child Cost" style="width:100px;">
						
					</label>
				</div>
				</td>
			
	
				<td style="padding-right: 0px;" class="SICClass">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Infant&nbsp;Cost</div>
						<input type="text" name="tfinfantCostU" id="tfinfantCostU" value="<?php echo $transferQuotData['infantCost']; ?>" class="gridfield1" displayname="Infant Cost" style="width:100px;">
						
					</label>
				</div>
				</td>

				<td style="padding-right: 0px;" class="PVTClass" style="display:none;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Vehicle&nbsp;Cost</div>
						<input type="text" name="vehicleCostU" id="vehicleCostU" value="<?php echo $transferQuotData['vehicleCost']; ?>" class="gridfield1" displayname="Vehicle Cost">
					
					</label>
				</div>
				</td>
				<td style="padding-right: 0px;" class="PVTClass" style="display:none;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Parking&nbsp;Fee</div>
						<input type="text" name="parkingFeeU" id="parkingFeeU" value="<?php echo $transferQuotData['parkingFee']; ?>" class="gridfield1" displayname="Parking Fee" style="width:100px;">
					
					</label>
				</div>
				</td>
				
				<td style="padding-right: 0px;" class="PVTClass" style="display:none;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Assistance&nbsp;Fee</div>
						<input type="text" name="AssistanceFeeU" id="AssistanceFeeU" value="<?php echo $transferQuotData['assistance']; ?>" class="gridfield1" displayname="Assistance Fee" style="width:100px;">
					
					</label>
				</div>
				</td>

				<td style="padding-right: 0px;" class="PVTClass" style="display:none;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Additional&nbsp;Allowance</div>
						<input type="text" name="additionalAllowanceU" id="additionalAllowanceU" value="<?php echo $transferQuotData['guideAllowance']; ?>" class="gridfield1" displayname="Additional&nbsp;Allowance" style="width:123px;">
					
					</label>
				</div>
				</td>
				<td style="padding-right: 0px;" class="PVTClass" style="display:none;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Inter&nbsp;State&nbsp;&&nbsp;Toll</div>
						<input type="text" name="interStateU" id="interStateU" value="<?php echo $transferQuotData['interStateAndToll']; ?>" class="gridfield1" displayname="Additional&nbsp;Allowance" style="width:100px;">
					
					</label>
				</div>
				</td>
				<td style="padding-right: 0px;" class="PVTClass" style="display:none;">
				<div class="griddiv"><label>
					<div class="gridlable gridlable1">Misc&nbsp;Cost</div>
						<input type="text" name="misslaneousCostU" id="misslaneousCostU" value="<?php echo $transferQuotData['miscellaneous']; ?>" class="gridfield1" displayname="Additional&nbsp;Allowance">
					
					</label>
				</div>
				</td>
				<td align="center">
				<div class="editbtnselect" id="selectthis" style="background: #233A49 !important;width:70px !important;margin-top: 5px;"  onclick="EditTrasferCostToQuotation();" >Save
				</div>
			</td>
			</tr> 
			<script>
					function selectTransferType(){
					var type = $("#sicpvtTypeU").val();
					if(type==1){
						$(".SICClass").show();
						$(".PVTClass").hide();
					}
					if(type==2){
						$(".SICClass").hide();
						$(".PVTClass").show();
					}
				}
				selectTransferType();
			</script>
	
			<input type="hidden" name="transferRateId" id="transferRateId" value="<?php echo $transferQuotData['rateId']; ?>">
			<input type="hidden" name="editId" id="editId" value="<?php echo $transferQuotData['id']; ?>">
		
		<!-- <i class="fa fa-hand-pointer-o" aria-hidden="true"></i>&nbsp; -->
	</tbody>
</table>
<div id="selectFlightCost" style="display:none;">loading...</div>
	<script>
	
		function EditTrasferCostToQuotation(){
			
			var transferNameId = $("#transferNameIdU").val();
			var ttransferDate = $("#ttransferDateU").val();
			var destinationId = $("#TransferDestionationU").val();
			var transferType = $("#transferTypeU").val();
			var sicpvtType = $("#sicpvtTypeU").val();
			var vehicleTypeId = $("#vehicleTypeIdU").val();
			var repCostt = $("#repCosttU").val();
			var adultCost = $("#tfadultCostU").val();
			var childCost = $("#tfchildCostU").val();
			var infantCost = $("#tfinfantCostU").val();
			var vehicleCost = $("#vehicleCostU").val();
			var parkingFee = $("#parkingFeeU").val();
			var AssistanceFee = $("#AssistanceFeeU").val();
			var additionalAllowance = $("#additionalAllowanceU").val();
			var interState = $("#interStateU").val();
			var misslaneousCost = $("#misslaneousCostU").val();
			var adultPax = $("#FadultPaxU").val();
			var childPax = $("#FchildPaxU").val();
			var infantPax = $("#FinfantPaxU").val();
			var tfcurrencyId = $("#tfcurrencyIdU").val();
			var currencyValue132 = $("#tcurrencyValue132U").val();
			var tfcurrencyValue = $("#tfcurrencyValueU").val();
	
			if(transferNameId>0){
	
			$("#selectTraincost").load('loadValueAddedserviceCost.php?action=saveTransferCosttoQuotation&transferNameId='+transferNameId+'&transferType='+transferType+'&sicpvtType='+encodeURI(sicpvtType)+'&adultCost='+adultCost+'&childCost='+childCost+'&infantCost='+infantCost+'&adultPax='+adultPax+'&childPax='+childPax+'&infantPax='+infantPax+'&currencyId='+tfcurrencyId+'&currencyValue='+currencyValue132+'&quotationId=<?php echo $quotationId; ?>&queryId=<?php echo $_REQUEST['queryId']; ?>&ttransferDate='+encodeURI(ttransferDate)+'&destinationId='+encodeURI(destinationId)+'&vehicleTypeId='+vehicleTypeId+'&repCost='+repCostt+'&vehicleCost='+vehicleCost+'&parkingFee='+parkingFee+'&AssistanceFee='+AssistanceFee+'&additionalAllowance='+additionalAllowance+'&interState='+interState+'&misslaneousCost='+misslaneousCost+'&editId=<?php echo $transferQuotData['id']; ?>');
			}else{
				alert('Please, Select Transfer Name');
			}
	}
	</script>
	</div>
	</div>

<?php
}



if($_REQUEST['action'] == 'deletePassQuotationRate' && $_REQUEST['quoteRateId']!='' && $_REQUEST['quotationId']!='' ){
	deleteRecord('quotationPassportRateMaster','id = "'.$_REQUEST['quoteRateId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['quoteRateId'].'" and serviceType="passport" and quotationId="'.$_REQUEST['quotationId'].'"');
   ?>
   <script>
	   warningalert('Passport Rate Deleted!');
	//    loadquotationmainfile();
	//    needValueAddedServices('passportRequirementAct');
	   window.location.reload();
   </script>
   <?php
}


if($_REQUEST['action'] == 'deleteVisaQuotationRate' && $_REQUEST['quoteRateId']!='' && $_REQUEST['quotationId']!='' ){
	deleteRecord('quotationVisaRateMaster','id = "'.$_REQUEST['quoteRateId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
	deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['quoteRateId'].'" and serviceType="visa" and quotationId="'.$_REQUEST['quotationId'].'"');
   ?>
   <script>
	   warningalert('Visa Rate Deleted!');
	//    loadquotationmainfile();
	//    needValueAddedServices('visaRequirementAct');
	   window.location.reload();
   </script>
   <?php
}


if($_REQUEST['action'] == 'deleteInsuranceQuotationRate' && $_REQUEST['quoteRateId']!='' && $_REQUEST['quotationId']!='' ){
	deleteRecord('quotationInsuranceRateMaster','id = "'.$_REQUEST['quoteRateId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
   deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['quoteRateId'].'" and serviceType="insurance" and quotationId="'.$_REQUEST['quotationId'].'"');
   ?>
   <script>
	   warningalert('Insurance Rate Deleted!');
	//    loadquotationmainfile();
	//    needValueAddedServices('insuranceRequirementAct');
	window.location.reload();
   </script>
   <?php
}

if($_REQUEST['action'] == 'deleteFlightQuotationRate' && $_REQUEST['quoteRateId']!='' && $_REQUEST['quotationId']!='' ){
	deleteRecord('quotationFlightMaster','id = "'.$_REQUEST['quoteRateId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
   deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['quoteRateId'].'" and serviceType="flight" and quotationId="'.$_REQUEST['quotationId'].'"');
   ?>
   <script>
	   warningalert('Flight Rate Deleted!');
	//    loadquotationmainfile();
	//    needValueAddedServices('insuranceRequirementAct');
	window.location.reload();
   </script>
   <?php
}

if($_REQUEST['action'] == 'deleteTrainQuotationRate' && $_REQUEST['quoteRateId']!='' && $_REQUEST['quotationId']!='' ){
	deleteRecord('quotationTrainsMaster','id = "'.$_REQUEST['quoteRateId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
   deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['quoteRateId'].'" and serviceType="train" and quotationId="'.$_REQUEST['quotationId'].'"');
   ?>
   <script>
	   warningalert('Train Rate Deleted!');
	//    loadquotationmainfile();
	//    needValueAddedServices('insuranceRequirementAct');
	window.location.reload();
   </script>
   <?php
}

if($_REQUEST['action'] == 'deleteTransferQuotationRate' && $_REQUEST['quoteRateId']!='' && $_REQUEST['quotationId']!='' ){
	deleteRecord('quotationTransferMaster','id = "'.$_REQUEST['quoteRateId'].'" and quotationId="'.$_REQUEST['quotationId'].'"');
   deleteRecord('quotationItinerary','serviceId="'.$_REQUEST['quoteRateId'].'" and serviceType="transfer" and quotationId="'.$_REQUEST['quotationId'].'"');
   ?>
   <script>
	   warningalert('Transfer Rate Deleted!');
	//    loadquotationmainfile();
	//    needValueAddedServices('insuranceRequirementAct');
	window.location.reload();
   </script>
   <?php
}


if($_REQUEST['serviceId']=='' && $_REQUEST['action']!='' ){ ?>
<style>
.gridtable td {
    padding: 0px 2px;
}
.addeditpagebox .griddiv {
    margin-bottom: 10px;
}
.editbtnselect {
    border: 1px solid;
    text-align: center;
    font-size: 13px;
    border-radius: 3px;
    background-color: #4caf50;
    cursor: pointer;
    color: #fff;
    width: fit-content !important;
    padding: 8px !important;
}
.griddiv{font-size:12px; text-transform:uppercase; color:#999999;}
.addeditpagebox .griddiv .gridlable {
    width: 100% !important;
}
.editbtnselect, .addBtn1{
	border: 1px solid;
	padding: 8px 15px;
	text-align: center;
	font-size: 13px;
	border-radius: 3px;
	background-color: #4caf50;
	cursor: pointer;
	color: #fff;
}
.addBtn1{
	width: fit-content !important;
	position: absolute;
	right: 30px;
	top: 2px;
	padding: 8px 12px !important;
	background-color: #7a96ff;
}
.guideselect{
	padding: 5px 10px;
    border-radius: 3px;
    width: 96%;
}
.guideformbox{
	/*position: absolute;
    top: -34px;
    width: 30%;
    right: 54px;
	*/
	position: absolute;
    top: -50px;
    left: 10px;
    width: 30%;
    right: auto;
}
</style>


<?php }



?>
