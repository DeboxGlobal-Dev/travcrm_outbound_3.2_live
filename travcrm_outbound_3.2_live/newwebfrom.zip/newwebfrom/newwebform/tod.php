<script>
$('#balitourid').val('<?php echo $_REQUEST['queryId'];.'R'; ?>');
</script>